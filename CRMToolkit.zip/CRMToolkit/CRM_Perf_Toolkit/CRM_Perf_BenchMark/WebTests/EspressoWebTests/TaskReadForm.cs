﻿namespace CRM_Perf_BenchMark
{
	public class me_TaskReadForm : me_ReadForm
	{
		public me_TaskReadForm()
			: base(EntityNames.Tasks)
		{

		}
	}
}
