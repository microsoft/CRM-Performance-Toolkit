﻿using System;
using System.Data.SqlTypes;
using System.Globalization;
using System.Net;
using Microsoft.Crm;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages.Internal;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using ServiceCreator;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// The test class for SDK request that happen as a part of normal state manager operation
	/// </summary>
	[TestClass]
	public sealed class StateManagerTest : UnitTestBase
	{
		#region Individual Test Cases

		/// <summary>
		/// WhoAmI request that happens as a part of state manager operations to check if client is still connected to the server
		/// </summary>
		[TestMethod]
		public void WhoAmIRequestRichClient()
		{
			IOrganizationService organizationService = serviceCreator.OrganizationService;
			WhoAmIRequest request = new WhoAmIRequest();
			organizationService.Execute(request);
		}

		/// <summary>
		/// Checks client compatibility, currently occurs during every iteration of state manager
		/// </summary>
		/// <remarks>
		/// Return results:
		/// -1  Client Version is lower
		/// 0  Client Version is compatible with server
		/// 1  Client Version is higher
		/// </remarks>
		[TestMethod]
		public void CheckClientCompatibility()
		{
			IOrganizationService organizationService = serviceCreator.OrganizationService;
			CheckClientCompatibilityRequest request = new CheckClientCompatibilityRequest();
			request.CrmClientVersion = "5.0.9688.583"; // version doesn't matter as long as it's in valid format
			organizationService.Execute(request);
		}

		#endregion
	}
}
