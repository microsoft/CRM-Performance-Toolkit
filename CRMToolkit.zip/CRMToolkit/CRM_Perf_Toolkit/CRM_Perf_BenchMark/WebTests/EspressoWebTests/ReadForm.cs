﻿
namespace CRM_Perf_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using Espresso;

	/// <summary>
	/// 1. Go to sitemap
	/// 2. Go to random grid
	/// 3. Go to read random entity
	/// </summary>

	public abstract class me_ReadForm : EspressoPageTestBase
	{
		private readonly string _logicalName;

		public me_ReadForm(string logicalName)
			: base()
		{
			this._logicalName = logicalName;
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			ME_EntityHelper meeh = MobileExpressHelper.Instance.GetHomepageEntity(_logicalName.ToLowerInvariant());
			CRMEntity entity = RetrieveTestEntity(user, _logicalName);

			this.BeginTransaction(EspressoTransactionNames.HomePage);
			_m_default_aspx hp = new _m_default_aspx(user);
			yield return (hp);
			this.EndTransaction(EspressoTransactionNames.HomePage);

			this.BeginTransaction(EspressoTransactionNames.EntityGrid);
			string referer = hp.lastResponse.ResponseUri.ToString();
			WebTestRequestHeader header = new WebTestRequestHeader();
			header.Name = "referer";
			header.Value = referer;
			_m_eh_aspx eh = new _m_eh_aspx(user);
			eh.Headers.Add(header);
			eh.etn = meeh.logicalName;
			yield return (eh);
			this.EndTransaction(EspressoTransactionNames.EntityGrid);

			string recordIdString = MobileExpressHelper.Instance.GetEntityId(this._logicalName, entity);
			Guid recordId = Guid.Parse(recordIdString);

			this.BeginTransaction(String.Format(EspressoTransactionNames.EntityReadPage, _logicalName));
			_m_ef_aspx forms = new _m_ef_aspx(user)
			{
				Etn = meeh.logicalName,
				Id = recordId
			};
			forms.Headers.Add(new WebTestRequestHeader("referer", eh.lastResponse.ResponseUri.ToString()));
			yield return forms;
			this.EndTransaction(String.Format(EspressoTransactionNames.EntityReadPage, _logicalName));
		}
	}
}
