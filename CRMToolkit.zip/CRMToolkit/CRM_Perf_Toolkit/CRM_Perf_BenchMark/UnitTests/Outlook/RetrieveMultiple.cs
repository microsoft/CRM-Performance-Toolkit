﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Extensibility;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Types;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Test class for executing RetrieveMultiple SDK calls
	/// </summary>
	[TestClass]
	public class RetrieveMultiple : OutlookTestBaseClass
	{
		#region Individual Test Cases

		/// <summary>
		/// Execute RetrieveMultiple SDK requests
		/// </summary>
		/// <remarks>Makes following SDK calls: RetrieveMultiple</remarks>
		[TestMethod]
		public void RetrieveMultipleEmail()
		{
			RetrieveMultipleHelper(EntityName.email.ToString());
		}

		/// <summary>
		/// Execute RetrieveMultiple SDK requests
		/// </summary>
		/// <remarks>Makes following SDK calls: RetrieveMultiple</remarks>
		[TestMethod]
		public void RetrieveMultipleAccount()
		{
			RetrieveMultipleHelper(EntityName.account.ToString());
		}

		#endregion

		#region Private Methods

		private void RetrieveMultipleHelper(string entityName)
		{
			QueryExpression query = new QueryExpression()
			{
				Distinct = false,
				EntityName = entityName,
				PageInfo = new PagingInfo()
				{
					Count = 5000,
					PageNumber = 1
				}
			};
			IOrganizationService organizationService = serviceCreator.OrganizationService;
			EntityCollection collection = organizationService.RetrieveMultiple(query);
		}

		#endregion
	}
}
