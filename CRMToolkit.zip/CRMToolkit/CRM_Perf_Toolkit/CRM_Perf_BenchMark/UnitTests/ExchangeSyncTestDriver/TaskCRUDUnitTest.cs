﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting task entity
	/// </summary>
	[TestClass]
	public class TaskCRUDExSyncUnitTest : CreateBasicEntityBaseTest
	{
		public override string EntityName
		{
			get { return EntityNames.Tasks; }
		}

		public override string PrintEntityData(Entity entity)
		{
			return String.Format("{0} subject={1}", EntityName, entity["subject"].ToString());
		}


		public override void CreateEntity(string name)
		{
			string timerName = "Task Create Unit Test";

			Entity task = new Entity("task");
			task["subject"] = Utils.GetRandomString(5, 20) + " " + name;
			Guid taskId = this.CreateEntityInCRM(task, timerName);

			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Tasks, g,new string[] {"OwnerId", "ActivityID", "EntityManagerOwningUser", "Subject"},new string[]{m_user["systemuserid"], taskId.ToString(), g.ToString(),task["subject"].ToString()});
		}

		/// <summary>
		/// Test creating an task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_TaskExchangeSync()
		{
			this.Init();
			//create a task
			this.CreateEntity(this.DeleteIdentifier);
		}

		//test retrieving and updating an task
		[TestMethod()]
		public void UnitTest__Update_TaskExchangeSync()
		{
			string timer = "Task Update Unit Test";
			Entity task = new Entity("task");
			//find a CRM Entity for update test
			Init("subject", this.UpdateIdentifier);
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes =
				new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] {"subject", "description"});
			//get the task in CRM
			task = proxy.Retrieve(task.LogicalName, new Guid(m_contact["ActivityId"]), attributes);
			//update task subject value
			task["description"] = Utils.GetRandomString(10, 20);
			//update the task
			this.UpdateEntityInCRM(task, timer);
		}

		//test deleting a task
		[TestMethod()]
		public void UnitTest__Delete_TaskExchangeSync()
		{
			Entity task = new Entity("task");
			//find a CRM Entity for update test
			if (!Init("subject", this.DeleteIdentifier))
			{
				DeleteEntityInCRM("activityid", task, " Delete Task Entity");
			}
			else
			{
				Trace.WriteLine(" Couldn't Find a Task to Delete so Created one");
			}
		}
	}
}
