﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class RetrieveMultipleCaseUnitTest : UnitTestBase
	{
		#region Retreive multiple cases
		/// <summary>
		/// Retrieve multiple cases
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_Case()
		{
			CRMEntity m_incident = RetrieveTestEntity(m_user, EntityNames.Incidents);
			Entity incident = new Entity("incident");
			QueryExpression query = new QueryExpression("incident");
			query.ColumnSet.AddColumn("incidentid");
			query.ColumnSet.AddColumn("title");
			query.Criteria.AddCondition("customerid", ConditionOperator.Equal, new Guid(m_incident["CustomerId"]));
			EntityCollection results;

			TestContext.BeginTimer("Case RetrieveMultiple UnitTest");
			try
			{
				results = Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Case RetrieveMultiple UnitTest");
		}
		#endregion
	}
}
