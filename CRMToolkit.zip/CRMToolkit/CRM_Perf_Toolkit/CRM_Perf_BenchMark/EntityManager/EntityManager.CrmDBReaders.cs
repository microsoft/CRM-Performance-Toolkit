﻿using System;
using System.Collections;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Reflection;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Metadata;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using System.Linq;
using System.Collections.Generic;

namespace CRM_Perf_BenchMark
{

	internal delegate void SyncCRMDataDelegate(MultipleServersData serverData, Guid organizationId);
	public partial class EntityManager
	{

		private static uint MaxRecordsPerEntityToRead
		{
			get
			{
				return EntityManager.Context.ContainsKey("MaxRecordsPerEntity") ? uint.Parse(EntityManager.Context["MaxRecordsPerEntity"]) : Int32.MaxValue;
			}
		}

		/// <summary>
		/// Overloaded ReadEntityFromTable. Assumes no optional WHERE filter is needed.
		/// </summary>
		/// <param name="EntityName">Name of entity to read. This MUST correspond to the SQL table name for the entity.</param>
		/// <param name="Props">String array of properties to read, i.e. {"OwnerID", "CreatedBy"} etc.
		///                     Prop[0] MUST be the owerID for the entity.
		///                     Prop[1] MUST be the primary key for the entity.
		///                     Additional properties optional.</param>
		/// <param name="UserOwned">Is the entityType owned by a ORG or a user.</param>
		/// <returns>Count of read entities.</returns>
		private static uint ReadEntityFromTable(MultipleServersData serverData, string EntityName, string[] Props, Guid orgId)
		{
			return ReadEntityFromTable(serverData, EntityName, Props, null, null, null, orgId);
		}

		private static uint ReadEntityFromTable(MultipleServersData serverData, string EntityName, string[] Props, FilterExpression where, Guid orgId)
		{
			return ReadEntityFromTable(serverData, EntityName, Props, where, null, null, orgId);
		}


		/// <summary>
		/// Primary ReadEntityFromTable.
		/// </summary>
		/// <param name="EntityName">Name of entity to read. This MUST correspond to the SQL table name for the entity.</param>
		/// <param name="Props">String array of properties to read, i.e. {"OwnerID", "CreatedBy"} etc.
		///     Prop[0] MUST be the owerID for the entity.
		///     Prop[1] MUST be the primary key for the entity.
		///     Additional properties optional.</param>
		/// <param name="WHERE">WHERE clause added to end of query to filter. "WHERE" keyword provided by caller.</param>
		/// <param name="strORDERBY"></param>
		/// <param name="topClause"></param>
		/// <param name="UserOwned">Is the entityType owned by a ORG or a user.</param>
		/// <returns>Count of read entities.</returns>
		private static uint ReadEntityFromTable(MultipleServersData serverData, string EntityName, string[] Props, FilterExpression Where, string strORDERBY, int? topRows, Guid orgId, string inEntityName = "", CommonTypes.EntityType entityType = CommonTypes.EntityType.Normal)
		{
			if (serverData == null)
			{
				return CommonTypes.EntityReader.ReadEntityFromTable(adminUserProxy, ConfigSettings.Default.EMSQLCNN, EntityName, Props, Where, strORDERBY, topRows, orgId, m_Owners, inEntityName, entityType);
			}
			else
			{
				IOrganizationService service = GetAdminUserProxy(serverData);
				return CommonTypes.EntityReader.ReadEntityFromTable(service, ConfigSettings.Default.EMSQLCNN, EntityName, Props, Where, strORDERBY, topRows, orgId, m_Owners, inEntityName, entityType);
			}
		}

		private static void LoadEntityMatadata()
		{
			RetrieveAllEntitiesRequest request = new RetrieveAllEntitiesRequest();
			RetrieveAllEntitiesResponse response = (RetrieveAllEntitiesResponse)adminUserProxy.Execute(request);
			m_EntityMatadatas = ((EntityMetadata[])response.Results["EntityMetadata"]).ToList();
		}

		/// <summary>
		/// Reads all defined incidents.
		/// </summary>
		private static void ReadIncidents(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { "OwnerID", "IncidentID", "Title", "CustomerID", "CustomerIdName", "StateCode", "PriorityCode" };
			string Table = EntityNames.Incidents;

			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, Table, Fields, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Incidents");
		}

		private static void ReadNotes(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { "OwnerID", "AnnotationID", "ObjectID", "ObjectTypeCode" };
			string Table = EntityNames.Notes;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, Table, Fields, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Notes");

		}

		private static void ReadLeads(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Lead, "FirstName", "LastName" };
			string EntityName = EntityNames.Leads;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Leads");
		}

		private static void ReadCampaigns(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Campaign };
			string EntityName = EntityNames.Campaigns;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Campaigns");

		}

		/// <summary>
		/// Reads all defined Quotes.
		/// </summary>
		private static void ReadQuotes(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerID", EntityIDNames.Quote, "Name", "CustomerId", "CustomerIdName", "CustomerIdType" };
			string EntityName = EntityNames.Quotes;

			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = new FilterExpression();
				where.AddCondition("statecode", ConditionOperator.In, 0, 2);
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Quotes");
		}

		/// <summary>
		/// Reads all defined SalesOrder.
		/// </summary>
		private static void ReadSalesOrders(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerID", EntityIDNames.SalesOrders, "Name", "CustomerId", "CustomerIdName", "CustomerIdType" };
			string EntityName = EntityNames.SalesOrders;

			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = new FilterExpression();
				where.AddCondition("statecode", ConditionOperator.Equal, 0);
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " SalesOrders");
		}

		/// <summary>
		/// Reads all defined opportunities.
		/// </summary>
		private static void ReadOpportunities(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Opportunities, "name" };
			string EntityName = EntityNames.Opportunities;

			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = new FilterExpression();
				where.AddCondition("statecode", ConditionOperator.Equal, 0);
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Opportunities");
		}

		/// <summary>
		/// Reads all defined accounts
		/// </summary>
		private static void ReadAccounts(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Account, "name", "ParentAccountId" };
			string EntityName = EntityNames.Accounts;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Accounts");
		}

		/// <summary>
		/// Reads Uii_hostedapplication data.
		/// </summary>
		private static void ReadUII_hostedapplication(Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.HostedApplication, "uii_name" };
			string EntityName = EntityNames.HostedApplication;
			FilterExpression where = null;
			where = CreateQueryForUserSubset(where);

			Trace.WriteLine("Read " + ReadEntityFromTable(null, EntityName, Props, where, orgId) + "HostedApplication");
		}


		/// <summary>
		/// Reads all contacts
		/// </summary>
		private static void ReadContacts(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Contact, "lastname" };
			string EntityName = EntityNames.Contacts;

			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Contacts");
		}

		/// <summary>
		/// Reads all defined tasks
		/// </summary>
		private static void ReadTasks(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Task, "subject" };
			string EntityName = EntityNames.Tasks;

			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = new FilterExpression();
				where.AddCondition("statecode", ConditionOperator.Equal, 0);

				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Tasks");
		}

		/// <summary>
		/// Reads all defined appointments
		/// </summary>
		private static void ReadAppointments(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Appointment, "subject", "instancetypecode" };
			string EntityName = EntityNames.Appointments;

			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Appointments");
		}

		private static void ReadExchangeTask(Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.ExchangeTask, "Subject" };
			String EntityName = EntityNames.ExchangeTask;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(null, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " ExchangeTask");
		}

		/// <summary>
		/// Reads all defined emails
		/// </summary>
		private static void ReadEmails(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Email };
			string EntityName = EntityNames.Emails;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Emails");
		}

		/// <summary>
		/// Reads all defined letters
		/// </summary>
		private static void ReadLetters(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Letter, "Subject" };
			string EntityName = EntityNames.Letters;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Letter");
		}

		/// <summary>
		/// Reads all defined phonecalls
		/// </summary>
		private static void ReadPhonecalls(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Phonecall, "Subject", "RegardingObjectTypeCode" };
			string EntityName = EntityNames.Phonecalls;

			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Phonecalls");
		}

		/// <summary>
		/// Reads all defined faxes
		/// </summary>
		private static void ReadFaxes(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Fax };
			string EntityName = EntityNames.Faxes;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Faxes");

		}


		/// <summary>
		/// Reads all defined faxes
		/// </summary>
		private static void ReadGoals(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Goal, "title", "goalownerid", "metricid", "OwningBusinessUnit", "ParentGoalId" };
			string EntityName = EntityNames.Goals;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Goal");
		}



		/// <summary>
		/// Reads all defined lists
		/// </summary>
		private static void ReadLists(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.List };
			string EntityName = EntityNames.Lists;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Lists");
		}

		/// <summary>
		/// Reads all defined lists
		/// </summary>
		private static void ReadServiceAppointments(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.ServiceAppointment, "Subject" };
			string EntityName = EntityNames.ServiceAppointments;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " ServiceAppointments");
		}


		private static void ReadRecurringAppointments(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.RecurringAppointmentMaster, "subject", "recurrencepatterntype" };
			string EntityName = EntityNames.RecurringAppointments;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " RecurringAppointments");
		}

		private static void ReadWorkflows(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.Workflow, "Name", "PrimaryEntity", "Type", "IsCrmUIWorkflow", "ActiveWorkflowId", "ParentWorkflowId" };
			string EntityName = EntityNames.Workflow;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(serverData, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " Workflow");
		}

		private static void ReadOrgs(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { null, EntityIDNames.Organization, "FeatureSet" };

			double NumOrgs = ReadEntityFromTable(null, EntityNames.Organizations, Props, orgId);

			if (1 != NumOrgs)
				throw new Exception(NumOrgs + " Were read from SQL. The number is not 1.");

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = m_EMSQLCon;
			cmd.CommandText = string.Format("UPDATE {0} SET ServerBaseUrl=@ServerBaseUrl where {1} =  @orgId",
				EntityNames.Organizations, EntityIDNames.Organization);
			cmd.Parameters.AddWithValue("ServerBaseUrl", serverData.ServerBaseUrl);
			cmd.Parameters.AddWithValue("orgId", orgId);
			Trace.WriteLine("Issuing SQL Command to set default password " + cmd.CommandText);
			cmd.ExecuteNonQuery();

			//Need to enter the org as a owner in our global table.
			string SqlCommand = string.Format("SELECT {0}, {1} FROM {2} where {3} = @orgId", EntityIDNames.Organization,
				EntityManagerID, EntityNames.Organizations, EntityIDNames.Organization);
			SqlCommand getOrg = new SqlCommand(SqlCommand, m_EMSQLCon);
			getOrg.Parameters.AddWithValue("orgId", orgId);
			SqlDataReader reader = getOrg.ExecuteReader();
			try
			{
				while (reader.Read())
				{
					Hashtable Owner = new Hashtable();

					Owner.Add(EntityManagerID, System.Int64.Parse(reader[EntityManagerID].ToString()));
					if (m_Owners.ContainsKey(reader.GetGuid(0)))
					{
						continue;
					}

					m_Owners.Add(reader.GetGuid(0), Owner);
				}
			}
			finally
			{
				reader.Close();
			}
		}

		// Read custom entity Prospect and custom activity IM
		private static void ReadNew_IMs(Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.New_IM, "subject" };
			string EntityName = EntityNames.New_IM;
			FilterExpression where = null;
			where = CreateQueryForUserSubset(where);

			Trace.WriteLine("Read " + ReadEntityFromTable(null, EntityName, Props, where, orgId) + " new_ims");
		}

		//Read new_customAccounts for rollup fields
		private static void ReadNew_CustomAccounts(Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.New_CustomAccount, "new_name", "new_parentid" };
			string EntityName = EntityNames.New_CustomAccount;
			for (int level = 1; level <= 100; level++)
			{
				FilterExpression where;
				//retrieve 30% deletable entities
				if (level <= 30)
					where = CreateQueryForCustomAccount(level, true);
				else
					where = CreateQueryForCustomAccount(level, false);
				Trace.WriteLine("Read " + ReadEntityFromTable(null, EntityName, Props, where, "OwnerId", 500, orgId) + " new_CustomAccounts");
			}
		}

		//Read new_customopportunities for rollup fields
		private static void ReadNew_CustomOpportunities(Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.New_CustomOpportunity, "new_name" };
			string EntityName = EntityNames.New_CustomOpportunity;

			FilterExpression where = null;
			Trace.WriteLine("Read " + ReadEntityFromTable(null, EntityName, Props, where, "OwnerId", 10000, orgId) + " new_CustomOpportunity");

			//retrieve 10K deletable opportunities
			where = new FilterExpression();
			where.AddCondition("new_name", ConditionOperator.Like, "%deletable%");
			Trace.WriteLine("Read " + ReadEntityFromTable(null, EntityName, Props, where, "OwnerId", 10000, orgId) + " new_CustomOpportunity");
		}

		private static void ReadNew_Prospects(Guid orgId)
		{
			string[] Props = { "OwnerId", EntityIDNames.New_Prospect, "new_name" };
			string EntityName = EntityNames.New_Prospect;
			uint totalCount = 0;
			foreach (string userid in m_UserSubSet)
			{
				FilterExpression where = null;
				FilterExpression where1 = CreateQueryForUserSubsetChunk(where, new Guid[] { new Guid(userid) });
				uint count = ReadEntityFromTable(null, EntityName, Props, where1, orgId);
				Trace.WriteLine("Read: owner:" + userid + " return: " + count + " records");
				totalCount += count;
			}

			Trace.WriteLine("Read " + totalCount + " New_Prospect");
		}


		private static void ReadSetupUser(MultipleServersData serverData, Guid orgId)
		{
			if (serverData.userBase == null)
				return;
			//Need to alter the systemuser table to set our default password.

			string[] Props = { EntityIDNames.Organization, EntityIDNames.User, "DomainName", "BusinessUnitId", "SetupUser" };
			string EntityName = EntityNames.Users;
			FilterExpression where = new FilterExpression();
			where.AddCondition("isdisabled", ConditionOperator.Equal, true);
			where.AddCondition("setupuser", ConditionOperator.Equal, false);
			where.AddCondition("fullname", ConditionOperator.Equal, "SYSTEM");
			//use default system admin user
			Trace.WriteLine("Read: " + ReadEntityFromTable(null, EntityName, Props, where, EntityIDNames.User, null, orgId, "SetupUser") + " Users");
		}

		private static FilterExpression GetUserFilter(MultipleServersData serverData)
		{
			FilterExpression where = new FilterExpression();
			where.FilterOperator = LogicalOperator.Or;

			// This is the main query
			string userNameBase = serverData.userBase;
			int userStart = int.Parse(serverData.userStart);
			int userCount = int.Parse(serverData.userCount);
			int userEnd = userStart + userCount - 1;

			// Create user list for user in range(like crmusr1 to crmusr320)
			List<string> m_FilterUserSet = new List<string>();
			QueryExpression query;
			ConditionExpression isDomainNameCondition = new ConditionExpression("domainname", ConditionOperator.Like, "%administrator%");

			EntityCollection results = null;
			try
			{
				query = new QueryExpression();
				query.EntityName = "systemuser";
				string[] Props = { "systemuserid", "domainname" };

				bool getmorerows = true;
				query = CommonTypes.EntityReader.BuildQueryExpression(CommonTypes.EntityType.Normal, query.EntityName.ToString(), Props, where, null);

				while (getmorerows)
				{
					results = adminUserProxy.RetrieveMultiple(query);
					query.PageInfo.PageNumber++;
					query.PageInfo.PagingCookie = results.PagingCookie;
					getmorerows = results.MoreRecords;

					for (int k = 0; k < results.Entities.Count; k++)
					{
						Entity en = results[k];
						string domainName = en.Attributes["domainname"].ToString();

						if (domainName.IndexOf(userNameBase, StringComparison.InvariantCultureIgnoreCase) >= 0)
						{
							var temp = domainName.Split('@');
							domainName = temp[0];
							int count = Int32.Parse(domainName.Substring(domainName.IndexOf(userNameBase, StringComparison.InvariantCultureIgnoreCase) + userNameBase.Length, domainName.Length - (domainName.IndexOf(userNameBase, StringComparison.InvariantCultureIgnoreCase) + userNameBase.Length)));
							if (count >= userStart && count <= userEnd)
							{
								m_FilterUserSet.Add(en.Attributes["systemuserid"].ToString());
							}
						}
					}
				}
			}
			catch (System.Exception e)
			{
				Trace.WriteLine("Exception:\n" + e.ToString());
				throw;
			}

			ConditionExpression userFilterCondition = new ConditionExpression("systemuserid", ConditionOperator.In, m_FilterUserSet.ToArray());
			where.AddCondition(userFilterCondition);
			where.AddCondition(isDomainNameCondition);
			return where;
		}

		private static void ReadUsers(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { "OrganizationId", "SystemUserId", "DomainName", "BusinessUnitId", "SetupUser", "InternalEmailAddress", "BusinessUnitIdName" };
#if (ARA)
			Array.Resize(ref Props, Props.Length + 1);
			Props[Props.Length - 1] = "MobileOfflineProfileId";
#endif
			var userFilter = GetUserFilter(serverData);
			var usersRead = ReadEntityFromTable(null, "SystemUser", Props, userFilter, EntityIDNames.User, null, orgId);
			Trace.WriteLine(string.Format("Read: {0} users", usersRead));
			if (usersRead == 0)
			{
				throw new Exception("Failed to read CRM users to EMDB");
			}

			string cmdText = string.Format("UPDATE SystemUser SET ServerBaseUrl='{0}', OrganizationBaseUrl='{1}', OrganizationServiceUrl='{2}', 			DiscoveryServer='{3}',  UserPassword='{4}',  OrganizationName='{5}' "
			, serverData.ServerBaseUrl, serverData.OrganizationBaseUrl, serverData.OrganizationServiceUrl, serverData.DiscoveryServer,serverData.userPassword, serverData.OrgName);
#if (ARA)
			cmdText += " , IsUserConfiguredForMobileOffline = CASE WHEN [MobileOfflineProfileId] IS NOT NULL THEN 1 ELSE 0 END ";
#endif
			cmdText += string.Format(" where {0} = '{1}'", EntityIDNames.Organization, orgId);
			SqlCommand cmd = new SqlCommand(cmdText, m_EMSQLCon);
			cmd.Parameters.AddWithValue("serverBaseUrl", serverData.ServerBaseUrl);
			cmd.Parameters.AddWithValue("organizationBaseUrl", serverData.OrganizationBaseUrl);
			cmd.Parameters.AddWithValue("organizationServiceUrl", serverData.OrganizationServiceUrl);
			cmd.Parameters.AddWithValue("discoveryServer", serverData.DiscoveryServer);
			cmd.Parameters.AddWithValue("userPassword", serverData.userPassword);
			cmd.Parameters.AddWithValue("OrganizationName", serverData.OrgName);
			cmd.Parameters.AddWithValue("orgId", orgId);
			Trace.WriteLine(string.Format("Issuing SQL Command to set ServerBaseUrl, DiscoveryServer, UserPassword, OrganizationName. SQL command = ", cmd.CommandText));
			cmd.ExecuteNonQuery();

			var userManager = GetUserManager();
			userManager.RefreshAllAuthTokens(serverData.userStart, serverData.userCount, serverData.userBase, serverData.userDomain, serverData.userPassword, serverData.OrgName, serverData.OrganizationBaseUrl);

			//Need to add the users as owners and set the org as a owner in our global tables
			cmdText = string.Format("SELECT SystemUserId, {0} from SystemUser {1} where {1} = @orgId", EntityManagerID, EntityIDNames.Organization);
			SqlCommand getOrg = new SqlCommand(cmdText, m_EMSQLCon);
			getOrg.Parameters.AddWithValue("orgId", orgId);
			using (SqlDataReader reader = getOrg.ExecuteReader())
			{
				while (reader.Read())
				{
					Hashtable owner = new Hashtable();
					owner.Add(EntityManagerID, System.Int64.Parse(reader[EntityManagerID].ToString()));
					//get a new user guid from user id and org id
					Guid g = GetOwnerGuid(reader.GetGuid(0), orgId);
					m_Owners.Add(g, owner);
				}
			}

		}


		private static void ReadPriceLevels(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { EntityIDNames.Organization, EntityIDNames.PriceLevel, "Name" };
			string EntityName = EntityNames.PriceLevels;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, EntityName, Props, orgId) + " PriceLevels");
		}
		private static void ReadProductPriceLevels(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { EntityIDNames.Organization, EntityIDNames.ProductPriceLevels, EntityIDNames.Products };
			string EntityName = EntityNames.ProductPriceLevels;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, EntityName, Props, orgId) + " ProductPriceLevels");
		}
		private static void ReadResource(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { EntityIDNames.Organization, EntityIDNames.Resource };
			string EntityName = EntityNames.Resource;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, EntityName, Props, orgId) + " Resource");
		}
		private static void ReadProducts(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, EntityIDNames.Products, EntityIDNames.TransactionCurrency, "Name" };
			string Table = EntityNames.Products;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, Table, Fields, orgId) + " Products");
		}
		private static void ReadSubjects(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { EntityIDNames.Organization, EntityIDNames.Subject, "Title" };
			string EntityName = EntityNames.Subject;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, EntityName, Props, orgId) + " Subjects");
		}

		private static void ReadConnectionRoles(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { EntityIDNames.Organization, EntityIDNames.ConnectionRole, "Category", "Name" };
			string EntityName = EntityNames.ConnectionRole;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, EntityName, Props, orgId) + " ConnectionRoles");
		}

		private static void ReadServices(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { EntityIDNames.Organization, EntityIDNames.Service, "Name" };
			string EntityName = EntityNames.Service;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, EntityName, Props, orgId) + " Services");
		}

		private static void ReadQueues(MultipleServersData serverData, Guid orgId)
		{
			string[] Props = { EntityIDNames.Organization, EntityIDNames.Queue, "Name", "OwningBusinessUnit" };
			string EntityName = EntityNames.Queue;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, EntityName, Props, orgId) + " Queues");
		}

		private static void ReadBUs(Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, EntityIDNames.BusinessUnit, "Name", "ParentBusinessUnitId" };
			string Table = EntityNames.BusinessUnits;

			Trace.WriteLine("Read " + ReadEntityFromTable(null, Table, Fields, orgId) + " BusinessUnits");
		}

		private static void ReadRoles(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, EntityIDNames.Role, "Name" };
			string Table = EntityNames.Roles;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, Table, Fields, orgId) + " Roles");
		}
		private static void ReadEquipment(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, EntityIDNames.Equipment, "Name" };
			string Table = EntityNames.Equipment;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, Table, Fields, orgId) + " Equipment");
		}

		private static void ReadTeams(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, EntityIDNames.Team, EntityIDNames.BusinessUnit, "Name", "IsDefault" };
			string Table = EntityNames.Team;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, Table, Fields, orgId) + " Team");
		}

		private static void ReadSavedQueryVisualizations(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, EntityIDNames.SavedQueryVisualizationId, "Name", "PrimaryEntityTypeCode" };
			string Table = EntityNames.SavedQueryVisualizations;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, Table, Fields, orgId) + " SavedQueryVisualization");
		}

		private static void ReadSolutions(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, EntityIDNames.Solution, "OrganizationIdName", "FriendlyName" };
			string Table = EntityNames.Solution;

			Trace.WriteLine("Read " + ReadEntityFromTable(serverData, Table, Fields, orgId) + " Solution");
		}

		private static void ReadSpSite(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, EntityIDNames.SpSite, "OwningBusinessUnit", "RelativeUrl", "AbsoluteUrl", "isdefault" };
			string Table = EntityNames.SpSite;

			Trace.WriteLine("Read " + ReadSpecialEntityFromTable(serverData, Table, Fields, null, null, orgId) + " SharePointSites");
		}

		private static void ReadSharePointDocumentLocation(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, EntityIDNames.SharePointDocumentLocation, "ParentSiteOrLocation", "OwningBusinessUnit", "RelativeUrl", "AbsoluteURL", "RegardingObjectId", "SiteCollectionId" };
			string Table = EntityNames.SharePointDocumentLocation;

			Trace.WriteLine("Read " + ReadSpecialEntityFromTable(serverData, Table, Fields, null, null, orgId) + " SharePointDocumentLocation");
		}
	}
}
