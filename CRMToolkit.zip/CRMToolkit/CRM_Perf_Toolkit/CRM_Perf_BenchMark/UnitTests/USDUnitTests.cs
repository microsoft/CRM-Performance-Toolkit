﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using System.Reflection;
using System.Data.SqlClient;
using System.Data;
using System.Threading;

namespace CRM_Perf_BenchMark.UnitTests
{

	[TestClass]
	public class USDUnitTests : UnitTestBase
	{
		private string uii_hostedapplicationid_AgentScripting;
		private string uii_hostedapplicationid_NotesManager;
		private string uii_hostedapplicationid_CustomPanel;
		private string uii_hostedapplicationid_Dashboard;
		private string uii_hostedapplicationid_Contact;
		private string uii_hostedapplicationid_Notes;
		private string uii_hostedapplicationid_Incident;
		private string uii_hostedapplicationid_Bing;
		private string uii_hostedapplicationid_Email;
		private string uii_hostedapplicationid_Search;
		private Guid phonecallId;
		private CRMEntity m_contact;
		private CRMEntity m_incidents;
		private CRMEntity m_activeincidents;

		public void Cleanup(int expectedexctime, long actualexectime)
		{
			if (m_user == null)
			{
				return;
			}

			Int32 WaitTime = Convert.ToInt32(expectedexctime - actualexectime);
			Thread.Sleep(WaitTime);
			EntityManager.Instance.FreeUser(m_user);
		}
		[TestInitialize]
		public void testInitialize()
		{

			phonecallId = Guid.Empty;
			m_contact = RetrieveTestEntity(m_user, EntityNames.Contacts);
			m_incidents = RetrieveTestEntity(m_user, EntityNames.Incidents);

			Hashtable table = GetUiiHostedApplicationId("Agent Scripting");
			CRMEntity table1 = (CRMEntity)table["UII_hostedapplicationid"];
			uii_hostedapplicationid_AgentScripting = table1["uii_hostedapplicationid"].ToString();

			Hashtable table2 = GetUiiHostedApplicationId("NotesManager");
			CRMEntity table3 = (CRMEntity)table2["UII_hostedapplicationid"];
			uii_hostedapplicationid_NotesManager = table3["uii_hostedapplicationid"].ToString();

			Hashtable table4 = GetUiiHostedApplicationId("Custom Panel");
			CRMEntity table5 = (CRMEntity)table4["UII_hostedapplicationid"];
			uii_hostedapplicationid_CustomPanel = table5["uii_hostedapplicationid"].ToString();

			Hashtable table6 = GetUiiHostedApplicationId("Dashboard");
			CRMEntity table7 = (CRMEntity)table6["UII_hostedapplicationid"];
			uii_hostedapplicationid_Dashboard = table7["uii_hostedapplicationid"].ToString();

			Hashtable table8 = GetUiiHostedApplicationId("Contact");
			CRMEntity table9 = (CRMEntity)table8["UII_hostedapplicationid"];
			uii_hostedapplicationid_Contact = table9["uii_hostedapplicationid"].ToString();

			Hashtable table10 = GetUiiHostedApplicationId("Notes");
			CRMEntity table11 = (CRMEntity)table10["UII_hostedapplicationid"];
			uii_hostedapplicationid_Notes = table11["uii_hostedapplicationid"].ToString();

			Hashtable table18 = GetUiiHostedApplicationId("Incident");
			CRMEntity table19 = (CRMEntity)table18["UII_hostedapplicationid"];
			uii_hostedapplicationid_Incident = table19["uii_hostedapplicationid"].ToString();

			Hashtable table12 = GetUiiHostedApplicationId("Bing");
			CRMEntity table13 = (CRMEntity)table12["UII_hostedapplicationid"];
			uii_hostedapplicationid_Bing = table13["uii_hostedapplicationid"].ToString();

			Hashtable table14 = GetUiiHostedApplicationId("Email");
			CRMEntity table15 = (CRMEntity)table14["UII_hostedapplicationid"];
			uii_hostedapplicationid_Email = table15["uii_hostedapplicationid"].ToString();

			Hashtable table16 = GetUiiHostedApplicationId("Search");
			CRMEntity table17 = (CRMEntity)table16["UII_hostedapplicationid"];
			uii_hostedapplicationid_Search = table17["uii_hostedapplicationid"].ToString();
		}

		[TestMethod()]
		public void UnitTest__testforOneXrmCall()
		{
			TestContext.BeginTimer("testforOneXrmCall");
			var stopwatch = Stopwatch.StartNew();
			// GOAL 5 Min.
			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("RetrieveMultipleRequest_account1");
			string query1 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"account\"><attribute name=\"name\"/><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest_account1");

		}

		[TestMethod()]
		public void UnitTest__ActivityCreationAndSolutionSearch()
		{
			TestContext.BeginTimer("ActivityCreationAndSolutionSearch");
			var stopwatch = Stopwatch.StartNew();
			// GOAL 5 Min.
			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("AuditRequest1");
			organizationRequests.CreateAuditRequest(4, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest1");
			Thread.Sleep(30 * 1000);

			TestContext.BeginTimer("RetrieveMultipleRequest1");
			string query1 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest1");

			TestContext.BeginTimer("AuditRequest2");
			organizationRequests.CreateAuditRequest(6, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest2");

			TestContext.BeginTimer("RetrieveMultipleRequest2");
			string query2 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest2");

			Thread.Sleep(60 * 1000);
			TestContext.BeginTimer("RetrieveMultipleRequest3");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest3");

			TestContext.BeginTimer("InstantiateTemplateRequest1");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest1");

			Thread.Sleep(45 * 1000);
			TestContext.BeginTimer("AuditRequests3");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_NotesManager, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(6, m_contact, uii_hostedapplicationid_Dashboard, Proxy);
			organizationRequests.CreateAuditRequest(5, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Notes, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Bing, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Email, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, Proxy);
			TestContext.EndTimer("AuditRequests3");

			Thread.Sleep(30 * 1000);
			//CloseCall step
			TestContext.BeginTimer("CloseCallStep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Bing, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(5, m_contact, uii_hostedapplicationid_Search, Proxy);
			//RetrieveEntitiesrequest
			organizationRequests.RetrieveEntityRequest(Proxy);
			TestContext.EndTimer("CloseCallStep");

			Thread.Sleep(15 * 1000);
			TestContext.EndTimer("ActivityCreationAndSolutionSearch");
			stopwatch.Stop();
			long testTime = stopwatch.ElapsedMilliseconds;
			// 5minutes 
			Int32 expectedexectime = 300000;
			if (testTime < expectedexectime)
			{
				Cleanup(expectedexectime, testTime);
			}
		}

		[TestMethod()]
		public void UnitTest__CaseCreationAndSolutionSearch()
		{
			TestContext.BeginTimer("CaseCreationAndSolutionSearch");
			var stopwatch = Stopwatch.StartNew();
			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("AuditRequest1");
			organizationRequests.CreateAuditRequest(4, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest1");
			Thread.Sleep(30 * 1000);

			TestContext.BeginTimer("RetrieveMultipleRequest1");
			string query1 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest1");

			TestContext.BeginTimer("AuditRequest2");
			organizationRequests.CreateAuditRequest(6, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest2");

			TestContext.BeginTimer("RetrieveMultipleRequest2");
			string query2 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			string query3 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query3, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest2");


			TestContext.BeginTimer("AuditRequest3");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_NotesManager, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Dashboard, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Notes, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Incident, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Incident, Proxy);
			TestContext.EndTimer("AuditRequest3");

			int resolved = Convert.ToInt32(m_incidents["statecode"]);
			Thread.Sleep(60 * 1000);
			TestContext.BeginTimer("RetrieveMultipleRequest3");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest3");

			TestContext.BeginTimer("InstantiateTemplateRequest1");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest1");

			//ResolveCaseStep
			Thread.Sleep(45 * 1000);
			TestContext.BeginTimer("UpdateIncidentRequest2");
			TestContext.EndTimer("UpdateIncidentRequest2");

			string query4 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query4, Proxy);


			//CloseCall step
			TestContext.BeginTimer("CloseCallStep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			TestContext.EndTimer("CloseCallStep");

			TestContext.BeginTimer("AuditRequest4");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Bing, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Email, Proxy);
			organizationRequests.CreateAuditRequest(6, m_contact, uii_hostedapplicationid_Search, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Bing, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Incident, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Incident, Proxy);
			organizationRequests.CreateAuditRequest(5, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest4");
			Thread.Sleep(45 * 1000);
			TestContext.EndTimer("CaseCreationAndSolutionSearch");
			stopwatch.Stop();
			long testTime = stopwatch.ElapsedMilliseconds;
			// 5minutes 
			Int32 expectedexectime = 300000;
			if (testTime < expectedexectime)
			{
				Cleanup(expectedexectime, testTime);
			}
		}

		[TestMethod()]
		public void UnitTest__NewCustomerRecord()
		{
			TestContext.BeginTimer("NewCustomerRecord");
			var stopwatch = Stopwatch.StartNew();
			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("AuditRequest1");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Search, Proxy);
			TestContext.EndTimer("AuditRequest1");
			Thread.Sleep(30 * 1000);

			TestContext.BeginTimer("MultipleRequest1");
			string query1 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("MultipleRequest1");

			TestContext.BeginTimer("AuditRequest2");
			organizationRequests.CreateAuditRequest(4, m_contact, Proxy);
			organizationRequests.CreateAuditRequest(6, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest2");

			Thread.Sleep(60 * 1000);
			TestContext.BeginTimer("RetriveMultiple1");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetriveMultiple1");

			TestContext.BeginTimer("InstantiateTemplateRequest1");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest1");

			Thread.Sleep(45 * 1000);
			TestContext.BeginTimer("AuditRequest3");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_NotesManager, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Notes, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Bing, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Email, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Bing, Proxy);
			TestContext.EndTimer("AuditRequest3");

			//Close Call Step
			TestContext.BeginTimer("ClosecallStep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			TestContext.EndTimer("ClosecallStep");

			TestContext.BeginTimer("AuditRequest4");
			organizationRequests.CreateAuditRequest(5, m_contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest4");

			TestContext.BeginTimer("MultipleRequest2");
			string query2 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("MultipleRequest2");

			TestContext.BeginTimer("AuditRequest5");
			organizationRequests.CreateAuditRequest(6, m_contact, uii_hostedapplicationid_Search, Proxy);
			TestContext.EndTimer("AuditRequest5");

			Thread.Sleep(45 * 1000);
			TestContext.EndTimer("NewCustomerRecord");
			stopwatch.Stop();
			long testTime = stopwatch.ElapsedMilliseconds;
			// 5minutes 
			Int32 expectedexectime = 300000;
			if (testTime < expectedexectime)
			{
				Cleanup(expectedexectime, testTime);
			}
		}

		[TestMethod()]
		public void UnitTest__CustomerPhoneNumebrNotPresent()
		{
			TestContext.BeginTimer("CustomerPhoneNumberNotPresent");
			var stopwatch = Stopwatch.StartNew();
			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("AuditRequest1");
			organizationRequests.CreateAuditRequest(4, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest1");
			Thread.Sleep(30 * 1000);

			TestContext.BeginTimer("MultipleRequest1");
			string query1 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("MultipleRequest1");

			TestContext.BeginTimer("AuditRequest2");
			organizationRequests.CreateAuditRequest(6, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest2");

			TestContext.BeginTimer("MultipleRequest2");
			string query2 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("MultipleRequest2");

			TestContext.BeginTimer("AuditRequest3");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			TestContext.EndTimer("AuditRequest3");

			Thread.Sleep(60 * 1000);
			TestContext.BeginTimer("RetriveMultiple1");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetriveMultiple1");

			TestContext.BeginTimer("AuditRequest4");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_NotesManager, Proxy);
			TestContext.EndTimer("AuditRequest4");

			TestContext.BeginTimer("InstantiateTemplateRequest1");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest1");
			Thread.Sleep(45 * 1000);
			TestContext.BeginTimer("AuditRequest5");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Dashboard, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Notes, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Bing, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest5");

			//Close Call Step
			TestContext.BeginTimer("Closecallstep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			TestContext.EndTimer("Closecallstep");

			TestContext.BeginTimer("AuditRequest6");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Bing, Proxy);
			TestContext.EndTimer("AuditRequest6");

			TestContext.BeginTimer("MultipleRequest3");
			string query3 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query3, Proxy);
			TestContext.EndTimer("MultipleRequest3");

			TestContext.BeginTimer("AuditRequest7");
			organizationRequests.CreateAuditRequest(6, m_contact, uii_hostedapplicationid_Search, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);

			organizationRequests.CreateAuditRequest(5, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest7");
			Thread.Sleep(45 * 1000);
			stopwatch.Stop();
			TestContext.EndTimer("CustomerPhoneNumberNotPresent");
			stopwatch.Stop();
			long testTime = stopwatch.ElapsedMilliseconds;
			// 5minutes 
			Int32 expectedexectime = 300000;
			if (testTime < expectedexectime)
			{
				Cleanup(expectedexectime, testTime);
			}

		}

		[TestMethod()]
		public void UnitTest__CaseCreationAndAssignment()
		{
			TestContext.BeginTimer("CaseCreationAndAssignment");
			var stopwatch = Stopwatch.StartNew();
			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			Thread.Sleep(10 * 1000);
			TestContext.BeginTimer("AuditRequest1");
			organizationRequests.CreateAuditRequest(4, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest1");

			TestContext.BeginTimer("MultipleRequest1");
			string query1 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("MultipleRequest1");

			TestContext.BeginTimer("MultipleRequest2");
			string query2 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("MultipleRequest2");

			TestContext.BeginTimer("AuditRequest2");
			organizationRequests.CreateAuditRequest(6, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest2");

			TestContext.BeginTimer("MultipleRequest3");
			string query3 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query3, Proxy);
			TestContext.EndTimer("MultipleRequest3");

			//TODO: Close call with update incident is missing -- Have added comment for close call,there are no organization.svc calls for update incident
			Thread.Sleep(90 * 1000);
			TestContext.BeginTimer("AuditRequest3");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_NotesManager, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Dashboard, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Notes, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Incident, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Incident, Proxy);

			//CloseCall step
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			TestContext.EndTimer("AuditRequest3");

			TestContext.BeginTimer("MultipleRequest4");
			string query4 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query4, Proxy);
			TestContext.EndTimer("MultipleRequest4");

			TestContext.BeginTimer("AuditRequest4");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(6, m_contact, uii_hostedapplicationid_Search, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Bing, Proxy);
			organizationRequests.CreateAuditRequest(5, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest4");
			Thread.Sleep(10 * 1000);
			TestContext.EndTimer("CaseCreationAndAssignment");
			stopwatch.Stop();
			long testTime = stopwatch.ElapsedMilliseconds;
			// 5minutes 
			Int32 expectedexectime = 180000;
			if (testTime < expectedexectime)
			{
				Cleanup(expectedexectime, testTime);
			}
		}

		[TestMethod()]
		public void UnitTest__ActivityUpdateOnly()
		{
			TestContext.BeginTimer("ActivityUpdateOnly");
			var stopwatch = Stopwatch.StartNew();
			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			Thread.Sleep(10 * 1000);
			TestContext.BeginTimer("AuditRequest1");
			organizationRequests.CreateAuditRequest(4, m_contact, Proxy);
			organizationRequests.CreateAuditRequest(6, m_contact, Proxy);
			TestContext.EndTimer("AuditRequest1");

			TestContext.BeginTimer("RetrieveMultipleRequest1");
			string query1 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest1");

			Thread.Sleep(40 * 1000);
			//Close call
			TestContext.BeginTimer("CloseCallStep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			TestContext.EndTimer("CloseCallStep");

			TestContext.BeginTimer("RetrieveMultipleRequest2");
			string query2 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest2");

			TestContext.BeginTimer("AuditRequest2");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			TestContext.EndTimer("AuditRequest2");

			TestContext.BeginTimer("AuditRequests3");
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_NotesManager, Proxy);
			organizationRequests.CreateAuditRequest(6, m_contact, uii_hostedapplicationid_Search, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_AgentScripting, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_CustomPanel, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Dashboard, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Contact, Proxy);
			organizationRequests.CreateAuditRequest(3, m_contact, uii_hostedapplicationid_Notes, Proxy);
			organizationRequests.CreateAuditRequest(5, m_contact, Proxy);
			TestContext.EndTimer("AuditRequests3");

			Thread.Sleep(5 * 1000);
			TestContext.EndTimer("ActivityUpdateOnly");
			stopwatch.Stop();
			long testTime = stopwatch.ElapsedMilliseconds;
			// 5minutes 
			Int32 expectedexectime = 90000;
			if (testTime < expectedexectime)
			{
				Cleanup(expectedexectime, testTime);
			}
		}


		private Hashtable GetUiiHostedApplicationId(string uii_name)
		{

			CRMEntity FoundEntity = null;
			Hashtable RetEntities = new Hashtable();

			SqlConnection SqlCon = new SqlConnection(ConfigSettings.Default.EMSQLCNN);

			try
			{
				SqlCon.Open();
				//Build the SQL for the current request
				SqlTransaction tran = SqlCon.BeginTransaction(System.Data.IsolationLevel.Serializable);

				SqlCommand cmd = new SqlCommand();
				cmd.Transaction = tran;
				cmd.Connection = SqlCon;
				cmd.CommandText = ("SELECT top 1 UII_hostedapplicationid  FROM UII_hostedapplication where UII_Name = @UII_name");
				cmd.Parameters.AddWithValue("UII_name", uii_name);
				SqlDataReader reader = cmd.ExecuteReader();

				DataTable table = new DataTable();
				table.Load(reader);
				int numberOfRows = table.Rows.Count;

				if (numberOfRows <= 0)
				{
					throw new EntityNotFoundException("No rows found");
				}

				cmd.Parameters.Clear();
				tran.Dispose();
				reader.Close();
				cmd.Connection.Dispose();
				FoundEntity = new CRMEntity(table, 0, "UII_hostedapplicationid");
				RetEntities.Add("UII_hostedapplicationid", FoundEntity);
			}
			finally
			{
				SqlCon.Close();
			}
			return RetEntities;
		}
	}
}