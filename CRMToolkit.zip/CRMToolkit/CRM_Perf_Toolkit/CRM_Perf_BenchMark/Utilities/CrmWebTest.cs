﻿namespace CRM_Perf_BenchMark
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Runtime.Serialization;
	using System.IO;
	using System.Reflection;
	using Microsoft.Xrm.Sdk.Client;

	[Serializable]
	public abstract class CrmWebTest : WebTest
	{
		public static Version CrmVersionV6Ur1 = new Version(6, 0, 1, 0);
		public static Version CrmVersionV6Ur2 = new Version(6, 0, 2, 0);
		public static Version CrmVersionV6Leo = new Version(6, 1, 0, 0);

		public CrmWebTest()
		{
			this.PreAuthenticate = false;
			this.Guid = new Guid();

			this.PreRequest += new EventHandler<PreRequestEventArgs>(CrmWebTest_PreRequest);
			this.PostRequest += new EventHandler<PostRequestEventArgs>(CrmWebTest_PostRequest);
			this.PreWebTest += new EventHandler<PreWebTestEventArgs>(CrmWebTest_PreWebTest);
			this.PostWebTest += new EventHandler<PostWebTestEventArgs>(CrmWebTest_PostWebTest);
			this.PreTransaction += new EventHandler<PreTransactionEventArgs>(CrmWebTest_PreTransaction);
			this.PostTransaction += new EventHandler<PostTransactionEventArgs>(CrmWebTest_PostTransaction);
			this.PrePage += new EventHandler<PrePageEventArgs>(CrmWebTest_PrePage);
			this.PostPage += new EventHandler<PostPageEventArgs>(CrmWebTest_PostPage);
		}

		void CrmWebTest_PrePage(object sender, PrePageEventArgs e)
		{
			this.LogToTraceFile(new Dictionary<string, object> 
				{
					{"Page Started", e.Request.UrlWithQueryString}
				});
		}

		void CrmWebTest_PostPage(object sender, PostPageEventArgs e)
		{
			this.LogToTraceFile(new Dictionary<string, object> 
				{
					{"Page Finished", e.Request.UrlWithQueryString}
				});
		}

		void CrmWebTest_PreTransaction(object sender, PreTransactionEventArgs e)
		{
			this.LogToTraceFile(new Dictionary<string, object> 
				{
					{"Transaction Started", e.TransactionName}
				});
		}

		void CrmWebTest_PostTransaction(object sender, PostTransactionEventArgs e)
		{
			this.LogToTraceFile(new Dictionary<string, object> 
				{
					{"Transaction Finished", e.TransactionName},
					{"Duration", e.Duration},
				});
		}

		private void LogToTraceFile(string log)
		{
			FileWriter.Instance.WriteToFile(
					string.Format("[{0}], TestName: {1}, TestGuid: {2}, {3}",
						DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:fff"),
						this.ToString(),
						this.Guid.ToString(),
						log));
		}

		private void LogToTraceFile(Dictionary<string, object> fields)
		{
			this.LogToTraceFile(
				string.Join(", ",
					fields.Select(f =>
						string.Format("{0}: {1}", f.Key, f.Value.ToString()))));
		}

		void CrmWebTest_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			this.LogToTraceFile("Started");
		}

		void CrmWebTest_PostWebTest(object sender, PostWebTestEventArgs e)
		{
			this.LogToTraceFile("Finished");
		}

		private const string ReferrerReqIdHeader = "ReferrerReqId";
		private const string TrackerIdHeader = "TrackerId";

		void CrmWebTest_PreRequest(object sender, PreRequestEventArgs e)
		{
			if (e == null || e.Request == null || e.Request.Headers == null)
			{
				return;
			}

			var trackerId = Guid.NewGuid().ToString();
			e.Request.Headers.Add(TrackerIdHeader, trackerId);

			this.LogToTraceFile(new Dictionary<string, object> 
				{
					{"Request Started", e.Request.UrlWithQueryString},
					{TrackerIdHeader, trackerId}
				});

			if (!this.Context.ContainsKey(ReferrerReqIdHeader))
			{
				var referrerReqId = e.WebTest.Guid.ToString();
				this.Context[ReferrerReqIdHeader] = referrerReqId;
				e.Request.Headers.Add(ReferrerReqIdHeader, referrerReqId);
			}
		}

		void CrmWebTest_PostRequest(object sender, PostRequestEventArgs e)
		{
			if (e == null || !e.ResponseExists || e.Response == null || e.Response.Headers == null)
			{
				return;
			}

			var logFields = new Dictionary<string, object> 
				{
					{"Request Finished", e.Request.UrlWithQueryString},
					{"StatusCode", e.Response.StatusCode},
					{"MillisecondsToFirstByte", e.Response.Statistics.MillisecondsToFirstByte},
					{"MillisecondsToLastByte", e.Response.Statistics.MillisecondsToLastByte},
					{"ContentLength", e.Response.Statistics.ContentLength}
				};

			var trackerIdHeader = e.Request.Headers.FirstOrDefault(h => h.Name.Equals(TrackerIdHeader));
			if (trackerIdHeader != null)
			{
				logFields.Add(TrackerIdHeader, trackerIdHeader.Value);
			}

			var reqId = e.Response.Headers["REQ_ID"];
			if (!string.IsNullOrEmpty(reqId))
			{
				logFields.Add("REQ_ID", reqId);
				logFields.Add(ReferrerReqIdHeader, this.Context[ReferrerReqIdHeader]);
			}

			var crmRequest = e.Request as CrmRequest;
			if (crmRequest != null)
			{
				if (crmRequest.Name != null)
				{
					logFields.Add("REQ_Name", crmRequest.Name);
				}
			}

			this.LogToTraceFile(logFields);

		}

		public override abstract IEnumerator<WebTestRequest> GetRequestEnumerator();

		public void SetAuthToken(CRMEntity user, PreWebTestEventArgs e)
		{
			var userManager = EntityManager.GetUserManager();
			userManager.SetAuthToken(e.WebTest, user["domainname"], user["userpassword"], user["organizationname"], user["organizationbaseurl"], user["passportticketexpiration"], user["crmticket"]);
		}

		public new void BeginTransaction(string trac)
		{
			if (ConfigSettings.Default.BandWidthCapture != null)
			{
				if (ConfigSettings.Default.BandWidthCapture.ToLower() == "true")
				{
					string netCapDir = ConfigSettings.Default.NetCapDir;
					string outputDir = ConfigSettings.Default.BandWidthOutputDir;
					string initial = ConfigSettings.Default.ParseDependentRequests;
					string capFile = outputDir + "\\" + trac + "_" + this.Guid.ToString() + "_warm.cap";
					if (initial == "true")
						capFile = outputDir + "\\" + trac + "_" + this.Guid.ToString() + "_cold.cap";

					BandWidthUtilities.StartProgram(netCapDir + "\\netcap.exe ", " /C:\"" + capFile + "\" /n:2 /B:100 /T P 1e 01010101", string.Empty, false);
					System.Threading.Thread.Sleep(1000);
				}
			}

			base.BeginTransaction(trac);
		}

		public new void EndTransaction(string trac)
		{
			base.EndTransaction(trac);
			if (ConfigSettings.Default.BandWidthCapture != null)
			{
				if (ConfigSettings.Default.BandWidthCapture.ToLower() == "true")
				{
					string outputDir = ConfigSettings.Default.BandWidthOutputDir;

					string initial = ConfigSettings.Default.ParseDependentRequests;
					string capFile = outputDir + "\\" + trac + "_" + this.Guid.ToString() + "_warm.cap";
					if (initial == "true")
						capFile = outputDir + "\\" + trac + "_" + this.Guid.ToString() + "_cold.cap";

					BandWidthUtilities.StopCapture("Ping", "-n 1 1.1.1.1");

					string title = trac + " (Warm) ";
					if (initial == "true")
						title = trac + " (Cold) ";

					if (BandWidthUtilities.RunNetMonExpert(capFile))
					{
						BandWidthUtilities.ParseRTAFile(capFile, title);
					}
				}
			}
		}
	}
}
