﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;

using CrmSdk;
using Microsoft.Win32;


namespace CRM_Perf_BenchMark.SolutionUnitTests
{
	[TestClass]
	public class SolutionUnitTests
	{
		CRMEntity m_user;
		string m_userName = string.Empty;
		string m_domain = string.Empty;
		string m_password = string.Empty;
		string m_organization = string.Empty;
		string m_crmticket = string.Empty;
		XrmServiceCreator serviceCreator = null;
		IOrganizationService Proxy = null;
		string m_CrmServer = string.Empty;
		string m_ApiServer = string.Empty;
		string m_discoveryServer = string.Empty;


		private static string resultDir = Environment.SystemDirectory.Split(new char[] { '\\' }, 2)[0] + @"\PerfResult";

		static string solutionName = "CRM4Schools";

		string managedSolutionFilewithPath = string.Empty;
		string unmanagedSolutionFilewithPath = string.Empty;

		public SolutionUnitTests()
		{

		}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		[ClassInitialize()]
		public static void ClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");

		}

		// Use Initialize methodes to run code before running each test. Pass required parameters to search recurring appointments with specific properties
		public void ServiceInitialize()
		{
			try
			{

				if (m_user == null)
				{
					m_user = EntityManager.Instance.GetNextUser();
				}

				string[] splits = m_user["domainname"].Split(new char[] { '\\' }, 2, StringSplitOptions.RemoveEmptyEntries);
				if (splits.Length > 1)
				{
					m_domain = splits[0];
					m_userName = splits[1];
				}

				if (m_user["crmticket"] != "")
				{
					m_userName = m_user["passportname"];
				}

				m_CrmServer = m_user["CrmServer"];
				m_ApiServer = m_user["ApiServer"];
				m_discoveryServer = m_user["discoveryServer"];
				m_password = m_user["userpassword"];
				m_organization = m_user["organizationname"];
				string m_orgId = m_user["organizationid"];
				string key = m_orgId + "_" + m_user["domainname"];

				if (m_user["crmticket"] != "")
				{
					key = m_orgId + "_" + m_user["passportname"];
				}

				if (EntityManager.Instance.UserXrmServiceTable.ContainsKey(key))
				{
					serviceCreator = (XrmServiceCreator)EntityManager.Instance.UserXrmServiceTable[key];
				}
				else
				{
					if (m_user["crmticket"] != "")
					{
						serviceCreator = new XrmServiceCreator(m_domain, m_userName, m_password, m_CrmServer, m_organization, AuthenticationProviderType.LiveId, false);
					}
					else
					{
						serviceCreator = new XrmServiceCreator(m_domain, m_userName, m_password, m_CrmServer, m_organization, AuthenticationProviderType.ActiveDirectory, false);
					}
					EntityManager.Instance.UserXrmServiceTable.Add(key, serviceCreator);
				}

				EntityRequest userRequest = new EntityRequest();
				userRequest.Type = EntityNames.Users;
				userRequest.ParentID = new Guid(m_user[EntityIDNames.Organization]);
				userRequest.ReturnAs = EntityNames.Users;

				System.Collections.Hashtable userProps = new System.Collections.Hashtable();
				userProps.Add(EntityNames.Users, new EntityRequest[] { userRequest });


			}
			catch (Exception pe)
			{
				throw pe;
			}
		}


		// Use TestInitialize to run code before running each test 
		[TestInitialize()]
		public void TestInitialize()
		{

			string configDirKeyPath = "SOFTWARE\\Wow6432Node\\Microsoft\\MSCRMToolkit";
			string configDir = null;
			if (Registry.LocalMachine.OpenSubKey(configDirKeyPath) != null)
			{
				RegistryKey regKey = Registry.LocalMachine.OpenSubKey(configDirKeyPath);
				configDir = (string)regKey.GetValue("CRM_Perf_Toolkit_ConfigDir", Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles");
			}
			else
			{
				//setting the default directory of configsettings.xml to c:\crmstress folder
				configDir = Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles";
			}

			managedSolutionFilewithPath = configDir + "\\CRM4Schools_2_0_managed.zip";
			unmanagedSolutionFilewithPath = configDir + "\\CRM4Schools_2_0.zip";


			//get next available org, each org only run this test once
			Guid orgId = EntityManager.Instance.GetNextAvailableOrg();
			m_user = (CRMEntity)EntityManager.Instance.GetNextUser(orgId);

			ServiceInitialize();

		}


		// Use TestCleanup to run code after each test has run
		[TestCleanup()]
		public void TestCleanup()
		{
		}

		#endregion

		#region Individual Test Cases

		[TestMethod()]
		public void UnitTest_solution()
		{

			//bug 108534                
			//Import CRM4Schools_2_0_managed
			//Import CRM4Schools_2_0_managed (again) ; Overwrite = true
			//Uninstall CRM4Schools_2_0_managed
			//Import CRM4Schools_2_0 (unmanaged)
			//Publish All


			if (serviceCreator != null)
			{

				try
				{

					Proxy = serviceCreator.CreateOrganizationService();
				}
				catch (Exception pe)
				{
					throw pe;
				}


				string timestamp = System.DateTime.Now.Ticks.ToString();
				string SummaryFile = resultDir + @"\Perf_Solution_Summary_" + timestamp + ".log";

				//Run through the Install/Import/Delete/Publish sequence

				DateTime Installstart1 = DateTime.UtcNow;
				ImportSolution(managedSolutionFilewithPath);
				DateTime Installend1 = DateTime.UtcNow;
				TimeSpan Installduration1 = (Installend1 - Installstart1);

				DateTime Installstart2 = DateTime.UtcNow;
				ImportSolutionwithOverwrite(managedSolutionFilewithPath);
				DateTime Installend2 = DateTime.UtcNow;
				TimeSpan Installduration2 = (Installend2 - Installstart2);

				string solutionId = GetSolutionID(solutionName);


				DateTime Uninstallstart = DateTime.UtcNow;
				if (solutionId != null)
				{
					DeleteSolution(solutionId);
				}
				DateTime Uninstallend = DateTime.UtcNow;
				TimeSpan Uninstallduration = (Uninstallend - Uninstallstart);


				DateTime Importstart = DateTime.UtcNow;
				ImportSolution(unmanagedSolutionFilewithPath);
				DateTime Importend = DateTime.UtcNow;
				TimeSpan Importduration = (Importend - Importstart);

				DateTime Publishstart = DateTime.UtcNow;
				PublishAll();
				DateTime Publishend = DateTime.UtcNow;
				TimeSpan Publishduration = (Publishend - Publishstart);


				lock (typeof(StreamWriter))
				{
					StreamWriter logWriter = new StreamWriter(SummaryFile);
					logWriter.WriteLine("Logging test result for Solution ...");
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine("Install managed solution took {0} milisecond", Installduration1.TotalMilliseconds);
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine("Install managed solution second time took {0} milisecond", Installduration2.TotalMilliseconds);
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine("Uninstall managed solution took {0} milisecond", Uninstallduration.TotalMilliseconds);
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine("Import Solution took {0} milisecond", Importduration.TotalMilliseconds);
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine("Publish All Customization took {0} milisecond", Publishduration.TotalMilliseconds);
					logWriter.WriteLine("-----------------------------------------");
					logWriter.Flush();
					logWriter.Close();
				}


			}
		}

		#endregion


		#region Private Methods

		private void PublishAll()
		{
			//Publish customization

			try
			{
				PublishAllXmlRequest req = new PublishAllXmlRequest();
				PublishAllXmlResponse resp = (PublishAllXmlResponse)Proxy.Execute(req);

			}

			catch (Exception ex)
			{
				throw ex;
			}
		}

		private void ImportSolution(string solutionFilewithPath)
		{
			//import solution without overwrite
			try
			{
				ImportSolutionRequest req = new ImportSolutionRequest();
				req.CustomizationFile = File.ReadAllBytes(solutionFilewithPath);
				req.ImportJobId = Guid.NewGuid();
				req.PublishWorkflows = false; // set to true if you want to activate all installed workflows (processes) after import
				req.OverwriteUnmanagedCustomizations = false;
				ImportSolutionResponse resp = (ImportSolutionResponse)Proxy.Execute(req);
			}

			catch (Exception ex)
			{

				throw ex;
			}
		}

		private void ImportSolutionwithOverwrite(string solutionFilewithPath)
		{
			//Import solution with overwrite
			try
			{
				ImportSolutionRequest req = new ImportSolutionRequest();
				req.CustomizationFile = File.ReadAllBytes(solutionFilewithPath);
				req.ImportJobId = Guid.NewGuid();
				req.PublishWorkflows = false; // set to true if you want to activate all installed workflows (processes) after import
				req.OverwriteUnmanagedCustomizations = true;
				ImportSolutionResponse resp = (ImportSolutionResponse)Proxy.Execute(req);
			}

			catch (Exception ex)
			{
				throw ex;
			}
		}

		private string GetSolutionID(string solutionName)
		{
			//Get solution id by solution name

			string mySolutionID = string.Empty;

			//retrive the new solution ID
			try
			{
				QueryByAttribute query1 = new QueryByAttribute(Solution.EntityLogicalName);
				query1.Values.Add(solutionName);
				query1.ColumnSet = new ColumnSet(true);

				RetrieveMultipleRequest req1 = new RetrieveMultipleRequest();
				req1.Query = query1;
				RetrieveMultipleResponse resp1 = (RetrieveMultipleResponse)Proxy.Execute(req1);
				if (resp1.EntityCollection.Entities.Count == 0)
				{
					throw new ArgumentException("Solution is not found in the organization");
				}


				mySolutionID = resp1.EntityCollection.Entities[0].Id.ToString();


			}
			catch (Exception re)
			{
				throw re;

			}

			return mySolutionID;
		}

		private void DeleteSolution(string solutionId)
		{
			//Delete solution

			try
			{
				DeleteRequest req = new DeleteRequest();
				req.Target = new EntityReference(Solution.EntityLogicalName, new Guid(solutionId));
				DeleteResponse resp = (DeleteResponse)Proxy.Execute(req);
			}

			catch (Exception ex)
			{
				throw ex;
			}
		}

		#endregion
	}
}
