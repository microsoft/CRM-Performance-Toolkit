using System;
using System.IO;
using System.Net;
using Microsoft.Win32;
using System.Web.Services;
using System.Reflection;
using System.Xml;
using System.Xml.XPath;
using System.Web.Services.Protocols;
using System.Text;

using System.Runtime.InteropServices;
using System.Globalization;
using System.Security.Principal;
using Microsoft.Crm;

using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages.Internal;
using ServiceCreator;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Summary description for ManagedABPSync
	/// </summary>
	[TestClass]
	public class ManagedABPSync : OutlookTestBaseClass
	{
		XmlDocument resultsDoc = null;
		MySyncDataRecorder sdr = null;

		#region entity fields info
		// Account fields
		const string c_wzAccountColumnSetInsert = "<columnset><column>accountid</column><column>name</column><column>telephone1</column><column>telephone2</column><column>fax</column><column>emailaddress1</column><column>donotemail</column><column>donotfax</column><column>donotphone</column><column>donotpostalmail</column><column>address1_line1</column><column>address1_line2</column><column>address1_line3</column><column>address1_city</column><column>address1_stateorprovince</column><column>address1_postalcode</column><column>address1_country</column><column>modifiedon</column></columnset>";
		const string c_wzAccountColumnSetDelete = "<columnset><column>accountid</column></columnset>";

		// Contact fields
		const string c_wzContactColumnSetInsert = "<columnset><column>contactid</column><column>fullname</column><column>jobtitle</column><column>accountid</column><column>telephone1</column><column>telephone2</column><column>fax</column><column>emailaddress1</column><column>donotemail</column><column>donotfax</column><column>donotphone</column><column>donotpostalmail</column><column>address1_line1</column>column>address1_line2</column><column>address1_line3</column><column>address1_city</column><column>address1_stateorprovince</column><column>address1_postalcode</column><column>address1_country</column><column>modifiedon</column></columnset>";

		const string c_wzContactColumnSetDelete = "<columnset><column>contactid</column></columnset>";

		// Lead fields
		const string c_wzLeadColumnSetInsert = "<columnset><column>leadid</column><column>fullname</column><column>subject</column><column>companyname</column><column>telephone1</column><column>telephone2</column><column>fax</column><column>emailaddress1</column><column>donotemail</column><column>donotfax</column><column>donotphone</column><column>donotpostalmail</column><column>address1_line1</column><column>address1_line2</column><column>address1_line3</column><column>address1_city</column><column>address1_stateorprovince</column><column>address1_postalcode</column><column>address1_country</column><column>modifiedon</column></columnset>";

		const string c_wzLeadColumnSetDelete = "<columnset><column>leadid</column></columnset>";

		// Queue fields
		const string c_wzQueueColumnSetInsert = "<columnset><column>queueid</column><column>name</column><column>emailaddress</column><column>modifiedon</column></columnset>";

		const string c_wzQueueColumnSetDelete = "<columnset><column>queueid</column></columnset>";

		// SystemUser fields
		const string c_wzUserColumnSetInsert = "<columnset><column>systemuserid</column><column>fullname</column><column>title</column><column>internalemailaddress</column><column>address1_telephone1</column><column>address1_telephone2</column><column>homephone</column><column>mobilephone</column><column>modifiedon</column></columnset>";

		const string c_wzUserColumnSetDelete = "<columnset><column>systemuserid</column></columnset>";
		#endregion

		private int DELETED_ITEMS_BATCH_SIZE = 100;
		private int INSERTED_ITEMS_BATCH_SIZE = 100;	// TODO:  DISCOVER OPTIMUM VALUES FOR THESE

		private int enTotal = 5;

		private static string c_wzPlatformNameAccount = "Account";
		private static string c_wzPlatformNameContact = "Contact";
		private static string c_wzPlatformNameLead = "Lead";
		private static string c_wzPlatformNameQueue = "Queue";
		private static string c_wzPlatformNameUser = "SystemUser";

		// NOTE:  THE ORDER OF THIS ARRAY MUST MATCH THE ORDER OF THE ENTITY_NAMES ENUM!
		private static string[] s_EntityNamesForSync = {
															 c_wzPlatformNameAccount,
															 c_wzPlatformNameContact,
															 c_wzPlatformNameLead,
															 c_wzPlatformNameQueue,
															 c_wzPlatformNameUser};

		private String subscriptionId = null;
		private RegistryKey regKey = null;

		#region Additional test attributes

		[ClassInitialize()]
		public static void MyClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"outlooksyncdata\ManagedABPSYnc"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"outlooksyncdata\ManagedABPSYnc");
			}
		}

		private RegistryKey RegKey
		{
			get
			{
				if (this.regKey == null)
				{
					this.regKey = Registry.CurrentUser.OpenSubKey(m_clientKeyPath, true);
					if (this.regKey == null)
					{
						throw new Exception("Client registry subkey not found in the registry");
					}
				}
				return this.regKey;
			}
		}

		private String SubscriptionId
		{
			get
			{
				if (this.subscriptionId == null)
				{
					subscriptionId = (String)RegKey.GetValue("ABPSubscriptionId");
				}
				return this.subscriptionId;
			}
			set
			{
				subscriptionId = value;
				RegKey.SetValue("ABPSubscriptionId", subscriptionId);
			}
		}

		#endregion

		#region Test init
		/// <summary>
		/// Initialize() is called once during test execution before
		/// test methods in this test class are executed.
		/// </summary>
		[TestInitialize()]
		public override void Initialize()
		{
			System.Diagnostics.Trace.WriteLine("init" + DateTime.Now.ToString());
			base.Initialize();

			//we are going to see here if registry exists, if it does not then we are going to create the registry
			try
			{
				CreateRegistryForUser(m_nc);

				sdr = new MySyncDataRecorder();
				// create transfer data provider
				resultsDoc = new XmlDocument();
				resultsDoc.AppendChild(resultsDoc.CreateElement("run_results"));
			}
			catch (Exception ex)
			{
				base.Cleanup();
				throw ex;
			}
		}
#endregion

		#region test cleanup
		/// <summary>
		/// Cleanup() is called once during test execution after
		/// test methods in this class have executed unless the
		/// corresponding Initialize() call threw an exception.
		/// </summary>
		[TestCleanup()]
		public override void Cleanup()
		{
			if (m_user == null)
				return;
			System.Diagnostics.Trace.WriteLine("ManagedABPSync:cleanup" + DateTime.Now.ToString());

			base.Cleanup();

			try
			{
				XmlDocument docNode = resultsDoc.DocumentElement.OwnerDocument;
				XmlElement el;
				el = sdr.SerializeToXML(resultsDoc.DocumentElement.OwnerDocument);
				resultsDoc.DocumentElement.AppendChild(el);


				string fileName = string.Format("{0}_ManagedABP_{1}.xml", m_userName, DateTime.Now.ToString());
				fileName = fileName.Replace(" ", "_");
				fileName = fileName.Replace("/", "_");
				fileName = fileName.Replace(":", "_");
				System.Diagnostics.Trace.WriteLine(fileName);
				string dir = string.Format("{0}\\Documents and Settings\\{1}\\Application Data", Environment.GetEnvironmentVariable("SystemDrive"), m_userName);
				resultsDoc.Save(string.Format("{0}\\ManagedABPSync\\{1}", ConfigSettings.Default.OutlookSyncDir, fileName));
			}

			catch { }
		}
		#endregion

		#region Individual Test Cases

		[TestMethod]
		public void ManagedABPSyncTM()
		{
			if (m_user == null)
				return;

			try
			{
				DateTime dtStart = DateTime.Now;
				DateTime dtFinish = DateTime.Now;

				if (SubscriptionId == null)
				{
					TestContext.BeginTimer("ManagedABPSync:CreateSubscription");
					dtStart = DateTime.Now;
					CreateOnlineSubscription();
					dtFinish = DateTime.Now;
					TestContext.EndTimer("ManagedABPSync:CreateSubscription");

					if (sdr != null)
					{
						sdr.CreateSubscription = dtFinish - dtStart;
					}
				}

				// Step2 : PrepareSync
				TestContext.BeginTimer("ManagedABPSync:DoPrepareSync");
				dtStart = DateTime.Now;
				String syncInfo = PrepareOnlineSync();
				dtFinish = DateTime.Now;
				TestContext.EndTimer("ManagedABPSync:DoPrepareSync");
				if (sdr != null)
				{
					sdr.PrepareSync = dtFinish - dtStart;
					sdr.SyncInfo = syncInfo;
				}

				// Step2 : GetData

				SyncInfo[] syncData = new SyncInfo[enTotal];

				int total = 0;
				TestContext.BeginTimer("ManagedABPSync:GetData");
				dtStart = DateTime.Now;
				int numEntities = GetData(syncInfo, ref syncData, ref total);
				dtFinish = DateTime.Now;
				TestContext.EndTimer("ManagedABPSync:GetData");

				if (total == 0)
					return;

				for (int j = 0; j < numEntities; j++)
				{
					switch (syncData[j].entityName.ToLower())
					{
						case "account":
							TestContext.BeginTimer("ManagedABPSync:SyncItemByTypeForAccount");
							System.Diagnostics.Trace.WriteLine("ManagedABPSync:Syncing accounts");
							SyncItemByType(syncData[j], SubscriptionId, c_wzAccountColumnSetInsert, c_wzAccountColumnSetDelete);
							TestContext.EndTimer("ManagedABPSync:SyncItemByTypeForAccount");
							break;

						case "contact":
							TestContext.BeginTimer("ManagedABPSync:SyncItemByTypeForContact");
							System.Diagnostics.Trace.WriteLine("ManagedABPSync:Syncing contacts");
							SyncItemByType(syncData[j], SubscriptionId, c_wzContactColumnSetInsert, c_wzContactColumnSetDelete);
							TestContext.EndTimer("ManagedABPSync:SyncItemByTypeForContact");
							break;
						case "lead":
							TestContext.BeginTimer("ManagedABPSync:SyncItemByTypeForLead");
							System.Diagnostics.Trace.WriteLine("ManagedABPSync:Syncing Leads");
							SyncItemByType(syncData[j], SubscriptionId, c_wzLeadColumnSetInsert, c_wzLeadColumnSetDelete);
							TestContext.EndTimer("ManagedABPSync:SyncItemByTypeForLead");

							break;
						case "queue":
							TestContext.BeginTimer("ManagedABPSync:SyncItemByTypeForQueue");
							System.Diagnostics.Trace.WriteLine("ManagedABPSync:Syncing Queue");
							SyncItemByType(syncData[j], SubscriptionId, c_wzQueueColumnSetInsert, c_wzQueueColumnSetDelete);
							TestContext.EndTimer("ManagedABPSync:SyncItemByTypeForQueue");
							break;
						case "systemuser":
							TestContext.BeginTimer("ManagedABPSync:SyncItemByTypeForSystemUser");
							System.Diagnostics.Trace.WriteLine("ManagedABPSync:Syncing Users");
							SyncItemByType(syncData[j], SubscriptionId, c_wzUserColumnSetInsert, c_wzUserColumnSetDelete);
							TestContext.EndTimer("ManagedABPSync:SyncItemByTypeForSystemUser");
							break;
						default:
							break;
					}
				}
				dtFinish = DateTime.Now;
				if (sdr != null)
					sdr.MoveData = dtFinish - dtStart;

				System.Diagnostics.Trace.WriteLine("ManagedABPSync:User:" + m_userName + " SyncEnd:" + DateTime.Now.ToString());
			}

			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine("ManagedABPSync:User:" + m_userName + " Begin Got SOAP exception");
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine("ManagedABPSync:User:" + m_userName + " End Got SOAP exception");
				throw e;
			}

			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine("ManagedABPSync:User:" + m_userName + " Begin Got exception");
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine("ManagedABPSync:User:" + m_userName + " End Got exception");
				throw e;
			}
		}

		#endregion

		#region Private Methods

		private XmlDocument CreateXmlDocument(string xml)
		{
			XmlTextReader reader = new XmlTextReader(new StringReader(xml));

			reader.DtdProcessing = DtdProcessing.Prohibit;
			reader.WhitespaceHandling = WhitespaceHandling.Significant;

			XmlDocument xmlDoc = new XmlDocument();

			// Set XmlResolver to null to prevent usage of the default XmlResolver.
			xmlDoc.XmlResolver = null;

			xmlDoc.Load(reader);
			reader.Close();

			return xmlDoc;
		}

		private int ConvertAttributeToInt(XmlAttribute attribute)
		{
			if (attribute == null)
				return 0;

			try
			{
				int count = Int32.Parse(attribute.Value);
				return count;
			}
			catch
			{
				throw new CrmArgumentException("Cannot convert attribute to integer.", attribute.Value);
			}
		}

		private void CreateOnlineSubscription()
		{
			IOrganizationService Proxy = serviceCreator.CreateOrganizationService();
			Entity subsc = new Entity("subscription");
			subsc["subscriptiontype"] = 0; // new CrmNumber(); //CrmSdk.Crm4SubscriptionSubscriptionType.AddressBookProvider;
			//subsc.subscriptiontype.Value = SubscriptionType.AddressBookProvider;
			subsc["machinename"] = Environment.UserDomainName + "\\" + Environment.MachineName; ;

			CreateOutlookSubscriptionSubscriptionClientsRequest request = new CreateOutlookSubscriptionSubscriptionClientsRequest();
			request.Target = subsc;

			CreateOutlookSubscriptionSubscriptionClientsResponse response = (CreateOutlookSubscriptionSubscriptionClientsResponse)Proxy.Execute(request);
			SubscriptionId = response.id.ToString("B").ToUpper();
		}

		private String PrepareOnlineSync()
		{
			IOrganizationService Proxy = serviceCreator.OrganizationService;
			PrepareSyncSubscriptionRequest request = new PrepareSyncSubscriptionRequest();
			request.SubscriptionId = new Guid(SubscriptionId);
			PrepareSyncSubscriptionResponse response = (PrepareSyncSubscriptionResponse)Proxy.Execute(request);
			return response.SyncInfoXml;
		}

		private String GetOnlineData(String subscriptionId, String entityName, SyncAction syncAction, int batchSize, String columnSetXml)
		{
			IOrganizationService Proxy = serviceCreator.OrganizationService;
			GetSyncDataSubscriptionRequest request = new GetSyncDataSubscriptionRequest();
			request.BatchSize = batchSize;
			request.ColumnSetXml = columnSetXml;
			request.EntityName = entityName;
			request.SubscriptionId = new Guid(subscriptionId);
			request.SyncAction = syncAction;
			GetSyncDataSubscriptionResponse response = (GetSyncDataSubscriptionResponse)Proxy.Execute(request);
			return response.SyncDataXml;
		}

		private void PostOnlineSync(String subscriptionId, String entityName, SyncAction syncAction, int batchSize)
		{
			IOrganizationService Proxy = serviceCreator.OrganizationService;
			PostSyncSubscriptionRequest request = new PostSyncSubscriptionRequest();
			request.BatchSize = batchSize;
			request.EntityName = entityName;
			request.SubscriptionId = new Guid(subscriptionId);
			request.SyncAction = syncAction;
			Proxy.Execute(request);
		}

		private int GetData(String syncInfo, ref SyncInfo[] syncData, ref int total)
		{
			System.Diagnostics.Trace.WriteLine(syncInfo);

			XmlDocument doc = CreateXmlDocument(syncInfo);
			XPathNavigator nav = doc.CreateNavigator();
			XPathNodeIterator iterator = nav.Select("/result/entity");

			int insertCount = 0;
			int deleteCount = 0;
			int index = 0;
			while (iterator.MoveNext())
			{
				XmlNode node = ((IHasXmlNode)iterator.Current).GetNode();
				XmlAttributeCollection xmlAttributes = node.Attributes;

				String entityName = xmlAttributes["name"].Value;

				deleteCount = ConvertAttributeToInt(xmlAttributes["delete_count"]);
				insertCount = ConvertAttributeToInt(xmlAttributes["insert_count"]);
				syncData[index] = new SyncInfo();
				syncData[index].entityName = entityName;
				syncData[index].deleteCount = deleteCount;
				syncData[index].insertCount = insertCount;

				System.Diagnostics.Trace.WriteLine("Entity:" + syncData[index].entityName);
				System.Diagnostics.Trace.WriteLine("deleteCount:" + syncData[index].deleteCount);
				System.Diagnostics.Trace.WriteLine("insertCount:" + syncData[index].insertCount);

				index++;
				total += insertCount + deleteCount;
			}
			return index;
		}

		private void SyncItemByType(SyncInfo syncData, string id, string insertSet, string deleteSet)
		{
			int numberofItems = syncData.insertCount + syncData.deleteCount;

			System.Diagnostics.Trace.WriteLine("User:" + m_userName + " numberofItems:" + numberofItems + " " + DateTime.Now.ToString());
			if (numberofItems == 0)
				return;

			bool moreRecords = true;
			if (syncData.deleteCount > 0)
			{
				while (moreRecords)
				{
					string deletedItems = GetOnlineData(SubscriptionId, syncData.entityName, SyncAction.Delete, DELETED_ITEMS_BATCH_SIZE, deleteSet);
					XmlDocument doc = CreateXmlDocument(deletedItems);
					XmlNodeList delNodeList = doc.FirstChild.ChildNodes;

					if (delNodeList.Count == 0)
					{
						moreRecords = false;
						continue;
					}

					for (int i = 0; i < delNodeList.Count; i++)
					{
						XmlNode node = delNodeList[i];
						//System.Diagnostics.Trace.WriteLine("Sleeping for 10msec for a delete");
						//delete item from outlook
						//System.Threading.Thread.Sleep(10);
					}
					PostOnlineSync(SubscriptionId, syncData.entityName, SyncAction.Delete, DELETED_ITEMS_BATCH_SIZE);
				}
			}

			if (syncData.insertCount > 0)
			{
				moreRecords = true;
				while (moreRecords)
				{
					string insertedItems = GetOnlineData(SubscriptionId, syncData.entityName, SyncAction.Insert, INSERTED_ITEMS_BATCH_SIZE, insertSet);
					XmlDocument doc = CreateXmlDocument(insertedItems);

					XmlNodeList insertNodeList = doc.FirstChild.ChildNodes;

					if (insertNodeList.Count == 0)
					{
						moreRecords = false;
						continue;
					}

					for (int i = 0; i < insertNodeList.Count; i++)
					{
						XmlNode node = insertNodeList[i];
						//System.Diagnostics.Trace.WriteLine("Sleeping for 100msec for an insert");
						//insert item into outlook
						//System.Threading.Thread.Sleep(100);
					}
					PostOnlineSync(SubscriptionId, syncData.entityName, SyncAction.Insert, INSERTED_ITEMS_BATCH_SIZE);
				}
			}
		}

		private void CreateRegistryForUser(System.Net.NetworkCredential nc)
		{
			string userId = m_user["systemuserid"];
			string businessId = m_user["businessunitid"];

			RegistryKey userRegKey = Registry.CurrentUser.OpenSubKey(m_clientKeyPath, true);
			if (userRegKey == null)
				userRegKey = Registry.CurrentUser.CreateSubKey(m_clientKeyPath);

			//we need to create - BusinessId, UserId, ServerUrl
			userRegKey.SetValue("BusinessId", "{" + businessId + "}", RegistryValueKind.String);
			userRegKey.SetValue("UserId", "{" + userId + "}", RegistryValueKind.String);
			userRegKey.SetValue("ServerUrl", m_CrmServer + "/MSCRMServices", RegistryValueKind.String);
		}

		#endregion

	}
}
