//-------------------------------------------------------------------------------
// <copyright file="EmailActivityToMultipleEntitiesUnitTest.cs" company="Microsoft">
//		Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//-------------------------------------------------------------------------------

namespace CRM_Perf_BenchMark.EmailActivityToMultipleEntities
{
	using CRM_Perf_BenchMark.UnitTests;
	using Microsoft.Crm.Sdk.Messages;
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using Microsoft.Xrm.Sdk;
	using ServiceCreator;
	using System;
	using System.Diagnostics;
	using System.ServiceModel;

	/// <summary>
	/// Unit Test to check Email to Multiple Entities Flow
	/// </summary>
	[TestClass]
	public class EmailActivityToMultipleEntitiesUnitTests : ServiceManagementSettingsUnitTest
	{
		private readonly int numOfRecipients = 3;
		private CRMEntity sender;
		private CRMEntity[] recipients;
		private Guid workFlowId = new Guid("688bb978-7fcc-4cb3-a570-2c8bec242ac6");
		private EmailUnitTestHelp euth = new EmailUnitTestHelp();

		#region Additional test attributes

		// Use TestInitialize to run code before running each test 
		[TestInitialize()]
		public void TestInitialize()
		{
			base.Initialize();
			System.Collections.ArrayList lockedUsers = new System.Collections.ArrayList();
			recipients = new CRMEntity[numOfRecipients];
			Guid orgId = EntityManager.Instance.GetRandomOrg();
			sender = m_user;
			lockedUsers.Add(sender);

			try
			{
				string userRole = string.Empty;
				if (TestContext.Properties["userRole"] != null)
				{
					userRole = "Customer Service Representative";
				}
				recipients = EntityManager.Instance.GetRandomUserRecipients(userRole, orgId);
			}
			catch (EntityNotFoundException nf)
			{
				//release all the locked users
				foreach (CRMEntity lockedUser in lockedUsers)
				{
					EntityManager.Instance.FreeUser(lockedUser);
				}
				throw nf;
			}

		}

		// Use TestCleanup to run code after each test has run
		[TestCleanup()]
		public void TestCleanup()
		{
			//release all the locked users
			EntityManager.Instance.FreeUser(sender);
			foreach (CRMEntity lockedUser in recipients)
			{
				if (null != lockedUser)
				{
					EntityManager.Instance.FreeUser(lockedUser);
				}
			}
		}

		#endregion

		#region Individual Test Cases

		/// <summary>
		/// Test Case for Email to MultipleEntities
		/// </summary>
		[TestMethod()]
		public void EmailToMultipleEntitiesTest()
		{
			string emailAddress = "recipient_" + Utils.GetRandomString(5, 10) + "@queue.domain.com";
			string fromEmailAddress = "customer_" + Utils.GetRandomString(5, 10) + "@contoso.domain.com";

			//create an queue
			CreateQueue(emailAddress);

			string subject = "EmailtoMultipleEntities" + DateTime.Now.ToString();
			var proxy = EntityManager.Instance.GetTestUserProxy(sender);
			DeliverIncomingEmailRequest deliverIncomingEmailRequest = euth.ComposeIncomingEmailRequest(subject, new EntityCollection(), "activitymimeattachment", emailAddress, fromEmailAddress, String.Empty, String.Empty, Guid.NewGuid().ToString(), euth.GenerateRandomText(1000), "high", DateTime.Now, euth.ConstructAddressList(new CRMEntity[] { sender }));
			DeliverIncomingEmailResponse deliverIncomingEmailResponse = proxy.Execute(deliverIncomingEmailRequest) as DeliverIncomingEmailResponse;

			ExecuteWorkflowRequest request = new ExecuteWorkflowRequest()
			{
				WorkflowId = workFlowId
			};
			request.EntityId = deliverIncomingEmailResponse.EmailId;
			proxy.Execute(request);

		}

		#endregion

		#region Private Methods

		/// <summary>
		/// Creates Queue with Email address
		/// </summary>
		/// <param name="emailAddress">EmailId</param>
		private void CreateQueue(string emailAddress)
		{
			Entity queue = new Entity("queue");
			queue["name"] = Utils.GetRandomString(5, 10);
			queue["emailaddress"] = emailAddress;
			try
			{
				Proxy.Create(queue);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
		}

		#endregion
	}

}
