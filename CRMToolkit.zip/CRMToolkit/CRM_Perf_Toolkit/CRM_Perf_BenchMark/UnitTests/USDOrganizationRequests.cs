﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;
using System.Diagnostics;
using System.Globalization;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using System.Reflection;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace CRM_Perf_BenchMark.OrionUnitTests
{

	public class USDOrganizationRequests : UnitTestBase
	{

		public void RetrieveAllEntitiesRequestRequest(IOrganizationService Proxy)
		{
			Microsoft.Xrm.Sdk.Messages.RetrieveAllEntitiesRequest req = new Microsoft.Xrm.Sdk.Messages.RetrieveAllEntitiesRequest();
			req.EntityFilters = Microsoft.Xrm.Sdk.Metadata.EntityFilters.Entity;
			req.RetrieveAsIfPublished = true;

			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
		}

		public void RetrieveMultiple(IOrganizationService Proxy)
		{
			//RetrieveMultipleRequest

			Entity template = new Entity("template");
			QueryExpression query = new QueryExpression("template");
			query.ColumnSet.AllColumns = true;
			FilterExpression filterexpression = new FilterExpression();
			filterexpression.FilterOperator = LogicalOperator.And;
			filterexpression.AddCondition("template", "title", ConditionOperator.Equal, "acknowledgement");
			query.Criteria.Filters.Add(filterexpression);

			EntityCollection results;

			try
			{
				results = Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
		}


		public void RetrieveMultipleRequest(string queryExp, IOrganizationService Proxy)
		{
			FetchXmlToQueryExpressionRequest req = new FetchXmlToQueryExpressionRequest();
			req.FetchXml = queryExp;

			try
			{
				FetchXmlToQueryExpressionResponse resp = (FetchXmlToQueryExpressionResponse)Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
		}



		public void InstantiateTemplateRequest(Guid _templateId, Guid _objectid, string EntityLogicalName, IOrganizationService Proxy)
		{
			// Use the InstantiateTemplate message to create an e-mail message using a template.
			InstantiateTemplateRequest instTemplateReq = new InstantiateTemplateRequest
			{
				TemplateId = _templateId,
				ObjectId = _objectid,
				ObjectType = EntityLogicalName
			};

			try
			{
				Proxy.Execute(instTemplateReq);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
			}
		}

		public void PhonecallSetStateRequest(Guid phonecallId, IOrganizationService Proxy)
		{
			SetStateRequest req = new SetStateRequest();
			req.EntityMoniker = new EntityReference("phonecall", phonecallId);
			//set the state to 
			req.State = new OptionSetValue(1);
			req.Status = new OptionSetValue(4);

			try
			{
				Proxy.Execute(req);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
			}
		}

		public void RetrieveEntityRequest(IOrganizationService Proxy)
		{
			//Since account is likely to the most customized entity, Retrieve all published metadata
			RetrieveEntityRequest retrieveEntityRequest = GetRetrieveEntityRequest(EntityFilters.All, Guid.Empty, false, "phonecall");

			try
			{

				RetrieveEntityResponse retrieveResponse = (RetrieveEntityResponse)Proxy.Execute(retrieveEntityRequest);
			}

			catch (FaultException<IOrganizationService> e)
			{
				System.Diagnostics.Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
		}

		private RetrieveEntityRequest GetRetrieveEntityRequest(EntityFilters entityFilters, Guid MetadataId, bool retrieveAsIfPublished, string entityName)
		{
			return new RetrieveEntityRequest()
			{
				EntityFilters = entityFilters,
				MetadataId = MetadataId,
				LogicalName = entityName,
				RetrieveAsIfPublished = retrieveAsIfPublished
			};

		}


		public void CreateAuditRequest(int activityid, CRMEntity m_contact, IOrganizationService Proxy)
		{
			Guid uii_auditId1 = Guid.Empty;
			Entity uii_audit1 = new Entity("uii_audit");

			uii_audit1["uii_activityid"] = activityid;
			uii_audit1["uii_machinename"] = Environment.MachineName;
			uii_audit1["uii_clienttimezone"] = System.Environment.GetEnvironmentVariable("Timezone");
			uii_audit1["uii_currenttime"] = DateTime.Now;
			uii_audit1["uii_customerid"] = m_contact["ContactId"];

			try
			{

				uii_auditId1 = Proxy.Create(uii_audit1);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
		}


		public void CreateAuditRequest(int activityid, CRMEntity m_contact, string uii_hostedapplicationid, IOrganizationService Proxy)
		{
			Guid uii_auditId1 = Guid.Empty;
			Entity uii_audit1 = new Entity("uii_audit");

			uii_audit1["uii_activityid"] = activityid;
			uii_audit1["uii_machinename"] = Environment.MachineName;
			uii_audit1["uii_clienttimezone"] = System.Environment.GetEnvironmentVariable("Timezone");
			uii_audit1["uii_currenttime"] = DateTime.Now;
			uii_audit1["uii_applicationid"] = uii_hostedapplicationid;
			uii_audit1["uii_customerid"] = m_contact["ContactId"];

			try
			{

				uii_auditId1 = Proxy.Create(uii_audit1);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
		}

		public void CreateAudit(CRMEntity m_contact)
		{
			Guid uii_auditId = Guid.Empty;
			Entity uii_audit = new Entity("uii_audit");
			OrganizationRequest organizationRequest = new OrganizationRequest("Create");
			uii_audit["uii_activityid"] = 2;
			organizationRequest["uii_machinename"] = Environment.MachineName;
			string timeZone = TimeZone.CurrentTimeZone.ToString();
			organizationRequest["uii_clienttimezone"] = timeZone;
			organizationRequest["uii_currenttime"] = DateTime.Now;
			uii_audit["uii_applicationid"] = "";
			organizationRequest["uii_customerid"] = m_contact["ContactId"];

			try
			{
				OrganizationResponse organizationResponse = Proxy.Execute(organizationRequest);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
		}

		public void UpdateIncident(CRMEntity m_incident, IOrganizationService Proxy)
		{
			Entity incident = new Entity("incident");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "incidentid" });
			incident = Proxy.Retrieve(incident.LogicalName, new Guid(m_incident["Incidentid"]), attributes);
			incident["firstresponsesent"] = true;

			try
			{
				Proxy.Update(incident);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
		}

		public void UpdateIncidentForResolution(CRMEntity m_incident, IOrganizationService Proxy)
		{
			Entity incident = new Entity("incident");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "incidentid" });
			incident = Proxy.Retrieve(incident.LogicalName, new Guid(m_incident["Incidentid"]), attributes);
			incident["actualserviceunits"] = 109;

			try
			{
				Proxy.Update(incident);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}

		}

		public void CloseIncident(CRMEntity m_incident, IOrganizationService Proxy)
		{
			CloseIncidentRequest closeIncidentRequest = new CloseIncidentRequest();

			// Create the incident's resolution.
			Entity incidentResolution = new Entity("incidentresolution");
			incidentResolution.Attributes.Add("subject", "Resolved Sample CWR Incident");
			incidentResolution.Attributes.Add("incidentid", new EntityReference("incident", new Guid(m_incident["incidentid"])));

			try
			{
				Proxy.Create(incidentResolution);
			}
			catch (FaultException<IOrganizationService> fe1)
			{
				Trace.WriteLine(fe1.Detail);
				Trace.WriteLine(fe1.StackTrace);
				throw;
			}

			closeIncidentRequest.IncidentResolution = incidentResolution;

			//set the incident's status to problem solved
			OptionSetValue status = new OptionSetValue();
			status.Value = 5;
			closeIncidentRequest.Status = status;
			closeIncidentRequest.RequestName = "CloseIncident";

			//execute the associate request
			try
			{
				Proxy.Execute(closeIncidentRequest);
			}
			catch (FaultException<IOrganizationService> fe3)
			{
				Trace.WriteLine(fe3.Detail);
				Trace.WriteLine(fe3.StackTrace);
				throw;
			}

			//update the status code in EMDB accordingly
			string[] prop = { "statecode" };
			string[] propvalue = { "1" };
			EntityManager.Instance.UpdateEntity(ref m_incident, "incident", new Guid(m_incident["EntityManagerOwningUser"]), prop, propvalue, "incidentid", m_incident["incidentid"].ToString());

		}

		public void CreateAndSetStateOfPhoneCallActivity(CRMEntity m_user, Guid phonecallId, string contactId, string lastName, string fromId, string toId, string description, IOrganizationService Proxy)
		{
			Entity phonecall = new Entity("phonecall");
			phonecall["regardingobjectid"] = contactId;
			phonecall["subject"] = "Call with" + lastName;
			phonecall["from"] = fromId;
			phonecall["to"] = toId;
			phonecall["description"] = description;
			//phonecall["SuppressDuplicateDetection"] = suppressDuplicateDetection;

			try
			{
				phonecallId = Proxy.Create(phonecall);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}

			//add the phonecall to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Phonecalls, g, new string[] { "OwnerId", "subject", "EntityManagerOwningUser", "ActivityId" }, new string[] { m_user["systemuserid"], phonecall["description"].ToString(), g.ToString(), g.ToString() });

			SetStateRequest req = new SetStateRequest();
			req.EntityMoniker = new EntityReference("phonecall", phonecallId);
			//set the state to 
			req.State = new OptionSetValue(1);
			req.Status = new OptionSetValue(4);

			try
			{
				Proxy.Execute(req);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
			}
		}
	}
}
