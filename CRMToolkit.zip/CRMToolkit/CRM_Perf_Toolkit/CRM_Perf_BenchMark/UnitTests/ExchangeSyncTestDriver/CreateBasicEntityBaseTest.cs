﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Base Class for All CRM Entity Creation
	/// </summary>
	[TestClass]
	public abstract class CreateBasicEntityBaseTest
	{
		#region Protected and Private Members
		protected CRMEntity m_user, m_contact;
		protected string SummaryFile;
		protected IOrganizationService proxy;
		private TestContext m_testContext;
		private CRMEntity[] users;
		private readonly int PARTYCOUNT = 5;
		private bool isExchange;

		protected virtual string FilterAppendable
		{
			get { return "ExchangeSync"; }
		}

		protected virtual string DeleteIdentifier
		{
			get { return FilterAppendable + " deletable"; }
		}

		protected virtual string UpdateIdentifier
		{
			get { return FilterAppendable + " updatable"; }
		}

		#endregion

		/// <summary>
		/// Abstract field used to Set the Entity Name
		/// </summary>
		public abstract string EntityName
		{
			get;
		}

		[TestCleanup()]
		public void myTestCleanup()
		{
			if (m_user != null)
			{
				EntityManager.Instance.FreeUser(m_user);
			}
		}

		/// <summary>
		/// Gets the Cached List of Users from the EMDB
		/// </summary>
		protected CRMEntity[] Users
		{
			get
			{
				if (users == null)
				{
					EntityRequest userRequest = new EntityRequest();
					userRequest.Type = EntityNames.Contacts;
					userRequest.ParentID = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]),new Guid(m_user["OrganizationId"]));userRequest.ReturnAs = EntityNames.Contacts;
					users = EntityManager.Instance.GetAllRecordsForEntity(userRequest, PARTYCOUNT);
				}
				return users;
			}
		}

		/// <summary>
		/// CTor for Base Class
		/// </summary>
		public CreateBasicEntityBaseTest()
		{
			string timestamp = System.DateTime.Now.Ticks.ToString();
			StringBuilder summaryFileSB = new StringBuilder();
			summaryFileSB.Append(CWR_Help.resultDir);
			summaryFileSB.Append(String.Format(@"\Perf_Contact_CRUD_Summary_",EntityName));
			summaryFileSB.Append(timestamp);
			summaryFileSB.Append(".log");
			SummaryFile = summaryFileSB.ToString();
		}

		/// <summary>
		/// Init method this should  retrieves data from EMDB
		/// </summary>
		/// <param name="help"></param>
		internal void Init(CWR_Help help, string entityMessage)
		{
			Hashtable Entities = null;
			Entities = help.getEntities();

			if (m_contact == null)
			{
				m_contact = (CRMEntity) Entities[EntityName];
			}
			if (m_user == null)
			{
				m_user = (CRMEntity) Entities[EntityNames.Users];
			}
			proxy = help.Proxy;
		}

		/// <summary>
		/// Init method This should be called before testing
		/// </summary>
		/// <param name="props"></param>
		/// <returns>true if hte entity was created</returns>
		public bool Init(System.Collections.Hashtable props, string entityMessage, bool exchangeEntity = false)
		{
			// If help fails it means we cna't find a free user or there is an issue with the environment
			bool createdEntity = false;
			isExchange = exchangeEntity;
			CWR_Help help = new CWR_Help();

			try
			{
				help.GetEntitiesForUser(props, isExchange);
			}
			catch (EntityNotFoundException enf)
			{
				// If the Entity that you are trying to find doesn't exist create it if the error is from another Entity Just throw. 
				// This will be an issue with the perf toolkit not the tests.
				if (enf.EntityType != null && enf.EntityType == this.EntityName)
				{
					Init(help, entityMessage);
					CreateEntity(entityMessage);
					help.GetEntitiesForUser(props, isExchange);
					createdEntity = true;
				}
				else
				{
					throw;
				}
			}
			Init(help, entityMessage);
			return createdEntity;
		}

		/// <summary>
		/// initialization with sub-properties requirement
		/// for instance, require name contains keyword of 'deleteable'
		/// </summary>
		/// <param name="filterPropertyName"></param>
		/// <param name="filter"></param>
		public virtual bool Init(string filterPropertyName = "lastname", string filter =null, bool isExchange = false)
		{
			System.Collections.Hashtable props = new System.Collections.Hashtable();
			System.Collections.Hashtable sub_props = new System.Collections.Hashtable();
		  
			if (!string.IsNullOrEmpty(filter))
			{
				sub_props.Add(filterPropertyName, filter);
				props.Add(EntityName, sub_props);				
			}

			return Init(props,filter,isExchange);
		}

		/// <summary>
		/// VS Test Context
		/// </summary>
		public TestContext TestContext
		{
			get { return m_testContext; }
			set { m_testContext = value; }
		}

		public abstract void CreateEntity(string name);

		/// <summary>
		/// Creates the Entity in CRM 
		/// </summary>
		/// <param name="entity">entity to Create</param>
		/// <param name="timerName">Timer Name</param>
		/// <returns></returns>
		public Guid CreateEntityInCRM(Entity entity, string timerName)
		{
			Guid returnGuid = Guid.Empty;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer(timerName);
			try
			{
				returnGuid = proxy.Create(entity);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer(timerName);
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof (StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Creating " + this.EntityName + " test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine(this.EntityName + " id created in this test is " + returnGuid.ToString());
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine(this.PrintEntityData(entity));
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
			return returnGuid;
		}

		/// <summary>
		/// Updates the Entity In CRM
		/// </summary>
		/// <param name="entity"></param>
		/// <param name="timerName"></param>
		public void UpdateEntityInCRM(Entity entity, string timerName)
		{
			//update the Phone Call
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer(timerName);
			try
			{
				proxy.Update(entity);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer(timerName);
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Updating " + this.EntityName + " test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the " + this.EntityName + " retrieved in this test is " + entity.Id.ToString());
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine(this.PrintEntityData(entity));
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		/// <summary>
		/// Deletes the Entity In CRM
		/// </summary>
		/// <param name="lookupId"></param>
		/// <param name="entity"></param>
		/// <param name="timerName"></param>
		public void DeleteEntityInCRM(string lookupId,Entity entity, string timerName)
		{
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer(timerName);
			try
			{
				proxy.Delete(entity.LogicalName, new Guid(m_contact[lookupId]));
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer(timerName);
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Deleting contact test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the contact deleted in this test is " + m_contact["contactId"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
			//delete the contact from EMDB
			EntityManager.Instance.DeleteEntity(m_contact);
		}

		/// <summary>
		/// Abstract String that has to be overwriten with the Entity Data that should be printed when a test finishes
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public abstract string PrintEntityData(Entity entity);

		/// <summary>
		/// Creates an EntityList with the current User only
		/// </summary>
		/// <returns></returns>
		internal Entity[] CreateEntityForSystemUser()
		{
			Entity organizer = new Entity("activityparty");
			organizer["partyid"] = new EntityReference("systemuser", new Guid(m_user["systemuserid"]));
			return new Entity[] {organizer};
		}

		/// <summary>
		/// Creates an Entity List with a list of CRM Users
		/// </summary>
		/// <returns></returns>
		protected Entity[] CreateListOfUsers()
		{
			//Get Min size or the two
			int actualPartyCount = Math.Min(PARTYCOUNT, this.Users.Length);
			Entity[] entityArray = new Entity[actualPartyCount];
			
			for (int i = 0; i < actualPartyCount; i++)
			{
				Entity party = new Entity("activityparty");
				party["partyid"] = new EntityReference("contact", new Guid(users[i]["contactid"]));
				entityArray[i] = party;
			}
			return entityArray;
		}
	}
}
