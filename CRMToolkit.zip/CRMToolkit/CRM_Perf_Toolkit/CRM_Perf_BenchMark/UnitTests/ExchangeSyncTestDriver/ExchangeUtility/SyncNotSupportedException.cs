﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CRM_Perf_BenchMark.Utilities
{
	/// <summary>
	/// SyncNotSupportedException to be used when Sync Helper Methods are called on an Entity not Supported for Sync
	/// </summary>
	[SuppressMessage("Microsoft.Security", "CA9881:ClassesShouldBeSealed", Justification = "Class has protected member", MessageId = "")]
	[Serializable]
	public class SyncNotSupportedException : System.Exception
	{
		/// <summary>
		/// Default Constructor
		/// </summary>
		public SyncNotSupportedException()
			: base()
		{
		}

		/// <summary>
		/// Constructs exception with message
		/// </summary>
		/// <param name="message">Message to pass</param>
		public SyncNotSupportedException(string message)
			: base(message)
		{
		}
		/// <summary>
		/// Constructs exception with message and inner exception
		/// </summary>
		/// <param name="message">Message to pass</param>
		/// <param name="innerException">Exception to include</param>
		public SyncNotSupportedException(string message, System.Exception innerException)
			: base(message, innerException)
		{
		}
		/// <summary>
		/// Serilization constructor
		/// </summary>
		/// <param name="serializationInfo"></param>
		/// <param name="sc"></param>
		protected SyncNotSupportedException(SerializationInfo serializationInfo, StreamingContext sc)
			:
			base(serializationInfo, sc)
		{
		}
	}
}
