﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	//test RetrieveBusinessHierarchyBusinessUnitRequest 
	[TestClass]
	public class RetrieveBusinessHierarchyBusinessUnitRequestUnitTest : UnitTestBase
	{
		private CRMEntity m_account;
		#region Retrieve business hierarchy business unit request
		/// <summary>
		/// Test retrieving business hierarchy business unit
		/// </summary>
		[TestMethod]
		public void UnitTest__RetrieveBusinessHierarchyBusinessUnitRequest()
		{
			m_account = RetrieveTestEntity(m_user, EntityNames.Accounts);
			//create RetrieveBusinessHierarchyBusinessUnit Request 
			RetrieveBusinessHierarchyBusinessUnitRequest req = new RetrieveBusinessHierarchyBusinessUnitRequest();
			req.EntityId = new Guid(m_account["accountid"]);
			req.ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet(true);

			//execute the request
			TestContext.BeginTimer("RetrieveBusinessHierarchyBusinessUnitRequest Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveBusinessHierarchyBusinessUnitRequest Unit Test");
		}
#endregion
	}
}
