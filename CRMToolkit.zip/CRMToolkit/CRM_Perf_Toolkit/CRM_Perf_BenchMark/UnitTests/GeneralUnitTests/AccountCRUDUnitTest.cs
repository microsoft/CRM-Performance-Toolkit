﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit Testcases for creating, updating, retrieving and deleting Account entity
	/// </summary>
	[TestClass]
	public class AccountCRUDUnitTest : UnitTestBase
	{

		#region Create an account
		/// <summary>
		/// Create an account
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_Account()
		{
			//create an account
			Guid accountId = Guid.Empty;
			Entity account = new Entity("account");
			account["name"] = Utils.GetRandomString(5, 30);

			TestContext.BeginTimer("Account Create UnitTest");
			try
			{
				accountId = Proxy.Create(account);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Account Create UnitTest");

			//add the account to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Accounts, g, new string[] { "OwnerId", "AccountID", "name", "EntityManagerOwningUser" }, new string[] { m_user["systemuserid"], accountId.ToString(), account["name"].ToString(), g.ToString() });

		}
		#endregion

		#region Retrieve an account
		/// <summary>
		/// Retrieve an account
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_Account()
		{
			CRMEntity m_account = RetrieveTestEntity(m_user, EntityNames.Accounts);
			Entity account = new Entity("account");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "name", "ownerid" });
			TestContext.BeginTimer("Account Retrieve UnitTest");
			try
			{
				account = Proxy.Retrieve(account.LogicalName, new Guid(m_account["AccountId"]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Account Retrieve UnitTest");

		}
		#endregion

		#region Updatea an account
		/// <summary>
		/// Update an account
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_Account()
		{
			Entity account = new Entity("account");
			//find a non-deletable CRM Entity for update test
			System.Collections.Hashtable filter = new System.Collections.Hashtable()
			{
				{"name", "connection"}
			};
			CRMEntity m_account = RetrieveTestEntity(m_user, EntityNames.Accounts, filter);
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "name", "ownerid" });
			//get the account in CRM
			account = Proxy.Retrieve(account.LogicalName, new Guid(m_account["AccountId"]), attributes);
			//update account address city value
			account["address1_postalcode"] = "98049";
			account["revenue"] = new Money(1000);
			//update the account
			TestContext.BeginTimer("Account Update UnitTest");
			try
			{
				Proxy.Update(account);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Account Update UnitTest");
		}
		#endregion

		#region Delete an account
		/// <summary>
		/// Delete an account
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_Account()
		{
			System.Collections.Hashtable filter = new System.Collections.Hashtable()
			{
				{"name", "connection"}
			};
			CRMEntity m_account = RetrieveTestEntity(m_user, EntityNames.Accounts, filter);
			TestContext.BeginTimer("Account Delete UnitTest");
			try
			{
				Proxy.Delete("account", new Guid(m_account["accountId"]));

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Account Delete UnitTest");
			//delte the test account from EMDB
			EntityManager.Instance.DeleteEntity(m_account);

		}
		#endregion

		#region Retreive multiple accounts
		/// <summary>
		/// Retrieve multiple accounts
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_Account()
		{
			Entity account = new Entity("account");
			QueryExpression query = new QueryExpression("account");
			query.ColumnSet.AddColumn("name");
			query.ColumnSet.AddColumn("numberofemployees");
			query.Criteria.AddCondition("numberofemployees", ConditionOperator.GreaterThan, "99900");
			EntityCollection results;
			
			TestContext.BeginTimer("Account RetrieveMultiple UnitTest");
			try
			{
				results = Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Account RetrieveMultiple UnitTest");
		}
		#endregion
	}
}
