﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;


namespace CRM_Perf_BenchMark.MetadataTests
{
	[TestClass]
	public class RetrieveMetadataTests : UnitTestBase
	{

		#region Additional test attributes
	   
		// Use TestInitialize to run code before running each test 
		[TestInitialize()]
		public void TestInitialize()
		{
			//base.Initialize();
			//Do a retrieve to ensure that the metadata cache is loaded before the test
			Proxy.Retrieve("systemuser", new Guid(m_user["systemuserid"]), new ColumnSet("firstname"));
			
		}


		#endregion

		#region Individual Test Cases

		[TestMethod()]
		public void MetadataTest_RetrieveEntityRequest_Published()
		{
		
			//Since account is likely to the most customized entity, Retrieve all published metadata
			RetrieveEntityRequest retrieveEntityRequest = GetRetrieveEntityRequest("account", EntityFilters.All, false);
			TestContext.BeginTimer("Retrieve Entity Metadata");
			try
			{

				RetrieveEntityResponse retrieveResponse = (RetrieveEntityResponse)Proxy.Execute(retrieveEntityRequest);
			}

			catch (FaultException<IOrganizationService> e)
			{
				System.Diagnostics.Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			
			TestContext.EndTimer("Retrieve Entity Metadata");
			
			
		}

		[TestMethod()]
		public void MetadataTest_RetrieveAllEntitiesRequest_Published()
		{
			//Retrieve all published metadata
			RetrieveAllEntitiesRequest retrieveAllEntitiesRequest = GetRetrieveAllEntitiesRequest(EntityFilters.All, false);
			TestContext.BeginTimer("Retrieve All Entities Metadata");
			try
			{
				RetrieveAllEntitiesResponse retrieveResponse = (RetrieveAllEntitiesResponse)Proxy.Execute(retrieveAllEntitiesRequest);	
			}
			catch (FaultException<IOrganizationService> e)
			{
				System.Diagnostics.Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			TestContext.EndTimer("Retrieve All Entities Metadata");
		}

		#endregion

		#region Private Methods

		private RetrieveEntityRequest GetRetrieveEntityRequest(string entityName, EntityFilters entityFilters, bool retrieveAsIfPublished)
		{
			return new RetrieveEntityRequest()
			{
				EntityFilters = entityFilters,
				LogicalName = entityName,
				RetrieveAsIfPublished = retrieveAsIfPublished
			};

		}

		private RetrieveAllEntitiesRequest GetRetrieveAllEntitiesRequest(EntityFilters entityFilters, bool retrieveAsIfPublished)
		{
			return new RetrieveAllEntitiesRequest()
			{
				EntityFilters = entityFilters,
				RetrieveAsIfPublished = retrieveAsIfPublished,
			};

		}

	  
		#endregion
	}

}
