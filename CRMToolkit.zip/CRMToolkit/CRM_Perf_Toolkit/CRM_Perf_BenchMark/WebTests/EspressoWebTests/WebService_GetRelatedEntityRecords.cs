﻿using System.Collections.Generic;
using CRM_Perf_BenchMark;
using CRM_Perf_BenchMark.Espresso;
using Microsoft.VisualStudio.TestTools.WebTesting;
using Microsoft.Xrm.Sdk;

namespace CRM_Perf_Benchmark
{
	public class WebService_GetRelatedEntityRecords : EspressoWebServiceTestBase
	{
		public WebService_GetRelatedEntityRecords()
			: base()
		{
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			var account = RetrieveTestEntity(user, EntityNames.Accounts);
			string objectId = account[EntityIDNames.Account];
			int objectTypeCode = 1;
			string relationshipId = "60807094-c373-4995-91f7-712993b50884";
			this.BeginTransaction(EspressoTransactionNames.WebService_GetRelatedEntityRecords);
			yield return base.Execute(() => new MobileExpressWebService().GetRelatedEntityRecords(objectTypeCode, objectId, relationshipId));
			this.EndTransaction(EspressoTransactionNames.WebService_GetRelatedEntityRecords);
		}

		protected override void ResponseValidator(object sender, ValidationEventArgs e)
		{
			// HTTP Status code is checked by default validator, no need for any more validation in this call.
		}
	}
}
