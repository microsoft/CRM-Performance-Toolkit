﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;


namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Unit test help class
	/// </summary>
	public class EmailUnitTestHelp
	{
		public string GenerateRandomText(int words)
		{
			StringBuilder subject = new StringBuilder();

			for (int i = 0; i < words; i++)
			{
				subject.Append(Guid.NewGuid().ToString());

				subject.Append(" ");
			}

			return subject.ToString();
		}

		public string ConstructAddressList(CRMEntity[] users)
		{
			StringBuilder address = new StringBuilder();

			for (int i = 0; i < users.Length; i++)
			{
				address.Append(users[i]["InternalEmailAddress"]);
				address.Append(";");
			}
			return address.ToString();
		}

		public DeliverPromoteEmailRequest ComposePromoteEmailRequest(String subject, EntityCollection attachements, String attachmentName, String to, String from, String cc, String bcc, String messageId, String body, String importance, DateTime receivedOn, String submittedBy)
		{ 
			DeliverPromoteEmailRequest emailRequest = new DeliverPromoteEmailRequest();
			emailRequest.Subject = subject;
			emailRequest.From = from;
			emailRequest.To = to;
			emailRequest.Cc = cc;
			emailRequest.Bcc = bcc;
			emailRequest.MessageId = messageId;
			emailRequest.ReceivedOn = receivedOn;
			emailRequest.SubmittedBy = submittedBy;
			emailRequest.Importance = importance;
			emailRequest.Body = body;
			emailRequest.Attachments = attachements;
			emailRequest.Attachments.EntityName = attachmentName;
			return emailRequest;
		}

		public DeliverIncomingEmailRequest ComposeIncomingEmailRequest(String subject,EntityCollection attachements,String attachmentName,String to,String from,String cc,String bcc,String messageId,String body,String importance,DateTime receivedOn,String submittedBy)
		{
			DeliverIncomingEmailRequest deliverIncomingRequest = new DeliverIncomingEmailRequest();
			deliverIncomingRequest.Attachments = attachements;
			deliverIncomingRequest.Attachments.EntityName = attachmentName;
			deliverIncomingRequest.Subject = subject;
			deliverIncomingRequest.To = to;
			deliverIncomingRequest.From = from;
			deliverIncomingRequest.Cc = cc;
			deliverIncomingRequest.Bcc = bcc;
			deliverIncomingRequest.MessageId = messageId;
			deliverIncomingRequest.Body = body;
			deliverIncomingRequest.Importance = importance;
			deliverIncomingRequest.ReceivedOn = receivedOn;
			deliverIncomingRequest.SubmittedBy = submittedBy;
			return deliverIncomingRequest;
		}

	}
}
