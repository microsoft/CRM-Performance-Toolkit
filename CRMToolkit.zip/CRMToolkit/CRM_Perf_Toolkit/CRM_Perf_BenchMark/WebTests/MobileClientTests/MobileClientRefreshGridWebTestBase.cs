﻿namespace CRM_Perf_BenchMark.OrionWebTests.MobileClientTests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using CRM_Perf_BenchMark.CrmRequests;
	using Microsoft.VisualStudio.TestTools.WebTesting;

	public abstract class MobileClientRefreshGridWebTestBase : MobileClientWebTestBase
	{
		public MobileClientRefreshGridWebTestBase(string entityName)
			: base()
		{
			this.EntityName = entityName;
		}

		public string EntityName { get; set; }

		/// <summary>
		/// Refresh grid
		/// </summary>
		/// <returns>Return list of WebTestRequests</returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction("MoCA_RefreshGrid" + this.EntityName);

			var childRequests = this.OpenEntityGrid(this.EntityName);
			while (childRequests.MoveNext())
			{
				yield return childRequests.Current;
			}

			string basePath = "\\CrmRequests\\MobileClientRequests\\MoCA_RefreshEntityGrid\\";

			var retrieveMultipleRequest = new OrganizationServiceExecuteRequest(user, basePath + "MoCA_RefreshGrid" + this.EntityName + "_RetrieveMultipleRequest");

			yield return PrepareRequest(retrieveMultipleRequest);

			this.EndTransaction("MoCA_RefreshGrid" + this.EntityName);
		}
	}
}
