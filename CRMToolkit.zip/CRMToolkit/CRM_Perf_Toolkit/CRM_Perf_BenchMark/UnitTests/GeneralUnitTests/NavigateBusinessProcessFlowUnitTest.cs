﻿namespace CRM_Perf_BenchMark.UnitTests
{
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using Microsoft.Xrm.Sdk;
	using Microsoft.Crm.Sdk.Messages.Internal;
	using System;
	using System.Diagnostics;
	using System.ServiceModel;
	using System.Web.Services.Protocols;

	/// <summary>
	/// Unit test for measuring macro performance of Navigate SDK method using in Multi entity Process control to navigate to the child record
	/// </summary>
	[TestClass]
	public class NavigateBusinessProcessFlowUnitTest : UnitTestBase
	{
		#region Private Members

		private CRMEntity m_account, m_contact;
		private readonly Guid AccountWorkflowId = new Guid("8A0F369C-FCB0-4783-B455-0544BB747A74");
		private readonly string _accountStageId = "7DBBD976-BFCB-4DEF-A64C-23ED0D06AE09";
		private readonly string _accountTraversedPath = "7dbbd976-bfcb-4def-a64c-23ed0d06ae09";
		private readonly string _contactStageId = "fc926057-8439-4417-a9f7-0e387438cf24";
		private readonly string _contactTraversedPath = "7dbbd976-bfcb-4def-a64c-23ed0d06ae09,fc926057-8439-4417-a9f7-0e387438cf24";
		private Guid _processId;

		#endregion

		#region Public methods

		/// <summary>
		/// Initializes data before the sdk method can be called. Following are the steps -
		/// Retrieve workflowid of the process that was imported during test set up;
		/// Activate the workflow that was imported during test set up
		/// Retrieve an account id from the database
		/// Set process Id and stage id values on the account
		/// Retrieve contact id that is child of account 
		/// </summary>
		public void init()
		{
			_processId = AccountWorkflowId;

			RetrieveAccountContact();
			UpdateAccount();
		}

		[TestMethod]
		public void UnitTest_NavigateBusinessProcessFlowUnitTest()
		{
			//initialize
			init();

			//set parameters for the request
			NavigateToNextEntityRequest req = new NavigateToNextEntityRequest();
			req.CurrentEntityId = Guid.Parse(m_account[EntityIDNames.Account]);
			req.CurrentEntityLogicalName = "account";
			req.NextEntityId = Guid.Parse(m_contact[EntityIDNames.Contact]);
			req.NextEntityLogicalName = "contact";
			req.ProcessId = _processId;
			req.NewActiveStageId = new Guid(_contactStageId);
			req.NewTraversedPath = _contactTraversedPath;

			TestContext.BeginTimer("Business Process Flow Navigate test");
			try
			{
				//navigate to child contact
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Business Process Flow Navigate test");
		}

		#endregion

		#region Private Methods

		private void UpdateAccount()
		{
			try
			{
				//set processid and stage id values
				//update the crm account
				Microsoft.Xrm.Sdk.Query.ColumnSet attributes =
					new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "processid", "stageid" });

				//get the account in CRM
				Entity account = Proxy.Retrieve("account", new Guid(m_account["AccountId"]), attributes);
				//update account process and stage values
				account["processid"] = _processId;
				account["stageid"] = new Guid(_accountStageId);
				account["traversedpath"] = _accountTraversedPath;
				//update the account
				Proxy.Update(account);
			}
			catch (Exception e)
			{
				Trace.WriteLine("Exception updating the account in NavigateBusinessProcessFlowUnitTest - " + e.ToString());
				Trace.WriteLine(e.StackTrace);
				throw;
			}

		}

		private void RetrieveAccountContact()
		{
			//retrive an account
			m_account = RetrieveTestEntity(m_user, EntityNames.Accounts);

			//retrieve contact 
			m_contact = RetrieveTestEntity(m_user, EntityNames.Contacts);
		}

		#endregion
	}
}
