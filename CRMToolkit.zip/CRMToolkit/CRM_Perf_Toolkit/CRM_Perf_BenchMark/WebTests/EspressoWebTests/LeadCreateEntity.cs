﻿using System;
using System.Web;

namespace CRM_Perf_BenchMark
{
	public class me_LeadCreateEntity : me_CreateEntity
	{
		private const string CommandXmlTemplate = @"
			<Input>
				<id>{0}</id>
				<name>lead</name>
				<formId>e3b6ddb7-8df0-4410-ac7b-fd32e5053d38</formId>
				<dataxml>{1}</dataxml>
				<associations/>
			</Input>";

		public me_LeadCreateEntity()
			: base(EntityNames.Leads)
		{
		}

		public override string GetCommandXml()
		{
			var currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
			string data = EntityXmlHelper.GetCreateLeadXml(new Guid(user[EntityIDNames.User]), 8, Utils.GetRandomString(5, 30), Utils.GetRandomString(5, 30), currency);
			data = HttpUtility.HtmlEncode(data);
			return string.Format(CommandXmlTemplate, Guid.Empty, data);

		}
	}
}
