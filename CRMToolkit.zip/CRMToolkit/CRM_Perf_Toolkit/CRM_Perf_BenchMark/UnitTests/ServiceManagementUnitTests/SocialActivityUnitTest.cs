//-------------------------------------------------------------------------------
// <copyright file="SocialActivityUnitTest.cs" company="Microsoft">
//		Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//-------------------------------------------------------------------------------

namespace CRM_Perf_BenchMark.SocialActivity
{
	using Microsoft.Crm.Sdk.Messages;
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using Microsoft.Xrm.Sdk;
	using System;

	/// <summary>
	/// Unit Test to check SocialActivity to Case Flow
	/// </summary>
	[TestClass]
	public class SocialActivityUnitTests : UnitTestBase
	{
		//WorkFlow Id for creating Social Activity to Case which is imported through solution
		private Guid workFlowId = new Guid("543be873-0170-4857-8129-91d4a1b914bf");

		#region Additional test attributes

		// Use TestInitialize to run code before running each test 
		[TestInitialize()]
		public void TestInitialize()
		{
			base.Initialize();
		}

		#endregion

		#region Individual Test Cases

		[TestMethod()]
		public void SocialActivityToCaseTest()
		{
			String socialActivityName = "socialactivity";
			Entity socialActivity = new Entity(socialActivityName);
			socialActivity.Attributes["subject"] = "Test Case " + Utils.GetRandomString(5, 10);

			string socialHandle = "social handle" + Utils.GetRandomString(5, 10);
			string profileName = "profile name" + Utils.GetRandomString(5, 10);
			string profileLink = "profile link" + Utils.GetRandomString(5, 10);
			socialActivity.Attributes["socialadditionalparams"] = "{'targetEntityName':'incident', 'socialHandle':'" + socialHandle + "', 'profileName':'" + profileName + "', 'profilelink':'" + profileLink + "','community':'1', 'influencescore':'1.2', queueId:'" + null + "'}";
			Guid socialActivityId = Proxy.Create(socialActivity);

			//Executing WorkFlow to Create Case
			ExecuteWorkflowRequest request = new ExecuteWorkflowRequest()
			{
				WorkflowId = workFlowId
			};
			request.EntityId = socialActivityId;
			Proxy.Execute(request);
		}

		#endregion

	}
}
