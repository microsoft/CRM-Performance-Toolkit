﻿namespace CRM_Perf_BenchMark.CrmRequests.MobileClientRequests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	
	class ApplicationMetadataService_asmx_RetrieveUserContext : MobileClientRequest
	{
		private const string url = "/AppWebServices/ApplicationMetadataService.asmx/RetrieveUserContext";

		public ApplicationMetadataService_asmx_RetrieveUserContext(CRMEntity user)
			: base(url, user)
		{
			var jsonBodyWrapper = new JsonHttpBodyWrapper(
				new Dictionary<string, object>
				{
					{ "userContextRetrieveRequest", new Dictionary<string, object>
						{
							{ "Roles",  new List<string>() },
							{ "LastUserSyncTime", "1970-01-01T00:00:00.000Z" }
						} 
					}
				}
			);

			this.Method = "POST";
			this.Body = jsonBodyWrapper.Body;
		}
	}
}
