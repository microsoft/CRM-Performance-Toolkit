﻿using System;
using System.Diagnostics;
using System.ServiceModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting SocialInsightsConfiguration entity
	/// </summary>
	[TestClass]
	public class SocialInsightsConfigurationUnitTest : UnitTestBase
	{
		public const string SocialInsightsLogicalName = "socialinsightsconfiguration";
		public const string SystemFormLogicalName = "systemform";
		private const string ControlId = "control1";
		#region Social Insights Configuration Attributes
		private const string SocialInsightsConfigurationIdAttribute = "socialInsightsConfigurationId";
		private const string FormIdAttribute = "formid";
		private const string ControlIdAttribute = "controlid";
		private const string SocialDataItemIdAttribute = "socialdataitemid";
		private const string SocialDataParametersAttribute = "socialdataparameters";
		#endregion

		#region Attribute Values
		private static readonly Guid formId = new Guid("b053a39a-041a-4356-acef-ddf00182762b");
		#endregion

		#region Create a social insights entity
		/// <summary>
		/// Test creating a social insights configuration entity
		/// </summary>
		[TestMethod]
		public void UnitTest__Create_SocialInsightsConfiguration()
		{
			//create a social insights configuration entity
			Guid socialInsightsConfigurationId = Guid.Empty;
			Entity socialInsightsConfiguration = new Entity(SocialInsightsLogicalName);
			socialInsightsConfiguration[SocialInsightsConfigurationUnitTest.FormIdAttribute] = new EntityReference(SystemFormLogicalName, formId);
			socialInsightsConfiguration[SocialInsightsConfigurationUnitTest.ControlIdAttribute] = ControlId;
			socialInsightsConfiguration[SocialInsightsConfigurationUnitTest.SocialDataItemIdAttribute] = Utils.GetRandomString(5, 10);
			socialInsightsConfiguration[SocialInsightsConfigurationUnitTest.SocialDataParametersAttribute] = Utils.GetRandomString(5, 10);

			TestContext.BeginTimer("SocialInsightsConfiguration Create Unit Test");
			try
			{
				socialInsightsConfigurationId = Proxy.Create(socialInsightsConfiguration);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("SocialInsightsConfiguration Create Unit Test");

			//add the socialInsightsConfiguration instance to EMDB
			Guid ownerGuid = EntityManager.Instance.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(
				EntityNames.SocialInsightsConfiguration,
				ownerGuid,
				new string[]
				{
					"OwnerId",
					"SocialInsightsConfigurationId",
					"FormId",
					"ControlId",
					"SocialDataItemId",
					"SocialDataParameters",
					"EntityManagerOwningUser"
				},
				new string[]
				{
					m_user["systemuserid"],
					socialInsightsConfigurationId.ToString(),
					((EntityReference)socialInsightsConfiguration[SocialInsightsConfigurationUnitTest.FormIdAttribute]).Id.ToString(),
					socialInsightsConfiguration[SocialInsightsConfigurationUnitTest.ControlIdAttribute].ToString(),
					socialInsightsConfiguration[SocialInsightsConfigurationUnitTest.SocialDataItemIdAttribute].ToString(),
					socialInsightsConfiguration[SocialInsightsConfigurationUnitTest.SocialDataParametersAttribute].ToString(),
					ownerGuid.ToString()
				});
		}
		#endregion

		#region Retrieve a social insights entity
		/// <summary>
		/// Test retrieving a social insights configuration entity
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_SocialInsightsConfiguration()
		{
			CRMEntity retrieveTestEntity = RetrieveTestEntity(m_user, EntityNames.SocialInsightsConfiguration);
			ColumnSet attributes =
				new ColumnSet(
					new String[]
					{
						SocialInsightsConfigurationUnitTest.SocialDataItemIdAttribute,
						SocialInsightsConfigurationUnitTest.SocialDataParametersAttribute
					});

			TestContext.BeginTimer("SocialInsightsConfiguration Retrieve Unit Test");
			try
			{
				QueryByAttribute query = new QueryByAttribute(SocialInsightsLogicalName);
				query.AddAttributeValue(SocialInsightsConfigurationUnitTest.FormIdAttribute, formId);
				query.AddAttributeValue(SocialInsightsConfigurationUnitTest.ControlIdAttribute, ControlId);

				EntityCollection socialInsightsConfiguration = this.Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("SocialInsightsConfiguration Retrieve Unit Test");
		}
		#endregion

		#region Update a social insights entity
		/// <summary>
		/// Test retrieving and updating a social insights configuration entity
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_SocialInsightsConfiguration()
		{
			CRMEntity retrieveTestEntity = RetrieveTestEntity(m_user, EntityNames.SocialInsightsConfiguration);
			Entity socialInsightsConfiguration = new Entity(SocialInsightsLogicalName);
			ColumnSet attributes =
				new ColumnSet(
					new String[]
					{
						SocialInsightsConfigurationUnitTest.SocialDataItemIdAttribute,
						SocialInsightsConfigurationUnitTest.SocialDataParametersAttribute
					});

			socialInsightsConfiguration =
				Proxy.Retrieve(
					socialInsightsConfiguration.LogicalName,
					new Guid(retrieveTestEntity[SocialInsightsConfigurationUnitTest.SocialInsightsConfigurationIdAttribute]),
					attributes);

			socialInsightsConfiguration[SocialInsightsConfigurationUnitTest.SocialDataItemIdAttribute] = Utils.GetRandomString(10, 20);

			TestContext.BeginTimer("SocialInsightsConfiguration Update Unit Test");
			try
			{
				Proxy.Update(socialInsightsConfiguration);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("SocialInsightsConfiguration Update Unit Test");
		}
		#endregion

		#region Delete a social insights entity
		/// <summary>
		/// Test deleting a social insights configuration entity
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_SocialInsightsConfiguration()
		{
			CRMEntity retrieveTestEntity = RetrieveTestEntity(m_user, EntityNames.SocialInsightsConfiguration);

			TestContext.BeginTimer("SocialInsightsConfiguration Delete Unit Test");
			try
			{
				Proxy.Delete(
					SocialInsightsLogicalName,
					new Guid(retrieveTestEntity[SocialInsightsConfigurationUnitTest.SocialInsightsConfigurationIdAttribute]));
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("SocialInsightsConfiguration Delete Unit Test");

			EntityManager.Instance.DeleteEntity(retrieveTestEntity);
		}
		#endregion
	}
}
