﻿using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit Testcases for creating, updating, retrieving and deleting Account entity
	/// </summary>
	[TestClass]
	public class RetrieveChangeTest : UnitTestBase
	{
		private EntityCollection RetrieveEntityCollection = new EntityCollection();
		private EntityReferenceCollection RetrieveEntityReferenceCollection = new EntityReferenceCollection();

		[TestMethod]
		public void UnitTest__RetrieveChange_Account()
		{
			var changeRequest = new RetrieveEntityChangesRequest
			{
				EntityName = "account",
				DataVersion = "",
				PageInfo = new PagingInfo
				{
					Count = 5000,
					PageNumber = 1,
					PagingCookie = null
				},
				Columns = new ColumnSet()
			};

			var moreRecord = true;
			TestContext.BeginTimer("Retrieve Change UnitTest");
			while (moreRecord)
			{
				var changeResponse = (RetrieveEntityChangesResponse)Proxy.Execute(changeRequest);
				if (changeResponse.EntityChanges.Changes.Count > 0)
				{
					foreach (IChangedItem changeItem in changeResponse.EntityChanges.Changes)
					{
						if (changeItem.Type == ChangeType.NewOrUpdated)
						{
							Entity entity = ((NewOrUpdatedItem)changeItem).NewOrUpdatedEntity;
							RetrieveEntityCollection.Entities.Add(entity);
						}
						else if (changeItem.Type == ChangeType.RemoveOrDeleted)
						{
							EntityReference entityrefer = ((RemovedOrDeletedItem)changeItem).RemovedItem;
							RetrieveEntityReferenceCollection.Add(entityrefer);
						}
						else
						{
							Trace.WriteLine("WARNING : change type of retrieved data is not recognized ..");
						}
					}
				}
				// update pageinfo for next set of records //
				changeRequest.PageInfo.PageNumber++;
				changeRequest.PageInfo.PagingCookie = changeResponse.EntityChanges.PagingCookie;
				moreRecord = changeResponse.EntityChanges.MoreRecords;
			}
			Trace.WriteLine(string.Format("Retrieve Change Test for Account: {0}-{1}", ChangeType.NewOrUpdated, RetrieveEntityCollection.Entities.Count));
			Trace.WriteLine(string.Format("Retrieve Change Test for Account: {0}-{1}", ChangeType.RemoveOrDeleted, RetrieveEntityReferenceCollection.Count));
			TestContext.EndTimer("Retrieve Change UnitTest");

		}

	}
}
