﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit Testcases for creating, updating, retrieving and deleting Social Profiles entity
	/// </summary>
	[TestClass]
	public class RetrieveMultipleSocialProfileUnitTest : UnitTestBase
	{

		#region Retreive multiple socialProfile
		/// <summary>
		/// Retrieve multiple accounts
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_SocialProfile()
		{
			Entity socialprofile = new Entity("socialprofile");
			QueryExpression query = new QueryExpression("socialprofile");
			query.TopCount = 10;
			query.AddOrder("modifiedon", OrderType.Descending);
			query.ColumnSet.AddColumn("profilename");
			query.ColumnSet.AddColumn("community");
			query.ColumnSet.AddColumn("profilefullname");
			query.Criteria.AddCondition("modifiedon", ConditionOperator.LastXHours, 12);
			EntityCollection results;

			TestContext.BeginTimer("SocialProfile RetrieveMultiple UnitTest");
			try
			{
				results = Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("SocialProfile RetrieveMultiple UnitTest");
		}
		#endregion
	}
}
