﻿using System;
using System.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.WebTesting;
using System.Net;


namespace CRM_Perf_BenchMark
{
	public interface IUserManager
	{
		string RefreshAuthToken(string userName, string password, string orgName, string orgBaseUrl);
		void RefreshAllAuthTokens(string userStart, string userCount, string userBase, string userDomain, string password, string orgName, string orgBaseUrl);

		void SetAuthToken(WebTest webTest, string userName, string password, string orgName, string orgBaseUrl, string tokenExpirationTime, string token);
		void SetAuthToken(HttpWebRequest webRequest, string userName, string password, string orgName, string orgBaseUrl, string tokenExpirationTime, string token);
	}
}
