﻿namespace CRM_Perf_BenchMark
{
	public class me_OpportunityReadForm : me_ReadForm
	{
		public me_OpportunityReadForm()
			: base(EntityNames.Opportunities)
		{

		}
	}
}
