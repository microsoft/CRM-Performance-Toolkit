﻿using System;
using System.Text;
using System.Xml;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.ObjectModel;
using Microsoft.Exchange.WebServices.Data;
using System.Net.Mail;
using System.Net;
using System.Data;
using System.Data.SqlClient;


namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Test class for Incoming Load.
	/// </summary>
	[TestClass]
	public class IncomingEmailTests : UnitTestBase
	{
		private bool _sendToCurrentUser;
		public IncomingEmailTests()
			: base()
		{
			_sendToCurrentUser = false;
		}

		protected override Guid GetCurrentOrgId()
		{
			return EntityManager.Instance.GetRandomExchangeOrg();
		}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		[ClassInitialize()]
		public static void ClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
			}
		}
		#endregion

		/// <summary>
		/// Initialize override to avoid locking user.
		/// </summary>
		[TestInitialize]
		public override void Initialize()
		{
			TestContext.Properties.Add("EnabledForACT", 1);
			if (_sendToCurrentUser) //If we want to send email to current user, then let's call Initialize to retrive user.
			{
				base.Initialize();
			}
		}

		/// <summary>
		/// Send an email with zero attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithZeroAttachmentToActiveUser()
		{
			SendEmail(true, true, 0);
		}

		/// <summary>
		/// Send an email with one attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithOneAttachmentToActiveUser()
		{
			SendEmail(true, true, 1);
		}

		/// <summary>
		/// Send an email with two attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithTwoAttachmentToActiveUser()
		{
			SendEmail(true, true, 2);
		}

		/// <summary>
		/// Send an email with five attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithFiveAttachmentToActiveUser()
		{
			SendEmail(true, true, 5);
		}

		/// <summary>
		/// Send an email with zero attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithZeroAttachmentToInActiveUser()
		{
			SendEmail(true, false, 0);
		}

		/// <summary>
		/// Send an email with one attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithOneAttachmentToInActiveUser()
		{
			SendEmail(true, false, 1);
		}

		/// <summary>
		/// Send an email with two attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithTwoAttachmentToInActiveUser()
		{
			SendEmail(true, false, 2);
		}

		/// <summary>
		/// Send an email with five attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithFiveAttachmentToInActiveUser()
		{
			SendEmail(true, false, 5);
		}

		/// <summary>
		/// Send an email with zero attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithZeroAttachmentToQueue()
		{
			SendEmail(false, true, 0);
		}

		/// <summary>
		/// Send an email with one attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithOneAttachmentToQueue()
		{
			SendEmail(false, true, 1);
		}

		/// <summary>
		/// Send an email with two attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithTwoAttachmentToQueue()
		{
			SendEmail(false, true, 2);
		}

		/// <summary>
		/// Send an email with five attachment.
		/// </summary>
		/// <param></param>
		[TestMethod]
		public void IncomingMailWithFiveAttachmentToQueue()
		{
			SendEmail(false, true, 5);
		}

		#region private methods

		private void SendEmail(bool isUser, bool isActive, int attachmentCount)
		{
			Mailbox to = GetCRMConfiguredMailbox(isUser, isActive);
			Mailbox from = GetContact(to.OrgName);
			string ewsEndpoint = null;
			SendMail(from, to, out ewsEndpoint, attachmentCount);
			if (!string.IsNullOrEmpty(ewsEndpoint))
			{
				UpdateEmailServerAddressAfterAutoDiscover(from, ewsEndpoint);
			}
		}

		private Mailbox GetCRMConfiguredMailbox(bool isUser, bool isActive)
		{
			//Read only SQL call without any explicit lock.
			//First try with cached SQLConnection.
			string commandString = null;
			if (_sendToCurrentUser && isUser)
			{
				commandString =
								@"
								Select top 1 *
								from CRMMailbox
								where IsUser = @isUser and
								IsActive = @isActive and
								UserId = @userId
								order by NEWID();
							";
			}
			else
			{
				commandString =
								@"
								Select top 1 *
								from CRMMailbox
								where IsUser = @isUser and
								IsActive = @isActive
								order by NEWID();
							";
			}
			try
			{
				using (SqlConnection connection = new SqlConnection(GetConnectionString()))
				{
					connection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, connection))
					{
						SqlParameterCollection parameters = (SqlParameterCollection)sqlCommand.Parameters;
						parameters.AddWithValue("@isUser", isUser);
						parameters.AddWithValue("@isActive", isActive);
						if (_sendToCurrentUser && isUser)
						{
							parameters.AddWithValue("@userId", UserId);
						}
						SqlDataReader dataReader = sqlCommand.ExecuteReader();
						dataReader.Read();
						Mailbox to = new Mailbox();
						to.Id = (Guid)dataReader["UserId"];
						to.EmailAddress = (string)dataReader["EmailAddress"];
						to.EWSEndpoint = (string)dataReader["EndPoint"];
						to.Password = (string)dataReader["Password"];
						to.UseAutoDiscover = (bool)dataReader["useAutoDiscover"];
						to.OrgName = (string)dataReader["OrgName"];
						to.useSSL = (bool)dataReader["UseSSL"];
						return to;
					}
				}
			}
			catch (Exception)
			{
				//ToDo: Log Exception.

				//Waiting for 10 seconds.
				System.Threading.Thread.CurrentThread.Join(10 * 1000);

				using (SqlConnection connection = new SqlConnection(GetConnectionString()))
				{
					connection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, connection))
					{
						SqlParameterCollection parameters = (SqlParameterCollection)sqlCommand.Parameters;
						parameters.AddWithValue("@isUser", isUser);
						parameters.AddWithValue("@isActive", isActive);
						SqlDataReader dataReader = sqlCommand.ExecuteReader();
						dataReader.Read();
						Mailbox to = new Mailbox();
						to.Id = (Guid)dataReader["UserId"];
						to.EmailAddress = (string)dataReader["EmailAddress"];
						to.EWSEndpoint = (string)dataReader["EndPoint"];
						to.Password = (string)dataReader["Password"];
						to.UseAutoDiscover = (bool)dataReader["useAutoDiscover"];
						to.OrgName = (string)dataReader["OrgName"];
						to.useSSL = (bool)dataReader["UseSSL"];
						return to;
					}
				}
			}
		}

		private Mailbox GetContact(string orgName)
		{
			//Read only SQL call without any explicit lock.
			//First try with cached SQLConnection.
			string commandString = @"
										Select top 1 *
										from CRMContact
										where OrgName = @orgName
										order by NEWID();
									";

			try
			{
				using (SqlConnection connection = new SqlConnection(GetConnectionString()))
				{
					connection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, connection))
					{
						SqlParameterCollection parameters = (SqlParameterCollection)sqlCommand.Parameters;
						parameters.AddWithValue("@orgName", orgName);
						SqlDataReader dataReader = sqlCommand.ExecuteReader();
						dataReader.Read();
						Mailbox from = new Mailbox();
						from.Id = (Guid)dataReader["Id"];
						from.EmailAddress = (string)dataReader["EmailAddress"];
						from.EWSEndpoint = (string)dataReader["EndPoint"];
						from.Password = (string)dataReader["Password"];
						from.UseAutoDiscover = (bool)dataReader["useAutoDiscover"];
						from.OrgName = (string)dataReader["OrgName"];
						from.useSSL = (bool)dataReader["UseSSL"];
						return from;
					}
				}
			}
			catch (Exception)
			{
				//ToDo: Log Exception.

				//Waiting for 10 seconds.
				System.Threading.Thread.CurrentThread.Join(10 * 1000);

				using (SqlConnection connection = new SqlConnection(GetConnectionString()))
				{
					connection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, connection))
					{
						SqlParameterCollection parameters = (SqlParameterCollection)sqlCommand.Parameters;
						parameters.AddWithValue("@orgName", orgName);
						SqlDataReader dataReader = sqlCommand.ExecuteReader();
						dataReader.Read();
						Mailbox from = new Mailbox();
						from.Id = (Guid)dataReader["Id"];
						from.EmailAddress = (string)dataReader["EmailAddress"];
						from.EWSEndpoint = (string)dataReader["EndPoint"];
						from.Password = (string)dataReader["Password"];
						from.UseAutoDiscover = (bool)dataReader["useAutoDiscover"];
						from.OrgName = (string)dataReader["OrgName"];
						from.useSSL = (bool)dataReader["UseSSL"];
						return from;
					}
				}
			}
		}

		/// <summary>
		/// Send mail with attachment and get the autodiscovered URL if required.
		/// </summary>
		/// <param name="from"></param>
		/// <param name="to"></param>
		/// <param name="emailServerAddress"></param>
		/// <param name="attachmentCount"></param>
		private void SendMail(Mailbox from, Mailbox to, out string emailServerAddress, int attachmentCount)
		{
			ExchangeService service = new ExchangeService(Microsoft.Exchange.WebServices.Data.ExchangeVersion.Exchange2010);

			CredentialCache credCache = new CredentialCache();
			credCache.Add(new Uri(from.EWSEndpoint), "Basic", new NetworkCredential(from.EmailAddress, from.Password));
			service.Credentials = credCache;
			string domain = from.EmailAddress.Split(new string[] { "@" }, StringSplitOptions.RemoveEmptyEntries)[1];
			emailServerAddress = null;
			if (from.UseAutoDiscover)
			{
				if (!String.IsNullOrEmpty(from.EWSEndpoint))
				{
					service.Url = new Uri(from.EWSEndpoint);
				}
				else
				{
					service.AutodiscoverUrl(from.EmailAddress, (string val) => { return true; });
					emailServerAddress = service.Url.AbsoluteUri;
				}
			}
			else
			{
				service.Url = new Uri(from.EWSEndpoint);
			}

			EmailMessage msg = new EmailMessage(service);
			msg.ToRecipients.Add(to.EmailAddress);
			msg.Subject = EmailSubject + System.DateTime.Now.ToString();
			msg.Body = EmailBody;

			for (int i = 0; i < attachmentCount; i++)
			{
				msg.Attachments.AddFileAttachment("Attachment_" + (i + 1), new MemoryStream(Encoding.ASCII.GetBytes(EmailBody)));
			}

			Console.WriteLine("Sending email from {0} to {1}.", from.EmailAddress, to.EmailAddress);
			msg.Send();
		}

		/// <summary>
		/// Update the Incoming Load DB with autodiscovered URI.
		/// </summary>
		/// <param></param>
		private void UpdateEmailServerAddressAfterAutoDiscover(Mailbox fromMailBox, string ewsEndpoint)
		{
			string commandString = @"
									Update CRMContact
									Set EndPoint = @ewsEndpoint
									where EmailAddress = @emailAddress;
									";
			try
			{
				using (SqlConnection sqlConnection = new SqlConnection(GetConnectionString()))
				{
					sqlConnection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection))
					{
						sqlCommand.Parameters.AddWithValue("@ewsEndpoint", ewsEndpoint);
						sqlCommand.Parameters.AddWithValue("@emailAddress", fromMailBox.EmailAddress);
						sqlCommand.ExecuteNonQuery();
					}
				}
			}
			catch (Exception)
			{
				//Todo: Log exception.

				//Waiting for 10 seconds.
				System.Threading.Thread.CurrentThread.Join(10 * 1000);

				using (SqlConnection sqlConnection = new SqlConnection(GetConnectionString()))
				{
					sqlConnection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection))
					{
						sqlCommand.Parameters.AddWithValue("@ewsEndpoint", ewsEndpoint);
						sqlCommand.Parameters.AddWithValue("@emailAddress", fromMailBox.EmailAddress);
						sqlCommand.ExecuteNonQuery();
					}
				}
			}
		}

		/// <summary>
		/// Get the connection string otherwise thorws informative exception.
		/// </summary>
		/// <param></param>
		private static string GetConnectionString()
		{
			return ConfigSettings.Default.EMSQLCNN;
		}

		private object _emailBodyLock = new object();
		private string _emailBody;
		public string EmailBody
		{
			get
			{
				if (String.IsNullOrEmpty(_emailBody))
				{
					lock (_emailBodyLock)
					{
						if (String.IsNullOrEmpty(_emailBody))
						{
							_emailBody = "ServersideSyncIncoming " + GenerateAlphanumeric(50000);
						}
					}
				}
				return _emailBody;
			}
		}

		private Object _emailSubjectLock = new object();
		private string _emailSubject;
		public string EmailSubject
		{
			get
			{
				if (String.IsNullOrEmpty(_emailSubject))
				{
					lock (_emailSubjectLock)
					{
						if (String.IsNullOrEmpty(_emailSubject))
						{
							_emailSubject = "ServersideSyncIncoming " + GenerateAlphanumeric(5);
						}
					}
				}
				return _emailSubject;
			}
		}

		private Object _attachmentLock = new object();
		private MemoryStream _inMemoryAttachment_50KB;
		public MemoryStream InMemoryAttachment_50KB
		{
			get
			{
				if (_inMemoryAttachment_50KB == null)
				{
					lock (_attachmentLock)
					{
						if (_inMemoryAttachment_50KB == null)
						{
							_inMemoryAttachment_50KB = new MemoryStream(Encoding.ASCII.GetBytes(EmailBody));
						}
					}
				}
				return InMemoryAttachment_50KB;
			}
		}

		/// <summary>
		/// Get the random alpha numeric string.
		/// </summary>
		/// <param name="length"></param>
		private string GenerateAlphanumeric(int length)
		{
			string charSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890~!@#$%^&*()_+{}[]:;<,>.?";
			StringBuilder strBuilder = new StringBuilder();
			Random random = new Random();
			while (length > 0)
			{
				strBuilder.Append(charSet[(int)(random.NextDouble() * charSet.Length)]);
				--length;
			}
			return strBuilder.ToString();
		}

		#endregion

		/// <summary>
		/// Mailbox class to handle mailbox rows in Incoming Load DB.
		/// </summary>
		public sealed class Mailbox
		{
			public Guid Id { get; set; }
			public string EmailAddress { get; set; }
			public string EWSEndpoint { get; set; }
			public string Password { get; set; }
			public bool UseAutoDiscover { get; set; }
			public string OrgName { get; set; }
			public bool useSSL { get; set; }
		}
	}
}
