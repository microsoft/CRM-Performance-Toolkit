//-------------------------------------------------------------------------------
// <copyright file="CustomActivityToMultipleEntitiesUnitTest.cs" company="Microsoft">
//		Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//-------------------------------------------------------------------------------

namespace CRM_Perf_BenchMark.CustomActivityToMultipleEntities
{
	using Microsoft.Crm.Sdk.Messages;
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using Microsoft.Xrm.Sdk;
	using System;

	/// <summary>
	/// Unit Test to check CustomActivity to MultipleEntities Flow
	/// </summary>
	[TestClass]
	public class CustomActivityToMultipleEntitiesUnitTests : UnitTestBase
	{
		//WorkFlow Id for creating Custom Activity to MultipleEntities which is imported through solution
		private Guid workFlowId = new Guid("8565495f-a7d2-48a8-ade8-8ca22c33788a");

		#region Additional test attributes

		// Use TestInitialize to run code before running each test 
		[TestInitialize()]
		public void TestInitialize()
		{
			base.Initialize();
		}

		#endregion

		#region Individual Test Cases

		/// <summary>
		/// Test Case for Custom Activity to MultipleEntities
		/// </summary>
		[TestMethod()]
		public void CustomActivityToMultipleEntitiesTest()
		{
			String customActivityName = "new_customactivityentity";
			Entity customActivity = new Entity(customActivityName);
			customActivity.Attributes["subject"] = "Custom Activity To MultipleEntities " + Utils.GetRandomString(5, 10);

			Guid customActivityId = Proxy.Create(customActivity);

			//Executing WorkFlow to Create MultipleEntities
			ExecuteWorkflowRequest request = new ExecuteWorkflowRequest()
			{
				WorkflowId = workFlowId
			};
			request.EntityId = customActivityId;
			Proxy.Execute(request);
		}

		#endregion

	}
}
