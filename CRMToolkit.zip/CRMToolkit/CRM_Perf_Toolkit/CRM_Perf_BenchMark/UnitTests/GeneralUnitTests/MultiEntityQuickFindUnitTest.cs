﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CRM_Perf_BenchMark.UnitTests
{
	using System.Diagnostics;
	using System.IO;
	using System.ServiceModel;
	using System.Web.Services.Protocols;
	using Microsoft.Xrm.Sdk;

	[TestClass]
	public class MultiEntityQuickFindUnitTest : UnitTestBase
	{
	
		[TestMethod]
		public void UnitTest__MultiEntityQuickFindRequest()
		{
			OrganizationRequest req = new OrganizationRequest("executequickfind");
			req.Parameters.Add("SearchText", "b");
			req.Parameters.Add("EntityGroupName", "Mobile Client Search");

			//execute the ExecuteQuickFind request
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("MultiEntityQuickFind Unit Test");
			try
			{
				var resp = Proxy.Execute(req);
			}
			catch (FaultException<IOrganizationService> fe)
			{
				Trace.WriteLine(fe.Detail);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("MultiEntityQuickFind Unit Test");
			
		}
	}
}
