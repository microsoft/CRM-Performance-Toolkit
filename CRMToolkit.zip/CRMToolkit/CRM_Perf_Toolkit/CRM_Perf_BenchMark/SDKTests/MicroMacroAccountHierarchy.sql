SET NOCOUNT ON
DECLARE @MICRO_TEST_ENVIRONMENT BIT
DECLARE @HIERARCHY_IDENTIFIER VARCHAR(50)
DECLARE @MICRO_TEST_INPUT TABLE(MaxLevel INT, MaxChildren INT, IsProcessed BIT, ProcessingOrder INT)
DECLARE @MACRO_TEST_INPUT TABLE(MaxLevel INT, MaxChildren INT, IsProcessed BIT, ProcessingOrder INT)

--SET INPUT PARAMETERS
	--Set to 1 for creating hierarchy in micro test environment else 0 for macro test environment
	SET @MICRO_TEST_ENVIRONMENT = 0
	--Hierarchy identifier. Hierarchy format: HIERARCHY1 - LEVEL1
	SET @HIERARCHY_IDENTIFIER = 'HIERARCHY'
	--Input rows for number of hierarchies to be created in micro environment. Here is node structure and has 364 accounts
	--		(1 Node)				(3 Node)				(9 Node)			(27 Node)				(81 Node)				(243 Node)
	-- (HIERARCHY1 - Level1)->(HIERARCHY1 - Level2)->(HIERARCHY1 - Level3)->(HIERARCHY1 - Level4)->(HIERARCHY1 - Level5)->(HIERARCHY1 - Level6)
	INSERT INTO @MICRO_TEST_INPUT VALUES(6,3,0,1) 
	
	--Input rows for number of hierarchies to be created in macro environment. Here is node structure and has 1093 accounts
	--		(1 Node)				(3 Node)				(9 Node)			(27 Node)				(81 Node)				(243 Node)			(729 Node)
	-- (HIERARCHY1 - Level1)->(HIERARCHY1 - Level2)->(HIERARCHY1 - Level3)->(HIERARCHY1 - Level4)->(HIERARCHY1 - Level5)->(HIERARCHY1 - Level6)->(HIERARCHY1 - Level7)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,1)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,2)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,3)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,4)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,5)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,6)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,7)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,8)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,9)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,10)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,11)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,12)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,13)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,14)
	INSERT INTO @MACRO_TEST_INPUT VALUES(7,3,0,15)
--END OF INPUT PARAMETERS

DECLARE @ProcessingOrder INT
DECLARE @MaxChildren INT
DECLARE @MaxLevels INT
DECLARE @AccountsRequired INT
DECLARE @ParentIndex INT
DECLARE @ChildrenIndex INT
DECLARE @AccountGuid UNIQUEIDENTIFIER
DECLARE @ParentAccountGuid UNIQUEIDENTIFIER
DECLARE @Children INT
DECLARE @Level INT
DECLARE @Threshold INT
DECLARE @StartingIndex INT
DECLARE @Hierarchy TABLE ( 
	Id INT PRIMARY KEY NOT NULL IDENTITY,
	AccountGuid UNIQUEIDENTIFIER,
	ParentAccountGuid UNIQUEIDENTIFIER,
	HierarchyIdentifier VARCHAR(100),
	HierarchyLevel INT
	)

IF(@MICRO_TEST_ENVIRONMENT = 1) -- Micro test environment population
BEGIN

WHILE((SELECT COUNT(*) FROM @MICRO_TEST_INPUT WHERE IsProcessed = 0) > 0)
BEGIN

	-- Clean up 
	DELETE FROM @Hierarchy
	SELECT TOP 1 @MaxChildren = MaxChildren, @MaxLevels = MaxLevel, @ProcessingOrder = ProcessingOrder 
	FROM @MICRO_TEST_INPUT
	WHERE IsProcessed = 0
	ORDER BY ProcessingOrder ASC
	
	UPDATE @MICRO_TEST_INPUT SET IsProcessed = 1 WHERE ProcessingOrder = @ProcessingOrder

	SET @AccountsRequired = 1*(1- POWER(@MaxChildren, @MaxLevels))/(1-@MaxChildren)
	
	-- Don't include accounts which are already part of some hierarchy 
	-- and accounts with deletable key word
	;WITH NoParent(accountId, ParentAccountId, Name) AS 
	  (
		  SELECT accountId, ParentAccountId, Name
		  FROM AccountBase 
		  WHERE ParentAccountId IS NULL
		  AND Name NOT LIKE '%deletable%'
	  )
	  
	--Select required accounts to build hierarchy. Exclude accounts part of another hierarchy
	INSERT INTO @Hierarchy(AccountGuid)
	SELECT TOP (@AccountsRequired) n.accountId
	FROM NoParent n
	LEFT JOIN AccountBase a
	ON n.accountId = a.ParentAccountId 
	WHERE a.AccountId IS NULL
	
	--Algorithm to build account hierarchy
	SELECT @StartingIndex = MIN(Id) FROM @Hierarchy
	SET @ParentIndex = @StartingIndex
	SET @ChildrenIndex = @StartingIndex + 1
	SET @Level = 2
	SELECT @Threshold = @MaxChildren -- Initially set to no of children
	
	UPDATE @Hierarchy 
	SET HierarchyIdentifier = @HIERARCHY_IDENTIFIER+CONVERT(varchar(5),@ProcessingOrder)+' - LEVEL1',
		HierarchyLevel = 1
	WHERE Id = @StartingIndex 
			
	WHILE(@ChildrenIndex <= @AccountsRequired + @StartingIndex)
	BEGIN

		IF(@ChildrenIndex > @Threshold + @StartingIndex - 1)
		BEGIN
			SET @Level = @Level + 1
			SET @Threshold = 1*(1- POWER(@MaxChildren, @Level))/(1-@MaxChildren)
		END
		SELECT @ParentAccountGuid = AccountGuid 
		FROM @Hierarchy WHERE Id = @ParentIndex
		
		SET @Children = 1
		WHILE(@Children <= @MaxChildren)
		BEGIN
			UPDATE @Hierarchy 
			SET ParentAccountGuid = @ParentAccountGuid,
			HierarchyIdentifier = @HIERARCHY_IDENTIFIER+CONVERT(varchar(5),@ProcessingOrder)+' - LEVEL'+ CONVERT(varchar(5),@Level),
			HierarchyLevel = @Level
			WHERE Id = @ChildrenIndex
			
			--Update counters
			SET @Children = @Children + 1
			SET @ChildrenIndex = @ChildrenIndex + 1
		END
		
		--Update parent index
		SET @ParentIndex = @ParentIndex + 1
	END


	--Finally update account entity
	UPDATE act
	SET ParentAccountId = hrc.ParentAccountGuid, new_hierarchynodelevel = hrc.HierarchyIdentifier
	FROM AccountBase act
	JOIN @Hierarchy hrc
	ON act.AccountId = hrc.AccountGuid
	
END
END
ELSE  -- Macro test environment population
BEGIN
WHILE((SELECT COUNT(*) FROM @MACRO_TEST_INPUT WHERE IsProcessed = 0) > 0)
BEGIN

    -- Clean up 
	DELETE FROM @Hierarchy
	SELECT TOP 1 @MaxChildren = MaxChildren, @MaxLevels = MaxLevel, @ProcessingOrder = ProcessingOrder
	FROM @MACRO_TEST_INPUT
	WHERE IsProcessed = 0
	ORDER BY ProcessingOrder ASC
		
	UPDATE @MACRO_TEST_INPUT SET IsProcessed = 1 WHERE ProcessingOrder = @ProcessingOrder

	SET @AccountsRequired = 1*(1- POWER(@MaxChildren, @MaxLevels))/(1-@MaxChildren)
	
	-- Don't include accounts which are already part of some hierarchy 
	-- and accounts with deletable key word
	;WITH NoParent(accountId, ParentAccountId) AS 
	  (
		  SELECT accountId, ParentAccountId
		  FROM AccountBase a
		  INNER JOIN SystemUserRoles sr ON a.OwnerId = sr.SystemUserId 
		  INNER JOIN RoleBase r ON sr.RoleId = r.RoleId 
		  AND a.Name NOT LIKE '%deletable%'
		  AND a.ParentAccountId IS NULL
	  )
	  
	--Select some accounts from sales person role
	INSERT INTO @Hierarchy(AccountGuid)
	SELECT TOP (@AccountsRequired) n.accountId
	FROM NoParent n
	LEFT JOIN AccountBase a
	ON n.accountId = a.ParentAccountId 
	WHERE a.AccountId IS NULL
	ORDER BY NEWID()

	--Algorithm to build account hierarchy
	SELECT @StartingIndex = MIN(Id) FROM @Hierarchy
	SET @ParentIndex = @StartingIndex
	SET @ChildrenIndex = @StartingIndex + 1
	SET @Level = 2
	SET @Threshold = @MaxChildren -- Initially set to no of children
	
	UPDATE @Hierarchy 
	SET HierarchyIdentifier = @HIERARCHY_IDENTIFIER+CONVERT(varchar(5),@ProcessingOrder)+' - LEVEL1',
	HierarchyLevel = 1
	WHERE Id = @StartingIndex 
			
	WHILE(@ChildrenIndex <= (@AccountsRequired + @StartingIndex))
	BEGIN

		IF(@ChildrenIndex >= (@Threshold + @StartingIndex - 1))
		BEGIN
			SET @Level = @Level + 1
			SET @Threshold = 1*(1- POWER(@MaxChildren, @Level))/(1-@MaxChildren)
		END
		SELECT @ParentAccountGuid = AccountGuid 
		FROM @Hierarchy WHERE Id = @ParentIndex
		
		SET @Children = 1
		WHILE(@Children <= @MaxChildren)
		BEGIN
			UPDATE @Hierarchy 
			SET ParentAccountGuid = @ParentAccountGuid,
				HierarchyIdentifier = @HIERARCHY_IDENTIFIER+CONVERT(varchar(5),@ProcessingOrder)+' - LEVEL'+ CONVERT(varchar(5),@Level),
				HierarchyLevel = @Level
			WHERE Id = @ChildrenIndex
			
			--Update counters
			SET @Children = @Children + 1
			SET @ChildrenIndex = @ChildrenIndex + 1
		END
		
		--Update parent index
		SET @ParentIndex = @ParentIndex + 1
	END
	
	--Finally update account entity
	UPDATE act
	SET ParentAccountId = hrc.ParentAccountGuid , new_hierarchynodelevel = hrc.HierarchyIdentifier
	FROM AccountBase act
	JOIN @Hierarchy hrc
	ON act.AccountId = hrc.AccountGuid
	
	END
END
