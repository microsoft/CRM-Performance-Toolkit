﻿using System;
using System.Web;

namespace CRM_Perf_BenchMark
{
	public class me_TaskCreateEntity : me_CreateEntity
	{
		private const string CommandXmlTemplate = @"
		<Input>
			<id>{0}</id>
			<name>task</name>
			<formId>6356ff2a-bbbe-49fb-9da2-160b08865688</formId>
			<dataxml>{1}</dataxml>
			<associations/>
		</Input>";

		public me_TaskCreateEntity()
			: base(EntityNames.Tasks)
		{
		}

		public override string GetCommandXml()
		{
			var currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
			string data = EntityXmlHelper.GetCreateTaskXml(new Guid(user[EntityIDNames.User]), 8, new Guid(currency[EntityIDNames.TransactionCurrency]));
			data = HttpUtility.HtmlEncode(data);
			return string.Format(CommandXmlTemplate, Guid.Empty, data);
		}
	}
}
