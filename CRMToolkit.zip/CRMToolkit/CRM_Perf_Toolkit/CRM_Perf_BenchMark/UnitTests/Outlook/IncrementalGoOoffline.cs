using System;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Security.Permissions;
using System.Diagnostics;
using System.Collections.Generic;
using Microsoft.Win32;
using System.Xml;
using System.Web.Services.Protocols;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.WebTesting;
using Microsoft.Crm.Application.Outlook.OfflineSync;
//using OfflineSyncTestDriver;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Summary description for GoOfflineUT
	/// </summary>
	[TestClass]
	public class IncrementalGoOfflineUT : OutlookTestBaseClass
	{
		private BcpTransferDataProvider bcp = null;
		private PerfSync sync = null;
		private XmlDocument resultsDoc = null;
		private SyncDataRecorder sdr = null;

		public IncrementalGoOfflineUT()
		{
			System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:Ctor{0}", DateTime.Now.ToString()));
		}

		#region Additional test attributes

		[ClassInitialize()]
		public static void MyClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"outlooksyncdata\GoOffline"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"outlooksyncdata\GoOffline");
			}
			EntityManager.Instance.IsPerUserPerRun = true;
		}

		#endregion

		#region test init
		/// <summary>
		/// Initialize() is called once during test execution before
		/// test methods in this test class are executed.
		/// </summary>
		[TestInitialize()]
		public override void Initialize()
		{
			System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:Init {0}", DateTime.Now.ToString()));
			base.Initialize();
			System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:User {0} {1}", m_userName, DateTime.Now.ToString()));

			try
			{
				Guid OrganizationId = new Guid(m_user["organizationid"]);

				//we are going to see here if registry exists, if it does not then we are going to create the registry
				CreateRegistryForUser(m_nc);

				//MSCRMClient just needs one entry RCOffline == 0
				RegistryKey clientRegKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\MSCRMClient", true);
				if (clientRegKey == null)
				{
					clientRegKey = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\MSCRMClient");
					clientRegKey.SetValue("RCOffline", 0, RegistryValueKind.DWord);
					clientRegKey.SetValue("WebAppUrl", m_CrmServer, RegistryValueKind.String);
				}

				PT_ClientOrgInfo myPTClientOrgInfo = new PT_ClientOrgInfo(m_clientKeyPath);

				// create transfer data provider - don't need this anymore but registry get set wrong without fix then remove
				bcp = new BcpTransferDataProvider2(myPTClientOrgInfo);
				bcp.NetworkCredential = m_nc;

				sdr = new SyncDataRecorder();
				sync = new PerfSync(sdr);
				sync.ClientKeyPath = m_clientKeyPath;
				sync.ServiceCreator = serviceCreator;
				sync.MachineName = m_userName;
				sync.UserName = m_userName;
				sync.UserDomain = m_domain;
				sync.NetworkCredential = m_nc;
				sync.OrganizationId = OrganizationId;

				resultsDoc = new XmlDocument();
				resultsDoc.AppendChild(resultsDoc.CreateElement("run_result"));
			}

			catch (System.Web.Services.Protocols.SoapException ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("User {0} Soap Exception Detail: {1}", m_userName, ex.Detail.InnerXml));
				base.Cleanup();
				throw ex;
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("User {0}:Exception Message: {1}", m_userName, ex.Message));
				base.Cleanup();
				throw ex;
			}

		}
		#endregion

		#region test cleanup
		/// <summary>
		/// Cleanup() is called once during test execution after
		/// test methods in this class have executed unless the
		/// corresponding Initialize() call threw an exception.
		/// </summary>
		[TestCleanup()]
		public override void Cleanup()
		{
			//we need a valid user to run
			if (m_user == null)
				return;
			System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:Cleanup {0}", DateTime.Now.ToString()));

			base.Cleanup();

			XmlDocument docNode = resultsDoc.DocumentElement.OwnerDocument;
			XmlElement el;

			try
			{
				el = sdr.SerializeToXML(resultsDoc.DocumentElement.OwnerDocument);
				resultsDoc.DocumentElement.AppendChild(el);

				string fileName = string.Format("{0}_GoOffline_{1}.xml", m_userName, DateTime.Now.ToString());
				fileName = fileName.Replace(" ", "_");
				fileName = fileName.Replace("/", "_");
				fileName = fileName.Replace(":", "_");
				System.Diagnostics.Trace.WriteLine(fileName);
				resultsDoc.Save(string.Format("{0}\\GoOffline\\{1}", ConfigSettings.Default.OutlookSyncDir, fileName));
			}
			catch
			{
			}

			sync = null;
			bcp = null;
			sdr = null;
			resultsDoc = null;
		}
		#endregion

		#region Individual Test Cases

		[TestMethod]
		public void IncrementalGoOfflineTM()
		{
			//we need a valid user to run
			if (m_user == null)
				return;

			try
			{
				System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:SyncStart User: {0} {1}", m_userName, DateTime.Now.ToString()));
				TestContext.BeginTimer("GoOffline");
				if (m_user["crmticket"] != "")
				{
					DateTime expiration = DateTime.Parse(m_user["passportticketexpiration"]);
					string crmTicket = m_user["crmTicket"];

					if (DateTime.Now > expiration)
					{
						//If cookie has expired, request for new cookie, store in EMDB and retrieve it.
						crmTicket = EntityManager.Instance.UpdateCrmTicket(m_user);
					}
					sync.Sync(bcp, m_user["crmticket"]);
				}
				else
				{

					sync.Sync(bcp);
				}
				TestContext.EndTimer("GoOffline");
				System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:SyncEnd User: {0} {1}",m_userName, DateTime.Now.ToString()));
			}

			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:Exception: User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:Exception: User: {0} End Got SOAP exception", m_userName));
				throw e;
			}

			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:Exception: User: {0} Begin Got exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine(string.Format("IncrementalGoOfflineUT:Exception: User: {0} End Got exception", m_userName));
			}
		}
		#endregion

		#region Private Methods

		private void CreateRegistryForUser(System.Net.NetworkCredential m_nc)
		{
			string userId = m_user["systemuserid"];
			string businessId = m_user["businessunitid"];

			RegistryKey userRegKey = Registry.CurrentUser.OpenSubKey(m_clientKeyPath, true);
			if (userRegKey == null)
				userRegKey = Registry.CurrentUser.CreateSubKey(m_clientKeyPath);

			//we need to create - BusinessId, UserId, ServerUrl
			userRegKey.SetValue("BusinessId", "{" + businessId + "}", RegistryValueKind.String);
			userRegKey.SetValue("UserId", "{" + userId + "}", RegistryValueKind.String);
			userRegKey.SetValue("OrganizationId", "{" + m_user["organizationid"] + "}", RegistryValueKind.String);
			userRegKey.SetValue("ServerUrl", m_CrmServer + "/MSCRMServices", RegistryValueKind.String);
			//we need connection string
			userRegKey.SetValue("database", "Provider=SQLOLEDB;Data Source=" + System.Environment.MachineName + "\\CRM;Initial Catalog=MSCRM_MSDE;Integrated Security=SSPI", RegistryValueKind.String);
			userRegKey.SetValue("metabase", "Provider=SQLOLEDB;Data Source=" + System.Environment.MachineName + "\\CRM;Initial Catalog=METABASE;Integrated Security=SSPI", RegistryValueKind.String);
			userRegKey.SetValue("OfflineQueueDBConnection", "Provider=SQLOLEDB;Data Source=" + System.Environment.MachineName + "\\CRM;Initial Catalog=MSCRM_MSDE;Integrated Security=SSPI", RegistryValueKind.String);

			userRegKey.SetValue("OfflineUIDetails", 1, RegistryValueKind.DWord);
			userRegKey.SetValue("OfflineUIShowConfirmation", 0, RegistryValueKind.DWord);
			userRegKey.SetValue("OfflineRowsBatchSize", 100000, RegistryValueKind.DWord);
			userRegKey.SetValue("OfflineMaxRetryCount", 3, RegistryValueKind.DWord);
			userRegKey.SetValue("OfflineMinBatchTimeMilliSec", 10000, RegistryValueKind.DWord);
			userRegKey.SetValue("OfflineMaxBatchTimeMilliSec", 60000, RegistryValueKind.DWord);
			userRegKey.SetValue("OfflineIncreaseRate", 2, RegistryValueKind.DWord);
			userRegKey.SetValue("OfflineDecreaseRate", 2, RegistryValueKind.DWord);
			userRegKey.SetValue("OfflineSetOffline", 1, RegistryValueKind.DWord);
		}

		#endregion
	}
}
