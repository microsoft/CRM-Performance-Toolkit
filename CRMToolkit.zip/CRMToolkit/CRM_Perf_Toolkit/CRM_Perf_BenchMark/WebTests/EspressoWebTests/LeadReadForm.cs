﻿namespace CRM_Perf_BenchMark
{
	public class me_LeadReadForm : me_ReadForm
	{
		public me_LeadReadForm()
			: base(EntityNames.Leads)
		{

		}
	}
}
