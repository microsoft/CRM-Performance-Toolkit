﻿namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;
	using System.Collections;
	using System.Web;
	using CRM_Perf_BenchMark.CrmRequests.MobileClientRequests;
	using CRM_Perf_BenchMark.CrmRequests;
	using System.Linq;
	using System.Xml.Linq;

	/// <summary>
	/// Account Activity rollup
	/// 1.Open MoCA
	/// 2.Navigate to search page.
	/// 3.Insert search criteria in text box, select Account entity in filter dropdown and click on search button.
	/// 4.Click on any Account record from search results.
	/// 5.Navigate to Activities sub grid.
	/// 6.Click on Activities sub grid.
	/// </summary>
	public class MoCA_AccountActivityRollup : MobileClientWebTestBase
	{
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		private CRMEntity account;
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			account = RetrieveTestEntity(user, EntityNames.Accounts, null, true);
			// Account Activity rollup
			this.BeginTransaction("MoCA_AccountActivityRollup");

			// Search for the account
			var searchEntity = this.SearchEntity(EntityNames.Accounts, "Acc");
			while (searchEntity.MoveNext())
			{
				yield return searchEntity.Current;
			}

			// Open the account
			var childRequests = this.OpenEntity(EntityNames.Accounts);
			while (childRequests.MoveNext())
			{
				yield return childRequests.Current;
			}

			string basePath = "\\CrmRequests\\MobileClientRequests\\MoCA_AccountActivityRollup\\";

			var RetrieveMultipleRequest = new OrganizationServiceExecuteRequest(user, basePath + "MoCA_AccountActivityRollup_RetrieveMultipleRequest", new Dictionary<string, string> 
				{
					{"ACCOUNT_ID", account[EntityIDNames.Account]},
				});

			yield return PrepareRequest(RetrieveMultipleRequest);

			this.EndTransaction("MoCA_AccountActivityRollup");
			EntityManager.Instance.FreeEntity(account);
		}
	}
}