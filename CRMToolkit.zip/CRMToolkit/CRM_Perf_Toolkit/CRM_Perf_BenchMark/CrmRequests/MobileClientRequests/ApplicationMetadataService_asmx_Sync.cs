﻿namespace CRM_Perf_BenchMark.CrmRequests.MobileClientRequests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	
	public class ApplicationMetadataService_asmx_Sync : MobileClientRequest
	{
		// Endpoint URL
		private const string url = "/AppWebServices/ApplicationMetadataService.asmx/Sync";

		public ApplicationMetadataService_asmx_Sync(CRMEntity user)
			: base(url, user)
		{
			// 503 is an expected error case for this test
			this.ValidHttpStatusCodes.Add(HttpStatusCode.ServiceUnavailable);

			this.PostRequest += new EventHandler<PostRequestEventArgs>((sender, e) => 
			{ 
				if(e.Response.StatusCode == HttpStatusCode.ServiceUnavailable)
				{
					this.Outcome = Outcome.Pass;
				}
			});

			var jsonBodyWrapper = new JsonHttpBodyWrapper(
				new Dictionary<string, object>
			    {
			        { "applicationMetadataSyncRequest", new Dictionary<string, object>
			            {
			                { "ClientInfo",  new Dictionary<string, object> 
			                    {
			                        { "FormFactor", 1 }
			                    }
			                },
			                { "ApplicationMetadataUserContextJson", "" },
			                { "LastUserSyncTime", "1970-01-01T00:00:00.000Z" }
			            } 
			        }
			    }
			);

			this.Method = "POST";
			this.Body = jsonBodyWrapper.Body;
		}
	}
}
