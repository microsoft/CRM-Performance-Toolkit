﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;


namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	///help class that generates organization service proxy and initializes the related test properties
	/// </summary>
	class CWR_Help
	{
		CRMEntity m_user;
		string m_userName = string.Empty;
		string m_domain = string.Empty;
		string m_password = string.Empty;
		string m_organization = string.Empty;
		string m_crmticket = string.Empty;
		XrmServiceCreator serviceCreator = null;
		string m_CrmServer = string.Empty;
		string m_ApiServer = string.Empty;
		string m_discoveryServer = string.Empty;
		System.Collections.Hashtable m_Entities;
		string[] m_Props;
		public static string resultDir = Environment.SystemDirectory.Split(new char[] { '\\' }, 2)[0] + @"\PerfResult";

		//construct with the list of entities to be returned 
		//usage: if need to create account and contact Entities, the props parameter will be like {EntityName.Accounts, EntityName.Contacts} 
		//it also takes an optional parameter for returning an admin user
		public CWR_Help(string[] props, bool requireAdminRights = false)
		{
			m_Entities = new System.Collections.Hashtable();
			m_Props = props;
			//if results dir doesn't exist, create one
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
			}
			init(requireAdminRights);
		}

		/// <summary>
		/// constructor with list of entities and the entities's sub-property list
		/// </summary>
		/// <param name="props">props</param>
		/// <param name="requireAdminRights">requireAdminRights</param>
		public CWR_Help(Hashtable props, bool requireAdminRights = false)
		{
			m_Entities = new System.Collections.Hashtable();
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
			}
			init(props, requireAdminRights);
		}

		/// <summary>
		/// initialization of all the entities properties needed for test
		/// </summary>
		/// <param name="requireAdminRights">requireAdminRights</param>
		public void init(bool requireAdminRights)
		{
			EntityRequest er = new EntityRequest();
			er.Type = EntityNames.Users;
			er.ReturnAs = EntityNames.Users;
			er.ParentID = EntityManager.Instance.OrgId;

			System.Collections.Hashtable userProps = new System.Collections.Hashtable();
			if (requireAdminRights)
			{
				userProps.Add("role", "system administrator");
			}
			foreach (var item in m_Props)
			{
				EntityRequest req = new EntityRequest();
				req.Type = item.ToString();
				req.ParentID = new Guid();
				req.ReturnAs = item.ToString();
				userProps.Add(item.ToString(), new EntityRequest[] { req}); 
			}


			er.Props = userProps;
			m_Entities = EntityManager.Instance.GetEntities(er);

			m_user = (CRMEntity)m_Entities[EntityNames.Users];

			if (m_user == null)
			{
				m_user = EntityManager.Instance.GetNextUser();
			}

			string[] splits = m_user["domainname"].Split(new char[] { '\\' }, 2, StringSplitOptions.RemoveEmptyEntries);
			if (splits.Length > 1)
			{
				m_domain = splits[0];
				m_userName = splits[1];
			}

			m_CrmServer = m_user["CrmServer"];
			m_ApiServer = m_user["ApiServer"];
			m_discoveryServer = m_user["discoveryserver"];
			m_password = m_user["userpassword"];
			m_organization = m_user["organizationname"];
			string m_orgId = m_user["organizationid"];
			string key = m_orgId + "_" + m_user["domainname"];
			if (m_user["crmticket"] != "")
			{
				m_userName = m_user["passportname"];
				key = m_orgId + "_" + m_user["passportname"];
			}

			lock (EntityManager.Instance.UserXrmServiceTable)
			{
				if (EntityManager.Instance.UserXrmServiceTable.ContainsKey(key))
				{
					serviceCreator = (XrmServiceCreator)EntityManager.Instance.UserXrmServiceTable[key];
				}
				else
				{
					//if (m_user["crmticket"] != "")
					if (!string.IsNullOrEmpty(m_user["crmticket"]))
					{
						serviceCreator = new XrmServiceCreator(m_domain, m_userName, m_password, m_discoveryServer, m_organization, AuthenticationProviderType.LiveId, true);
					}
					else
					{
						serviceCreator = new XrmServiceCreator(m_domain, m_userName, m_password, m_CrmServer, m_organization, AuthenticationProviderType.ActiveDirectory, false);
					}

					if (null != serviceCreator.OrganizationService)
					{
						EntityManager.Instance.UserXrmServiceTable.Add(key, serviceCreator);
					}
					else
					{
						string msg = string.Format("The OrganizationService of XrmServiceCreator of key: " + key + " is NULL after retry for " + XrmServiceCreator.MaxRetry + " times");
						FileWriter.Instance.WriteToFile(msg);
						//    throw new NullReferenceException(msg);
					}
				} 
			}
		}

		
		/// <summary>
		/// initialzation of the all the entities properties needed for test
		/// individual entity can be queried based on specified criteria
		/// </summary>
		/// <param name="props">props</param>
		/// <param name="requireAdminRights">requireAdminRights</param>
		public void init(Hashtable props, bool requireAdminRights)
		{
			EntityRequest er = new EntityRequest();
			er.Type = EntityNames.Users;
			er.ReturnAs = EntityNames.Users;
			er.ParentID = EntityManager.Instance.OrgId;

			System.Collections.Hashtable userProps = new System.Collections.Hashtable();
			if (requireAdminRights)
				userProps.Add("role", "system administrator");

			foreach (var item in props.Keys)
			{
				EntityRequest req = new EntityRequest();
				req.Type = item.ToString();
				req.ParentID = Guid.NewGuid();
				req.ReturnAs = item.ToString();
				//get the specified criteria for the entity
				req.Props = (Hashtable)props[item];
				userProps.Add(item.ToString(), new EntityRequest[] { req });
			}


			er.Props = userProps;
			m_Entities = EntityManager.Instance.GetEntities(er);

			m_user = (CRMEntity)m_Entities[EntityNames.Users];

			if (m_user == null)
			{
				m_user = EntityManager.Instance.GetNextUser();
			}

			string[] splits = m_user["domainname"].Split(new char[] { '\\' }, 2, StringSplitOptions.RemoveEmptyEntries);
			if (splits.Length > 1)
			{
				m_domain = splits[0];
				m_userName = splits[1];
			}

			m_CrmServer = m_user["CrmServer"];
			m_ApiServer = m_user["ApiServer"];
			m_discoveryServer = m_user["discoveryserver"];
			m_password = m_user["userpassword"];
			m_organization = m_user["organizationname"];
			string m_orgId = m_user["organizationid"];
			string key = m_orgId + "_" + m_user["domainname"];
			if (m_user["crmticket"] != "")
			{
				m_userName = m_user["passportname"];
				key = m_orgId + "_" + m_user["passportname"];
			}

			lock (EntityManager.Instance.UserXrmServiceTable)
			{
				if (EntityManager.Instance.UserXrmServiceTable.ContainsKey(key))
				{
					serviceCreator = (XrmServiceCreator)EntityManager.Instance.UserXrmServiceTable[key];
				}
				else
				{
					if (m_user["crmticket"] != "")
					{
						int i = 0;
						do
						{
							serviceCreator = new XrmServiceCreator(m_domain, m_userName, m_password, m_discoveryServer, m_organization, AuthenticationProviderType.LiveId, true);
							i++;
						} while (i < XrmServiceCreator.MaxRetry && null == serviceCreator.OrganizationService);
					}
					else
					{
						serviceCreator = new XrmServiceCreator(m_domain, m_userName, m_password, m_CrmServer, m_organization, AuthenticationProviderType.ActiveDirectory, false);
					}

					if (null != serviceCreator.OrganizationService)
					{
						EntityManager.Instance.UserXrmServiceTable.Add(key, serviceCreator);
					}
					else
					{
						string msg = string.Format("The OrganizationService of XrmServiceCreator of key: " + key + " is NULL after retry for " + XrmServiceCreator.MaxRetry + " times");
						FileWriter.Instance.WriteToFile(msg);
						//    throw new NullReferenceException(msg);
					}
				} 
			}
		}

		/// <summary>
		/// retrieve the organization service proxy
		/// </summary>
		/// <returns>IOrganizationService</returns>
		public IOrganizationService getOrganizationServiceProxy()
		{
			return serviceCreator.OrganizationService;
		}

		/// <summary>
		/// retrieve all the entities needed for test
		/// </summary>
		/// <returns>Hashtable</returns>
		public System.Collections.Hashtable getEntities()
		{
			return m_Entities;
		}


	}
}
