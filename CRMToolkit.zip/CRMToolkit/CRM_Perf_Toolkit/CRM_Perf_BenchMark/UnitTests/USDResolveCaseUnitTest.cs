﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;
using System.Diagnostics;
using System.Globalization;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using System.Reflection;

namespace CRM_Perf_BenchMark.UnitTests
{

	[TestClass]
	public class UpdateIncident : UnitTestBase
	{

		/// <summary>
		/// Create a phone call
		/// </summary>
		[TestMethod()]
		public void UnitTest__UpdateIncident()
		{
			Entity incident = new Entity("incident");
			//find a non-deletable CRM Entity for update test
			CRMEntity m_incident = RetrieveTestEntity(m_user, EntityNames.Incidents);

			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "incidentid" });
			//// get the account in CRM
			incident = Proxy.Retrieve(incident.LogicalName, new Guid(m_incident["Incidentid"]), attributes);
			// //update account address city value
			incident["actualserviceunits"] = 109;
			//update the account
			try
			{
				Proxy.Update(incident);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}

			CloseIncidentRequest closeIncidentRequest = new CloseIncidentRequest();

			// Create the incident's resolution.
			Entity incidentResolution = new Entity("incidentresolution");
			incidentResolution.Attributes.Add("subject", "Resolved Sample CWR Incident");
			incidentResolution.Attributes.Add("incidentid", new EntityReference("incident", new Guid(m_incident["incidentid"])));

			try
			{
				Proxy.Create(incidentResolution);
			}
			catch (FaultException<IOrganizationService> fe1)
			{
				Trace.WriteLine(fe1.Detail);
				Trace.WriteLine(fe1.StackTrace);
				throw;
			}

			closeIncidentRequest.IncidentResolution = incidentResolution;

			//set the incident's status to problem solved
			OptionSetValue status = new OptionSetValue();
			status.Value = 5;
			closeIncidentRequest.Status = status;
			closeIncidentRequest.RequestName = "CloseIncident";

			//execute the associate request
			TestContext.BeginTimer("Close Incident Request Unit Test");
			try
			{
				Proxy.Execute(closeIncidentRequest);
			}
			catch (FaultException<IOrganizationService> fe3)
			{
				Trace.WriteLine(fe3.Detail);
				Trace.WriteLine(fe3.StackTrace);
				throw;
			}
			TestContext.EndTimer("Close Incident Request Unit Test");

			//update the status code in EMDB accordingly
			string[] prop = { "statecode" };
			string[] propvalue = { "1" };
			//EntityManager.Instance.UpdateEntity(ref m_incident, "incident", new Guid(m_incident["EntityManagerOwningUser"]), prop, propvalue, "incidentid", m_incident["incidentid"].ToString());
		}
	}
}




