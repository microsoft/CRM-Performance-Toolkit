﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class RetrieveAllEntitiesRequestUnitTest : UnitTestBase
	{
		#region Retrieve all entities request
		/// <summary>
		/// Test retrieving all entities request
		/// </summary>
		[TestMethod]
		public void UnitTest__RetrieveAllEntitiesRequestRequest()
		{
			Microsoft.Xrm.Sdk.Messages.RetrieveAllEntitiesRequest req = new Microsoft.Xrm.Sdk.Messages.RetrieveAllEntitiesRequest();
			req.EntityFilters = Microsoft.Xrm.Sdk.Metadata.EntityFilters.Entity;
			req.RetrieveAsIfPublished = true;
			TestContext.BeginTimer("RetrieveAllEntitiesRequest Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveAllEntitiesRequest Unit Test");
		}
		#endregion
	}
}
