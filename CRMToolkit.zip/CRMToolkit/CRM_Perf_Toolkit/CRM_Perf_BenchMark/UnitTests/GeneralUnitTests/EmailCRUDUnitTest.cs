﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting email entity
	/// </summary>
	[TestClass]
	public class EmailCRUDUnitTest : UnitTestBase
	{

		#region Create an email
		/// <summary>
		/// Test creating an email
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_email()
		{
			//create an email
			Guid emailId = Guid.Empty;
			Entity email = new Entity("email");
			email["subject"] = Utils.GetRandomString(5, 30);

			TestContext.BeginTimer("Email Create Unit Test");
			try
			{
				emailId = Proxy.Create(email);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			
			TestContext.EndTimer("Email Create Unit Test");
			
			//add the email to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Emails, g, new string[] { "OwnerId", "activityid", "EntityManagerOwningUser" }, new string[] { m_user["systemuserid"], emailId.ToString(), g.ToString() });

		}
		#endregion

		#region Retrieve an email
		/// <summary>
		/// Test retrieving an email
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_email()
		{
			Entity email = new Entity("email");
			CRMEntity m_email = RetrieveTestEntity(m_user, EntityNames.Emails);
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "subject" });
			TestContext.BeginTimer("Email Retrieve Unit Test");
			try
			{
				email = Proxy.Retrieve(email.LogicalName, new Guid(m_email["activityid"]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Email Retrieve Unit Test");
			
		}
		#endregion

		#region Update an email
		/// <summary>
		/// Test updating an email
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_email()
		{
			Entity email = new Entity("email");
			//find a CRM Entity for update test
			email["subject"] = Utils.GetRandomString(5, 30);
			Guid emailId = Proxy.Create(email);
			
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "subject" });
			//get the email in CRM
			email = Proxy.Retrieve(email.LogicalName, emailId, attributes);
			//update email address city value

			email["subject"] = Utils.GetRandomString(5, 10);
			//update the email
			TestContext.BeginTimer("Email Update Unit Test");
			try
			{
				Proxy.Update(email);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Email Update Unit Test");
			
		}
		#endregion

		#region Delete an email
		/// <summary>
		/// test deleting an email
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_email()
		{
			//create an email for deletion
			Entity email = new Entity("email");
			email["subject"] = Utils.GetRandomString(5, 30);
			Guid emailId = Proxy.Create(email);

			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Email Delete Unit Test");
			try
			{
				Proxy.Delete("email", emailId);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Email Delete Unit Test");

		}
		#endregion

		#region Retrieve multiple emails
		/// <summary>
		///testing retrieve multiple email records
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_email()
		{
			Entity email = new Entity("email");
			var queryExpression = new QueryExpression()
			{
				Distinct = false,
				EntityName = email.LogicalName,
				ColumnSet = new ColumnSet("activityid"),

				Criteria =
				{
					Filters = 
						{
							new FilterExpression
							{
								FilterOperator = LogicalOperator.And,
								Conditions = 
								{
								   
								},
							},

							new FilterExpression
							{
								FilterOperator = LogicalOperator.Or,
								Conditions =
								{
								}
							}
							
						   
						}
				}
			};


			EntityCollection results;
			TestContext.BeginTimer("Email RetrieveMultiple Unit Test");
			try
			{
				results = Proxy.RetrieveMultiple(queryExpression);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Email RetrieveMultiple Unit Test");

		}
		#endregion

	}
}
