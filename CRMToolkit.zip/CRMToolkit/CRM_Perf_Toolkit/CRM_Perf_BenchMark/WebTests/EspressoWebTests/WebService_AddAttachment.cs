﻿using System.Collections.Generic;
using CRM_Perf_BenchMark;
using CRM_Perf_BenchMark.Espresso;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace CRM_Perf_Benchmark
{
	public class WebService_AddAttachment : EspressoWebServiceTestBase
	{
		public WebService_AddAttachment()
			: base()
		{
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			var account = RetrieveTestEntity(user, EntityNames.Accounts);

			string parentEntityId = account[EntityIDNames.Account];
			int parentEntityOtc = 1;
			string fileName = "TestAddAttachment_MacroTesting.txt";
			string base64EncodedContents = "dGVzdGluZyAxMjMgdGVzdGluZw==";
			string mimeType = "text/plain";
			this.BeginTransaction(EspressoTransactionNames.WebService_AddAttachment);
			yield return this.Execute(() => new MobileExpressWebService().AddAttachment(parentEntityId, parentEntityOtc, fileName, base64EncodedContents, mimeType));
			this.EndTransaction(EspressoTransactionNames.WebService_AddAttachment);
		}

		protected override void ResponseValidator(object sender, ValidationEventArgs e)
		{
			// HTTP Status code is checked by default validator, no need for any more validation in this call.
		}
	}
}
