﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using CRM_Perf_BenchMark.Utilities;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting task entity
	/// </summary>
	[TestClass]
	public class ExchangeTaskCRUDUnitTest : CreateBasicExchangeEntityBaseTest
	{
		/// <summary>
		/// Entity used to query EMDB for the entity data
		/// </summary>
		public override string EntityName
		{
			get { return EntityNames.ExchangeTask; }
		}

		/// <summary>
		/// Overide for to print the entity Data
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public override string PrintEntityData(Entity entity)
		{
			return String.Format("attributes are task subject. Subject={0} ", entity["subject"].ToString());
		}

		/// <summary>
		/// Test creating a task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create__ExchangeTask()
		{
			Init();
			string contactId;
			string timer = "Exchange Task Create Unit Test";
			Entity task = new Entity("task");            
			task["subject"] = Utils.GetRandomString(5, 10) + " exchange update";
			contactId = this.CreateEntityInExchange(task, timer);
			Guid g = EntityManager.Instance.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.ExchangeTask, g, new string[] { "OwnerId", "ExchangeID", "EntityManagerOwningUser", "Subject" }, new string[] { m_user["systemuserid"], contactId, g.ToString(), task.Attributes["subject"].ToString() });
		}        

		/// <summary>
		/// test retrieving and updating a Task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_ExchangeTask()
		{
			//find a Entity for update test
			string timerName = "Update Exchange Task";
			Init("subject", "exchange update");
			this.UpdateEntityInExchange(this.EntityName, m_contact, timerName, Utils.GetRandomString(5, 10) + " exchange update");
		}
		
		/// <summary>
		/// test deleting an task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_ExchangeTask()
		{
			//find a Entity for update test
			string timerName = "Update Exchange Contact";
			Init("subject", "exchange del");
			this.DeleteEntityInExchange(this.EntityName, m_contact, timerName);
			EntityManager.Instance.DeleteEntity(m_contact);
		}
	}
}
