﻿using System;
using System.Web;

namespace CRM_Perf_BenchMark
{
	public class me_LeadEditEntity : me_EditEntity
	{
		private const string CommandXmlTemplate =
			@"<Input>
				<id>{0}</id>
				<name>lead</name>
				<formId>63aca3b7-723a-4118-9c47-ea8c361143bb</formId>
				<dataxml>
					<lead>
						<description>{1}</description>
					</lead>
				</dataxml>
				<associations/>
			</Input>";

		public me_LeadEditEntity()
			: base(EntityNames.Leads)
		{
		}

		public override string GetCommandXml(Guid editEntity)
		{
			var data = string.Format(CommandXmlTemplate, editEntity.ToString("B"), Utils.GetRandomString(5, 10));
			data = HttpUtility.HtmlEncode(data);
			return data;
		}
	}
}
