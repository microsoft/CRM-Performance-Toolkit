﻿namespace CRM_Perf_BenchMark
{
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System;
	using System.Collections;
	using System.Collections.Generic;
	using System.Data.SqlClient;
	using System.Diagnostics;
	using System.IO;
	using System.Net;
	using System.Text;
	using System.Text.RegularExpressions;
	using System.Threading;
	using System.Web;
	using System.Web.Services.Protocols;
	using System.Xml;

	internal class Rexp
	{
		// NOTE - the below are simplified version of rfc 2046 specification
		// X: Y
		// Y = z(;|\n)z(;|\n)z
		// z = text | a = b
		public static string reText = @"[\w0-9./_<>=-]+";
		public static string reSep = @"(;|\r\n)+";
		public static string reLHS = @"(\w+\s*)";
		public static string reRHS = @"(""" + reText + @""")";
		public static string reStmt = reLHS + "=" + reRHS;
		public static string reZ = "(" + reText + "|" + reStmt + ")+";
		public static string reY = "(" + reZ + @"\s*" + reSep + @"\s*" + ")+";
		public static string reXY = reText + @"\s*:\s*" + reY; // complex, consumes lots of time :(
		public static string reSimpleXY = reText + @"\s*:\s*.+" + reSep;
	}

	internal class MhtmlBlock
	{
		public string contentID;
		public string rawData;
		public string rawContent;

		public MhtmlBlock(string d)
		{
			rawData = d;
			_parseContentHeader();
			_getRawContent();
		}

		private void _parseContentHeader()
		{
			// extract the information (Content-ID) from the header
			string reContentID = @"Content-ID\s*:\s*" + Rexp.reText;
			Match m = Regex.Match(rawData, reContentID);
			if (m.Success)
			{
				contentID = m.Value;
				contentID = contentID.Substring(contentID.IndexOf("<")).Trim().TrimStart("<".ToCharArray()).TrimEnd(">".ToCharArray());
			}
			else
			{
				throw new Exception("No Content ID found");
			}
		}

		private void _getRawContent()
		{
			int i, l;
			Regex re = new Regex(Rexp.reSimpleXY);
			Match m = re.Match(rawData);
			do
			{
				string x = m.Value;
				i = m.Index;
				l = m.Length;
				m = m.NextMatch();
				if (!m.Success)
				{
					rawContent = rawData.Substring(i + l).Trim();
					break;
				}
			} while (m.Success);
		}
	}

	public sealed class ExecuteMultipleTestSettings
	{
		private int m_maxThreads = 1;
		public int MaxThreads
		{
			get { return m_maxThreads; }
			internal set { m_maxThreads = value; }
		}
		private int m_batchSize = 10;
		public int BatchSize
		{
			get { return m_batchSize; }
			internal set { m_batchSize = value; }
		}
		private int m_totalEntities = 10;
		public int TotalEntities
		{
			get { return m_totalEntities; }
			internal set { m_totalEntities = value; }
		}
	}

	public class WRPCInfo
	{
		public string token;
		public long timeStamp;
	}

	[Serializable]
	public class CrmDelRequest : CrmRequest
	{
		public CrmDelRequest(string url)
			: base(url)
		{
		}

		public CrmDelRequest(string url, CRMEntity user)
			: base(url, user)
		{
		}

		public CrmDelRequest(Uri uri)
			: base(uri)
		{
		}

		public override void CrmRequest_ValidateResponse(object sender, ValidationEventArgs e)
		{
			e.IsValid = true;

			if (e.Response.StatusCode != HttpStatusCode.OK)
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString == null)
			{
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString.Contains("<title>Microsoft CRM Application Error Report</title>"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString.Contains("<title>Microsoft CRM Platform Error Report</title>"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			// redirects in CRM indicate an error.  "Found" is the code you get after being redirected.
			if (e.Response.StatusCode == HttpStatusCode.Found)
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.ResponseUri.AbsolutePath.Contains("errorhandler.aspx"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString.Contains("<details>Exception from HRESULT:"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			lastResponse = e.Response;
			return;
		}
	}

	public class Utils
	{
		/// <summary>
		/// Combine UrlPath
		/// </summary>
		/// <param name="path1"></param>
		/// <param name="path2"></param>
		/// <returns></returns>
		public static string UrlPathCombine(string baseUrl, string relativeUrl)
		{
			baseUrl = baseUrl.EndsWith("/") ? baseUrl : string.Format("{0}/", baseUrl);
			relativeUrl = relativeUrl.StartsWith("/") ? relativeUrl.TrimStart('/') : relativeUrl;
			var uri = new Uri(new Uri(baseUrl), relativeUrl);
			return uri.ToString();
		}

		//added another function to get WPRCTokento support multi server scenario
		public static WRPCInfo GenerateWRPCToken()
		{
			WRPCInfo rpcInfo = new WRPCInfo();
			rpcInfo.timeStamp = DateTime.UtcNow.Ticks;
			rpcInfo.token = "";
			return rpcInfo;
		}

		//this functions replace the server name with the server name from crm server
		//we are assuming url is like http://perf1web:5555/test.asmx and crmserver is like http://perf5web
		public static string ReplaceServerName(string url, CRMEntity user)
		{
			var uri = new Uri(url);
			url = Utils.UrlPathCombine(user["OrganizationBaseUrl"], uri.AbsolutePath);
			return url;
		}

		/// <summary>
		/// This is used to route generated client proxies to crm:\\
		/// </summary>
		/// <param name="client"></param>
		public static WebClientProtocol RouteSoapClientToAppWebServiceCrmPrefix(WebClientProtocol client)
		{
			if (client != null)
			{
				string urlSetting = System.Configuration.ConfigurationManager.AppSettings["urlkey"];
				// Do this only if urlkey wasn't defined
				if (string.IsNullOrEmpty(urlSetting))
				{
					const string urlPrefixToReplace = "http://localhost";
					var prefixIndex = client.Url.IndexOf(urlPrefixToReplace);
					if (prefixIndex >= 0)
					{
						client.Url = Utils.UrlPathCombine("crm://DummyBaseAddress/AppWebServices", client.Url.Substring(prefixIndex + urlPrefixToReplace.Length));
					}
				}
			}

			return client;
		}

		public static string GetRandomString(int minLen, int maxLen)
		{

			int alphabetLength = Alphabet.Length;
			int stringLength;
			lock (m_randLock) { stringLength = m_randomInstance.Next(minLen, maxLen); }
			char[] str = new char[stringLength];

			// max length of the randomizer array is 5
			int randomizerLength = (stringLength > 5) ? 5 : stringLength;

			int[] rndInts = new int[randomizerLength];
			int[] rndIncrements = new int[randomizerLength];

			// Prepare a "randomizing" array
			for (int i = 0; i < randomizerLength; i++)
			{
				int rnd = m_randomInstance.Next(alphabetLength);
				rndInts[i] = rnd;
				rndIncrements[i] = rnd;
			}

			// Generate "random" string out of the alphabet used
			for (int i = 0; i < stringLength; i++)
			{
				int indexRnd = i % randomizerLength;
				int indexAlphabet = rndInts[indexRnd] % alphabetLength;
				str[i] = Alphabet[indexAlphabet];

				// Each rndInt "cycles" characters from the array, 
				// so we have more or less random string as a result
				rndInts[indexRnd] += rndIncrements[indexRnd];
			}
			return (new string(str));
		}

		public static double GetRandomDouble()
		{
			return (m_randomInstance.NextDouble());
		}

		public static string GetRandomNumber(int min, int max)
		{
			return (m_randomInstance.Next(min, max)).ToString();
		}

		public static int GetRandomInt()
		{
			return (m_randomInstance.Next());
		}

		public static int GetRandomInt(int min, int max)
		{
			return (m_randomInstance.Next(min, max));
		}

		public static string GetRandomPhoneNumber()
		{
			int area_code, first3, last4;

			lock (m_randLock)
			{
				area_code = 100 + m_randomInstance.Next(899);
				first3 = 100 + m_randomInstance.Next(899);
				last4 = m_randomInstance.Next(9999);
			}

			return string.Format("({0:D3}) {1:D3}-{2:D4}", area_code, first3, last4);
		}

		public static XmlReader GetXmlReaderForXmlElement(string xmlStr)
		{
			var settings = new XmlReaderSettings();
			settings.XmlResolver = null;
			settings.DtdProcessing = DtdProcessing.Prohibit;
			return XmlReader.Create(xmlStr, settings);
		}

		public static XmlReader GetXmlReaderForXmlFile(string xmlFilePath)
		{
			var settings = new XmlReaderSettings();
			settings.XmlResolver = null;
			settings.DtdProcessing = DtdProcessing.Prohibit;
			return XmlReader.Create(xmlFilePath, settings);
		}

		private static char[] Alphabet = ("ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz0123456789").ToCharArray();
		private static Random m_randomInstance = new Random();
		private static Object m_randLock = new object();
	}


	[Serializable]
	public class SqlRequest : WebTestRequest
	{
		public SqlRequest(string url)
			: base(url)
		{
			this.Url = ConfigSettings.Default.ReportServer + this.Url;
			this.ParseDependentRequests = false;
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}

		public SqlRequest(Uri uri)
			: base(uri)
		{
			// IMPORTANT:  if we come in through this constructor (typically used in the WSDL hijacking (crmrequest.GetResponse())
			// check to see if the uri prefix is crm (again, this is used to enable the WSDL hijacking).  If so, convert it to				// http              
			Url = Url.Replace("crm://", "http://");

			this.ParseDependentRequests = false;
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}

		public void RequestTypePost()
		{
			formBody = new FormPostHttpBody();
			Method = "POST";
			Body = formBody;
		}

		public QueryStringParameter AddQueryStringParameter(string name, string value)
		{
			QueryStringParameter p = new QueryStringParameter();
			QueryStringParameters.Add(p);
			p.Name = name;
			p.Value = value;
			return p;
		}

		public void AddFormParameter(string name, string value)
		{
			// if we haven't been here yet, allocate the FormPostHttpBody
			// ASSUME:  if we set a form parameter, we must be doing a POST
			if (formBody == null)
			{
				formBody = new FormPostHttpBody();
				Method = "POST";
				Body = formBody;
			}
			formBody.FormPostParameters.Add(new FormPostParameter(name, value));
		}

		public virtual void CrmRequest_ValidateResponse(object sender, ValidationEventArgs e)
		{
			e.IsValid = true;

			if (e.Response.StatusCode != HttpStatusCode.OK)
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString == null)
			{
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString.Contains("<title>Microsoft CRM Application Error Report</title>"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString.Contains("<title>Microsoft CRM Platform Error Report</title>"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			// redirects in CRM indicate an error.  "Found" is the code you get after being redirected.
			if (e.Response.StatusCode == HttpStatusCode.Found || e.Response.StatusCode == HttpStatusCode.Redirect)
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.ResponseUri.AbsolutePath.Contains("errorhandler.aspx"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			lastResponse = e.Response;
		}

		public WebTestResponse lastResponse = null;
		protected FormPostHttpBody formBody = null;
	}

	[Serializable]
	public class SPRequest : WebTestRequest
	{
		//we should not call into this after we move to multi server
		public SPRequest(string url)
			: base(url)
		{
			this.ParseDependentRequests = false;
			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}

		public SPRequest(string url, CRMEntity user)
			: base(url)
		{
			this.Url = Utils.UrlPathCombine(user["OrganizationBaseUrl"], url);
			this.ParseDependentRequests = false;

			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}

		public SPRequest(string url, CRMEntity user, string siteURL)
			: base(url)
		{
			this.Url = siteURL + url;

			this.ParseDependentRequests = false;
			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}

		public SPRequest(string url, CRMEntity user, string siteURL, string entityName)
			: base(url)
		{
			this.Url = siteURL + "/" + entityName + url;

			this.ParseDependentRequests = false;
			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}

		public SPRequest(Uri uri)
			: base(uri)
		{
			// IMPORTANT:  if we come in through this constructor (typically used in the WSDL hijacking (crmrequest.GetResponse())
			// check to see if the uri prefix is crm (again, this is used to enable the WSDL hijacking).  If so, convert it to http
			Url = Url.Replace("crm://", "http://");

			this.ParseDependentRequests = false;
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}

		public void RequestTypePost()
		{
			formBody = new FormPostHttpBody();
			Method = "POST";
			Body = formBody;
		}

		public QueryStringParameter AddQueryStringParameter(string name, string value)
		{
			QueryStringParameter p = new QueryStringParameter();
			QueryStringParameters.Add(p);
			p.Name = name;
			p.Value = value;

			return p;
		}

		public QueryStringParameter AddQueryStringParameter(string name, string value, bool UrlEncoded)
		{
			QueryStringParameter p = new QueryStringParameter();
			QueryStringParameters.Add(p);
			p.Name = name;
			p.Value = value;
			p.UrlEncode = true;
			return p;
		}

		public void AddFormParameter(string name, string value)
		{
			// if we haven't been here yet, allocate the FormPostHttpBody
			// ASSUME:  if we set a form parameter, we must be doing a POST
			if (formBody == null)
			{
				formBody = new FormPostHttpBody();
				Method = "POST";
				Body = formBody;
			}
			formBody.FormPostParameters.Add(new FormPostParameter(name, value));
		}

		public virtual void CrmRequest_ValidateResponse(object sender, ValidationEventArgs e)
		{
			e.IsValid = true;

			if (e.Response.StatusCode != HttpStatusCode.OK)
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString == null)
			{
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString.Contains("<title>Microsoft CRM Application Error Report</title>"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.BodyString.Contains("<title>Microsoft CRM Platform Error Report</title>"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			// redirects in CRM indicate an error.  "Found" is the code you get after being redirected.
			if (e.Response.StatusCode == HttpStatusCode.Found || e.Response.StatusCode == HttpStatusCode.Redirect)
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			if (e.Response.ResponseUri.AbsolutePath.Contains("errorhandler.aspx"))
			{
				e.IsValid = false;
				lastResponse = e.Response;
				return;
			}

			lastResponse = e.Response;
		}

		public WebTestResponse lastResponse = null;
		protected FormPostHttpBody formBody = null;
	}

	[Serializable]
	public class crmRequestFactory : System.Net.IWebRequestCreate
	{
		public WebRequest Create(Uri uri)
		{
			return (new crmrequest(uri));
		}

		public crmRequestFactory()
		{

		}
	}

	[Serializable]
	public class crmrequest : WebRequest
	{
		public crmrequest(Uri uri)
		{
			m_uri = uri;
			m_cocStream = new copyoncloseStream();
			m_whc = new WebHeaderCollection();
		}

		public override string Method
		{
			get
			{
				return (m_method);
			}
			set
			{
				m_method = value;
			}
		}

		public override Uri RequestUri
		{
			get
			{
				return (m_uri);
			}
		}

		public override WebHeaderCollection Headers
		{
			get
			{
				return m_whc;
			}
			set
			{
				m_whc = value;
			}
		}

		public override long ContentLength
		{
			get
			{
				return (m_cl);
			}
			set
			{
				m_cl = value;
			}
		}

		public override string ContentType
		{
			get
			{
				return (m_ct);
			}
			set
			{
				m_ct = value;
			}
		}

		public override ICredentials Credentials
		{
			get
			{
				return (m_cred);
			}
			set
			{
				m_cred = value;
			}
		}

		public override bool PreAuthenticate
		{
			get
			{
				return (m_preauth);
			}
			set
			{
				m_preauth = value;
			}
		}

		public override System.IO.Stream GetRequestStream()
		{
			return (m_cocStream);
		}

		public override WebResponse GetResponse()
		{
			// Copy on close stream snaps the SOAP body off the stream on close.  Access it here to setup a WebTestRequest that we'll
			// throw back to the caller (we get here from SoapHttpClientProtocol::Invoke).
			// Didn't necessarily like to use exceptions here, but it was the only straightforward way I could find.

			WebTestRequest wtr = new CrmRequest(RequestUri);
			wtr.Method = Method;

			// TODO: find out more about this setting
			wtr.Cache = false;
			for (int i = 0; i < Headers.Count; i++)
			{
				wtr.Headers.Add(new WebTestRequestHeader(Headers.Keys[i], Headers[i]));
			}

			UTF8Encoding utf8 = new UTF8Encoding();
			string foo = utf8.GetString(m_cocStream.ba, 0, (int)m_cocStream.length);

			StringHttpBody body = new StringHttpBody();
			body.BodyString = foo;
			body.ContentType = ContentType;
			wtr.Body = body;
			throw new crmException(wtr);
		}

		public override int Timeout
		{
			get
			{
				return (m_to);
			}
			set
			{
				m_to = value;
			}
		}

		public override string ConnectionGroupName
		{
			get
			{
				return (m_cgn);
			}
			set
			{
				m_cgn = value;
			}
		}

		private string m_method;
		private Uri m_uri;
		private WebHeaderCollection m_whc;
		private long m_cl;
		private string m_ct;
		private ICredentials m_cred;
		private bool m_preauth;
		private copyoncloseStream m_cocStream;
		private int m_to;
		private string m_cgn;
	}

	[Serializable]
	public class copyoncloseStream : MemoryStream
	{
		public override void Close()
		{
			ba = GetBuffer();
			length = Length;
			base.Close();
		}
		public byte[] ba;
		public long length;
	}

	[Serializable]
	public class crmException : Exception
	{
		public crmException(WebTestRequest wtr)
		{
			this.wtr = wtr;
		}
		public WebTestRequest wtr;
	}

	//<summary>
	//Currently implemented as a set of simple text operations, based off of
	//the code in remotecommand.js
	//Should there be a need to move this to a proper XmlDocument, etc. I don't see
	//any difficulties
	//</summary>

	public class CrmSoapBody
	{
		private const string soapHead =
			@"<?xml version=""1.0"" encoding=""utf-8"" ?>
						<soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
						<soap:Body>";

		// need that space before the xmlns attribute!
		private const string cmdNS = @" xmlns=""http://www.microsoft.com/BusinessSolutions/Crm/2.0/WebServices""";

		public CrmSoapBody()
		{
			sbParams = new StringBuilder();
		}
		private string m_cmdName;
		private StringBuilder sbParams;
	}

	public class GetContextHtml_Helper
	{
		public static void ServiceRelatedInformation(out RelatedInformation.Context cntx, out string formXml, out string formSubmitId)
		{
			cntx = new RelatedInformation.Context();
			cntx.TabIndex = 1280;

			cntx.FormObjectType = 4214;
			cntx.FormId = new Guid("00000000-0000-0000-0000-000000000000");
			cntx.FormType = RelatedInformation.FormType.Main;

			RelatedInformation.LookupList lookupList = new RelatedInformation.LookupList();
			lookupList.CategoryId = "Category_Lookup";
			lookupList.CssClass = "CategoryData_Lookup";
			lookupList.DisplayName = "Look Up Records";
			lookupList.OrderIndex = 20;
			lookupList.LookupTypes = new int[] { 4001 };

			RelatedInformation.CustomerPreferencesListCategory cplc = new RelatedInformation.CustomerPreferencesListCategory();
			cplc.CategoryId = "Category_CustomerPreferredServices";
			cplc.CssClass = "CategoryData";
			cplc.DisplayName = "Customer Preferred";
			cplc.OrderIndex = 1;
			cplc.ObjectType = 4001;
			cplc.DependantFieldNames = new string[] { "customers" };
			cplc.GridEmptyMessageResourceId = "RelatedInformation_NoPreference";
			cplc.TargetObjectType = -1;
			cplc.DisplayAttribute = "name";
			cplc.DisplayField = "preferredserviceid";
			cplc.ValueField = "preferredserviceid";
			cplc.PreferenceType = RelatedInformation.CustomerPreferenceType.Services;
			cplc.ObjectTypes = "4001";

			RelatedInformation.TipsCategory tc = new RelatedInformation.TipsCategory();
			tc.CategoryId = "CategoryTips";
			tc.CssClass = "CategoryData";
			tc.DisplayName = "Tips";
			tc.OrderIndex = 100;
			tc.DisplayText = "To see whether the customer prefers a specific service, select Service from the Form Assistant list. Preferences are stored on the Administration tab in account and contact records.";

			object[] objects = new object[3];
			objects[0] = (object)lookupList;
			objects[1] = (object)cplc;
			objects[2] = (object)tc;
			cntx.Items = objects;

			cntx.ContextId = "serviceid";
			cntx.ControlId = "serviceid";
			cntx.DisplayName = "Service";
			cntx.OrderIndex = 1010;

			formXml = "&#60;serviceappointment&#62;&#60;subject&#62;asdf&#60;&#47;subject&#62;&#60;serviceid type&#61;&#34;4001&#34; name&#61;&#34;Branch &#38;&#35;58&#59; 474 - 37893019749 - Discount Bicycle Specialists&#34;&#62;&#123;0265D471-1D8C-DD11-91DF-00155DA14208&#125;&#60;&#47;serviceid&#62;&#60;statuscode name&#61;&#34;Requested&#34;&#62;1&#60;&#47;statuscode&#62;&#60;scheduledstart&#62;2008-10-07T12&#58;00&#58;00&#60;&#47;scheduledstart&#62;&#60;scheduleddurationminutes&#62;60&#60;&#47;scheduleddurationminutes&#62;&#60;scheduledend&#62;2008-10-07T13&#58;00&#58;00&#60;&#47;scheduledend&#62;&#60;isalldayevent&#62;0&#60;&#47;isalldayevent&#62;&#60;ownerid type&#61;&#34;8&#34; name&#61;&#34;CRM user1&#34;&#62;&#123;D8913708-1D8C-DD11-91DF-00155DA14208&#125;&#60;&#47;ownerid&#62;&#60;prioritycode name&#61;&#34;Normal&#34;&#62;1&#60;&#47;prioritycode&#62;&#60;isbilled name&#61;&#34;&#34;&#62;false&#60;&#47;isbilled&#62;&#60;statecode name&#61;&#34;Open&#34;&#62;Open&#60;&#47;statecode&#62;&#60;isworkflowcreated name&#61;&#34;&#34;&#62;false&#60;&#47;isworkflowcreated&#62;&#13;&#10;&#60;&#47;serviceappointment&#62;";
			formXml = HttpUtility.HtmlDecode(formXml);
			formSubmitId = null;
		}
	}

	public class EntityXmlHelper
	{
		public static string GetCreateAccountWithCustomAttributesXml(Guid ownerid, int owneridtype, string name, Guid currencyId)
		{
			try
			{
				string accountStr = "<account><name>" + name + "</name><transactioncurrencyid type=\"9105\">" + currencyId.ToString("B") + "</transactioncurrencyid><new_attribute1>" + Utils.GetRandomString(5, 8) + "</new_attribute1><new_attribute2 name=\"label1\">" + Utils.GetRandomNumber(100000001, 100000004) + "</new_attribute2><new_attribute3>0</new_attribute3><new_attribute4>" + Utils.GetRandomNumber(1, 10) + "</new_attribute4><new_attribute5>" + Utils.GetRandomInt(1, 10) + "</new_attribute5><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><creditonhold>0</creditonhold><preferredcontactmethodcode name=\"Any\">1</preferredcontactmethodcode><donotemail>0</donotemail><donotbulkemail>0</donotbulkemail><donotphone>0</donotphone><donotfax>0</donotfax><donotpostalmail>0</donotpostalmail><donotsendmm>0</donotsendmm><isprivate name=\"\">false</isprivate><donotbulkpostalmail name=\"\">false</donotbulkpostalmail><merged name=\"\">false</merged><shippingmethodcode>1</shippingmethodcode><address2_shippingmethodcode>1</address2_shippingmethodcode><address2_addresstypecode>1</address2_addresstypecode><accountratingcode>1</accountratingcode><participatesinworkflow name=\"\">false</participatesinworkflow><territorycode>1</territorycode><customersizecode>1</customersizecode><address2_freighttermscode>1</address2_freighttermscode><statecode name=\"Active\">Active</statecode><accountclassificationcode>1</accountclassificationcode><businesstypecode>1</businesstypecode></account>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(accountStr);
				return accountStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateCompetitorXml(string name, CRMEntity currency)
		{
			try
			{
				string accountStr = "<competitor><name>" + name + "</name><transactioncurrencyid type=\"9105\" name=\"US Dollar\">" + currency["transactioncurrencyid"] + "</transactioncurrencyid><address2_shippingmethodcode>1</address2_shippingmethodcode><address1_shippingmethodcode>1</address1_shippingmethodcode><address2_addresstypecode>1</address2_addresstypecode><address1_addresstypecode>1</address1_addresstypecode></competitor>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(accountStr);
				return accountStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateAccountXml(Guid ownerid, int owneridtype, string name, CRMEntity currency)
		{
			try
			{
				string accountStr = "<account><name>" + name + "</name><transactioncurrencyid type=\"9105\" name=\"" + currency["currencyname"] + "\">{" + currency["transactioncurrencyid"] + "}</transactioncurrencyid><ownerid type=\"" + owneridtype + "\">" + ownerid.ToString("B") + "</ownerid><creditonhold>0</creditonhold><preferredcontactmethodcode name=\"Any\">1</preferredcontactmethodcode><donotemail>0</donotemail><donotbulkemail>0</donotbulkemail><donotphone>0</donotphone><donotfax>0</donotfax><donotpostalmail>0</donotpostalmail><donotsendmm>0</donotsendmm><isprivate name=\"\">false</isprivate><donotbulkpostalmail name=\"\">false</donotbulkpostalmail><merged name=\"\">false</merged><shippingmethodcode>1</shippingmethodcode><address2_shippingmethodcode>1</address2_shippingmethodcode><address2_addresstypecode>1</address2_addresstypecode><accountratingcode>1</accountratingcode><participatesinworkflow name=\"\">false</participatesinworkflow><territorycode>1</territorycode><customersizecode>1</customersizecode><address2_freighttermscode>1</address2_freighttermscode><statecode name=\"Active\">Active</statecode><accountclassificationcode>1</accountclassificationcode><businesstypecode>1</businesstypecode></account>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(accountStr);
				return accountStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateQueueXml(Guid ownerid, int owneridtype, string name)
		{
			try
			{
				string accountStr = "<queue><name>" + name + "</name><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid>";
				string temp = "<incomingemailfilteringmethod>0</incomingemailfilteringmethod><incomingemaildeliverymethod>0</incomingemaildeliverymethod><outgoingemaildeliverymethod>0</outgoingemaildeliverymethod><allowemailcredentials>false</allowemailcredentials><transactioncurrencyid name=\"US Dollar\" type=\"9105\">{8A9B2CF6-A173-E111-A566-002264A0B07A}</transactioncurrencyid><ignoreunsolicitedemail name=\"\">false</ignoreunsolicitedemail><statecode name=\"Active\">Active</statecode><queuetypecode name=\"\">1</queuetypecode><isfaxqueue name=\"\">false</isfaxqueue></queue>";
				accountStr = accountStr + temp;
				XmlDocument test = new XmlDocument();
				test.LoadXml(accountStr);
				return accountStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateQueueOriginalXml(Guid ownerid, int owneridtype)
		{
			try
			{
				string accountStr = "<queue><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid>";
				string temp = "<transactioncurrencyid name=\"US Dollar\" type=\"9105\">{8A9B2CF6-A173-E111-A566-002264A0B07A}</transactioncurrencyid><emailrouteraccessapproval name=\"\">0</emailrouteraccessapproval><ignoreunsolicitedemail name=\"\">false</ignoreunsolicitedemail><statecode name=\"Active\">Active</statecode><allowemailcredentials name=\"\">false</allowemailcredentials><incomingemailfilteringmethod name=\"\">0</incomingemailfilteringmethod><queuetypecode name=\"\">1</queuetypecode><incomingemaildeliverymethod name=\"\">0</incomingemaildeliverymethod><outgoingemaildeliverymethod name=\"\">0</outgoingemaildeliverymethod><isfaxqueue name=\"\">false</isfaxqueue></queue>";
				accountStr = accountStr + temp;
				XmlDocument test = new XmlDocument();
				test.LoadXml(accountStr);
				return accountStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetAssignAccountXml(Guid ownerid, int owneridtype)
		{
			try
			{
				string accountStr = "<account><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid></account>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(accountStr);
				return accountStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetAssignContactXml()
		{
			try
			{
				string contactStr = "<contact></contact>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(contactStr);
				return contactStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetAssignOpportunityXml()
		{
			try
			{
				string opportunityStr = "<opportunity></opportunity>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(opportunityStr);
				return opportunityStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetAssignIncidentXml()
		{
			try
			{
				string incidentStr = "<incident></incident>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(incidentStr);
				return incidentStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateAnnotationXml(Guid objectid, int objectidtypecode, Guid ownerid, int owneridtypecode)
		{
			StringBuilder annotationStr = new StringBuilder();
			annotationStr.Append("<annotation><isdocument>0</isdocument><notetext>");
			annotationStr.Append(Utils.GetRandomString(10, 15));
			annotationStr.Append("</notetext><objectid>");
			annotationStr.Append(objectid.ToString("B"));
			annotationStr.Append("</objectid><objecttypecode>");
			annotationStr.Append(objectidtypecode.ToString());
			annotationStr.Append("</objecttypecode><subject>");
			annotationStr.Append(Utils.GetRandomString(10, 15));
			annotationStr.Append("</subject><ownerid type='");
			annotationStr.Append(owneridtypecode.ToString());
			annotationStr.Append("'>");
			annotationStr.Append(ownerid.ToString("B"));
			annotationStr.Append("</ownerid></annotation>");
			XmlDocument test = new XmlDocument();
			try
			{
				//verify the xml is in the right format
				test.LoadXml(annotationStr.ToString());
			}
			catch (XmlException e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				throw e;
			}
			return annotationStr.ToString();
		}

		public static string GetCreateAppointmentXml(Guid requiredattendeeid, int requiredattendeetypecode, Guid ownerid, int owneridtypecode)
		{
			try
			{
				DateTime sysEnd = System.DateTime.Now + System.TimeSpan.FromMinutes(30);

				string appointmentStr = "<appointment><subject>" + ExchangeSyncLoadMapper.CreateAppointmentAppendable() + Utils.GetRandomString(5, 10) + "</subject><requiredattendees><activityparty><partyid type=\"" + requiredattendeetypecode.ToString() + "\">" + requiredattendeeid.ToString("B") + "</partyid></activityparty></requiredattendees><statuscode name=\"Busy\">5</statuscode><scheduledstart>" + DateTime.Now.ToString("s") + "</scheduledstart><scheduleddurationminutes>30</scheduleddurationminutes><scheduledend>" + sysEnd.ToString("s") + "</scheduledend><isalldayevent>0</isalldayevent><description>" + Utils.GetRandomString(10, 30) + "</description><ownerid type=\"" + owneridtypecode.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><organizer><activityparty><partyid type=\"" + owneridtypecode.ToString() + "\">" + ownerid.ToString("B") + "</partyid></activityparty></organizer></appointment>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(appointmentStr);
				return appointmentStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateCampaignXml(Guid ownerid, int owneridtype)
		{
			try
			{
				string campaignStr = "<campaign><name>" + Utils.GetRandomString(5, 10) + "-" + System.DateTime.Now.ToString() + "</name><statuscode>0</statuscode><codename>" + Utils.GetRandomString(5, 10) + "</codename><typecode>1</typecode><expectedresponse>" + Utils.GetRandomNumber(1, 100) + "</expectedresponse><objective>" + Utils.GetRandomString(10, 15) + "</objective><description>" + Utils.GetRandomString(50, 60) + "</description><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid></campaign>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(campaignStr);
				return campaignStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateCampaignResponseActivityXml(Guid ownerid, int owneridtype, Guid regardingobjectid, int regardingobjectidtype, int channeltypecode, CRMEntity currency)
		{
			try
			{
				StringBuilder sb = new StringBuilder();
				sb.Append("<campaignresponse><receivedon>");
				sb.Append(System.DateTime.Today);
				sb.Append("</receivedon>");
				sb.Append(@"<regardingobjectid type=""");
				sb.Append(regardingobjectidtype);
				sb.Append(@""" name=""");
				sb.Append(Utils.GetRandomString(2, 5));
				sb.Append(@""">");
				sb.Append(regardingobjectid.ToString("B"));
				sb.Append("</regardingobjectid><responsecode>1</responsecode><subject>");
				sb.Append(Utils.GetRandomString(5, 10));
				sb.Append("</subject>");
				sb.Append(@"<ownerid type=""8"" name=""CRM&#32;user1"">");
				sb.Append(ownerid.ToString("B"));
				sb.Append("</ownerid><prioritycode>1</prioritycode>");
				sb.Append(@"<transactioncurrencyid name=""US Dollar"" type=""9105"">{");
				sb.Append(currency[EntityIDNames.TransactionCurrency]);
				sb.Append("}</transactioncurrencyid>");
				sb.Append(@"<isworkflowcreated name="""">false</isworkflowcreated>");
				sb.Append(@"<isregularactivity name="""">false</isregularactivity>");
				sb.Append(@"<isbilled name="""">false</isbilled>");
				sb.Append(@"<statecode name=""Open"">Open</statecode>");
				sb.Append(@"<activitytypecode name=""Campaign Response"">4401</activitytypecode>");
				sb.Append(@"<actualdurationminutes formattedvalue=""30"">30</actualdurationminutes>");
				sb.Append("</campaignresponse>");
				string campaignactStr = sb.ToString();
				XmlDocument test = new XmlDocument();
				test.LoadXml(campaignactStr);
				return campaignactStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateCampaignActivityXml(Guid ownerid, int owneridtype, Guid regardingobjectid, int regardingobjectidtype, int channeltypecode, CRMEntity currency)
		{
			try
			{
				string campaignactStr = "<campaignactivity><regardingobjectid type=\"" + regardingobjectidtype.ToString() + "\">" + regardingobjectid.ToString("B") + "</regardingobjectid><statuscode>1</statuscode><channeltypecode>" + channeltypecode.ToString() + "</channeltypecode><typecode>1</typecode><subject>" + Utils.GetRandomString(10, 15) + "</subject><description>" + Utils.GetRandomString(50, 60) + "</description><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><transactioncurrencyid type=\"" + currency["transactioncurrencyidtype"] + "\">" + currency["transactioncurrencyid"] + "</transactioncurrencyid><prioritycode>1</prioritycode><isbilled name=\"\">false</isbilled><isworkflowcreated name=\"\">false</isworkflowcreated><donotsendonoptout name=\"\">true</donotsendonoptout><ignoreinactivelistmembers name=\"\">true</ignoreinactivelistmembers><statecode name=\"Open\">Open</statecode><actualdurationminutes formattedvalue=\"\">30</actualdurationminutes></campaignactivity>";

				XmlDocument test = new XmlDocument();
				test.LoadXml(campaignactStr);
				return campaignactStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}


		public static string GetCreateCampaignActivityXml(Guid ownerid, int owneridtype, Guid regardingobjectid, int regardingobjectidtype, int channeltypecode)
		{
			try
			{
				string campaignactStr = "<campaignactivity><regardingobjectid type=\"" + regardingobjectidtype.ToString() + "\">" + regardingobjectid.ToString("B") + "</regardingobjectid><statuscode>1</statuscode><channeltypecode>" + channeltypecode.ToString() + "</channeltypecode><typecode>1</typecode><subject>" + Utils.GetRandomString(10, 15) + "</subject><description>" + Utils.GetRandomString(50, 60) + "</description><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><prioritycode>1</prioritycode><isbilled name=\"\">false</isbilled><isworkflowcreated name=\"\">false</isworkflowcreated><donotsendonoptout name=\"\">true</donotsendonoptout><ignoreinactivelistmembers name=\"\">true</ignoreinactivelistmembers><statecode name=\"Open\">Open</statecode><actualdurationminutes formattedvalue=\"\">30</actualdurationminutes></campaignactivity>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(campaignactStr);
				return campaignactStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateContactWithCustomAttributesXml(Guid ownerid, int owneridtype, string lastname, string firstname, Guid currencyId)
		{
			try
			{
				string contactStr = "<contact><lastname>" + lastname + "</lastname><transactioncurrencyid type=\"9105\">" + currencyId.ToString("B") + "</transactioncurrencyid><new_attribute1>" + Utils.GetRandomString(5, 8) + "</new_attribute1><new_attribute2>" + Utils.GetRandomNumber(100000001, 100000004) + "</new_attribute2><new_attribute3>0</new_attribute3><new_attribute4>" + Utils.GetRandomNumber(1, 100).ToString() + "</new_attribute4><new_attribute5>" + Utils.GetRandomNumber(1, 100).ToString() + "</new_attribute5><new_attribute6>" + Utils.GetRandomNumber(1, 100).ToString() + "</new_attribute6><new_attribute7>" + Utils.GetRandomNumber(1, 100).ToString() + "</new_attribute7><new_attribute8>" + Utils.GetRandomString(30, 60) + "</new_attribute8><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><creditonhold>0</creditonhold><preferredcontactmethodcode name=\"Any\">1</preferredcontactmethodcode><donotemail>0</donotemail><donotbulkemail>0</donotbulkemail><donotphone>0</donotphone><donotfax>0</donotfax><donotpostalmail>0</donotpostalmail><donotsendmm>0</donotsendmm><preferredappointmenttimecode name=\"Morning\">1</preferredappointmenttimecode><customersizecode>1</customersizecode><participatesinworkflow name=\"\">false</participatesinworkflow><haschildrencode>1</haschildrencode><educationcode>1</educationcode><territorycode>1</territorycode><address2_addresstypecode>1</address2_addresstypecode><isbackofficecustomer name=\"\">false</isbackofficecustomer><address2_shippingmethodcode>1</address2_shippingmethodcode><customertypecode>1</customertypecode><donotbulkpostalmail name=\"\">false</donotbulkpostalmail><leadsourcecode>1</leadsourcecode><merged name=\"\">false</merged><statecode name=\"Active\">Active</statecode><address2_freighttermscode>1</address2_freighttermscode><isprivate name=\"\">false</isprivate><shippingmethodcode>1</shippingmethodcode></contact>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(contactStr);
				return contactStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateContactXml(Guid ownerid, int owneridtype, string lastname, string firstname, CRMEntity currency)
		{
			try
			{
				string contactStr = "<contact><firstname>" + firstname + "</firstname><lastname>" + lastname + "</lastname><transactioncurrencyid type=\"9105\">" + currency["transactioncurrencyid"] + "</transactioncurrencyid><ownerid type=\"" + owneridtype + "\">" + ownerid.ToString("B") + "</ownerid><creditonhold>0</creditonhold><preferredcontactmethodcode name=\"Any\">1</preferredcontactmethodcode><donotemail>0</donotemail><donotbulkemail>0</donotbulkemail><donotphone>0</donotphone><donotfax>0</donotfax><donotpostalmail>0</donotpostalmail><donotsendmm>0</donotsendmm><preferredappointmenttimecode name=\"Morning\">1</preferredappointmenttimecode><customersizecode>1</customersizecode><participatesinworkflow name=\"\">false</participatesinworkflow><haschildrencode>1</haschildrencode><educationcode>1</educationcode><territorycode>1</territorycode><address2_addresstypecode>1</address2_addresstypecode><isbackofficecustomer name=\"\">false</isbackofficecustomer><address2_shippingmethodcode>1</address2_shippingmethodcode><customertypecode>1</customertypecode><donotbulkpostalmail name=\"\">false</donotbulkpostalmail><leadsourcecode>1</leadsourcecode><merged name=\"\">false</merged><statecode name=\"Active\">Active</statecode><address2_freighttermscode>1</address2_freighttermscode><isprivate name=\"\">false</isprivate><shippingmethodcode>1</shippingmethodcode></contact>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(contactStr);
				return contactStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetMerchantId(string content)
		{
			string merchantXml = string.Empty;

			/// <input type="hidden" name="MerchantId" value="&#123;00BF2ED3-7CEE-E011-9533-78E7D1E5EFC4&#125;">
			string reMerchant = @"input type=""hidden"" name=""MerchantId"" id=""MerchantId"" value=";

			Match mMerchantVal = Regex.Match(content, reMerchant);
			if (mMerchantVal.Success)
			{

				string merchantXmlValue = content.Substring(mMerchantVal.Index);
				merchantXmlValue = merchantXmlValue.Substring(61, merchantXmlValue.IndexOf('\"', 61) - 61);
				merchantXml = merchantXmlValue;
				merchantXml = HttpUtility.HtmlDecode(merchantXml);

			}
			return merchantXml;
		}

		public static string GetErrorUrl(string content)
		{
			string errorUrlXml = string.Empty;

			/// <input type="hidden" name="MerchantId" value="&#123;00BF2ED3-7CEE-E011-9533-78E7D1E5EFC4&#125;">
			string reErrorUrl = @"input type=""hidden"" id=""ErrorURL"" name=""ErrorURL""  value=";
			Match mErrorUrlVal = Regex.Match(content, reErrorUrl);
			if (mErrorUrlVal.Success)
			{

				string errorUrlValValue = content.Substring(mErrorUrlVal.Index);
				errorUrlValValue = errorUrlValValue.Substring(58, errorUrlValValue.IndexOf('\"', 58) - 58);
				errorUrlXml = errorUrlValValue;
				errorUrlXml = HttpUtility.HtmlDecode(errorUrlXml);

			}
			return errorUrlXml;
		}

		public static string GetSuccessUrl(string content)
		{
			string successUrlXml = string.Empty;


			///<input type="hidden" name="SuccessURL"  value="&#47;TestOrg&#47;Activities&#47;Attachment&#47;edit.aspx&#63;pId&#61;&#37;7bFAA84BD1-4801-E111-A5BC-78E7D1E5EFC4&#37;7d&#38;pType&#61;4202">
			string reSuccessUrl = @"input type=""hidden"" id=""SuccessURL"" name=""SuccessURL""  value=";
			Match mSuccessUrlVal = Regex.Match(content, reSuccessUrl);
			if (mSuccessUrlVal.Success)
			{

				string successUrlValValue = content.Substring(mSuccessUrlVal.Index);
				successUrlValValue = successUrlValValue.Substring(62, successUrlValValue.IndexOf('\"', 62) - 62);
				successUrlXml = successUrlValValue;
				successUrlXml = HttpUtility.HtmlDecode(successUrlXml);

			}
			return successUrlXml;
		}

		public static string GetCreateEmailXml(string subject, Guid fromid, int fromidtype, Guid toid, int toidtype, Guid regardingobjectid, int regardingobjectidtype, Guid ownerid, int owneridtype)
		{
			try
			{
				string emailStr = null;
				if (regardingobjectid == Guid.Empty)
				{
					emailStr = "<email><directioncode>true</directioncode><from><activityparty><partyid type=\"" + fromidtype.ToString() + "\">" + fromid.ToString("B") + "</partyid></activityparty></from><to><activityparty><partyid type=\"" + toidtype.ToString() + "\">" + toid.ToString("B") + "</partyid></activityparty></to><subject>" + subject + "</subject><description>" + Utils.GetRandomString(20, 40) + "</description><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode><statuscode>1</statuscode></email>";
				}
				else
				{
					emailStr = "<email><directioncode>true</directioncode><from><activityparty><partyid type=\"" + fromidtype.ToString() + "\">" + fromid.ToString("B") + "</partyid></activityparty></from><to><activityparty><partyid type=\"" + toidtype.ToString() + "\">" + toid.ToString("B") + "</partyid></activityparty></to><subject>" + subject + "</subject><description>" + Utils.GetRandomString(20, 40) + "</description><regardingobjectid type=\"" + regardingobjectidtype.ToString() + "\">" + regardingobjectid.ToString("B") + "</regardingobjectid><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode><statuscode>1</statuscode></email>";
				}
				XmlDocument test = new XmlDocument();
				test.LoadXml(emailStr);
				return emailStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetSendEmailXml(string subject)
		{
			try
			{
				string emailStr = "<email><directioncode>true</directioncode><subject>" + subject + "</subject></email>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(emailStr);
				return emailStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateFaxXml(Guid fromid, int fromidtype, Guid toid, int toidtype, Guid regardingobjectid, int regardingobjectidtype, Guid ownerid, int owneridtype)
		{
			try
			{
				string faxStr = "<fax><from><activityparty><partyid type=\"" + fromidtype.ToString() + "\">" + fromid.ToString("B") + "</partyid></activityparty></from><faxnumber>" + Utils.GetRandomPhoneNumber() + "</faxnumber><to><activityparty><partyid type=\"" + toidtype.ToString() + "\">" + toid.ToString("B") + "</partyid></activityparty></to><directioncode>1</directioncode><subject>" + Utils.GetRandomString(10, 15) + "</subject><description>" + Utils.GetRandomString(20, 30) + "</description><regardingobjectid type=\"" + regardingobjectidtype.ToString() + "\">" + regardingobjectid.ToString("B") + "</regardingobjectid><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode></fax>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(faxStr);
				return faxStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateServiceIncidentXml(Guid ownerid, int owneridtype, Guid customerid, int customeridtype, Guid subjectid, int subjectidtype)
		{
			try
			{
				string incidentStr = string.Format("<incident><title>{0}</title><customerid type=\"{1}\">{2}</customerid><subjectid type=\"{3}\">{4}</subjectid><ownerid type=\"{5}\">{6}</ownerid><statuscode name=\"In Progress\">1</statuscode><prioritycode name=\"Normal\">2</prioritycode><stageid>15322a8f-67b8-47fb-8763-13a28686c29d</stageid><processid>0ffbcde4-61c1-4355-aa89-aa1d7b2b8792</processid></incident>", Utils.GetRandomString(5, 10), customeridtype.ToString(), customerid.ToString("B"), subjectidtype.ToString(), subjectid.ToString("B"), owneridtype.ToString(), ownerid.ToString("B"));
				XmlDocument test = new XmlDocument();
				test.LoadXml(incidentStr);
				return incidentStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateConnectionOriginalXml(Guid ownerid, int owneridtype, Guid record1, int record1type)
		{
			try
			{
				string leadStr = "<connection><record1id type=\"" + record1type.ToString() + "\">" + record1.ToString("B") + "</record1id><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><ismaster name=\"\">false</ismaster><statecode name=\"Active\">Active</statecode></connection>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(leadStr);
				return leadStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateLeadXml(Guid ownerid, int owneridtype, string firstname, string lastname, CRMEntity currency)
		{
			try
			{
				string leadStr = @"<lead><subject>" + Utils.GetRandomString(5, 10) + "</subject><lastname>" + lastname + "</lastname><companyname>" + Utils.GetRandomString(5, 10) + "</companyname><leadqualitycode name=\"Warm\">2</leadqualitycode><transactioncurrencyid type=\"9105\">" + currency["transactioncurrencyid"] + "</transactioncurrencyid><ownerid type=\"" + owneridtype + "\">" + ownerid.ToString("B") + "</ownerid><statuscode name=\"New\">1</statuscode><preferredcontactmethodcode name=\"Any\">1</preferredcontactmethodcode><donotemail>0</donotemail><donotbulkemail>0</donotbulkemail><donotphone>0</donotphone><donotfax>0</donotfax><donotpostalmail>0</donotpostalmail><donotsendmm>0</donotsendmm><salesstagecode>1</salesstagecode><statecode name=\"Open\">Open</statecode><address2_shippingmethodcode>1</address2_shippingmethodcode><prioritycode>1</prioritycode><address1_shippingmethodcode>1</address1_shippingmethodcode><isprivate name=\"\">false</isprivate><address1_addresstypecode>1</address1_addresstypecode><participatesinworkflow name=\"\">false</participatesinworkflow><merged name=\"\">false</merged><address2_addresstypecode>1</address2_addresstypecode></lead>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(leadStr);
				return leadStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateLetterXml(Guid fromid, int fromidtype, Guid toid, int toidtype, Guid regardingobjectid, int regardingobjectidtype, Guid ownerid, int owneridtype)
		{
			try
			{
				string letterStr = "<letter><from><activityparty><partyid type=\"" + fromidtype.ToString() + "\">" + fromid.ToString("B") + "</partyid></activityparty></from><to><activityparty><partyid type=\"" + toidtype.ToString() + "\">" + toid.ToString("B") + "</partyid></activityparty></to><directioncode>1</directioncode><subject>" + Utils.GetRandomString(10, 15) + ExchangeSyncLoadMapper.CreateLetterAppendable() + "</subject><description>" + Utils.GetRandomString(15, 20) + "</description><regardingobjectid type=\"" + regardingobjectidtype.ToString() + "\">" + regardingobjectid.ToString("B") + "</regardingobjectid><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode></letter>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(letterStr);
				return letterStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateListXml(Guid ownerid, int owneridtype, CRMEntity currency)
		{
			return GetCreateListXml(ownerid, owneridtype, currency, false);
		}

		public static string GetCreateListXml(Guid ownerid, int owneridtype, CRMEntity currency, bool type)
		{
			try
			{
				string listStr = "<list><listname>" + Utils.GetRandomString(5, 10) + "</listname><createdfromcode name=\"Account\">1</createdfromcode><transactioncurrencyid type=\"" + currency["transactioncurrencyidtype"] + "\">" + currency["transactioncurrencyid"] + "</transactioncurrencyid><cost>" + Utils.GetRandomNumber(1000, 50000) + "</cost><lockstatus>0</lockstatus><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><statecode name=\"Active\">Active</statecode><donotsendonoptout name=\"\">true</donotsendonoptout><ignoreinactivelistmembers name=\"\">true</ignoreinactivelistmembers><type>" + type.ToString() + "</type></list>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(listStr);
				return listStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateTeamXml(Guid businessUnitId, Guid ownerid, int owneridtype, CRMEntity currency)
		{
			try
			{
				string teamStr = "<team><name>" + Utils.GetRandomString(5, 10) + "</name><businessunitid type=\"10\" name=\"Sector1\">" + businessUnitId + "</businessunitid><administratorid type=\"" + owneridtype.ToString() + " \" > " + ownerid.ToString("B") + "</administratorid>";
				teamStr += string.Format("<teamtype>0</teamtype><transactioncurrencyid name=\"US Dollar\" type=\"9105\">{0}</transactioncurrencyid></team>", currency[EntityIDNames.TransactionCurrency]);
				XmlDocument test = new XmlDocument();
				test.LoadXml(teamStr);
				return teamStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateOpportunityXml(Guid ownerid, int owneridtype, string name, Guid customerid, int customeridtype, CRMEntity currency)
		{
			try
			{
				string oppStr = "<opportunity><name>" + name + "</name><customerid type=\"" + customeridtype + "\">" + customerid.ToString("B") + "</customerid><transactioncurrencyid type=\"9105\">" + currency["transactioncurrencyid"] + "</transactioncurrencyid><isrevenuesystemcalculated>1</isrevenuesystemcalculated><opportunityratingcode name=\"Warm\">2</opportunityratingcode><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><statuscode>1</statuscode><statecode name=\"Open\">Open</statecode><salesstagecode>1</salesstagecode><prioritycode>1</prioritycode><participatesinworkflow name=\"\">false</participatesinworkflow><pricingerrorcode>1</pricingerrorcode><isprivate name=\"\">false</isprivate></opportunity>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(oppStr);
				return oppStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateOpportunityOriginalXml(Guid ownerid, int owneridtype, string name, CRMEntity currency)
		{
			try
			{
				string oppStr = "<opportunity><ownerid type=\"" + owneridtype + "\">" + ownerid.ToString("B") + "</ownerid><transactioncurrencyid type=\"9105\">" + currency["transactioncurrencyid"] + "</transactioncurrencyid><statecode name=\"Open\">Open</statecode><isrevenuesystemcalculated name=\"\">true</isrevenuesystemcalculated><salesstagecode>1</salesstagecode><prioritycode>1</prioritycode><participatesinworkflow name=\"\">false</participatesinworkflow><pricingerrorcode>1</pricingerrorcode><opportunityratingcode>2</opportunityratingcode><isprivate name=\"\">false</isprivate></opportunity>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(oppStr);
				return oppStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreatePhonecallXml(Guid ownerid, int owneridtype, Guid toUser, int toUsertype, Guid regardingobjectid, int regardingobjectidtype)
		{
			try
			{
				string phonecallStr = "<phonecall><from><activityparty><partyid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</partyid></activityparty></from><phonenumber>" + Utils.GetRandomPhoneNumber() + "</phonenumber><to><activityparty><partyid type=\"" + toUsertype.ToString() + "\">" + toUser.ToString("B") + "</partyid></activityparty></to><directioncode>1</directioncode><subject>" + Utils.GetRandomString(10, 15) + ExchangeSyncLoadMapper.CreatePhoneCallAppendable() + "</subject><description>" + Utils.GetRandomString(50, 60) + "</description><regardingobjectid type=\"" + regardingobjectidtype.ToString() + "\">" + regardingobjectid.ToString("B") + "</regardingobjectid><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode></phonecall>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(phonecallStr);
				return phonecallStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateQuoteXml(Guid ownerid, int owneridtype, Guid pricelevelid, int pricelevelidtype, Guid customerid, int customeridtype)
		{
			try
			{
				string quoteStr = "<quote><name>" + Utils.GetRandomString(5, 10) + "</name><customerid type=\"" + customeridtype.ToString() + "\">" + customerid.ToString("B") + "</customerid><pricelevelid type=\"" + pricelevelidtype.ToString() + "\">" + pricelevelid.ToString("B") + "</pricelevelid><willcall>0</willcall><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><statuscode>1</statuscode><discountpercentage>15</discountpercentage><discountamount>7</discountamount><freightamount>20</freightamount></quote>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(quoteStr);
				return quoteStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateOpportunityPricelistXml(Guid ownerid, int owneridtype, Guid pricelevelid, int pricelevelidtype, string name, Guid customerid, int customeridtype, CRMEntity currency)
		{
			try
			{
				string oppStr = "<opportunity><name>" + name + "</name><customerid type=\"" + customeridtype + "\">" + customerid.ToString("B") + "</customerid><pricelevelid type=\"" + pricelevelidtype.ToString() + "\">" + pricelevelid.ToString("B") + "</pricelevelid><transactioncurrencyid type=\"9105\">" + currency["transactioncurrencyid"] + "</transactioncurrencyid><isrevenuesystemcalculated>1</isrevenuesystemcalculated><opportunityratingcode name=\"Warm\">2</opportunityratingcode><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><statuscode>1</statuscode><statecode name=\"Open\">Open</statecode><salesstagecode>1</salesstagecode><prioritycode>1</prioritycode><participatesinworkflow name=\"\">false</participatesinworkflow><pricingerrorcode>1</pricingerrorcode><isprivate name=\"\">false</isprivate></opportunity>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(oppStr);
				return oppStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateSalesOrderXml(Guid ownerid, int owneridtype, Guid pricelevelid, int pricelevelidtype, Guid customerid, int customeridtype)
		{
			try
			{
				string salesOrderStr = "<salesorder><name>" + Utils.GetRandomString(5, 10) + "</name><customerid type=\"" + customeridtype.ToString() + "\">" + customerid.ToString("B") + "</customerid><pricelevelid type=\"" + pricelevelidtype.ToString() + "\">" + pricelevelid.ToString("B") + "</pricelevelid><willcall>0</willcall><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><statuscode>1</statuscode><discountpercentage>10</discountpercentage><discountamount>4</discountamount><freightamount>21</freightamount></salesorder>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(salesOrderStr);
				return salesOrderStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateInvoiceXml(Guid ownerid, int owneridtype, Guid pricelevelid, int pricelevelidtype, Guid customerid, int customeridtype, CRMEntity currency)
		{
			try
			{
				string salesOrderStr = "<invoice><name>" + Utils.GetRandomString(5, 10) + "</name><transactioncurrencyid type=\"9105\">" + currency["transactioncurrencyid"] + "</transactioncurrencyid><customerid type=\"" + customeridtype.ToString() + "\">" + customerid.ToString("B") + "</customerid><pricelevelid type=\"" + pricelevelidtype.ToString() + "\">" + pricelevelid.ToString("B") + "</pricelevelid><ispricelocked>0</ispricelocked><pricingerrorcode>0</pricingerrorcode><willcall>0</willcall><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><statuscode>1</statuscode><shipto_freighttermscode>1</shipto_freighttermscode></invoice>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(salesOrderStr);
				return salesOrderStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		// for existing product
		public static string GetCreateInvoiceDetailXml(Guid productid, string productName, int quantity)
		{
			try
			{
				productName = HttpUtility.HtmlDecode(productName);
				string invoicedetailStr = @"<productid type=""1024"" name="""">" + productid.ToString("B") + @"</productid><productname>" + productName + "</productname><priceperunit>0</priceperunit><recordid>" + Guid.Empty.ToString("B") + "</recordid><quantity>" + quantity + @"</quantity><manualdiscountamount>0</manualdiscountamount><iscreatenew>true</iscreatenew><sequencenumber>-99</sequencenumber>";
				//XmlDocument test = new XmlDocument();
				//test.LoadXml(invoicedetailStr);
				return invoicedetailStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateproductDetailXml(Guid productid, string productName, int quantity)
		{
			try
			{
				productName = HttpUtility.HtmlDecode(productName);
				string invoicedetailStr = @"<productid type=""1024"" name="""">" + productid.ToString("B") + @"</productid><productname>" + productName + "</productname><priceperunit>0</priceperunit><recordid>" + Guid.Empty.ToString("B") + "</recordid><quantity>" + quantity + @"</quantity><manualdiscountamount>0</manualdiscountamount><iscreatenew>true</iscreatenew><sequencenumber>-99</sequencenumber>";
				//XmlDocument test = new XmlDocument();
				//test.LoadXml(invoicedetailStr);
				return invoicedetailStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateTaskXml(Guid ownerid, int owneridtype, Guid regardingobjectid, int regardingobjectidtype, string regardingobname, Guid currencyId)
		{
			StringBuilder sb = new StringBuilder();
			string taskStr = "";
			sb.Append("<task><subject>");
			sb.Append(Utils.GetRandomString(5, 10));
			sb.Append("</subject><description>");
			sb.Append(Utils.GetRandomString(20, 30));
			sb.Append("</description><regardingobjectid type=\"");
			sb.Append(regardingobjectidtype.ToString());
			sb.Append("\" name=\"");
			sb.Append(regardingobname);
			sb.Append("\">");
			sb.Append(regardingobjectid.ToString("B"));
			sb.Append("</regardingobjectid><ownerid type=\"");
			sb.Append(owneridtype.ToString());
			sb.Append("\" name=\"\">");
			sb.Append(ownerid.ToString("B"));
			sb.Append("</ownerid><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode><new_attribute2>" + Utils.GetRandomNumber(100000001, 100000004) + "</new_attribute2><new_attribute3>false</new_attribute3><transactioncurrencyid name=\"US Dollar\" type=\"9105\">");
			sb.Append(currencyId.ToString("B"));
			sb.Append("</transactioncurrencyid><isregularactivity name=\"\">false</isregularactivity><statecode name=\"Open\">Open</statecode><activitytypecode name=\"Task\">4212</activitytypecode><isbilled name=\"\">false</isbilled><isworkflowcreated name=\"\">false</isworkflowcreated></task>");
			taskStr = sb.ToString();
			XmlDocument test = new XmlDocument();
			try
			{
				test.LoadXml(taskStr);
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
			return taskStr;
		}

		public static string GetCreateTaskXml(Guid ownerid, int owneridtype, Guid currencyId)
		{
			StringBuilder sb = new StringBuilder();
			string taskStr = "";
			sb.Append("<task><subject>");
			sb.Append(Utils.GetRandomString(5, 10));
			sb.Append("</subject><description>");
			sb.Append(Utils.GetRandomString(20, 30));
			sb.Append("</description><ownerid type=\"");
			sb.Append(owneridtype.ToString());
			sb.Append("\" name=\"\">");
			sb.Append(ownerid.ToString("B"));
			sb.Append("</ownerid><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode><new_attribute2>" + Utils.GetRandomNumber(100000001, 100000004) + "</new_attribute2><new_attribute3>false</new_attribute3><transactioncurrencyid name=\"US Dollar\" type=\"9105\">");
			sb.Append(currencyId.ToString("B"));
			sb.Append("</transactioncurrencyid><isregularactivity name=\"\">false</isregularactivity><statecode name=\"Open\">Open</statecode><activitytypecode name=\"Task\">4212</activitytypecode><isbilled name=\"\">false</isbilled><isworkflowcreated name=\"\">false</isworkflowcreated></task>");
			taskStr = sb.ToString();
			XmlDocument test = new XmlDocument();
			try
			{
				test.LoadXml(taskStr);
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
			return taskStr;
		}

		public static string GetCreateConnectionXml(Guid ownerid, int owneridtype, Guid record1Id, int record1Type, Guid record2Id, int record2Type)
		{
			try
			{
				string taskStr = "<connection><record1id type=\"" + record1Type.ToString() + "\"> " + record1Id.ToString("B") + "</record1id><record2id type=\"" + record2Type.ToString() + "\">" + record2Id.ToString("B") + "</record2id><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid><statecode name=\"Active\">Active</statecode><ismaster name=\"\">false</ismaster></connection>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(taskStr);
				return taskStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateTaskXml(Guid ownerid, int owneridtype)
		{
			try
			{
				string taskStr = "<task><subject>" + Utils.GetRandomString(10, 15) + ExchangeSyncLoadMapper.CreateTaskAppendable() + "</subject><description>" + Utils.GetRandomString(60, 80) + "</description><ownerid type=\"" + owneridtype.ToString() + "\">" + ownerid.ToString("B") + "</ownerid></task>";
				XmlDocument test = new XmlDocument();
				test.LoadXml(taskStr);
				return taskStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreateIMXml(Guid ownerid, int owneridtype, Guid accountId, Guid currencyId)
		{
			try
			{
				StringBuilder sb = new StringBuilder();
				sb.Append("<new_im>");
				sb.Append(@"<regardingobjectid type=""1"" name="""">");
				sb.Append(accountId.ToString("B"));
				sb.Append("</regardingobjectid>");
				sb.Append("<prioritycode>1</prioritycode><subject>asdfas</subject>");
				sb.Append(@" <ownerid type=""8"" name="""">");
				sb.Append(ownerid.ToString("B"));
				sb.Append("</ownerid>");
				sb.Append("<new_directioncode>false</new_directioncode>");
				sb.Append(@"<transactioncurrencyid name=""US Dollar"" type=""9105"">");
				sb.Append(currencyId.ToString("B"));
				sb.Append("</transactioncurrencyid>");
				sb.Append(@"<statecode name=""Open"">Open</statecode>");
				sb.Append(@"<instancetypecode name="""">0</instancetypecode>");
				sb.Append(@"<isworkflowcreated name="""">false</isworkflowcreated>");
				sb.Append(@"<isregularactivity name="""">true</isregularactivity>");
				sb.Append("</new_im>");
				string imStr = sb.ToString();
				XmlDocument test = new XmlDocument();
				test.LoadXml(imStr);
				return imStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetCreatePhoneSupportIncidentWithoutActivitiesXml(int prioritycode, int statuscode, int customerType, string customerName, string customerId, string incidentTitle, string incidentSubjectName, string incidentSubjectId, string ownerId, int casetypecode, int caseorigincode, string customerEntityName)
		{
			try
			{
				string incidentStr = "&lt;Input&gt;&lt;id&gt;{00000000-0000-0000-0000-000000000000}&lt;/id&gt;&lt;name&gt;incident&lt;/name&gt;&lt;formId&gt;4a63c8d1-6c1e-48ec-9db4-3e6c7155334c&lt;/formId&gt;&lt;dataxml&gt;&amp;#60;incident&amp;#62;&amp;#60;prioritycode&amp;#62;" + prioritycode + "&amp;#60;&amp;#47;prioritycode&amp;#62;&amp;#60;ownerid type&amp;#61;&amp;#34;8&amp;#34;&amp;#62;&amp;#38;&amp;#35;123&amp;#59;" + ownerId + "&amp;#38;&amp;#35;125&amp;#59;&amp;#60;&amp;#47;ownerid&amp;#62;&amp;#60;customerid type&amp;#61;&amp;#34;" + customerType + "&amp;#34; name&amp;#61;&amp;#34;" + customerName + "&amp;#34;&amp;#62;&amp;#38;&amp;#35;123&amp;#59;" + customerId + "&amp;#38;&amp;#35;125&amp;#59;&amp;#60;&amp;#47;customerid&amp;#62;&amp;#60;title&amp;#62;" + incidentTitle + "&amp;#60;&amp;#47;title&amp;#62;&amp;#60;subjectid type&amp;#61;&amp;#34;129&amp;#34; name&amp;#61;&amp;#34;" + incidentSubjectName + "&amp;#34;&amp;#62;&amp;#38;&amp;#35;123&amp;#59;" + incidentSubjectId + "&amp;#38;&amp;#35;125&amp;#59;&amp;#60;&amp;#47;subjectid&amp;#62;&amp;#60;caseorigincode&amp;#62;" + caseorigincode + "&amp;#60;&amp;#47;caseorigincode&amp;#62;&amp;#60;casetypecode&amp;#62;" + casetypecode + "&amp;#60;&amp;#47;casetypecode&amp;#62;&amp;#60;servicestage&amp;#62;0&amp;#60;&amp;#47;servicestage&amp;#62;&amp;#60;&amp;#47;incident&amp;#62;&lt;/dataxml&gt;&lt;associations&gt;&lt;association&gt;&lt;relationshipname&gt;incident_customer_contacts&lt;/relationshipname&gt;&lt;sourceentityid&gt;{" + customerId + "}&lt;/sourceentityid&gt;&lt;sourceentitylogicalname&gt;" + customerEntityName + "&lt;/sourceentitylogicalname&gt;&lt;relationshiproleordinal&gt;1&lt;/relationshiproleordinal&gt;&lt;/association&gt;&lt;/associations&gt;&lt;/Input&gt;";
				incidentStr = HttpUtility.HtmlDecode(incidentStr);
				XmlDocument test = new XmlDocument();
				test.LoadXml(incidentStr);
				return incidentStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

		public static string GetUpdatePhoneSupportIncidentXml(string incidentId, string ownerId)
		{
			try
			{
				string incidentStr = "&lt;Input&gt;&lt;id&gt;{" + incidentId + "}&lt;/id&gt;&lt;name&gt;incident&lt;/name&gt;&lt;formId&gt;4a63c8d1-6c1e-48ec-9db4-3e6c7155334c&lt;/formId&gt;&lt;dataxml&gt;&amp;#60;incident&amp;#62;&amp;#60;ownerid type&amp;#61;&amp;#34;8&amp;#34;&amp;#62;&amp;#38;&amp;#35;123&amp;#59;" + ownerId + "&amp;#38;&amp;#35;125&amp;#59;&amp;#60;&amp;#47;ownerid&amp;#62;&amp;#60;&amp;#47;incident&amp;#62;&lt;/dataxml&gt;&lt;associations&gt;&lt;/associations&gt;&lt;/Input&gt;";
				incidentStr = HttpUtility.HtmlDecode(incidentStr);
				XmlDocument test = new XmlDocument();
				test.LoadXml(incidentStr);
				return incidentStr;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(e.Message);
				return "";
			}
		}

	}

	public class VisualizationHelper
	{
		public static string GetVizXml(string vizFetchXml, string visualizationID, string viewID, int viewType, int visType, int layoutsize, int paneContentWidth, int paneContentHeight)
		{
			StringBuilder vizXml = new StringBuilder();
			vizXml.Append("<vizXml>");
			vizXml.Append("<filterFetchXml>" + vizFetchXml + "</filterFetchXml>");
			vizXml.Append("<visualizationId>&#123;" + visualizationID + "&#125;</visualizationId>");
			vizXml.Append("<viewid>&#123;" + viewID + "&#125;</viewid>");
			vizXml.Append("<viewtype>" + viewType + "</viewtype>");
			vizXml.Append("<visType>" + visType + "</visType>");
			vizXml.Append("<layoutSize>" + layoutsize + "</layoutSize>");
			vizXml.Append("<paneContentWidth>" + paneContentWidth + "</paneContentWidth>");
			vizXml.Append("<paneContentHeight>" + paneContentHeight + "</paneContentHeight>");
			vizXml.Append("<ie-browser-version>8</ie-browser-version>");
			vizXml.Append("</vizXml>");
			return vizXml.ToString();
		}

		public static string GetVizXml(string vizFetchXml, string visualizationID, string viewID, int viewType, int visType, int layoutsize, int paneContentWidth, int paneContentHeight, bool isEnableDrilldown)
		{
			StringBuilder vizXml = new StringBuilder();
			vizXml.Append("<vizXml>");
			vizXml.Append("<filterFetchXml>" + vizFetchXml + "</filterFetchXml>");
			vizXml.Append("<visualizationId>&#123;" + visualizationID + "&#125;</visualizationId>");
			vizXml.Append("<viewid>&#123;" + viewID + "&#125;</viewid>");
			vizXml.Append("<viewtype>" + viewType + "</viewtype>");
			vizXml.Append("<visType>" + visType + "</visType>");
			vizXml.Append("<layoutSize>" + layoutsize + "</layoutSize>");
			vizXml.Append("<paneContentWidth>" + paneContentWidth + "</paneContentWidth>");
			vizXml.Append("<paneContentHeight>" + paneContentHeight + "</paneContentHeight>");
			vizXml.Append("<enableDrillDown>" + isEnableDrilldown.ToString() + "</enableDrillDown>");
			vizXml.Append("<browser-version>8</browser-version>");
			vizXml.Append("</vizXml>");
			return vizXml.ToString();
		}

		public static string GetVizXml(string visualizationID, string viewID, int viewType, int visType, int layoutsize, int paneContentWidth, int paneContentHeight, string viewBy, string isDrillDown, string chartType, string x1Value, string xFormattedValue, string yColumnName, string aggFetchXml, string filterFetchXml, string presentationXml, string alreadyViewAttribute)
		{
			StringBuilder vizXml = new StringBuilder();
			vizXml.Append("<vizXml>");
			vizXml.Append("<visualizationId>&#123;" + visualizationID + "&#125;</visualizationId>");
			vizXml.Append("<viewid>&#123;" + viewID + "&#125;</viewid>");
			vizXml.Append("<viewtype>" + viewType + "</viewtype>");
			vizXml.Append("<visType>" + visType + "</visType>");
			vizXml.Append("<layoutSize>" + layoutsize + "</layoutSize>");
			vizXml.Append("<paneContentWidth>" + paneContentWidth + "</paneContentWidth>");
			vizXml.Append("<paneContentHeight>" + paneContentHeight + "</paneContentHeight>");
			vizXml.Append("<viewBy>" + viewBy + "</viewBy>");
			vizXml.Append("<isDrillDown>" + isDrillDown + "</isDrillDown>");
			vizXml.Append("<chartType>" + chartType + "</chartType>");
			vizXml.Append("<x1Value>" + x1Value + "</x1Value>");
			vizXml.Append("<x2Value></x2Value>");
			vizXml.Append("<formattedXValue>" + xFormattedValue + "</formattedXValue>");
			vizXml.Append("<seriesIndex>0</seriesIndex>");
			vizXml.Append("<yColumnName>" + yColumnName + "</yColumnName>");
			vizXml.Append("<aggregationFetchXml isCompressed='true'>" + aggFetchXml + "</aggregationFetchXml>");
			vizXml.Append("<filterFetchXml isCompressed='true'>" + filterFetchXml + "</filterFetchXml>");
			vizXml.Append("<presentationXml>" + presentationXml + "</presentationXml>");
			vizXml.Append("<alreadyViewByAttr>" + alreadyViewAttribute + "</alreadyViewByAttr>");
			vizXml.Append("<browser-version>8</browser-version>");
			vizXml.Append("</vizXml>");
			return vizXml.ToString();
		}

		public static string GetVizXml(string visualizationID, string viewID, int viewType, int visType, int layoutsize, int paneContentWidth, int paneContentHeight, string viewBy, string isDrillDown, string chartType, string x1Value, string xFormattedValue, string yColumnName, string aggFetchXml, string filterFetchXml, string presentationXml, string drilldownChartTitle, string alreadyViewAttribute)
		{
			StringBuilder vizXml = new StringBuilder();
			vizXml.Append("<vizXml>");
			vizXml.Append("<visualizationId>&#123;" + visualizationID + "&#125;</visualizationId>");
			vizXml.Append("<viewid>&#123;" + viewID + "&#125;</viewid>");
			vizXml.Append("<viewtype>" + viewType + "</viewtype>");
			vizXml.Append("<visType>" + visType + "</visType>");
			vizXml.Append("<layoutSize>" + layoutsize + "</layoutSize>");
			vizXml.Append("<paneContentWidth>" + paneContentWidth + "</paneContentWidth>");
			vizXml.Append("<paneContentHeight>" + paneContentHeight + "</paneContentHeight>");
			vizXml.Append("<viewBy>" + viewBy + "</viewBy>");
			vizXml.Append("<isDrillDown>" + isDrillDown + "</isDrillDown>");
			vizXml.Append("<chartType>" + chartType + "</chartType>");
			vizXml.Append("<x1Value>" + x1Value + "</x1Value>");
			vizXml.Append("<x2Value></x2Value>");
			vizXml.Append("<formattedXValue>" + xFormattedValue + "</formattedXValue>");
			vizXml.Append("<seriesIndex>0</seriesIndex>");
			vizXml.Append("<yColumnName>" + yColumnName + "</yColumnName>");
			vizXml.Append("<aggregationFetchXml isCompressed='true'>" + aggFetchXml + "</aggregationFetchXml>");
			vizXml.Append("<filterFetchXml isCompressed='true'>" + filterFetchXml + "</filterFetchXml>");
			vizXml.Append("<presentationXml>" + presentationXml + "</presentationXml>");
			vizXml.Append("<drillDownChartTitle>" + drilldownChartTitle + "</drillDownChartTitle>");
			vizXml.Append("<alreadyViewByAttr>" + alreadyViewAttribute + "</alreadyViewByAttr>");
			vizXml.Append("<browser-version>8</browser-version>");
			vizXml.Append("</vizXml>");
			return vizXml.ToString();
		}

		public static string GetVizXml(string visualizationID, string viewID, int viewType, int visType, int layoutsize, int paneContentWidth, int paneContentHeight, string viewBy, string isDrillDown, string chartType, string x1Value, string xFormattedValue, string yColumnName, string aggFetchXml, string filterFetchXml, string presentationXml, string drilldownChartTitle, string alreadyViewAttribute, string backNavigation)
		{
			StringBuilder vizXml = new StringBuilder();
			vizXml.Append("<vizXml>");
			vizXml.Append("<visualizationId>&#123;" + visualizationID + "&#125;</visualizationId>");
			vizXml.Append("<viewid>&#123;" + viewID + "&#125;</viewid>");
			vizXml.Append("<viewtype>" + viewType + "</viewtype>");
			vizXml.Append("<visType>" + visType + "</visType>");
			vizXml.Append("<layoutSize>" + layoutsize + "</layoutSize>");
			vizXml.Append("<paneContentWidth>" + paneContentWidth + "</paneContentWidth>");
			vizXml.Append("<paneContentHeight>" + paneContentHeight + "</paneContentHeight>");
			vizXml.Append("<viewBy>" + viewBy + "</viewBy>");
			vizXml.Append("<isDrillDown>" + isDrillDown + "</isDrillDown>");
			vizXml.Append("<chartType>" + chartType + "</chartType>");
			vizXml.Append("<x1Value>" + x1Value + "</x1Value>");
			vizXml.Append("<x2Value></x2Value>");
			vizXml.Append("<formattedXValue>" + xFormattedValue + "</formattedXValue>");
			vizXml.Append("<seriesIndex>0</seriesIndex>");
			vizXml.Append("<yColumnName>" + yColumnName + "</yColumnName>");
			vizXml.Append("<aggregationFetchXml isCompressed='true'>" + aggFetchXml + "</aggregationFetchXml>");
			vizXml.Append("<filterFetchXml isCompressed='true'>" + filterFetchXml + "</filterFetchXml>");
			vizXml.Append("<presentationXml>" + presentationXml + "</presentationXml>");
			vizXml.Append("<drillDownChartTitle>" + drilldownChartTitle + "</drillDownChartTitle>");
			vizXml.Append("<alreadyViewByAttr>" + alreadyViewAttribute + "</alreadyViewByAttr>");
			vizXml.Append("<backNavigation>" + backNavigation + "</backNavigation>");
			vizXml.Append("<browser-version>8</browser-version>");
			vizXml.Append("</vizXml>");
			return vizXml.ToString();
		}

		public static string GetAggregateFetchXml(string contentChart)
		{
			string aggregateFetchXml = string.Empty;
			string reAggValue = @"input type=""hidden"" id=""aggFetchXml"" name=""aggFetchXml"" value=";
			Match mAggValue = Regex.Match(contentChart, reAggValue);
			if (mAggValue.Success)
			{
				string aggValue = contentChart.Substring(mAggValue.Index);
				aggValue = aggValue.Substring(63, aggValue.IndexOf('\"', 63) - 63);
				aggregateFetchXml = aggValue;
				aggregateFetchXml = HttpUtility.HtmlDecode(aggregateFetchXml);
			}
			return aggregateFetchXml;
		}

		public static string GetAlreadyViewByAttribute(string contentChart)
		{
			string alreadyViewByAttribute = string.Empty;
			string reAlreadyViewBy = @"input type=""hidden"" id=""alreadyViewByAttr"" name=""alreadyViewByAttr"" value=";
			Match mAlreadyViewByValue = Regex.Match(contentChart, reAlreadyViewBy);
			if (mAlreadyViewByValue.Success)
			{
				string alreadyViewByValue = contentChart.Substring(mAlreadyViewByValue.Index);
				alreadyViewByValue = alreadyViewByValue.Substring(75, alreadyViewByValue.IndexOf('\"', 75) - 75);
				alreadyViewByAttribute = alreadyViewByValue;
				alreadyViewByAttribute = HttpUtility.HtmlDecode(alreadyViewByAttribute);
			}
			return alreadyViewByAttribute;
		}

		public static string GetDrilldownChartTitle(string contentChart)
		{
			string drillDownChartTitle = string.Empty;
			string reDrillDownChart = @"input type=""hidden"" id=""drillDownChartTitle"" name=""drillDownChartTitle"" value=";
			Match mDrillDownChartTitleVal = Regex.Match(contentChart, reDrillDownChart);
			if (mDrillDownChartTitleVal.Success)
			{
				string drillDownChartTitleValue = contentChart.Substring(mDrillDownChartTitleVal.Index);
				drillDownChartTitleValue = drillDownChartTitleValue.Substring(79, drillDownChartTitleValue.IndexOf('\"', 79) - 79);
				drillDownChartTitle = drillDownChartTitleValue;
				drillDownChartTitle = HttpUtility.HtmlDecode(drillDownChartTitle);
			}
			return drillDownChartTitle;
		}

		public static string GetFilterFetchXml(string contentChart)
		{
			string filterFetchXml = string.Empty;
			string reFilterFetchXmlChart = @"input type=""hidden"" id=""filterFetchXml"" name=""filterFetchXml"" value=";
			Match mDrillDownFilterFetchVal = Regex.Match(contentChart, reFilterFetchXmlChart);
			if (mDrillDownFilterFetchVal.Success)
			{
				string filterFetchXmlValue = contentChart.Substring(mDrillDownFilterFetchVal.Index);
				filterFetchXmlValue = filterFetchXmlValue.Substring(69, filterFetchXmlValue.IndexOf('\"', 69) - 69);
				filterFetchXml = filterFetchXmlValue;
				filterFetchXml = HttpUtility.HtmlDecode(filterFetchXml);
				filterFetchXml = System.Web.HttpUtility.HtmlEncode(filterFetchXml);
			}
			return filterFetchXml;
		}

		public static string GetPresentationXml(string contentChart)
		{
			string presentationXml = string.Empty;
			string rePresXmlValue = @"input type=""hidden"" id=""presXml"" name=""presXml"" value=";
			Match mPresXmlValue = Regex.Match(contentChart, rePresXmlValue);
			if (mPresXmlValue.Success)
			{
				string presXmlValue = contentChart.Substring(mPresXmlValue.Index);
				presXmlValue = presXmlValue.Substring(55, presXmlValue.IndexOf('\"', 55) - 55);
				presentationXml = presXmlValue;
				presentationXml = HttpUtility.HtmlDecode(presentationXml);
				presentationXml = System.Web.HttpUtility.HtmlEncode(presentationXml);
			}
			return presentationXml;
		}

		public static void GetChartPoints(string contentChart, ref ArrayList xList, ref ArrayList xFormattedList, ref string yColumnName)
		{
			string reShowDrillDown = @"javascript:Mscrm.Visualization.showDrillDown";

			MatchCollection drillDownString = Regex.Matches(contentChart, reShowDrillDown);
			// Getting all List values from HtmlResponse for DrillDown
			foreach (Match m in drillDownString)
			{
				string value = contentChart.Substring(m.Index);
				value = value.Substring(60, value.IndexOf('\"', 60) - 60);
				string[] drillDownValues = value.Split(new string[] { "&#39;," }, StringSplitOptions.None);
				if (xList.Count == 10)
					break;

				string xListVal = drillDownValues[5];
				if (xListVal != "")
				{
					xListVal = xListVal + "&#39;";
					xListVal = HttpUtility.HtmlDecode(xListVal);
					xListVal = HttpUtility.HtmlDecode(xListVal).Trim('\'');
					if (xListVal.Contains("\\x7b"))
					{
						xListVal = xListVal.Substring(4, 36);
						xListVal = "&#123;" + xListVal + "&#125;";
					}
					xList.Add(xListVal);
				}
				xFormattedList.Add(HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(drillDownValues[4] + "&#39;".Trim('\''))).Trim('\''));
				yColumnName = HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(drillDownValues[3] + "&#39;".Trim('\'')));
				yColumnName = yColumnName.Trim('\'');
			}
		}
	}

	public class TeamRoleHelper
	{
		public static void GetRoleIds(string contentRoles, ref ArrayList xList)
		{
			string reContentID = @"<GetRolesResult>";
			string reXValue = @"roleid([\s\w\d.{}_\-\)\(&;#]*)/roleid";
			Match m = Regex.Match(contentRoles, reContentID);

			if (m.Success)
			{
				string aggValue = contentRoles.Substring(m.Index);
				aggValue = aggValue.Substring(17, aggValue.IndexOf("</GetRolesResult>", 17) - 17);
				MatchCollection roleValues = Regex.Matches(aggValue, reXValue);

				// Getting all List values from HtmlResponse for Role
				foreach (Match mRole in roleValues)
				{
					string xListVal = mRole.Value;
					xListVal = HttpUtility.HtmlDecode(xListVal);
					xListVal = xListVal.Substring(7, 38);
					xListVal = new Guid(xListVal).ToString("B");
					xList.Add(xListVal);
				}
			}
		}
	}

	public class GridXmlHelper
	{
		public static string GetEffectiveFetchXml(string contentBody)
		{
			string effectiveFetchXml = string.Empty;
			string reEffectiveFetchValue = @"<div id=""effectiveFetchXml"" requiredMask=""2"">";
			string endEffectiveFectxml = "</div>";
			int startIndex = contentBody.IndexOf(reEffectiveFetchValue);
			if (startIndex == -1)
			{
				reEffectiveFetchValue = @"&lt;div id=""effectiveFetchXml"" requiredMask=""2""&gt;";
				startIndex = contentBody.IndexOf(reEffectiveFetchValue);
			}
			string fetchXmlTillEnd = contentBody.Substring(startIndex + reEffectiveFetchValue.Length);
			int endIndex = fetchXmlTillEnd.IndexOf(endEffectiveFectxml);
			effectiveFetchXml = fetchXmlTillEnd.Substring(0, endIndex);
			effectiveFetchXml = HttpUtility.HtmlDecode(effectiveFetchXml);
			effectiveFetchXml = HttpUtility.HtmlDecode(effectiveFetchXml);
			return System.Web.HttpUtility.HtmlEncode(effectiveFetchXml);
		}

		public static string AccountDrillDownPageView(string guid, string drilldownGuid)
		{
			string grid = @"<gridXml><grid><sortColumns>name&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>50</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>-1</max><refreshAsync>False</refreshAsync><pagingCookie></pagingCookie><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><parameters><autorefresh>1</autorefresh><isGridFilteringEnabled>1</isGridFilteringEnabled><viewid>VIEW_GUID</viewid><viewtype>1039</viewtype><RecordsPerPage>50</RecordsPerPage><preview>1,1</preview><otc>1</otc><otn>account</otn><entitydisplayname>Account</entitydisplayname><titleformat>&#123;0&#125;&#58; &#123;1&#125;</titleformat><entitypluraldisplayname>Accounts</entitypluraldisplayname><isWorkflowSupported>true</isWorkflowSupported><viewTitle>Active Accounts</viewTitle><layoutXml><grid name=""resultset"" object=""1"" jump=""name"" select=""1"" icon=""1"" preview=""1""><row name=""result"" id=""accountid""><cell name=""name"" width=""300"" /><cell name=""telephone1"" width=""100"" /><cell name=""address1_city"" width=""100"" /><cell name=""primarycontactid"" width=""150"" /><cell name=""accountprimarycontactidcontactcontactid.emailaddress1"" width=""150"" disableSorting=""1"" relatedentityname=""contact"" relatedentityattr=""contactid"" primaryentityattr=""primarycontactid"" relationshipid=""{7befeabe-bf01-4207-97f8-7a96e05d2332}"" relationshipname=""account_primary_contact"" /></row></grid></layoutXml><LayoutStyle>GridList</LayoutStyle><quickfind/><filter/><filterDisplay/><fetchXml><fetch version=""1.0"" output-format=""xml-platform"" mapping=""logical""><entity name=""account""><attribute name=""name""/><attribute name=""address1_city""/><order attribute=""name"" descending=""false""/><attribute name=""primarycontactid""/><attribute name=""telephone1""/><filter type=""and"" gridfilterid=""ccd4621bdec4a39994827aee711cb8d7""><condition attribute=""statecode"" operator=""eq"" value=""0""/><condition attribute=""ownerid"" operator=""eq"" gridfilterconditionid=""09349a5b79d7a051c22aee83789b712b"" value=""DRILLDOWN_GUID""/></filter><link-entity alias=""accountprimarycontactidcontactcontactid"" name=""contact"" from=""contactid"" to=""primarycontactid"" link-type=""outer"" visible=""false""><attribute name=""emailaddress1""/></link-entity><attribute name=""accountid""/></entity></fetch></fetchXml></parameters><columns><column width=""300"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Account&#32;Name"" fieldname=""name"" entityname=""account"" renderertype=""nvarchar"">name</column><column width=""100"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Main&#32;Phone"" fieldname=""telephone1"" entityname=""account"" renderertype=""nvarchar"">telephone1</column><column width=""100"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Address&#32;1&#58;&#32;City"" fieldname=""address1_city"" entityname=""account"" renderertype=""nvarchar"">address1_city</column><column width=""150"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Primary&#32;Contact"" fieldname=""primarycontactid"" entityname=""account"" renderertype=""lookup"">primarycontactid</column><column width=""150"" isHidden=""false"" isMetadataBound=""true"" isSortable=""false"" label=""E-mail&#32;&#40;Primary&#32;Contact&#41;"" fieldname=""emailaddress1"" entityname=""contact"" renderertype=""nvarchar"" relationshipname=""account_primary_contact"">accountprimarycontactidcontactcontactid.emailaddress1</column></columns></grid></gridXml>";

			grid = grid.Replace("VIEW_GUID", guid);
			grid = grid.Replace("DRILLDOWN_GUID", drilldownGuid);
			return grid;
		}

		public static string QueueListView(int pageNum, string guid, string pagingCookie)
		{
			string grid = @"&#60;grid&#62;&#60;sortColumns&#62;name&#38;&#35;58&#59;1&#60;&#47;sortColumns&#62;&#60;pageNum&#62;1&#60;&#47;pageNum&#62;&#60;recsPerPage&#62;50&#60;&#47;recsPerPage&#62;&#60;dataProvider&#62;Microsoft.Crm.Application.Controls.LookupGridDataProvider&#60;&#47;dataProvider&#62;&#60;uiProvider&#62;Microsoft.Crm.Application.Controls.GridUIProvider&#60;&#47;uiProvider&#62;&#60;cols&#47;&#62;&#60;max&#62;1&#60;&#47;max&#62;&#60;refreshAsync&#62;False&#60;&#47;refreshAsync&#62;&#60;pagingCookie&#47;&#62;&#60;enableMultiSort&#62;true&#60;&#47;enableMultiSort&#62;&#60;enablePagingWhenOnePage&#62;true&#60;&#47;enablePagingWhenOnePage&#62;&#60;parameters&#62;&#60;autorefresh&#62;1&#60;&#47;autorefresh&#62;&#60;disableDblClick&#62;0&#60;&#47;disableDblClick&#62;&#60;viewid&#62;&#38;&#35;123&#59;3434F892-B38A-4A21-98E4-35C473073F52&#38;&#35;125&#59;&#60;&#47;viewid&#62;&#60;viewtype&#62;1039&#60;&#47;viewtype&#62;&#60;RecordsPerPage&#62;50&#60;&#47;RecordsPerPage&#62;&#60;otc&#62;2020&#60;&#47;otc&#62;&#60;otn&#62;queue&#60;&#47;otn&#62;&#60;ObjectType&#62;2020&#60;&#47;ObjectType&#62;&#60;DataProviderOverride&#62;Microsoft.Crm.Application.Controls.LookupGridDataProvider&#60;&#47;DataProviderOverride&#62;&#60;LoadOnDemand&#62;0&#60;&#47;LoadOnDemand&#62;&#60;class&#47;&#62;&#60;objecttypes&#62;2020&#60;&#47;objecttypes&#62;&#60;browse&#62;0&#60;&#47;browse&#62;&#60;LookupStyle&#62;single&#60;&#47;LookupStyle&#62;&#60;ShowNewButton&#62;1&#60;&#47;ShowNewButton&#62;&#60;ShowPropButton&#62;1&#60;&#47;ShowPropButton&#62;&#60;DefaultType&#62;0&#60;&#47;DefaultType&#62;&#60;Mode&#62;2&#60;&#47;Mode&#62;&#60;searchvalue&#47;&#62;&#60;BindingColumns&#47;&#62;&#60;showjumpbar&#62;0&#60;&#47;showjumpbar&#62;&#60;viewTitle&#62;Queues Lookup View&#60;&#47;viewTitle&#62;&#60;layoutXml&#62;&#38;&#35;60&#59;grid name&#38;&#35;61&#59;&#38;&#35;34&#59;resultset&#38;&#35;34&#59; object&#38;&#35;61&#59;&#38;&#35;34&#59;2020&#38;&#35;34&#59; jump&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; select&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; preview&#38;&#35;61&#59;&#38;&#35;34&#59;0&#38;&#35;34&#59; icon&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;row name&#38;&#35;61&#59;&#38;&#35;34&#59;result&#38;&#35;34&#59; id&#38;&#35;61&#59;&#38;&#35;34&#59;queueid&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;300&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;row&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;grid&#38;&#35;62&#59;&#60;&#47;layoutXml&#62;&#60;fetchXmlForFilters&#62;&#38;&#35;60&#59;fetch version&#38;&#35;61&#59;&#38;&#35;34&#59;1.0&#38;&#35;34&#59; mapping&#38;&#35;61&#59;&#38;&#35;34&#59;logical&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;entity name&#38;&#35;61&#59;&#38;&#35;34&#59;queue&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;queueid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;filter type&#38;&#35;61&#59;&#38;&#35;34&#59;and&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;condition attribute&#38;&#35;61&#59;&#38;&#35;34&#59;queuetypecode&#38;&#35;34&#59; operator&#38;&#35;61&#59;&#38;&#35;34&#59;eq&#38;&#35;34&#59; value&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;filter&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;entity&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;fetch&#38;&#35;62&#59;&#60;&#47;fetchXmlForFilters&#62;&#60;relName&#47;&#62;&#60;effectiveFetchXml&#62;&#38;&#35;60&#59;fetch distinct&#38;&#35;61&#59;&#38;&#35;34&#59;false&#38;&#35;34&#59; mapping&#38;&#35;61&#59;&#38;&#35;34&#59;logical&#38;&#35;34&#59; page&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; count&#38;&#35;61&#59;&#38;&#35;34&#59;50&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;entity name&#38;&#35;61&#59;&#38;&#35;34&#59;queue&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;queueid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;queueid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;filter type&#38;&#35;61&#59;&#38;&#35;34&#59;and&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;condition attribute&#38;&#35;61&#59;&#38;&#35;34&#59;queuetypecode&#38;&#35;34&#59; operator&#38;&#35;61&#59;&#38;&#35;34&#59;eq&#38;&#35;34&#59; value&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;filter&#38;&#35;62&#59;&#38;&#35;60&#59;order attribute&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; descending&#38;&#35;61&#59;&#38;&#35;34&#59;false&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;entity&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;fetch&#38;&#35;62&#59;&#60;&#47;effectiveFetchXml&#62;&#60;LayoutStyle&#62;GridList&#60;&#47;LayoutStyle&#62;&#60;quickfind&#47;&#62;&#60;filter&#47;&#62;&#60;filterDisplay&#47;&#62;&#60;filteruser&#47;&#62;&#60;&#47;parameters&#62;&#60;&#47;grid&#62;";

			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string AllQueuesAllItemsView(int pageNum, string guid, string pagingCookie)
		{
			string grid = @"&lt;grid&gt;&lt;sortColumns&gt;enteredon&amp;#58;0&lt;/sortColumns&gt;&lt;pageNum&gt;1&lt;/pageNum&gt;&lt;recsPerPage&gt;50&lt;/recsPerPage&gt;&lt;dataProvider&gt;Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder&lt;/dataProvider&gt;&lt;uiProvider&gt;Microsoft.Crm.Application.Controls.GridUIProvider&lt;/uiProvider&gt;&lt;cols/&gt;&lt;max&gt;-1&lt;/max&gt;&lt;refreshAsync&gt;False&lt;/refreshAsync&gt;&lt;pagingCookie&gt;&amp;#60;cookie page&amp;#61;&amp;#34;1&amp;#34;&amp;#62;&amp;#60;enteredon last&amp;#61;&amp;#34;2012-03-22T16&amp;#58;25&amp;#58;35-07&amp;#58;00&amp;#34; first&amp;#61;&amp;#34;2012-04-16T15&amp;#58;18&amp;#58;50-07&amp;#58;00&amp;#34; &amp;#47;&amp;#62;&amp;#60;queueitemid last&amp;#61;&amp;#34;&amp;#123;E1E5CF50-7674-E111-A566-002264A0B07A&amp;#125;&amp;#34; first&amp;#61;&amp;#34;&amp;#123;3B922B31-1088-E111-A566-002264A0B07A&amp;#125;&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;cookie&amp;#62;&lt;/pagingCookie&gt;&lt;enableMultiSort&gt;true&lt;/enableMultiSort&gt;&lt;enablePagingWhenOnePage&gt;true&lt;/enablePagingWhenOnePage&gt;&lt;parameters&gt;&lt;autorefresh&gt;1&lt;/autorefresh&gt;&lt;isGridFilteringEnabled&gt;1&lt;/isGridFilteringEnabled&gt;&lt;viewid&gt;&amp;#123;2D8D408D-C255-4587-9E34-596D496E6738&amp;#125;&lt;/viewid&gt;&lt;viewtype&gt;1039&lt;/viewtype&gt;&lt;RecordsPerPage&gt;50&lt;/RecordsPerPage&gt;&lt;viewTitle&gt;All Items&lt;/viewTitle&gt;&lt;otc&gt;2029&lt;/otc&gt;&lt;otn&gt;queueitem&lt;/otn&gt;&lt;entitydisplayname&gt;Queue Item&lt;/entitydisplayname&gt;&lt;titleformat&gt;&amp;#123;0&amp;#125;&amp;#58; &amp;#123;1&amp;#125;&lt;/titleformat&gt;&lt;entitypluraldisplayname&gt;Queue Items&lt;/entitypluraldisplayname&gt;&lt;qid&gt;&amp;#123;5850FC36-8596-45fe-B607-FE81D0C453FD&amp;#125;&lt;/qid&gt;&lt;isWorkflowSupported&gt;true&lt;/isWorkflowSupported&gt;&lt;DisableContextMenu&gt;1&lt;/DisableContextMenu&gt;&lt;fetchXmlForFilters&gt;&amp;#60;fetch distinct&amp;#61;&amp;#34;false&amp;#34; mapping&amp;#61;&amp;#34;logical&amp;#34;&amp;#62;&amp;#60;entity name&amp;#61;&amp;#34;queueitem&amp;#34;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;title&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;enteredon&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objecttypecode&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objectid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;queueid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;workerid&amp;#34; &amp;#47;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;statecode&amp;#34; operator&amp;#61;&amp;#34;eq&amp;#34; value&amp;#61;&amp;#34;0&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;order attribute&amp;#61;&amp;#34;enteredon&amp;#34; descending&amp;#61;&amp;#34;true&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;entity&amp;#62;&amp;#60;&amp;#47;fetch&amp;#62;&lt;/fetchXmlForFilters&gt;&lt;isFetchXmlNotFinal&gt;False&lt;/isFetchXmlNotFinal&gt;&lt;effectiveFetchXml&gt;&amp;#60;fetch distinct&amp;#61;&amp;#34;false&amp;#34; no-lock&amp;#61;&amp;#34;false&amp;#34; mapping&amp;#61;&amp;#34;logical&amp;#34; page&amp;#61;&amp;#34;1&amp;#34; count&amp;#61;&amp;#34;50&amp;#34; returntotalrecordcount&amp;#61;&amp;#34;true&amp;#34;&amp;#62;&amp;#60;entity name&amp;#61;&amp;#34;queueitem&amp;#34;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;title&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;enteredon&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objecttypecode&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objectid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;queueid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;workerid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;title&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;enteredon&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objecttypecode&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;queueid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;workerid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;queueitemid&amp;#34; &amp;#47;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;statecode&amp;#34; operator&amp;#61;&amp;#34;eq&amp;#34; value&amp;#61;&amp;#34;0&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;order attribute&amp;#61;&amp;#34;enteredon&amp;#34; descending&amp;#61;&amp;#34;true&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;entity&amp;#62;&amp;#60;&amp;#47;fetch&amp;#62;&lt;/effectiveFetchXml&gt;&lt;LayoutStyle&gt;GridList&lt;/LayoutStyle&gt;&lt;quickfind/&gt;&lt;filter/&gt;&lt;filterDisplay/&gt;&lt;/parameters&gt;&lt;/grid&gt;";
			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string SingleQueueAllItemsView(int pageNum, string guid, string pagingCookie, string queueId)
		{
			string grid = @"&lt;grid&gt;&lt;sortColumns&gt;enteredon&amp;#58;0&lt;/sortColumns&gt;&lt;pageNum&gt;1&lt;/pageNum&gt;&lt;recsPerPage&gt;50&lt;/recsPerPage&gt;&lt;dataProvider&gt;Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder&lt;/dataProvider&gt;&lt;uiProvider&gt;Microsoft.Crm.Application.Controls.GridUIProvider&lt;/uiProvider&gt;&lt;cols/&gt;&lt;max&gt;-1&lt;/max&gt;&lt;refreshAsync&gt;False&lt;/refreshAsync&gt;&lt;pagingCookie&gt;&amp;#60;cookie page&amp;#61;&amp;#34;1&amp;#34;&amp;#62;&amp;#60;enteredon last&amp;#61;&amp;#34;2012-03-22T16&amp;#58;25&amp;#58;35-07&amp;#58;00&amp;#34; first&amp;#61;&amp;#34;2012-04-16T15&amp;#58;18&amp;#58;50-07&amp;#58;00&amp;#34; &amp;#47;&amp;#62;&amp;#60;queueitemid last&amp;#61;&amp;#34;&amp;#123;E1E5CF50-7674-E111-A566-002264A0B07A&amp;#125;&amp;#34; first&amp;#61;&amp;#34;&amp;#123;3B922B31-1088-E111-A566-002264A0B07A&amp;#125;&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;cookie&amp;#62;&lt;/pagingCookie&gt;&lt;enableMultiSort&gt;true&lt;/enableMultiSort&gt;&lt;enablePagingWhenOnePage&gt;true&lt;/enablePagingWhenOnePage&gt;&lt;initStatements&gt;crmCreate&amp;#40;Mscrm.FormInputControl.PresenceLookupUIBehavior,&amp;#123;&amp;#125;,null,&amp;#123;&amp;#125;,&amp;#36;get&amp;#40;&amp;#39;lookup_lookupFilterPopupcrmGridqueueitemqueueid&amp;#39;&amp;#41;&amp;#41;&amp;#59;&amp;#10;crmCreate&amp;#40;Mscrm.FormInputControl.PresenceLookupUIBehavior,&amp;#123;&amp;#125;,null,&amp;#123;&amp;#125;,&amp;#36;get&amp;#40;&amp;#39;lookup_lookupFilterPopupcrmGridqueueitemworkerid&amp;#39;&amp;#41;&amp;#41;&amp;#59;&lt;/initStatements&gt;&lt;parameters&gt;&lt;autorefresh&gt;1&lt;/autorefresh&gt;&lt;isGridFilteringEnabled&gt;1&lt;/isGridFilteringEnabled&gt;&lt;viewid&gt;&amp;#123;81484ACC-C30C-4869-B40C-2D1154FC1E5F&amp;#125;&lt;/viewid&gt;&lt;viewtype&gt;1039&lt;/viewtype&gt;&lt;RecordsPerPage&gt;50&lt;/RecordsPerPage&gt;&lt;viewTitle&gt;All Items&lt;/viewTitle&gt;&lt;otc&gt;2029&lt;/otc&gt;&lt;otn&gt;queueitem&lt;/otn&gt;&lt;entitydisplayname&gt;Queue Item&lt;/entitydisplayname&gt;&lt;titleformat&gt;&amp;#123;0&amp;#125;&amp;#58; &amp;#123;1&amp;#125;&lt;/titleformat&gt;&lt;entitypluraldisplayname&gt;Queue Items&lt;/entitypluraldisplayname&gt;&lt;qid&gt;&amp;#123;5850FC36-8596-45fe-B607-FE81D0C453FD&amp;#125;&lt;/qid&gt;&lt;isWorkflowSupported&gt;true&lt;/isWorkflowSupported&gt;&lt;fetchXmlForFilters&gt;&amp;#60;fetch distinct&amp;#61;&amp;#34;false&amp;#34; mapping&amp;#61;&amp;#34;logical&amp;#34;&amp;#62;&amp;#60;entity name&amp;#61;&amp;#34;queueitem&amp;#34;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;title&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;enteredon&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objecttypecode&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objectid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;queueid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;workerid&amp;#34; &amp;#47;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;statecode&amp;#34; operator&amp;#61;&amp;#34;eq&amp;#34; value&amp;#61;&amp;#34;0&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;order attribute&amp;#61;&amp;#34;enteredon&amp;#34; descending&amp;#61;&amp;#34;true&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;entity&amp;#62;&amp;#60;&amp;#47;fetch&amp;#62;&lt;/fetchXmlForFilters&gt;&lt;isFetchXmlNotFinal&gt;False&lt;/isFetchXmlNotFinal&gt;&lt;effectiveFetchXml&gt;&amp;#60;fetch distinct&amp;#61;&amp;#34;false&amp;#34; no-lock&amp;#61;&amp;#34;false&amp;#34; mapping&amp;#61;&amp;#34;logical&amp;#34; page&amp;#61;&amp;#34;1&amp;#34; count&amp;#61;&amp;#34;50&amp;#34; returntotalrecordcount&amp;#61;&amp;#34;true&amp;#34;&amp;#62;&amp;#60;entity name&amp;#61;&amp;#34;queueitem&amp;#34;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;title&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;enteredon&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objecttypecode&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objectid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;queueid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;workerid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;title&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;enteredon&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;objecttypecode&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;queueid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;workerid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;queueitemid&amp;#34; &amp;#47;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;statecode&amp;#34; operator&amp;#61;&amp;#34;eq&amp;#34; value&amp;#61;&amp;#34;0&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;order attribute&amp;#61;&amp;#34;enteredon&amp;#34; descending&amp;#61;&amp;#34;true&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;entity&amp;#62;&amp;#60;&amp;#47;fetch&amp;#62;&lt;/effectiveFetchXml&gt;&lt;LayoutStyle&gt;GridList&lt;/LayoutStyle&gt;&lt;quickfind/&gt;&lt;filter/&gt;&lt;filterDisplay/&gt;&lt;maxselectableitems&gt;-1&lt;/maxselectableitems&gt;&lt;/parameters&gt;&lt;/grid&gt;";
			grid = grid.Remove(grid.LastIndexOf("qid&gt;&amp;#123;") + 17, 36);
			grid = grid.Insert(grid.LastIndexOf("qid&gt;&amp;#123;") + 17, queueId);
			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string SingleQueueAllItemsViewRefresh(int pageNum, string guid, string pagingCookie, string queueId)
		{
			string grid = @"&#60;grid&#62;&#60;sortColumns&#62;enteredon&#38;&#35;58&#59;0&#60;&#47;sortColumns&#62;&#60;pageNum&#62;1&#60;&#47;pageNum&#62;&#60;recsPerPage&#62;50&#60;&#47;recsPerPage&#62;&#60;dataProvider&#62;Microsoft.Crm.Application.Controls.Grid.Data.GridDataProviderQueryBuilder&#60;&#47;dataProvider&#62;&#60;uiProvider&#62;Microsoft.Crm.Application.Controls.GridUIProvider&#60;&#47;uiProvider&#62;&#60;cols&#47;&#62;&#60;max&#62;-1&#60;&#47;max&#62;&#60;refreshAsync&#62;False&#60;&#47;refreshAsync&#62;&#60;pagingCookie&#47;&#62;&#60;enableMultiSort&#62;true&#60;&#47;enableMultiSort&#62;&#60;enablePagingWhenOnePage&#62;true&#60;&#47;enablePagingWhenOnePage&#62;&#60;parameters&#62;&#60;autorefresh&#62;1&#60;&#47;autorefresh&#62;&#60;isGridFilteringEnabled&#62;1&#60;&#47;isGridFilteringEnabled&#62;&#60;viewid&#62;&#38;&#35;123&#59;2D8D408D-C255-4587-9E34-596D496E6738&#38;&#35;125&#59;&#60;&#47;viewid&#62;&#60;viewtype&#62;1039&#60;&#47;viewtype&#62;&#60;RecordsPerPage&#62;50&#60;&#47;RecordsPerPage&#62;&#60;DisableContextMenu&#62;1&#60;&#47;DisableContextMenu&#62;&#60;preview&#62;1,1,1,1&#60;&#47;preview&#62;&#60;otc&#62;2029&#60;&#47;otc&#62;&#60;otn&#62;queueitem&#60;&#47;otn&#62;&#60;viewTitle&#62;All Items&#60;&#47;viewTitle&#62;&#60;layoutXml&#62;&#38;&#35;60&#59;grid name&#38;&#35;61&#59;&#38;&#35;34&#59;queueitems&#38;&#35;34&#59; object&#38;&#35;61&#59;&#38;&#35;34&#59;2029&#38;&#35;34&#59; jump&#38;&#35;61&#59;&#38;&#35;34&#59;title&#38;&#35;34&#59; select&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; icon&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; preview&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;row name&#38;&#35;61&#59;&#38;&#35;34&#59;queueitem&#38;&#35;34&#59; id&#38;&#35;61&#59;&#38;&#35;34&#59;objectid&#38;&#35;34&#59; multiobjectidfield&#38;&#35;61&#59;&#38;&#35;34&#59;objecttypecode&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;title&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;300&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;enteredon&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;140&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;objecttypecode&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;queueid&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;150&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;workerid&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;150&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;queueitemid&#38;&#35;34&#59; ishidden&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;row&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;grid&#38;&#35;62&#59;&#60;&#47;layoutXml&#62;&#60;fetchXmlForFilters&#47;&#62;&#60;effectiveFetchXml&#62;&#38;&#35;60&#59;fetch distinct&#38;&#35;61&#59;&#38;&#35;34&#59;false&#38;&#35;34&#59; mapping&#38;&#35;61&#59;&#38;&#35;34&#59;logical&#38;&#35;34&#59; page&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; count&#38;&#35;61&#59;&#38;&#35;34&#59;50&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;entity name&#38;&#35;61&#59;&#38;&#35;34&#59;queueitem&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;title&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;enteredon&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;objecttypecode&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;objectid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;queueid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;workerid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;title&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;enteredon&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;objecttypecode&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;queueid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;workerid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;queueitemid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;filter type&#38;&#35;61&#59;&#38;&#35;34&#59;and&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;condition attribute&#38;&#35;61&#59;&#38;&#35;34&#59;statecode&#38;&#35;34&#59; operator&#38;&#35;61&#59;&#38;&#35;34&#59;eq&#38;&#35;34&#59; value&#38;&#35;61&#59;&#38;&#35;34&#59;0&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;condition attribute&#38;&#35;61&#59;&#38;&#35;34&#59;objecttypecode&#38;&#35;34&#59; operator&#38;&#35;61&#59;&#38;&#35;34&#59;ne&#38;&#35;34&#59; value&#38;&#35;61&#59;&#38;&#35;34&#59;4406&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;filter&#38;&#35;62&#59;&#38;&#35;60&#59;order attribute&#38;&#35;61&#59;&#38;&#35;34&#59;enteredon&#38;&#35;34&#59; descending&#38;&#35;61&#59;&#38;&#35;34&#59;true&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;entity&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;fetch&#38;&#35;62&#59;&#60;&#47;effectiveFetchXml&#62;&#60;LayoutStyle&#62;GridList&#60;&#47;LayoutStyle&#62;&#60;quickfind&#47;&#62;&#60;filter&#47;&#62;&#60;filterDisplay&#47;&#62;&#60;qid&#62;&#38;&#35;123&#59;90FA71DE-6DC1-DD11-8A26-0018FE33924B&#38;&#35;125&#59;&#60;&#47;qid&#62;&#60;&#47;parameters&#62;&#60;columns&#62;&#60;column width&#61;&#34;300&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Title&#34; fieldname&#61;&#34;title&#34; entityname&#61;&#34;queueitem&#34; renderertype&#61;&#34;nvarchar&#34;&#62;title&#60;&#47;column&#62;&#60;column width&#61;&#34;140&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Entered Queue&#34; fieldname&#61;&#34;enteredon&#34; entityname&#61;&#34;queueitem&#34; renderertype&#61;&#34;datetime&#34;&#62;enteredon&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Type&#34; fieldname&#61;&#34;objecttypecode&#34; entityname&#61;&#34;queueitem&#34; renderertype&#61;&#34;picklist&#34;&#62;objecttypecode&#60;&#47;column&#62;&#60;column width&#61;&#34;150&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Queue&#34; fieldname&#61;&#34;queueid&#34; entityname&#61;&#34;queueitem&#34; renderertype&#61;&#34;lookup&#34;&#62;queueid&#60;&#47;column&#62;&#60;column width&#61;&#34;150&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Worked By&#34; fieldname&#61;&#34;workerid&#34; entityname&#61;&#34;queueitem&#34; renderertype&#61;&#34;lookup&#34;&#62;workerid&#60;&#47;column&#62;&#60;column width&#61;&#34;0&#34; isHidden&#61;&#34;true&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;undefined&#34; fieldname&#61;&#34;queueitemid&#34; entityname&#61;&#34;undefined&#34;&#62;queueitemid&#60;&#47;column&#62;&#60;&#47;columns&#62;&#60;&#47;grid&#62;";

			grid = grid.Remove(grid.LastIndexOf("qid&#62;&#38;&#35;123&#59;") + 26, 36);
			grid = grid.Insert(grid.LastIndexOf("qid&#62;&#38;&#35;123&#59;") + 26, queueId);

			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);


			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string AccountPageSearchViewRefresh(int pageNum, string guid, string random, string pagingCookie)
		{
			string grid = @"&#60;grid&#62;&#60;sortColumns&#62;name&#38;&#35;58&#59;1&#60;&#47;sortColumns&#62;&#60;pageNum&#62;1&#60;&#47;pageNum&#62;&#60;recsPerPage&#62;50&#60;&#47;recsPerPage&#62;&#60;dataProvider&#62;Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder&#60;&#47;dataProvider&#62;&#60;uiProvider&#62;Microsoft.Crm.Application.Controls.GridUIProvider&#60;&#47;uiProvider&#62;&#60;cols&#47;&#62;&#60;max&#62;-1&#60;&#47;max&#62;&#60;refreshAsync&#62;False&#60;&#47;refreshAsync&#62;&#60;pagingCookie&#47;&#62;&#60;enableMultiSort&#62;true&#60;&#47;enableMultiSort&#62;&#60;enablePagingWhenOnePage&#62;true&#60;&#47;enablePagingWhenOnePage&#62;&#60;refreshCalledFromRefreshButton&#62;1&#60;&#47;refreshCalledFromRefreshButton&#62;&#60;totalrecordcount&#62;332&#60;&#47;totalrecordcount&#62;&#60;allrecordscounted&#62;true&#60;&#47;allrecordscounted&#62;&#60;returntotalrecordcount&#62;true&#60;&#47;returntotalrecordcount&#62;&#60;getParameters&#62;&#60;&#47;getParameters&#62;&#60;parameters&#62;&#60;autorefresh&#62;1&#60;&#47;autorefresh&#62;&#60;isGridFilteringEnabled&#62;1&#60;&#47;isGridFilteringEnabled&#62;&#60;viewid&#62;&#38;&#35;123&#59;00000000-0000-0000-00AA-000010001001&#38;&#35;125&#59;&#60;&#47;viewid&#62;&#60;viewtype&#62;1039&#60;&#47;viewtype&#62;&#60;RecordsPerPage&#62;50&#60;&#47;RecordsPerPage&#62;&#60;viewTitle&#62;My Active Accounts&#60;&#47;viewTitle&#62;&#60;layoutXml&#62;&#38;&#35;60&#59;grid name&#38;&#35;61&#59;&#38;&#35;34&#59;resultset&#38;&#35;34&#59; object&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; jump&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; select&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; icon&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; preview&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;row name&#38;&#35;61&#59;&#38;&#35;34&#59;result&#38;&#35;34&#59; id&#38;&#35;61&#59;&#38;&#35;34&#59;accountid&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;300&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;telephone1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;address1_city&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;primarycontactid&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;150&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;accountprimarycontactidcontactcontactid.emailaddress1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;150&#38;&#35;34&#59; disableSorting&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; relatedentityname&#38;&#35;61&#59;&#38;&#35;34&#59;contact&#38;&#35;34&#59; relatedentityattr&#38;&#35;61&#59;&#38;&#35;34&#59;contactid&#38;&#35;34&#59; primaryentityattr&#38;&#35;61&#59;&#38;&#35;34&#59;primarycontactid&#38;&#35;34&#59; relationshipid&#38;&#35;61&#59;&#38;&#35;34&#59;&#38;&#35;123&#59;7befeabe-bf01-4207-97f8-7a96e05d2332&#38;&#35;125&#59;&#38;&#35;34&#59; relationshipname&#38;&#35;61&#59;&#38;&#35;34&#59;account_primary_contact&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;row&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;grid&#38;&#35;62&#59;&#60;&#47;layoutXml&#62;&#60;otc&#62;1&#60;&#47;otc&#62;&#60;otn&#62;account&#60;&#47;otn&#62;&#60;entitydisplayname&#62;Account&#60;&#47;entitydisplayname&#62;&#60;titleformat&#62;&#38;&#35;123&#59;0&#38;&#35;125&#59;&#38;&#35;58&#59; &#38;&#35;123&#59;1&#38;&#35;125&#59;&#60;&#47;titleformat&#62;&#60;entitypluraldisplayname&#62;Accounts&#60;&#47;entitypluraldisplayname&#62;&#60;isWorkflowSupported&#62;true&#60;&#47;isWorkflowSupported&#62;&#60;LayoutStyle&#62;GridList&#60;&#47;LayoutStyle&#62;&#60;&#47;parameters&#62;&#60;columns&#62;&#60;column width&#61;&#34;300&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Account&#38;&#35;32&#59;Name&#34; fieldname&#61;&#34;name&#34; entityname&#61;&#34;account&#34; renderertype&#61;&#34;Crm.PrimaryField&#34;&#62;name&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Main&#38;&#35;32&#59;Phone&#34; fieldname&#61;&#34;telephone1&#34; entityname&#61;&#34;account&#34; renderertype&#61;&#34;nvarchar&#34;&#62;telephone1&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Address&#38;&#35;32&#59;1&#38;&#35;58&#59;&#38;&#35;32&#59;City&#34; fieldname&#61;&#34;address1_city&#34; entityname&#61;&#34;account&#34; renderertype&#61;&#34;nvarchar&#34;&#62;address1_city&#60;&#47;column&#62;&#60;column width&#61;&#34;150&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Primary&#38;&#35;32&#59;Contact&#34; fieldname&#61;&#34;primarycontactid&#34; entityname&#61;&#34;account&#34; renderertype&#61;&#34;lookup&#34;&#62;primarycontactid&#60;&#47;column&#62;&#60;column width&#61;&#34;150&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;E-mail&#38;&#35;32&#59;&#38;&#35;40&#59;Primary&#38;&#35;32&#59;Contact&#38;&#35;41&#59;&#34; fieldname&#61;&#34;emailaddress1&#34; entityname&#61;&#34;contact&#34; renderertype&#61;&#34;nvarchar&#34; relationshipname&#61;&#34;account_primary_contact&#34;&#62;accountprimarycontactidcontactcontactid.emailaddress1&#60;&#47;column&#62;&#60;&#47;columns&#62;&#60;&#47;grid&#62;";

			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);
			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string ServiceGridForEntityView(int pageNum, string guid, string pagingCookie)
		{
			string grid = "&lt;grid&gt;&lt;sortColumns/&gt;&lt;pageNum&gt;1&lt;/pageNum&gt;&lt;recsPerPage&gt;50&lt;/recsPerPage&gt;&lt;dataProvider&gt;Microsoft.Crm.Application.Controls.LookupGridDataProvider&lt;/dataProvider&gt;&lt;uiProvider&gt;Microsoft.Crm.Application.Controls.GridUIProvider&lt;/uiProvider&gt;&lt;cols/&gt;&lt;max&gt;1&lt;/max&gt;&lt;refreshAsync&gt;False&lt;/refreshAsync&gt;&lt;pagingCookie/&gt;&lt;enableMultiSort&gt;true&lt;/enableMultiSort&gt;&lt;enablePagingWhenOnePage&gt;true&lt;/enablePagingWhenOnePage&gt;&lt;parameters&gt;&lt;autorefresh&gt;1&lt;/autorefresh&gt;&lt;maxselectableitems&gt;1&lt;/maxselectableitems&gt;&lt;disableDblClick&gt;0&lt;/disableDblClick&gt;&lt;viewid&gt;&amp;#123;B9B07F89-085A-4AC4-A66C-AC9A1CFED5AA&amp;#125;&lt;/viewid&gt;&lt;viewtype&gt;1039&lt;/viewtype&gt;&lt;RecordsPerPage&gt;50&lt;/RecordsPerPage&gt;&lt;viewTitle&gt;Services Lookup View&lt;/viewTitle&gt;&lt;otc&gt;4001&lt;/otc&gt;&lt;otn&gt;service&lt;/otn&gt;&lt;entitydisplayname&gt;Service&lt;/entitydisplayname&gt;&lt;titleformat&gt;&amp;#123;0&amp;#125; &amp;#123;1&amp;#125;&lt;/titleformat&gt;&lt;entitypluraldisplayname&gt;Services&lt;/entitypluraldisplayname&gt;&lt;ObjectType&gt;4001&lt;/ObjectType&gt;&lt;DataProviderOverride&gt;Microsoft.Crm.Application.Controls.LookupGridDataProvider&lt;/DataProviderOverride&gt;&lt;LoadOnDemand&gt;0&lt;/LoadOnDemand&gt;&lt;DisableContextMenu&gt;1&lt;/DisableContextMenu&gt;&lt;AllowFilterOff&gt;1&lt;/AllowFilterOff&gt;&lt;DefaultType&gt;4001&lt;/DefaultType&gt;&lt;DefaultViewId&gt;&amp;#123;B9B07F89-085A-4AC4-A66C-AC9A1CFED5AA&amp;#125;&lt;/DefaultViewId&gt;&lt;DisableQuickFind&gt;0&lt;/DisableQuickFind&gt;&lt;DisableViewPicker&gt;0&lt;/DisableViewPicker&gt;&lt;LookupStyle&gt;single&lt;/LookupStyle&gt;&lt;ShowNewButton&gt;1&lt;/ShowNewButton&gt;&lt;ShowPropButton&gt;1&lt;/ShowPropButton&gt;&lt;browse&gt;false&lt;/browse&gt;&lt;dType&gt;1&lt;/dType&gt;&lt;objecttypes&gt;4001&lt;/objecttypes&gt;&lt;Mode&gt;2&lt;/Mode&gt;&lt;quickFind/&gt;&lt;BindingColumns/&gt;&lt;showjumpbar&gt;0&lt;/showjumpbar&gt;&lt;tabindex&gt;6&lt;/tabindex&gt;&lt;isWorkflowSupported&gt;true&lt;/isWorkflowSupported&gt;&lt;fetchXmlForFilters&gt;&amp;#60;fetch version&amp;#61;&amp;#34;1.0&amp;#34; mapping&amp;#61;&amp;#34;logical&amp;#34;&amp;#62;&amp;#60;entity name&amp;#61;&amp;#34;service&amp;#34;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;name&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;duration&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;serviceid&amp;#34; &amp;#47;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;isschedulable&amp;#34; operator&amp;#61;&amp;#34;eq&amp;#34; value&amp;#61;&amp;#34;1&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;&amp;#47;entity&amp;#62;&amp;#60;&amp;#47;fetch&amp;#62;&lt;/fetchXmlForFilters&gt;&lt;relName/&gt;&lt;isFetchXmlNotFinal&gt;False&lt;/isFetchXmlNotFinal&gt;&lt;effectiveFetchXml&gt;&amp;#60;fetch distinct&amp;#61;&amp;#34;false&amp;#34; no-lock&amp;#61;&amp;#34;false&amp;#34; mapping&amp;#61;&amp;#34;logical&amp;#34; page&amp;#61;&amp;#34;1&amp;#34; count&amp;#61;&amp;#34;50&amp;#34; returntotalrecordcount&amp;#61;&amp;#34;true&amp;#34;&amp;#62;&amp;#60;entity name&amp;#61;&amp;#34;service&amp;#34;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;name&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;duration&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;serviceid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;name&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;duration&amp;#34; &amp;#47;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;isschedulable&amp;#34; operator&amp;#61;&amp;#34;eq&amp;#34; value&amp;#61;&amp;#34;1&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;or&amp;#34; isquickfindfields&amp;#61;&amp;#34;true&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;name&amp;#34; operator&amp;#61;&amp;#34;like&amp;#34; value&amp;#61;&amp;#34;aa&amp;#37;&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;&amp;#47;entity&amp;#62;&amp;#60;&amp;#47;fetch&amp;#62;&lt;/effectiveFetchXml&gt;&lt;LayoutStyle&gt;GridList&lt;/LayoutStyle&gt;&lt;enableFilters&gt;1&lt;/enableFilters&gt;&lt;EnableFirstRecordSelection&gt;True&lt;/EnableFirstRecordSelection&gt;&lt;sameWindow&gt;false&lt;/sameWindow&gt;&lt;quickfind/&gt;&lt;filter/&gt;&lt;filterDisplay/&gt;&lt;filteruser&gt;false&lt;/filteruser&gt;&lt;/parameters&gt;&lt;/grid&gt;";
			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string MarketingListGridForEntityView(int pageNum, string guid, string pagingCookie)
		{
			string grid = @"&lt;grid&gt;&lt;sortColumns&gt;listname&amp;#58;1&lt;/sortColumns&gt;&lt;pageNum&gt;1&lt;/pageNum&gt;&lt;recsPerPage&gt;50&lt;/recsPerPage&gt;&lt;dataProvider&gt;Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder&lt;/dataProvider&gt;&lt;uiProvider&gt;Microsoft.Crm.Application.Controls.GridUIProvider&lt;/uiProvider&gt;&lt;cols/&gt;&lt;max&gt;-1&lt;/max&gt;&lt;refreshAsync&gt;False&lt;/refreshAsync&gt;&lt;pagingCookie/&gt;&lt;enableMultiSort&gt;true&lt;/enableMultiSort&gt;&lt;enablePagingWhenOnePage&gt;true&lt;/enablePagingWhenOnePage&gt;&lt;parameters&gt;&lt;autorefresh&gt;1&lt;/autorefresh&gt;&lt;isGridFilteringEnabled&gt;1&lt;/isGridFilteringEnabled&gt;&lt;viewid&gt;&amp;#123;3535C5B5-DBBF-46AE-B860-FC9149B60411&amp;#125;&lt;/viewid&gt;&lt;viewtype&gt;1039&lt;/viewtype&gt;&lt;RecordsPerPage&gt;50&lt;/RecordsPerPage&gt;&lt;viewTitle&gt;My Active Marketing Lists&lt;/viewTitle&gt;&lt;otc&gt;4300&lt;/otc&gt;&lt;otn&gt;list&lt;/otn&gt;&lt;entitydisplayname&gt;Marketing List&lt;/entitydisplayname&gt;&lt;titleformat&gt;&amp;#123;0&amp;#125;&amp;#58; &amp;#123;1&amp;#125;&lt;/titleformat&gt;&lt;entitypluraldisplayname&gt;Marketing Lists&lt;/entitypluraldisplayname&gt;&lt;isWorkflowSupported&gt;true&lt;/isWorkflowSupported&gt;&lt;LayoutStyle&gt;GridList&lt;/LayoutStyle&gt;&lt;quickfind&gt;test&lt;/quickfind&gt;&lt;filter/&gt;&lt;filterDisplay/&gt;&lt;/parameters&gt;&lt;/grid&gt;";
			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string UserGridForEntityView(int pageNum, string guid, string pagingCookie)
		{
			string grid = @"&#60;grid&#62;&#60;sortColumns&#62;fullname&#38;&#35;58&#59;1&#60;&#47;sortColumns&#62;&#60;pageNum&#62;1&#60;&#47;pageNum&#62;&#60;recsPerPage&#62;50&#60;&#47;recsPerPage&#62;&#60;dataProvider&#62;Microsoft.Crm.Application.Controls.LookupGridDataProvider&#60;&#47;dataProvider&#62;&#60;uiProvider&#62;Microsoft.Crm.Application.Controls.GridUIProvider&#60;&#47;uiProvider&#62;&#60;cols&#47;&#62;&#60;max&#62;1&#60;&#47;max&#62;&#60;refreshAsync&#62;False&#60;&#47;refreshAsync&#62;&#60;pagingCookie&#47;&#62;&#60;enableMultiSort&#62;true&#60;&#47;enableMultiSort&#62;&#60;enablePagingWhenOnePage&#62;true&#60;&#47;enablePagingWhenOnePage&#62;&#60;parameters&#62;&#60;autorefresh&#62;1&#60;&#47;autorefresh&#62;&#60;disableDblClick&#62;0&#60;&#47;disableDblClick&#62;&#60;viewid&#62;&#38;&#35;123&#59;E88CA999-0B16-4AE9-B6A9-9EDC840D42D8&#38;&#35;125&#59;&#60;&#47;viewid&#62;&#60;viewtype&#62;1039&#60;&#47;viewtype&#62;&#60;RecordsPerPage&#62;50&#60;&#47;RecordsPerPage&#62;&#60;otc&#62;8&#60;&#47;otc&#62;&#60;otn&#62;systemuser&#60;&#47;otn&#62;&#60;ObjectType&#62;8&#60;&#47;ObjectType&#62;&#60;DataProviderOverride&#62;Microsoft.Crm.Application.Controls.LookupGridDataProvider&#60;&#47;DataProviderOverride&#62;&#60;LoadOnDemand&#62;1&#60;&#47;LoadOnDemand&#62;&#60;LookupStyle&#62;single&#60;&#47;LookupStyle&#62;&#60;class&#62;BasicOwner&#60;&#47;class&#62;&#60;objecttypes&#62;8,9&#60;&#47;objecttypes&#62;&#60;browse&#62;0&#60;&#47;browse&#62;&#60;ShowNewButton&#62;1&#60;&#47;ShowNewButton&#62;&#60;ShowPropButton&#62;1&#60;&#47;ShowPropButton&#62;&#60;DefaultType&#62;0&#60;&#47;DefaultType&#62;&#60;Mode&#62;2&#60;&#47;Mode&#62;&#60;searchvalue&#47;&#62;&#60;BindingColumns&#47;&#62;&#60;showjumpbar&#62;0&#60;&#47;showjumpbar&#62;&#60;LayoutStyle&#62;GridList&#60;&#47;LayoutStyle&#62;&#60;quickfind&#47;&#62;&#60;filter&#47;&#62;&#60;filterDisplay&#47;&#62;&#60;filteruser&#47;&#62;&#60;&#47;parameters&#62;&#60;&#47;grid&#62;";

			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string AttributePageView(Guid entityId, int pageNum, string guid, string pagingCookie)
		{
			string grid = @"&lt;grid&gt;&lt;sortColumns&gt;schemaname&amp;#58;1&lt;/sortColumns&gt;&lt;pageNum&gt;1&lt;/pageNum&gt;&lt;recsPerPage&gt;50&lt;/recsPerPage&gt;&lt;dataProvider&gt;Microsoft.Crm.Application.Controls.SystemCustomization.AttributeGridDataProvider&lt;/dataProvider&gt;&lt;uiProvider&gt;Microsoft.Crm.Application.Controls.GridUIProvider&lt;/uiProvider&gt;&lt;cols/&gt;&lt;max&gt;-1&lt;/max&gt;&lt;refreshAsync&gt;False&lt;/refreshAsync&gt;&lt;pagingCookie/&gt;&lt;enableMultiSort&gt;true&lt;/enableMultiSort&gt;&lt;enablePagingWhenOnePage&gt;true&lt;/enablePagingWhenOnePage&gt;&lt;refreshCalledFromRefreshButton&gt;1&lt;/refreshCalledFromRefreshButton&gt;&lt;totalrecordcount&gt;19&lt;/totalrecordcount&gt;&lt;allrecordscounted&gt;true&lt;/allrecordscounted&gt;&lt;returntotalrecordcount&gt;true&lt;/returntotalrecordcount&gt;&lt;getParameters&gt;&lt;/getParameters&gt;&lt;parameters&gt;&lt;autorefresh&gt;1&lt;/autorefresh&gt;&lt;viewid&gt;&amp;#123;0741364C-84E1-488F-8A06-B2E068461DFE&amp;#125;&lt;/viewid&gt;&lt;viewtype&gt;1039&lt;/viewtype&gt;&lt;RecordsPerPage&gt;50&lt;/RecordsPerPage&gt;&lt;viewTitle&gt;Attributes&lt;/viewTitle&gt;&lt;layoutXml&gt;&amp;#60;grid name&amp;#61;&amp;#34;resultset&amp;#34; object&amp;#61;&amp;#34;0&amp;#34; jump&amp;#61;&amp;#34;schemaname&amp;#34; select&amp;#61;&amp;#34;0&amp;#34; preview&amp;#61;&amp;#34;0&amp;#34; icon&amp;#61;&amp;#34;1&amp;#34;&amp;#62;&amp;#60;row name&amp;#61;&amp;#34;result&amp;#34; id&amp;#61;&amp;#34;oid&amp;#34; multiobjectidfield&amp;#61;&amp;#34;moid&amp;#34;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;name&amp;#34; disableMetaDataBinding&amp;#61;&amp;#34;1&amp;#34; width&amp;#61;&amp;#34;150&amp;#34; LabelId&amp;#61;&amp;#34;query.0741364C-84E1-488F-8A06-B2E068461DFE.cell.schemaname.label&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;schemaname&amp;#34; disableMetaDataBinding&amp;#61;&amp;#34;1&amp;#34; width&amp;#61;&amp;#34;150&amp;#34; LabelId&amp;#61;&amp;#34;query.1948b400-2b19-435d-8a0b-9a6549b2f026.schemaname.label&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;displayname&amp;#34; disableMetaDataBinding&amp;#61;&amp;#34;1&amp;#34; width&amp;#61;&amp;#34;100&amp;#34; LabelId&amp;#61;&amp;#34;query.0741364C-84E1-488F-8A06-B2E068461DFE.cell.displayname.label&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;type&amp;#34; disableMetaDataBinding&amp;#61;&amp;#34;1&amp;#34; width&amp;#61;&amp;#34;100&amp;#34; LabelId&amp;#61;&amp;#34;query.0741364C-84E1-488F-8A06-B2E068461DFE.cell.type.label&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;ismanaged&amp;#34; disableMetaDataBinding&amp;#61;&amp;#34;1&amp;#34; width&amp;#61;&amp;#34;100&amp;#34; LabelId&amp;#61;&amp;#34;query.&amp;#123;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&amp;#125;.cell.ismanaged.label&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;isauditenabled&amp;#34; disableMetaDataBinding&amp;#61;&amp;#34;1&amp;#34; width&amp;#61;&amp;#34;100&amp;#34; LabelId&amp;#61;&amp;#34;query.&amp;#123;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&amp;#125;.cell.isauditenabled.label&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;iscustomizable&amp;#34; disableMetaDataBinding&amp;#61;&amp;#34;1&amp;#34; width&amp;#61;&amp;#34;100&amp;#34; LabelId&amp;#61;&amp;#34;query.&amp;#123;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&amp;#125;.cell.iscustomizable.label&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;description&amp;#34; disableMetaDataBinding&amp;#61;&amp;#34;1&amp;#34; width&amp;#61;&amp;#34;400&amp;#34; LabelId&amp;#61;&amp;#34;query.0741364C-84E1-488F-8A06-B2E068461DFE.cell.description.label&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;row&amp;#62;&amp;#60;&amp;#47;grid&amp;#62;&lt;/layoutXml&gt;&lt;otc&gt;0&lt;/otc&gt;&lt;otn&gt;&lt;/otn&gt;&lt;entitydisplayname&gt;&lt;/entitydisplayname&gt;&lt;titleformat&gt;&amp;#123;0&amp;#125;&amp;#58; &amp;#123;1&amp;#125;&lt;/titleformat&gt;&lt;entitypluraldisplayname&gt;&lt;/entitypluraldisplayname&gt;&lt;isquirksmode&gt;true&lt;/isquirksmode&gt;&lt;showjumpbar&gt;0&lt;/showjumpbar&gt;&lt;enablepaging&gt;1&lt;/enablepaging&gt;&lt;attributeFilter&gt;All&lt;/attributeFilter&gt;&lt;entityId&gt;&amp;#123;0550f5aa-339e-e111-bab2-f4ce46b298b1&amp;#125;&lt;/entityId&gt;&lt;disableDblClick&gt;0&lt;/disableDblClick&gt;&lt;isWorkflowSupported&gt;false&lt;/isWorkflowSupported&gt;&lt;LayoutStyle&gt;GridList&lt;/LayoutStyle&gt;&lt;/parameters&gt;&lt;columns&gt;&lt;column width=&quot;150&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;false&quot; isSortable=&quot;true&quot; label=&quot;Name&quot; fieldname=&quot;&quot; entityname=&quot;&quot;&gt;name&lt;/column&gt;&lt;column width=&quot;150&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;false&quot; isSortable=&quot;true&quot; label=&quot;Schema&amp;#32;Name&quot; fieldname=&quot;&quot; entityname=&quot;&quot;&gt;schemaname&lt;/column&gt;&lt;column width=&quot;100&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;false&quot; isSortable=&quot;true&quot; label=&quot;Display&amp;#32;Name&quot; fieldname=&quot;&quot; entityname=&quot;&quot;&gt;displayname&lt;/column&gt;&lt;column width=&quot;100&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;false&quot; isSortable=&quot;true&quot; label=&quot;Type&quot; fieldname=&quot;&quot; entityname=&quot;&quot;&gt;type&lt;/column&gt;&lt;column width=&quot;100&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;false&quot; isSortable=&quot;true&quot; label=&quot;State&quot; fieldname=&quot;&quot; entityname=&quot;&quot;&gt;ismanaged&lt;/column&gt;&lt;column width=&quot;100&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;false&quot; isSortable=&quot;true&quot; label=&quot;Audit&amp;#32;Status&quot; fieldname=&quot;&quot; entityname=&quot;&quot;&gt;isauditenabled&lt;/column&gt;&lt;column width=&quot;100&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;false&quot; isSortable=&quot;true&quot; label=&quot;Customizable&quot; fieldname=&quot;&quot; entityname=&quot;&quot;&gt;iscustomizable&lt;/column&gt;&lt;column width=&quot;400&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;false&quot; isSortable=&quot;true&quot; label=&quot;Description&quot; fieldname=&quot;&quot; entityname=&quot;&quot;&gt;description&lt;/column&gt;&lt;/columns&gt;&lt;/grid&gt;";
			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("ENTITY_GUID", entityId.ToString().ToUpper());
			grid = grid.Replace("VIEW_GUID", guid);
			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string AttributePageViewRefresh2(Guid entityId, int pageNum, string guid, string pagingCookie)
		{
			string grid = @"&#60;grid&#62;&#60;sortColumns&#62;displayname&#38;&#35;58&#59;1&#60;&#47;sortColumns&#62;&#60;pageNum&#62;1&#60;&#47;pageNum&#62;&#60;recsPerPage&#62;50&#60;&#47;recsPerPage&#62;&#60;dataProvider&#62;Microsoft.Crm.Application.Controls.SystemCustomization.SolutionComponentsGridDataProvider&#60;&#47;dataProvider&#62;&#60;uiProvider&#62;Microsoft.Crm.Application.Controls.GridUIProvider&#60;&#47;uiProvider&#62;&#60;cols&#47;&#62;&#60;max&#62;-1&#60;&#47;max&#62;&#60;refreshAsync&#62;False&#60;&#47;refreshAsync&#62;&#60;pagingCookie&#47;&#62;&#60;enableMultiSort&#62;true&#60;&#47;enableMultiSort&#62;&#60;enablePagingWhenOnePage&#62;true&#60;&#47;enablePagingWhenOnePage&#62;&#60;refreshCalledFromRefreshButton&#62;1&#60;&#47;refreshCalledFromRefreshButton&#62;&#60;totalrecordcount&#62;96&#60;&#47;totalrecordcount&#62;&#60;allrecordscounted&#62;true&#60;&#47;allrecordscounted&#62;&#60;getParameters&#62;&#60;&#47;getParameters&#62;&#60;parameters&#62;&#60;autorefresh&#62;1&#60;&#47;autorefresh&#62;&#60;oId&#62;&#38;&#35;123&#59;ENTITY_GUID&#38;&#35;125&#59;&#60;&#47;oId&#62;&#60;oType&#62;7100&#60;&#47;oType&#62;&#60;showjumpbar&#62;0&#60;&#47;showjumpbar&#62;&#60;queryapi&#47;&#62;&#60;enablepaging&#62;1&#60;&#47;enablepaging&#62;&#60;isCustomRelationship&#62;false&#60;&#47;isCustomRelationship&#62;&#60;subgridAutoExpand&#62;0&#60;&#47;subgridAutoExpand&#62;&#60;fixedsizerows&#62;0&#60;&#47;fixedsizerows&#62;&#60;tabindex&#62;-1&#60;&#47;tabindex&#62;&#60;roleOrd&#62;-1&#60;&#47;roleOrd&#62;&#60;isGridFilteringEnabled&#62;1&#60;&#47;isGridFilteringEnabled&#62;&#60;componentTypeFilter&#62;1&#60;&#47;componentTypeFilter&#62;&#60;componentSubFilter&#62;1&#60;&#47;componentSubFilter&#62;&#60;solutionid&#62;&#38;&#35;123&#59;ENTITY_GUID&#38;&#35;125&#59;&#60;&#47;solutionid&#62;&#60;otcmb&#62;7103&#60;&#47;otcmb&#62;&#60;relationshipType&#62;1&#60;&#47;relationshipType&#62;&#60;ribbonContext&#62;HomePageGrid&#60;&#47;ribbonContext&#62;&#60;viewid&#62;&#38;&#35;123&#59;VIEW_GUID&#38;&#35;125&#59;&#60;&#47;viewid&#62;&#60;viewtype&#62;1039&#60;&#47;viewtype&#62;&#60;RecordsPerPage&#62;50&#60;&#47;RecordsPerPage&#62;&#60;layoutXml&#62;&#38;&#35;60&#59;grid name&#38;&#35;61&#59;&#38;&#35;34&#59;resultset&#38;&#35;34&#59; object&#38;&#35;61&#59;&#38;&#35;34&#59;7103&#38;&#35;34&#59; jump&#38;&#35;61&#59;&#38;&#35;34&#59;displayname&#38;&#35;34&#59; select&#38;&#35;61&#59;&#38;&#35;34&#59;0&#38;&#35;34&#59; preview&#38;&#35;61&#59;&#38;&#35;34&#59;0&#38;&#35;34&#59; icon&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; iconrenderer&#38;&#35;61&#59;&#38;&#35;34&#59;Crm.SolutionComponentIcon&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;row name&#38;&#35;61&#59;&#38;&#35;34&#59;result&#38;&#35;34&#59; id&#38;&#35;61&#59;&#38;&#35;34&#59;oid&#38;&#35;34&#59; multiobjectidfield&#38;&#35;61&#59;&#38;&#35;34&#59;moid&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;displayname&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;200&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;76106eca-4473-4004-ab0b-5d1d730c18be&#38;&#35;125&#59;.cell.displayname.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;150&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;c9c2048f-4f52-4f81-8a33-b7b555eef9b2&#38;&#35;125&#59;.cell.name.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;type&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;150&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;ismanaged&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.ismanaged.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;iscustomizable&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.iscustomizable.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;isauditenabled&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.isauditenabled.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;description&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;300&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;66e2cea1-a35f-4a0e-80f1-5580733b0e60&#38;&#35;125&#59;.cell.description.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;solutioncomponentid&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; ishidden&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;componenttype&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; ishidden&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;subtype&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; ishidden&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;otc&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; ishidden&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;row&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;grid&#38;&#35;62&#59;&#60;&#47;layoutXml&#62;&#60;otc&#62;7103&#60;&#47;otc&#62;&#60;otn&#62;solutioncomponent&#60;&#47;otn&#62;&#60;entitydisplayname&#62;Solution Component&#60;&#47;entitydisplayname&#62;&#60;titleformat&#62;&#38;&#35;123&#59;0&#38;&#35;125&#59;&#38;&#35;58&#59; &#38;&#35;123&#59;1&#38;&#35;125&#59;&#60;&#47;titleformat&#62;&#60;entitypluraldisplayname&#62;Solution Components&#60;&#47;entitypluraldisplayname&#62;&#60;GridType&#62;AssociatedGrid&#60;&#47;GridType&#62;&#60;isWorkflowSupported&#62;false&#60;&#47;isWorkflowSupported&#62;&#60;LayoutStyle&#62;GridList&#60;&#47;LayoutStyle&#62;&#60;effectiveFetchXml&#47;&#62;&#60;isFetchXmlNotFinal&#47;&#62;&#60;&#47;parameters&#62;&#60;columns&#62;&#60;column width&#61;&#34;200&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Display&#38;&#35;32&#59;Name&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;displayname&#60;&#47;column&#62;&#60;column width&#61;&#34;150&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Name&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;name&#60;&#47;column&#62;&#60;column width&#61;&#34;150&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Type&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;type&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;State&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;ismanaged&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Customizable&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;iscustomizable&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Audit&#38;&#35;32&#59;Status&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;isauditenabled&#60;&#47;column&#62;&#60;column width&#61;&#34;300&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Description&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;description&#60;&#47;column&#62;&#60;column width&#61;&#34;0&#34; isHidden&#61;&#34;true&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;undefined&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;undefined&#34;&#62;solutioncomponentid&#60;&#47;column&#62;&#60;column width&#61;&#34;0&#34; isHidden&#61;&#34;true&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;undefined&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;undefined&#34;&#62;componenttype&#60;&#47;column&#62;&#60;column width&#61;&#34;0&#34; isHidden&#61;&#34;true&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;undefined&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;undefined&#34;&#62;subtype&#60;&#47;column&#62;&#60;column width&#61;&#34;0&#34; isHidden&#61;&#34;true&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;undefined&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;undefined&#34;&#62;otc&#60;&#47;column&#62;&#60;&#47;columns&#62;&#60;&#47;grid&#62;";

			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("ENTITY_GUID", entityId.ToString().ToUpper());
			grid = grid.Replace("VIEW_GUID", guid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string BusinessUnitPageView(int pageNum, string guid, string pagingCookie)
		{
			string grid = "&lt;grid&gt;&lt;sortColumns&gt;name&amp;#58;1&lt;/sortColumns&gt;&lt;pageNum&gt;1&lt;/pageNum&gt;&lt;recsPerPage&gt;50&lt;/recsPerPage&gt;&lt;dataProvider&gt;Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder&lt;/dataProvider&gt;&lt;uiProvider&gt;Microsoft.Crm.Application.Controls.GridUIProvider&lt;/uiProvider&gt;&lt;cols/&gt;&lt;max&gt;-1&lt;/max&gt;&lt;refreshAsync&gt;False&lt;/refreshAsync&gt;&lt;pagingCookie/&gt;&lt;enableMultiSort&gt;true&lt;/enableMultiSort&gt;&lt;enablePagingWhenOnePage&gt;true&lt;/enablePagingWhenOnePage&gt;&lt;refreshCalledFromRefreshButton&gt;1&lt;/refreshCalledFromRefreshButton&gt;&lt;totalrecordcount&gt;11&lt;/totalrecordcount&gt;&lt;allrecordscounted&gt;true&lt;/allrecordscounted&gt;&lt;returntotalrecordcount&gt;true&lt;/returntotalrecordcount&gt;&lt;getParameters&gt;&lt;/getParameters&gt;&lt;parameters&gt;&lt;autorefresh&gt;1&lt;/autorefresh&gt;&lt;isGridFilteringEnabled&gt;1&lt;/isGridFilteringEnabled&gt;&lt;viewid&gt;&amp;#123;00000000-0000-0000-00AA-000010001018&amp;#125;&lt;/viewid&gt;&lt;viewtype&gt;1039&lt;/viewtype&gt;&lt;RecordsPerPage&gt;50&lt;/RecordsPerPage&gt;&lt;viewTitle&gt;Active Business Units&lt;/viewTitle&gt;&lt;layoutXml&gt;&amp;#60;grid name&amp;#61;&amp;#34;resultset&amp;#34; object&amp;#61;&amp;#34;10&amp;#34; jump&amp;#61;&amp;#34;name&amp;#34; select&amp;#61;&amp;#34;1&amp;#34; icon&amp;#61;&amp;#34;1&amp;#34; preview&amp;#61;&amp;#34;1&amp;#34;&amp;#62;&amp;#60;row name&amp;#61;&amp;#34;result&amp;#34; id&amp;#61;&amp;#34;businessunitid&amp;#34;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;name&amp;#34; width&amp;#61;&amp;#34;300&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;address1_telephone1&amp;#34; width&amp;#61;&amp;#34;150&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;websiteurl&amp;#34; width&amp;#61;&amp;#34;150&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;parentbusinessunitid&amp;#34; width&amp;#61;&amp;#34;300&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;row&amp;#62;&amp;#60;&amp;#47;grid&amp;#62;&lt;/layoutXml&gt;&lt;otc&gt;10&lt;/otc&gt;&lt;otn&gt;businessunit&lt;/otn&gt;&lt;entitydisplayname&gt;Business Unit&lt;/entitydisplayname&gt;&lt;titleformat&gt;&amp;#123;0&amp;#125; &amp;#123;1&amp;#125;&lt;/titleformat&gt;&lt;entitypluraldisplayname&gt;Business Units&lt;/entitypluraldisplayname&gt;&lt;isWorkflowSupported&gt;true&lt;/isWorkflowSupported&gt;&lt;fetchXmlForFilters&gt;&amp;#60;fetch version&amp;#61;&amp;#34;1.0&amp;#34; output-format&amp;#61;&amp;#34;xml-platform&amp;#34; mapping&amp;#61;&amp;#34;logical&amp;#34;&amp;#62;&amp;#60;entity name&amp;#61;&amp;#34;businessunit&amp;#34;&amp;#62;&amp;#60;order attribute&amp;#61;&amp;#34;name&amp;#34; descending&amp;#61;&amp;#34;false&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;name&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;address1_telephone1&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;websiteurl&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;parentbusinessunitid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;businessunitid&amp;#34; &amp;#47;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;isdisabled&amp;#34; operator&amp;#61;&amp;#34;eq&amp;#34; value&amp;#61;&amp;#34;0&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;&amp;#47;entity&amp;#62;&amp;#60;&amp;#47;fetch&amp;#62;&lt;/fetchXmlForFilters&gt;&lt;isFetchXmlNotFinal&gt;False&lt;/isFetchXmlNotFinal&gt;&lt;effectiveFetchXml&gt;&amp;#60;fetch distinct&amp;#61;&amp;#34;false&amp;#34; no-lock&amp;#61;&amp;#34;false&amp;#34; mapping&amp;#61;&amp;#34;logical&amp;#34; page&amp;#61;&amp;#34;1&amp;#34; count&amp;#61;&amp;#34;50&amp;#34; returntotalrecordcount&amp;#61;&amp;#34;true&amp;#34;&amp;#62;&amp;#60;entity name&amp;#61;&amp;#34;businessunit&amp;#34;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;name&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;address1_telephone1&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;websiteurl&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;parentbusinessunitid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;businessunitid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;name&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;address1_telephone1&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;websiteurl&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;parentbusinessunitid&amp;#34; &amp;#47;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;isdisabled&amp;#34; operator&amp;#61;&amp;#34;eq&amp;#34; value&amp;#61;&amp;#34;0&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;order attribute&amp;#61;&amp;#34;name&amp;#34; descending&amp;#61;&amp;#34;false&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;entity&amp;#62;&amp;#60;&amp;#47;fetch&amp;#62;&lt;/effectiveFetchXml&gt;&lt;LayoutStyle&gt;GridList&lt;/LayoutStyle&gt;&lt;enableFilters&gt;1&lt;/enableFilters&gt;&lt;/parameters&gt;&lt;columns&gt;&lt;column width=&quot;300&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Name&quot; fieldname=&quot;name&quot; entityname=&quot;businessunit&quot; renderertype=&quot;Crm.PrimaryField&quot;&gt;name&lt;/column&gt;&lt;column width=&quot;150&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Main&amp;#32;Phone&quot; fieldname=&quot;address1_telephone1&quot; entityname=&quot;businessunit&quot; renderertype=&quot;nvarchar&quot;&gt;address1_telephone1&lt;/column&gt;&lt;column width=&quot;150&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Website&quot; fieldname=&quot;websiteurl&quot; entityname=&quot;businessunit&quot; renderertype=&quot;Crm.Url&quot;&gt;websiteurl&lt;/column&gt;&lt;column width=&quot;300&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Parent&amp;#32;Business&quot; fieldname=&quot;parentbusinessunitid&quot; entityname=&quot;businessunit&quot; renderertype=&quot;lookup&quot;&gt;parentbusinessunitid&lt;/column&gt;&lt;/columns&gt;&lt;/grid&gt;";
			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string AllAffiliatedRecordsViewRefresh(int pageNum, string guid, string pagingCookie)
		{
			string grid = @"&#60;grid&#62;&#60;sortColumns&#62;name&#38;&#35;58&#59;1&#60;&#47;sortColumns&#62;&#60;pageNum&#62;1&#60;&#47;pageNum&#62;&#60;recsPerPage&#62;50&#60;&#47;recsPerPage&#62;&#60;dataProvider&#62;Microsoft.Crm.Application.Controls.Grid.Data.GridDataProviderQueryBuilder&#60;&#47;dataProvider&#62;&#60;uiProvider&#62;Microsoft.Crm.Application.Controls.GridUIProvider&#60;&#47;uiProvider&#62;&#60;cols&#47;&#62;&#60;max&#62;-1&#60;&#47;max&#62;&#60;refreshAsync&#62;False&#60;&#47;refreshAsync&#62;&#60;pagingCookie&#47;&#62;&#60;enableMultiSort&#62;true&#60;&#47;enableMultiSort&#62;&#60;enablePagingWhenOnePage&#62;true&#60;&#47;enablePagingWhenOnePage&#62;&#60;parameters&#62;&#60;autorefresh&#62;1&#60;&#47;autorefresh&#62;&#60;oId&#62;&#38;&#35;123&#59;92a8b577-e7b5-dd11-8a26-0018fe33924b&#38;&#35;125&#59;&#60;&#47;oId&#62;&#60;oType&#62;2&#60;&#47;oType&#62;&#60;queryapi&#62;CRMOpportunity.ExtendedByObject&#60;&#47;queryapi&#62;&#60;enablepaging&#62;1&#60;&#47;enablepaging&#62;&#60;isCustomRelationship&#62;false&#60;&#47;isCustomRelationship&#62;&#60;fixedsizerows&#62;0&#60;&#47;fixedsizerows&#62;&#60;relName&#62;opportunity_customer_contacts&#60;&#47;relName&#62;&#60;roleOrd&#62;-1&#60;&#47;roleOrd&#62;&#60;viewid&#62;&#38;&#35;123&#59;00000000-0000-0000-00AA-000010001203&#38;&#35;125&#59;&#60;&#47;viewid&#62;&#60;viewtype&#62;1039&#60;&#47;viewtype&#62;&#60;RecordsPerPage&#62;50&#60;&#47;RecordsPerPage&#62;&#60;preview&#62;1&#60;&#47;preview&#62;&#60;otc&#62;3&#60;&#47;otc&#62;&#60;otn&#62;opportunity&#60;&#47;otn&#62;&#60;showjumpbar&#62;1&#60;&#47;showjumpbar&#62;&#60;crmGrid_statecode&#62;0&#60;&#47;crmGrid_statecode&#62;&#60;viewTitle&#62;Opportunity Associated View&#60;&#47;viewTitle&#62;&#60;layoutXml&#62;&#38;&#35;60&#59;grid name&#38;&#35;61&#59;&#38;&#35;34&#59;opportunities&#38;&#35;34&#59; object&#38;&#35;61&#59;&#38;&#35;34&#59;3&#38;&#35;34&#59; jump&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; select&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; icon&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; preview&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;row name&#38;&#35;61&#59;&#38;&#35;34&#59;opportunity&#38;&#35;34&#59; id&#38;&#35;61&#59;&#38;&#35;34&#59;opportunityid&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;300&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;estimatedvalue&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;statuscode&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;estimatedclosedate&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;125&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;row&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;grid&#38;&#35;62&#59;&#60;&#47;layoutXml&#62;&#60;fetchXmlForFilters&#62;&#38;&#35;60&#59;fetch distinct&#38;&#35;61&#59;&#38;&#35;34&#59;false&#38;&#35;34&#59; mapping&#38;&#35;61&#59;&#38;&#35;34&#59;logical&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;entity name&#38;&#35;61&#59;&#38;&#35;34&#59;opportunity&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;estimatedvalue&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;statuscode&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;estimatedclosedate&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;opportunityid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;order attribute&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; descending&#38;&#35;61&#59;&#38;&#35;34&#59;false&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;entity&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;fetch&#38;&#35;62&#59;&#60;&#47;fetchXmlForFilters&#62;&#60;effectiveFetchXml&#62;&#38;&#35;60&#59;fetch distinct&#38;&#35;61&#59;&#38;&#35;34&#59;false&#38;&#35;34&#59; mapping&#38;&#35;61&#59;&#38;&#35;34&#59;logical&#38;&#35;34&#59; page&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; count&#38;&#35;61&#59;&#38;&#35;34&#59;50&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;entity name&#38;&#35;61&#59;&#38;&#35;34&#59;opportunity&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;estimatedvalue&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;statuscode&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;estimatedclosedate&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;opportunityid&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;estimatedvalue&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;statuscode&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;attribute name&#38;&#35;61&#59;&#38;&#35;34&#59;estimatedclosedate&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;order attribute&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; descending&#38;&#35;61&#59;&#38;&#35;34&#59;false&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;entity&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;fetch&#38;&#35;62&#59;&#60;&#47;effectiveFetchXml&#62;&#60;LayoutStyle&#62;GridList&#60;&#47;LayoutStyle&#62;&#60;statecode&#62;0&#60;&#47;statecode&#62;&#60;&#47;parameters&#62;&#60;columns&#62;&#60;column width&#61;&#34;300&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Topic&#34; fieldname&#61;&#34;name&#34; entityname&#61;&#34;opportunity&#34; renderertype&#61;&#34;nvarchar&#34;&#62;name&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Est. Revenue&#34; fieldname&#61;&#34;estimatedvalue&#34; entityname&#61;&#34;opportunity&#34; renderertype&#61;&#34;money&#34;&#62;estimatedvalue&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Status Reason&#34; fieldname&#61;&#34;statuscode&#34; entityname&#61;&#34;opportunity&#34; renderertype&#61;&#34;status&#34;&#62;statuscode&#60;&#47;column&#62;&#60;column width&#61;&#34;125&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Est. Close Date&#34; fieldname&#61;&#34;estimatedclosedate&#34; entityname&#61;&#34;opportunity&#34; renderertype&#61;&#34;datetime&#34;&#62;estimatedclosedate&#60;&#47;column&#62;&#60;&#47;columns&#62;&#60;&#47;grid&#62;";

			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string EntityPageView(int pageNum, string guid, string pagingCookie)
		{
			string grid = @"&#60;grid&#62;&#60;sortColumns&#62;displayname&#38;&#35;58&#59;1&#60;&#47;sortColumns&#62;&#60;pageNum&#62;1&#60;&#47;pageNum&#62;&#60;recsPerPage&#62;50&#60;&#47;recsPerPage&#62;&#60;dataProvider&#62;Microsoft.Crm.Application.Controls.SystemCustomization.SolutionComponentsGridDataProvider&#60;&#47;dataProvider&#62;&#60;uiProvider&#62;Microsoft.Crm.Application.Controls.GridUIProvider&#60;&#47;uiProvider&#62;&#60;cols&#47;&#62;&#60;max&#62;-1&#60;&#47;max&#62;&#60;refreshAsync&#62;False&#60;&#47;refreshAsync&#62;&#60;pagingCookie&#47;&#62;&#60;enableMultiSort&#62;true&#60;&#47;enableMultiSort&#62;&#60;enablePagingWhenOnePage&#62;true&#60;&#47;enablePagingWhenOnePage&#62;&#60;refreshCalledFromRefreshButton&#62;1&#60;&#47;refreshCalledFromRefreshButton&#62;&#60;totalrecordcount&#62;95&#60;&#47;totalrecordcount&#62;&#60;allrecordscounted&#62;true&#60;&#47;allrecordscounted&#62;&#60;getParameters&#62;&#60;&#47;getParameters&#62;&#60;parameters&#62;&#60;autorefresh&#62;1&#60;&#47;autorefresh&#62;&#60;oId&#62;&#38;&#35;123&#59;fd140aaf-4df4-11dd-bd17-0019b9312238&#38;&#35;125&#59;&#60;&#47;oId&#62;&#60;oType&#62;7100&#60;&#47;oType&#62;&#60;showjumpbar&#62;0&#60;&#47;showjumpbar&#62;&#60;queryapi&#47;&#62;&#60;enablepaging&#62;1&#60;&#47;enablepaging&#62;&#60;isCustomRelationship&#62;false&#60;&#47;isCustomRelationship&#62;&#60;subgridAutoExpand&#62;0&#60;&#47;subgridAutoExpand&#62;&#60;fixedsizerows&#62;0&#60;&#47;fixedsizerows&#62;&#60;tabindex&#62;-1&#60;&#47;tabindex&#62;&#60;roleOrd&#62;-1&#60;&#47;roleOrd&#62;&#60;isGridFilteringEnabled&#62;1&#60;&#47;isGridFilteringEnabled&#62;&#60;componentTypeFilter&#62;1&#60;&#47;componentTypeFilter&#62;&#60;componentSubFilter&#62;1&#60;&#47;componentSubFilter&#62;&#60;solutionid&#62;&#38;&#35;123&#59;fd140aaf-4df4-11dd-bd17-0019b9312238&#38;&#35;125&#59;&#60;&#47;solutionid&#62;&#60;otcmb&#62;7103&#60;&#47;otcmb&#62;&#60;relationshipType&#62;1&#60;&#47;relationshipType&#62;&#60;ribbonContext&#62;HomePageGrid&#60;&#47;ribbonContext&#62;&#60;viewid&#62;&#38;&#35;123&#59;EBA2D9CB-47B5-11DD-982E-00188B01DCE6&#38;&#35;125&#59;&#60;&#47;viewid&#62;&#60;viewtype&#62;1039&#60;&#47;viewtype&#62;&#60;RecordsPerPage&#62;50&#60;&#47;RecordsPerPage&#62;&#60;layoutXml&#62;&#38;&#35;60&#59;grid name&#38;&#35;61&#59;&#38;&#35;34&#59;resultset&#38;&#35;34&#59; object&#38;&#35;61&#59;&#38;&#35;34&#59;7103&#38;&#35;34&#59; jump&#38;&#35;61&#59;&#38;&#35;34&#59;displayname&#38;&#35;34&#59; select&#38;&#35;61&#59;&#38;&#35;34&#59;0&#38;&#35;34&#59; preview&#38;&#35;61&#59;&#38;&#35;34&#59;0&#38;&#35;34&#59; icon&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; iconrenderer&#38;&#35;61&#59;&#38;&#35;34&#59;Crm.SolutionComponentIcon&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;row name&#38;&#35;61&#59;&#38;&#35;34&#59;result&#38;&#35;34&#59; id&#38;&#35;61&#59;&#38;&#35;34&#59;oid&#38;&#35;34&#59; multiobjectidfield&#38;&#35;61&#59;&#38;&#35;34&#59;moid&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;displayname&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;200&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;76106eca-4473-4004-ab0b-5d1d730c18be&#38;&#35;125&#59;.cell.displayname.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;name&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;150&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;c9c2048f-4f52-4f81-8a33-b7b555eef9b2&#38;&#35;125&#59;.cell.name.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;type&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;150&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;ismanaged&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.ismanaged.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;iscustomizable&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.iscustomizable.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;isauditenabled&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.isauditenabled.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;description&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;300&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;66e2cea1-a35f-4a0e-80f1-5580733b0e60&#38;&#35;125&#59;.cell.description.label&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;solutioncomponentid&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; ishidden&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;componenttype&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; ishidden&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;subtype&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; ishidden&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;otc&#38;&#35;34&#59; disableMetaDataBinding&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; LabelId&#38;&#35;61&#59;&#38;&#35;34&#59;query.&#38;&#35;123&#59;40ef3a86-3725-4d4f-bdd3-7c8bf985c1a2&#38;&#35;125&#59;.cell.type.label&#38;&#35;34&#59; ishidden&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;row&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;grid&#38;&#35;62&#59;&#60;&#47;layoutXml&#62;&#60;otc&#62;7103&#60;&#47;otc&#62;&#60;otn&#62;solutioncomponent&#60;&#47;otn&#62;&#60;entitydisplayname&#62;Solution Component&#60;&#47;entitydisplayname&#62;&#60;titleformat&#62;&#38;&#35;123&#59;0&#38;&#35;125&#59;&#38;&#35;58&#59; &#38;&#35;123&#59;1&#38;&#35;125&#59;&#60;&#47;titleformat&#62;&#60;entitypluraldisplayname&#62;Solution Components&#60;&#47;entitypluraldisplayname&#62;&#60;GridType&#62;AssociatedGrid&#60;&#47;GridType&#62;&#60;isWorkflowSupported&#62;false&#60;&#47;isWorkflowSupported&#62;&#60;LayoutStyle&#62;GridList&#60;&#47;LayoutStyle&#62;&#60;&#47;parameters&#62;&#60;columns&#62;&#60;column width&#61;&#34;200&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Display&#38;&#35;32&#59;Name&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;displayname&#60;&#47;column&#62;&#60;column width&#61;&#34;150&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Name&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;name&#60;&#47;column&#62;&#60;column width&#61;&#34;150&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Type&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;type&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;State&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;ismanaged&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Customizable&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;iscustomizable&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Audit&#38;&#35;32&#59;Status&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;isauditenabled&#60;&#47;column&#62;&#60;column width&#61;&#34;300&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Description&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;&#34;&#62;description&#60;&#47;column&#62;&#60;column width&#61;&#34;0&#34; isHidden&#61;&#34;true&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;undefined&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;undefined&#34;&#62;solutioncomponentid&#60;&#47;column&#62;&#60;column width&#61;&#34;0&#34; isHidden&#61;&#34;true&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;undefined&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;undefined&#34;&#62;componenttype&#60;&#47;column&#62;&#60;column width&#61;&#34;0&#34; isHidden&#61;&#34;true&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;undefined&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;undefined&#34;&#62;subtype&#60;&#47;column&#62;&#60;column width&#61;&#34;0&#34; isHidden&#61;&#34;true&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;undefined&#34; fieldname&#61;&#34;&#34; entityname&#61;&#34;undefined&#34;&#62;otc&#60;&#47;column&#62;&#60;&#47;columns&#62;&#60;&#47;grid&#62;";

			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string IncidentPageViewRefresh(int pageNum, string guid, string pagingCookie)
		{
			string grid = "&lt;grid&gt;&lt;sortColumns&gt;modifiedon&amp;#58;0&lt;/sortColumns&gt;&lt;pageNum&gt;1&lt;/pageNum&gt;&lt;recsPerPage&gt;5&lt;/recsPerPage&gt;&lt;dataProvider&gt;Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder&lt;/dataProvider&gt;&lt;uiProvider&gt;Microsoft.Crm.Application.Controls.GridUIProvider&lt;/uiProvider&gt;&lt;cols/&gt;&lt;max&gt;1&lt;/max&gt;&lt;refreshAsync&gt;True&lt;/refreshAsync&gt;&lt;pagingCookie/&gt;&lt;enableMultiSort&gt;true&lt;/enableMultiSort&gt;&lt;enablePagingWhenOnePage&gt;true&lt;/enablePagingWhenOnePage&gt;&lt;refreshCalledFromRefreshButton&gt;1&lt;/refreshCalledFromRefreshButton&gt;&lt;returntotalrecordcount&gt;true&lt;/returntotalrecordcount&gt;&lt;getParameters&gt;getFetchXmlForFilters&lt;/getParameters&gt;&lt;parameters&gt;&lt;viewid&gt;&amp;#123;00000000-0000-0000-00AA-000010001039&amp;#125;&lt;/viewid&gt;&lt;RenderAsync&gt;0&lt;/RenderAsync&gt;&lt;LoadOnDemand&gt;0&lt;/LoadOnDemand&gt;&lt;deleteAction&gt;&lt;/deleteAction&gt;&lt;autorefresh&gt;1&lt;/autorefresh&gt;&lt;LayoutStyle&gt;LiteGridList&lt;/LayoutStyle&gt;&lt;maxselectableitems&gt;1&lt;/maxselectableitems&gt;&lt;isGridFilteringEnabled&gt;1&lt;/isGridFilteringEnabled&gt;&lt;viewtype&gt;1039&lt;/viewtype&gt;&lt;viewts&gt;294774&lt;/viewts&gt;&lt;RecordsPerPage&gt;5&lt;/RecordsPerPage&gt;&lt;viewTitle&gt;All Cases for Customer&lt;/viewTitle&gt;&lt;layoutXml&gt;&amp;#60;grid name&amp;#61;&amp;#34;resultset&amp;#34; object&amp;#61;&amp;#34;112&amp;#34; jump&amp;#61;&amp;#34;statecode&amp;#34; select&amp;#61;&amp;#34;1&amp;#34; icon&amp;#61;&amp;#34;1&amp;#34; preview&amp;#61;&amp;#34;1&amp;#34;&amp;#62;&amp;#60;row name&amp;#61;&amp;#34;result&amp;#34; id&amp;#61;&amp;#34;incidentid&amp;#34;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;statecode&amp;#34; width&amp;#61;&amp;#34;70&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;title&amp;#34; width&amp;#61;&amp;#34;105&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;row&amp;#62;&amp;#60;&amp;#47;grid&amp;#62;&lt;/layoutXml&gt;&lt;otc&gt;112&lt;/otc&gt;&lt;otn&gt;incident&lt;/otn&gt;&lt;entitydisplayname&gt;Case&lt;/entitydisplayname&gt;&lt;titleformat&gt;&amp;#123;0&amp;#125; &amp;#123;1&amp;#125;&lt;/titleformat&gt;&lt;entitypluraldisplayname&gt;Cases&lt;/entitypluraldisplayname&gt;&lt;expandable&gt;1&lt;/expandable&gt;&lt;showjumpbar&gt;0&lt;/showjumpbar&gt;&lt;maxrowsbeforescroll&gt;7&lt;/maxrowsbeforescroll&gt;&lt;tabindex&gt;1620&lt;/tabindex&gt;&lt;refreshasynchronous&gt;1&lt;/refreshasynchronous&gt;&lt;subgridAutoExpand&gt;1&lt;/subgridAutoExpand&gt;&lt;relName&gt;incident_customer_accounts&lt;/relName&gt;&lt;roleOrd&gt;-1&lt;/roleOrd&gt;&lt;relationshipType&gt;1&lt;/relationshipType&gt;&lt;ribbonContext&gt;SubGridStandard&lt;/ribbonContext&gt;&lt;GridType&gt;SubGrid&lt;/GridType&gt;&lt;teamTemplateId&gt;&lt;/teamTemplateId&gt;&lt;isWorkflowSupported&gt;true&lt;/isWorkflowSupported&gt;&lt;enableFilters&gt;&lt;/enableFilters&gt;&lt;InnerGridDisabled&gt;0&lt;/InnerGridDisabled&gt;&lt;oId&gt;&amp;#123;1F5872E9-83EB-E211-8F97-00155DA9F713&amp;#125;&lt;/oId&gt;&lt;oType&gt;1&lt;/oType&gt;&lt;/parameters&gt;&lt;columns&gt;&lt;column width=&quot;70&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Status&quot; fieldname=&quot;statecode&quot; entityname=&quot;incident&quot;&gt;statecode&lt;/column&gt;&lt;column width=&quot;105&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Case&amp;#32;Title&quot; fieldname=&quot;title&quot; entityname=&quot;incident&quot; renderertype=&quot;Crm.PrimaryField&quot;&gt;title&lt;/column&gt;&lt;/columns&gt;&lt;/grid&gt;";
			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string IncidentPageSearchViewRefresh(int pageNum, string guid, string random, string pagingCookie)
		{
			string grid = @"&lt;grid&gt;&lt;sortColumns&gt;title&amp;#58;1&lt;/sortColumns&gt;&lt;pageNum&gt;1&lt;/pageNum&gt;&lt;recsPerPage&gt;50&lt;/recsPerPage&gt;&lt;dataProvider&gt;Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder&lt;/dataProvider&gt;&lt;uiProvider&gt;Microsoft.Crm.Application.Controls.GridUIProvider&lt;/uiProvider&gt;&lt;cols/&gt;&lt;max&gt;-1&lt;/max&gt;&lt;refreshAsync&gt;False&lt;/refreshAsync&gt;&lt;pagingCookie/&gt;&lt;enableMultiSort&gt;true&lt;/enableMultiSort&gt;&lt;enablePagingWhenOnePage&gt;true&lt;/enablePagingWhenOnePage&gt;&lt;refreshCalledFromRefreshButton&gt;1&lt;/refreshCalledFromRefreshButton&gt;&lt;totalrecordcount&gt;157&lt;/totalrecordcount&gt;&lt;allrecordscounted&gt;true&lt;/allrecordscounted&gt;&lt;returntotalrecordcount&gt;true&lt;/returntotalrecordcount&gt;&lt;getParameters&gt;&lt;/getParameters&gt;&lt;parameters&gt;&lt;autorefresh&gt;1&lt;/autorefresh&gt;&lt;isGridFilteringEnabled&gt;1&lt;/isGridFilteringEnabled&gt;&lt;viewid&gt;&amp;#123;D95D47EF-4A1D-479E-9065-B9CEA0089048&amp;#125;&lt;/viewid&gt;&lt;viewtype&gt;1039&lt;/viewtype&gt;&lt;RecordsPerPage&gt;50&lt;/RecordsPerPage&gt;&lt;viewTitle&gt;Quick Find Active Cases&lt;/viewTitle&gt;&lt;layoutXml&gt;&amp;#60;grid name&amp;#61;&amp;#34;resultset&amp;#34; object&amp;#61;&amp;#34;112&amp;#34; jump&amp;#61;&amp;#34;title&amp;#34; select&amp;#61;&amp;#34;1&amp;#34; icon&amp;#61;&amp;#34;1&amp;#34; preview&amp;#61;&amp;#34;1&amp;#34;&amp;#62;&amp;#60;row name&amp;#61;&amp;#34;result&amp;#34; id&amp;#61;&amp;#34;incidentid&amp;#34;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;title&amp;#34; width&amp;#61;&amp;#34;300&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;ticketnumber&amp;#34; width&amp;#61;&amp;#34;150&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;prioritycode&amp;#34; width&amp;#61;&amp;#34;150&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;createdon&amp;#34; width&amp;#61;&amp;#34;150&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;row&amp;#62;&amp;#60;&amp;#47;grid&amp;#62;&lt;/layoutXml&gt;&lt;otc&gt;112&lt;/otc&gt;&lt;otn&gt;incident&lt;/otn&gt;&lt;entitydisplayname&gt;Case&lt;/entitydisplayname&gt;&lt;titleformat&gt;&amp;#123;0&amp;#125;&amp;#58; &amp;#123;1&amp;#125;&lt;/titleformat&gt;&lt;entitypluraldisplayname&gt;Cases&lt;/entitypluraldisplayname&gt;&lt;isWorkflowSupported&gt;true&lt;/isWorkflowSupported&gt;&lt;LayoutStyle&gt;GridList&lt;/LayoutStyle&gt;&lt;quickfind&gt;ab&lt;/quickfind&gt;&lt;filter/&gt;&lt;filterDisplay/&gt;&lt;maxselectableitems&gt;-1&lt;/maxselectableitems&gt;&lt;/parameters&gt;&lt;columns&gt;&lt;column width=&quot;300&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Title&quot; fieldname=&quot;title&quot; entityname=&quot;incident&quot; renderertype=&quot;Crm.PrimaryField&quot;&gt;title&lt;/column&gt;&lt;column width=&quot;150&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Case&amp;#32;Number&quot; fieldname=&quot;ticketnumber&quot; entityname=&quot;incident&quot; renderertype=&quot;nvarchar&quot;&gt;ticketnumber&lt;/column&gt;&lt;column width=&quot;150&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Priority&quot; fieldname=&quot;prioritycode&quot; entityname=&quot;incident&quot; renderertype=&quot;picklist&quot;&gt;prioritycode&lt;/column&gt;&lt;column width=&quot;150&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Created&amp;#32;On&quot; fieldname=&quot;createdon&quot; entityname=&quot;incident&quot; renderertype=&quot;datetime&quot;&gt;createdon&lt;/column&gt;&lt;/columns&gt;&lt;/grid&gt;";
			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");

			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			grid = grid.Remove(grid.IndexOf("<quickfind>") + 11, grid.IndexOf("</quickfind>") - (grid.IndexOf("<quickfind>") + 11));
			grid = grid.Insert(grid.IndexOf("<quickfind>") + 11, random);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string ListPageViewRefresh(int pageNum, string guid, string pagingCookie)
		{
			string grid = @"&#60;grid&#62;&#60;sortColumns&#62;listname&#38;&#35;58&#59;1&#60;&#47;sortColumns&#62;&#60;pageNum&#62;1&#60;&#47;pageNum&#62;&#60;recsPerPage&#62;50&#60;&#47;recsPerPage&#62;&#60;dataProvider&#62;Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder&#60;&#47;dataProvider&#62;&#60;uiProvider&#62;Microsoft.Crm.Application.Controls.GridUIProvider&#60;&#47;uiProvider&#62;&#60;cols&#47;&#62;&#60;max&#62;-1&#60;&#47;max&#62;&#60;refreshAsync&#62;False&#60;&#47;refreshAsync&#62;&#60;pagingCookie&#62;&#38;&#35;60&#59;cookie page&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;listname last&#38;&#35;61&#59;&#38;&#35;34&#59;EsgyF&#38;&#35;34&#59; first&#38;&#35;61&#59;&#38;&#35;34&#59;0b1lJq3s&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;listid last&#38;&#35;61&#59;&#38;&#35;34&#59;&#38;&#35;123&#59;72D49F63-BBEA-E011-8002-002264A0E014&#38;&#35;125&#59;&#38;&#35;34&#59; first&#38;&#35;61&#59;&#38;&#35;34&#59;&#38;&#35;123&#59;D6FAE73F-BDEA-E011-8002-002264A0E014&#38;&#35;125&#59;&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;cookie&#38;&#35;62&#59;&#60;&#47;pagingCookie&#62;&#60;enableMultiSort&#62;true&#60;&#47;enableMultiSort&#62;&#60;enablePagingWhenOnePage&#62;true&#60;&#47;enablePagingWhenOnePage&#62;&#60;refreshCalledFromRefreshButton&#62;1&#60;&#47;refreshCalledFromRefreshButton&#62;&#60;totalrecordcount&#62;154&#60;&#47;totalrecordcount&#62;&#60;allrecordscounted&#62;true&#60;&#47;allrecordscounted&#62;&#60;returntotalrecordcount&#62;true&#60;&#47;returntotalrecordcount&#62;&#60;getParameters&#62;&#60;&#47;getParameters&#62;&#60;parameters&#62;&#60;autorefresh&#62;1&#60;&#47;autorefresh&#62;&#60;isGridFilteringEnabled&#62;1&#60;&#47;isGridFilteringEnabled&#62;&#60;viewid&#62;&#38;&#35;123&#59;823B9210-B82A-4B11-B0F6-B9E4C9C8403F&#38;&#35;125&#59;&#60;&#47;viewid&#62;&#60;viewtype&#62;1039&#60;&#47;viewtype&#62;&#60;RecordsPerPage&#62;50&#60;&#47;RecordsPerPage&#62;&#60;viewTitle&#62;My Active Marketing Lists&#60;&#47;viewTitle&#62;&#60;layoutXml&#62;&#38;&#35;60&#59;grid name&#38;&#35;61&#59;&#38;&#35;34&#59;resultset&#38;&#35;34&#59; object&#38;&#35;61&#59;&#38;&#35;34&#59;4300&#38;&#35;34&#59; jump&#38;&#35;61&#59;&#38;&#35;34&#59;listname&#38;&#35;34&#59; select&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; icon&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59; preview&#38;&#35;61&#59;&#38;&#35;34&#59;1&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;row name&#38;&#35;61&#59;&#38;&#35;34&#59;result&#38;&#35;34&#59; id&#38;&#35;61&#59;&#38;&#35;34&#59;listid&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;listname&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;300&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;type&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;createdfromcode&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;lastusedon&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;cell name&#38;&#35;61&#59;&#38;&#35;34&#59;purpose&#38;&#35;34&#59; width&#38;&#35;61&#59;&#38;&#35;34&#59;100&#38;&#35;34&#59; &#38;&#35;47&#59;&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;row&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;grid&#38;&#35;62&#59;&#60;&#47;layoutXml&#62;&#60;otc&#62;4300&#60;&#47;otc&#62;&#60;otn&#62;list&#60;&#47;otn&#62;&#60;entitydisplayname&#62;Marketing List&#60;&#47;entitydisplayname&#62;&#60;titleformat&#62;&#38;&#35;123&#59;0&#38;&#35;125&#59;&#38;&#35;58&#59; &#38;&#35;123&#59;1&#38;&#35;125&#59;&#60;&#47;titleformat&#62;&#60;entitypluraldisplayname&#62;Marketing Lists&#60;&#47;entitypluraldisplayname&#62;&#60;isWorkflowSupported&#62;true&#60;&#47;isWorkflowSupported&#62;&#60;LayoutStyle&#62;GridList&#60;&#47;LayoutStyle&#62;&#60;&#47;parameters&#62;&#60;columns&#62;&#60;column width&#61;&#34;300&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Name&#34; fieldname&#61;&#34;listname&#34; entityname&#61;&#34;list&#34; renderertype&#61;&#34;Crm.PrimaryField&#34;&#62;listname&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Type&#34; fieldname&#61;&#34;type&#34; entityname&#61;&#34;list&#34; renderertype&#61;&#34;bit&#34;&#62;type&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Marketing&#38;&#35;32&#59;List&#38;&#35;32&#59;Member&#38;&#35;32&#59;Type&#34; fieldname&#61;&#34;createdfromcode&#34; entityname&#61;&#34;list&#34; renderertype&#61;&#34;picklist&#34;&#62;createdfromcode&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Last&#38;&#35;32&#59;Used&#38;&#35;32&#59;On&#34; fieldname&#61;&#34;lastusedon&#34; entityname&#61;&#34;list&#34; renderertype&#61;&#34;datetime&#34;&#62;lastusedon&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;true&#34; isSortable&#61;&#34;true&#34; label&#61;&#34;Purpose&#34; fieldname&#61;&#34;purpose&#34; entityname&#61;&#34;list&#34; renderertype&#61;&#34;nvarchar&#34;&#62;purpose&#60;&#47;column&#62;&#60;&#47;columns&#62;&#60;&#47;grid&#62;";

			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 14, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 14, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string ServicePage(string serviceID)
		{
			string grid = @"&#60;grid&#62;&#60;sortColumns&#62;&#38;&#35;58&#59;1&#60;&#47;sortColumns&#62;&#60;pageNum&#62;1&#60;&#47;pageNum&#62;&#60;recsPerPage&#62;50&#60;&#47;recsPerPage&#62;&#60;dataProvider&#62;Microsoft.Crm.Application.Controls.ScheduleSearchDataProvider&#60;&#47;dataProvider&#62;&#60;uiProvider&#62;Microsoft.Crm.Application.Controls.GridUIProvider&#60;&#47;uiProvider&#62;&#60;cols&#47;&#62;&#60;max&#62;1&#60;&#47;max&#62;&#60;refreshAsync&#62;True&#60;&#47;refreshAsync&#62;&#60;pagingCookie&#47;&#62;&#60;enableMultiSort&#62;false&#60;&#47;enableMultiSort&#62;&#60;enablePagingWhenOnePage&#62;true&#60;&#47;enablePagingWhenOnePage&#62;&#60;parameters&#62;&#60;autorefresh&#62;0&#60;&#47;autorefresh&#62;&#60;showjumpbar&#62;0&#60;&#47;showjumpbar&#62;&#60;enablepaging&#62;1&#60;&#47;enablepaging&#62;&#60;enablerefresh&#62;0&#60;&#47;enablerefresh&#62;&#60;refreshasynchronous&#62;1&#60;&#47;refreshasynchronous&#62;&#60;viewid&#62;&#38;&#35;123&#59;22520C00-3506-4670-89E8-E51C45D6DBA2&#38;&#35;125&#59;&#60;&#47;viewid&#62;&#60;viewtype&#62;1039&#60;&#47;viewtype&#62;&#60;RecordsPerPage&#62;50&#60;&#47;RecordsPerPage&#62;&#60;otc&#62;0&#60;&#47;otc&#62;&#60;otn&#47;&#62;&#60;disableDblClick&#62;0&#60;&#47;disableDblClick&#62;&#60;AppointmentRequest&#62;&#38;&#35;60&#59;AppointmentRequest&#38;&#35;62&#59;&#38;&#35;60&#59;ServiceId xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;&#38;&#35;123&#59;0265D471-1D8C-DD11-91DF-00155DA14208&#38;&#35;125&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;ServiceId&#38;&#35;62&#59;&#38;&#35;60&#59;Direction xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;Forward&#38;&#35;60&#59;&#38;&#35;47&#59;Direction&#38;&#35;62&#59;&#38;&#35;60&#59;NumberOfResults xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;50&#38;&#35;60&#59;&#38;&#35;47&#59;NumberOfResults&#38;&#35;62&#59;&#38;&#35;60&#59;SearchWindowStart xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;2008-10-07T11&#38;&#35;58&#59;36&#38;&#35;58&#59;17&#38;&#35;60&#59;&#38;&#35;47&#59;SearchWindowStart&#38;&#35;62&#59;&#38;&#35;60&#59;SearchWindowEnd xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;2009-10-07T00&#38;&#35;58&#59;00&#38;&#35;58&#59;00&#38;&#35;60&#59;&#38;&#35;47&#59;SearchWindowEnd&#38;&#35;62&#59;&#38;&#35;60&#59;AnchorOffset xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;480&#38;&#35;60&#59;&#38;&#35;47&#59;AnchorOffset&#38;&#35;62&#59;&#38;&#35;60&#59;UserTimeZoneCode xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;4&#38;&#35;60&#59;&#38;&#35;47&#59;UserTimeZoneCode&#38;&#35;62&#59;&#38;&#35;60&#59;SearchRecurrenceRule xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;FREQ&#38;&#35;61&#59;DAILY&#38;&#35;59&#59;INTERVAL&#38;&#35;61&#59;1&#38;&#35;60&#59;&#38;&#35;47&#59;SearchRecurrenceRule&#38;&#35;62&#59;&#38;&#35;60&#59;SearchRecurrenceStart xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;2008-10-07T08&#38;&#35;58&#59;00&#38;&#35;58&#59;00Z&#38;&#35;60&#59;&#38;&#35;47&#59;SearchRecurrenceStart&#38;&#35;62&#59;&#38;&#35;60&#59;RecurrenceDuration xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;541&#38;&#35;60&#59;&#38;&#35;47&#59;RecurrenceDuration&#38;&#35;62&#59;&#38;&#35;60&#59;RecurrenceTimeZoneCode xmlns&#38;&#35;61&#59;&#38;&#35;34&#59;http&#38;&#35;58&#59;&#38;&#35;47&#59;&#38;&#35;47&#59;schemas.microsoft.com&#38;&#35;47&#59;crm&#38;&#35;47&#59;2006&#38;&#35;47&#59;Scheduling&#38;&#35;34&#59;&#38;&#35;62&#59;4&#38;&#35;60&#59;&#38;&#35;47&#59;RecurrenceTimeZoneCode&#38;&#35;62&#59;&#38;&#35;60&#59;&#38;&#35;47&#59;AppointmentRequest&#38;&#35;62&#59;&#60;&#47;AppointmentRequest&#62;&#60;LayoutStyle&#62;GridList&#60;&#47;LayoutStyle&#62;&#60;ServiceName&#62;Branch &#38;&#35;58&#59; 474 - 37893019749 - Discount Bicycle Specialists&#60;&#47;ServiceName&#62;&#60;SearchWindowStart&#47;&#62;&#60;SearchWindowEnd&#47;&#62;&#60;&#47;parameters&#62;&#60;columns&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;Service&#34; fieldname&#61;&#34;Service&#34; entityname&#61;&#34;&#34;&#62;Service&#60;&#47;column&#62;&#60;column width&#61;&#34;240&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;Resources&#34; fieldname&#61;&#34;ProposalParties&#34; entityname&#61;&#34;&#34;&#62;ProposalParties&#60;&#47;column&#62;&#60;column width&#61;&#34;100&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;Site&#34; fieldname&#61;&#34;Site&#34; entityname&#61;&#34;&#34;&#62;Site&#60;&#47;column&#62;&#60;column width&#61;&#34;130&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;Scheduled Start&#34; fieldname&#61;&#34;Start&#34; entityname&#61;&#34;&#34;&#62;Start&#60;&#47;column&#62;&#60;column width&#61;&#34;130&#34; isHidden&#61;&#34;false&#34; isMetadataBound&#61;&#34;false&#34; isSortable&#61;&#34;false&#34; label&#61;&#34;Scheduled End&#34; fieldname&#61;&#34;End&#34; entityname&#61;&#34;&#34;&#62;End&#60;&#47;column&#62;&#60;&#47;columns&#62;&#60;&#47;grid&#62;";

			grid = HttpUtility.HtmlDecode(grid);
			string idx = "ServiceId xmlns&#61;&#34;http&#58;&#47;&#47;schemas.microsoft.com&#47;crm&#47;2006&#47;Scheduling&#34;&#62;&#123;";
			grid = grid.Remove(grid.IndexOf(idx) + idx.Length, 36);
			grid = grid.Insert(grid.IndexOf(idx) + idx.Length, serviceID);
			return grid;
		}

		public static string IMPageView(int pageNum, string guid, string pagingCookie)
		{
			string grid = @"<grid><sortColumns>subject:1</sortColumns><pageNum>1</pageNum><recsPerPage>50</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>-1</max><refreshAsync>False</refreshAsync><pagingCookie></pagingCookie><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><parameters><autorefresh>1</autorefresh><isGridFilteringEnabled>1</isGridFilteringEnabled><viewid>{6CF285AA-EB20-4277-925A-3E9735411FF0}</viewid><viewtype>1039</viewtype><RecordsPerPage>50</RecordsPerPage><viewTitle>My Open new_ims</viewTitle><layoutXml><grid name=""resultset"" object=""10003"" jump=""subject"" select=""1"" icon=""1"" preview=""1""><row name=""result"" id=""activityid""><cell name=""subject"" width=""300"" /><cell name=""createdon"" width=""125"" /></row></grid></layoutXml><otc>10003</otc><otn>new_im</otn><entitydisplayname>new_im</entitydisplayname><titleformat>{0}: {1}</titleformat><entitypluraldisplayname>new_ims</entitypluraldisplayname><datefilter>All</datefilter><isWorkflowSupported>true</isWorkflowSupported><fetchXmlForFilters><fetch version=""1.0"" mapping=""logical"" distinct=""true""><entity name=""new_im""><attribute name=""activityid"" /><attribute name=""subject"" /><attribute name=""createdon"" /><order attribute=""subject"" descending=""false"" /><filter type=""and""><condition attribute=""statecode"" operator=""in""><value>0</value><value>3</value></condition></filter><link-entity name=""activityparty"" from=""activityid"" to=""activityid"" alias=""aa""><filter type=""and""><condition attribute=""partyid"" operator=""eq-userid"" /></filter></link-entity></entity></fetch></fetchXmlForFilters><isFetchXmlNotFinal>False</isFetchXmlNotFinal><effectiveFetchXml><fetch distinct=""true"" mapping=""logical"" page=""1"" count=""50"" returntotalrecordcount=""true""><entity name=""new_im""><attribute name=""activityid"" /><attribute name=""subject"" /><attribute name=""createdon"" /><attribute name=""subject"" /><attribute name=""createdon"" /><filter type=""and""><condition attribute=""statecode"" operator=""in""><value>0</value><value>3</value></condition></filter><order attribute=""subject"" descending=""false"" /><link-entity name=""activityparty"" to=""activityid"" from=""activityid"" link-type=""inner"" alias=""aa""><filter type=""and""><condition attribute=""partyid"" operator=""eq-userid"" /></filter></link-entity></entity></fetch></effectiveFetchXml><LayoutStyle>GridList</LayoutStyle><quickfind/><filter/><filterDisplay/><maxselectableitems>-1</maxselectableitems></parameters></grid>";

			pagingCookie = HttpUtility.HtmlDecode(pagingCookie);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 9, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 9, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string IMPageViewRefresh(int pageNum, string guid, string pagingCookie)
		{
			string grid = @"<grid><sortColumns>subject:1</sortColumns><pageNum>1</pageNum><recsPerPage>50</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>-1</max><refreshAsync>False</refreshAsync><pagingCookie></pagingCookie><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><getParameters></getParameters><parameters><autorefresh>1</autorefresh><isGridFilteringEnabled>1</isGridFilteringEnabled><viewid>{25585E0C-AAF5-449E-97FF-3267B0D96BCA}</viewid><viewtype>1039</viewtype><RecordsPerPage>50</RecordsPerPage><viewTitle>All new_ims</viewTitle><layoutXml><grid name=""resultset"" object=""10003"" jump=""subject"" select=""1"" icon=""1"" preview=""1""><row name=""result"" id=""activityid""><cell name=""subject"" width=""300"" /><cell name=""createdon"" width=""125"" /></row></grid></layoutXml><otc>10003</otc><otn>new_im</otn><entitydisplayname>new_im</entitydisplayname><titleformat>{0}: {1}</titleformat><entitypluraldisplayname>new_ims</entitypluraldisplayname><datefilter>All</datefilter><isWorkflowSupported>true</isWorkflowSupported><LayoutStyle>GridList</LayoutStyle><quickfind/><filter/><filterDisplay/><maxselectableitems>-1</maxselectableitems></parameters><columns><column width=""300"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Subject"" fieldname=""subject"" entityname=""new_im"" renderertype=""Crm.PrimaryField"">subject</column><column width=""125"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Date Created"" fieldname=""createdon"" entityname=""new_im"" renderertype=""datetime"">createdon</column></columns></grid>";

			pagingCookie = HttpUtility.HtmlDecode(pagingCookie);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 9, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 9, guid);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string IMPageSearchView(int pageNum, string guid, string pagingCookie, string searchString)
		{
			string grid = @"<grid><sortColumns>subject:1</sortColumns><pageNum>1</pageNum><recsPerPage>50</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>-1</max><refreshAsync>False</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><parameters><autorefresh>1</autorefresh><isGridFilteringEnabled>1</isGridFilteringEnabled><viewid>{16502531-05A2-4FB7-BA5A-D78C8FF52C07}</viewid><viewtype>1039</viewtype><RecordsPerPage>50</RecordsPerPage><viewTitle>My Open new_ims</viewTitle><layoutXml><grid name=""resultset"" object=""10003"" jump=""subject"" select=""1"" icon=""1"" preview=""1""><row name=""result"" id=""activityid""><cell name=""subject"" width=""300"" /><cell name=""createdon"" width=""125"" /></row></grid></layoutXml><otc>10003</otc><otn>new_im</otn><entitydisplayname>new_im</entitydisplayname><titleformat>{0}: {1}</titleformat><entitypluraldisplayname>new_ims</entitypluraldisplayname><datefilter>All</datefilter><isWorkflowSupported>true</isWorkflowSupported><fetchXmlForFilters><fetch version=""1.0"" mapping=""logical"" distinct=""true""><entity name=""new_im""><attribute name=""activityid"" /><attribute name=""subject"" /><attribute name=""createdon"" /><order attribute=""subject"" descending=""false"" /><filter type=""and""><condition attribute=""statecode"" operator=""in""><value>0</value><value>3</value></condition></filter><link-entity name=""activityparty"" from=""activityid"" to=""activityid"" alias=""aa""><filter type=""and""><condition attribute=""partyid"" operator=""eq-userid"" /></filter></link-entity></entity></fetch></fetchXmlForFilters><isFetchXmlNotFinal>False</isFetchXmlNotFinal><effectiveFetchXml><fetch distinct=""true"" mapping=""logical"" page=""1"" count=""50"" returntotalrecordcount=""true""><entity name=""new_im""><attribute name=""activityid"" /><attribute name=""subject"" /><attribute name=""createdon"" /><attribute name=""subject"" /><attribute name=""createdon"" /><filter type=""and""><condition attribute=""statecode"" operator=""in""><value>0</value><value>3</value></condition></filter><order attribute=""subject"" descending=""false"" /><link-entity name=""activityparty"" to=""activityid"" from=""activityid"" link-type=""inner"" alias=""aa""><filter type=""and""><condition attribute=""partyid"" operator=""eq-userid"" /></filter></link-entity></entity></fetch></effectiveFetchXml><LayoutStyle>GridList</LayoutStyle><quickfind>Remember</quickfind><filter/><filterDisplay/><maxselectableitems>-1</maxselectableitems><scheduledend>All</scheduledend></parameters></grid>";

			pagingCookie = HttpUtility.HtmlDecode(pagingCookie);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<viewid>") + 9, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 9, guid);
			grid = grid.Remove(grid.IndexOf("<quickfind>") + 11, grid.IndexOf("</quickfind>") - (grid.IndexOf("<quickfind>") + 11));
			grid = grid.Insert(grid.IndexOf("<quickfind>") + 11, searchString);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		public static string IncidentActivityPointersGridRefreshData(int pageNum, string incidentId, string viewId, string pagingCookie)
		{
			string grid = @"<grid><sortColumns>createdon:0</sortColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><pagingCookie/><returntotalrecordcount>true</returntotalrecordcount><parameters><oId>{A7B862CD-E611-E211-A5DD-68B5996E4ED0}</oId><oType>112</oType><queryapi>CRMActivity.RetrieveByObject</queryapi><viewid>7F15E2BB-305A-468F-9AF7-BE865755A984</viewid><viewtype>1039</viewtype><otn>activitypointer</otn><GridType>AssociatedGrid</GridType><relName>Incident_ActivityPointers</relName><relationshipType>1</relationshipType></parameters><columns><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Subject"" fieldname=""subject"" entityname=""activitypointer"" renderertype=""Crm.PrimaryField"">subject</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Activity&#32;Type"" fieldname=""activitytypecode"" entityname=""activitypointer"">activitytypecode</column> <column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Activity&#32;Status"" fieldname=""statecode"" entityname=""activitypointer"">statecode</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Priority"" fieldname=""prioritycode"" entityname=""activitypointer"">prioritycode</column> <column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Due&#32;Date"" fieldname=""scheduledend"" entityname=""activitypointer"">scheduledend</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Created&#32;By"" fieldname=""createdby"" entityname=""activitypointer"">createdby</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Regarding"" fieldname=""regardingobjectid"" entityname=""activitypointer"">regardingobjectid</column><column width=""0"" isHidden=""true"" isMetadataBound=""true"" isSortable=""false"" label=""Recurring&#32;Instance&#32;Type"" fieldname=""instancetypecode"" entityname=""activitypointer"">instancetypecode</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""Description"" fieldname=""description"" entityname=""activitypointer"">description</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""CreatedOn"" fieldname=""createdon"" entityname=""activitypointer"">createdon</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""allparties"" fieldname=""allparties"" entityname=""activitypointer"">allparties</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""OwnerId"" fieldname=""ownerid"" entityname=""activitypointer"">ownerid</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""PriorityCode"" fieldname=""prioritycode"" entityname=""activitypointer"">prioritycode</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""StateCode"" fieldname=""statecode"" entityname=""activitypointer"">statecode</column><column width=""0"" isHidden=""false"" isMetadataBound=""true"" isSortable=""true"" label=""StatusCode"" fieldname=""statuscode"" entityname=""activitypointer"">statuscode</column></columns></grid>";
			grid = HttpUtility.HtmlDecode(grid);
			grid = grid.Replace("<pagingCookie/>", "<pagingCookie></pagingCookie>");
			grid = grid.Remove(grid.IndexOf("<oId>") + 6, 36);
			grid = grid.Insert(grid.IndexOf("<oId>") + 6, incidentId);
			grid = grid.Remove(grid.IndexOf("<viewid>") + 8, 36);
			grid = grid.Insert(grid.IndexOf("<viewid>") + 8, viewId);

			if (pagingCookie != null)
			{
				grid = grid.Replace("<pagingCookie>", "<pagingCookie>" + pagingCookie);
			}
			if (pageNum != -1)
			{
				grid = grid.Replace("<pageNum>1", "<pageNum>" + pageNum.ToString());
			}
			return grid;
		}

		/// <summary>
		/// Finds the available view names and views ids from Activity web service response body
		/// </summary>
		/// <param name="body">Activity web service response body</param>
		/// <param name="viewNames">Out parameter view name array</param>
		/// <param name="viewIds">Out parameter view id array</param>
		public static void SetViews(string body, out string[] viewNames, out string[] viewIds)
		{
			string decodedBody = HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(body));
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(decodedBody);
			XmlNodeList views = doc.GetElementsByTagName("option");
			viewNames = new string[views.Count];
			viewIds = new string[views.Count];
			for (int i = 0; i < views.Count; i++)
			{
				viewNames[i] = views[i].InnerXml;
				viewIds[i] = views[i].Attributes["value"].Value.Substring(1, views[i].Attributes["value"].Value.Length - 2);
			}
		}
	}

	public class Helper
	{
		public static XmlNode GenerateEntityXml()
		{
			//string dataXml = @"<entity><entityid></entityid><singularname></singularname><pluralname></pluralname><schemaname></schemaname><ownershiptype>UserOwned</ownershiptype><displayareas><displayarea id=""Workplace"" displayed=""false""/><displayarea id=""SFA"" displayed=""false""/><displayarea id=""MA"" displayed=""false""/><displayarea id=""CS"" displayed=""false""/><displayarea id=""Settings"" displayed=""false""/><displayarea id=""ResourceCenter"" displayed=""false""/></displayareas><entityisactivity><entityisactivity>false</entityisactivity></entityisactivity><ownershiptype>UserOwned</ownershiptype><richclient><offline>false</offline></richclient><mailmergecheck><mailmergecheck>true</mailmergecheck></mailmergecheck><duplicatecheck>true</duplicatecheck><associatedentity><notes>true</notes><activities>true</activities><activityparties>false</activityparties></associatedentity><connection><connection>true</connection></connection><auditenabled><auditenabled>false</auditenabled></auditenabled><docmgmtenabled><docmgmtenabled>false</docmgmtenabled></docmgmtenabled><collaboration>false</collaboration><autoroutetoownerqueue>false</autoroutetoownerqueue><visibleinmobile><visibleinmobile>false</visibleinmobile></visibleinmobile><readingpaneenabled><readingpaneenabled>true</readingpaneenabled></readingpaneenabled><attribute><displayname>Name</displayname><schemaname>name</schemaname><reqlevel>Required</reqlevel><description></description><type><name>nvarchar</name><format>text</format><length>100</length></type></attribute></entity>";
			string dataXml = "&lt;entity&gt;&lt;entityid&gt;&lt;/entityid&gt;&lt;singularname&gt;adfas&lt;/singularname&gt;&lt;pluralname&gt;asdfasf&lt;/pluralname&gt;&lt;schemaname&gt;adfas&lt;/schemaname&gt;&lt;ownershiptype&gt;UserOwned&lt;/ownershiptype&gt;&lt;displayareas&gt;&lt;displayarea id=&quot;SFA&quot; displayed=&quot;false&quot;/&gt;&lt;displayarea id=&quot;CS&quot; displayed=&quot;false&quot;/&gt;&lt;displayarea id=&quot;MA&quot; displayed=&quot;false&quot;/&gt;&lt;displayarea id=&quot;Settings&quot; displayed=&quot;false&quot;/&gt;&lt;displayarea id=&quot;HLP&quot; displayed=&quot;false&quot;/&gt;&lt;/displayareas&gt;&lt;entityisactivity&gt;&lt;entityisactivity&gt;false&lt;/entityisactivity&gt;&lt;/entityisactivity&gt;&lt;ownershiptype&gt;UserOwned&lt;/ownershiptype&gt;&lt;richclient&gt;&lt;offline&gt;false&lt;/offline&gt;&lt;/richclient&gt;&lt;mailmergecheck&gt;true&lt;/mailmergecheck&gt;&lt;autocreateaccessteams&gt;false&lt;/autocreateaccessteams&gt;&lt;duplicatecheck&gt;true&lt;/duplicatecheck&gt;&lt;associatedentity&gt;&lt;notes&gt;true&lt;/notes&gt;&lt;activities&gt;true&lt;/activities&gt;&lt;activityparties&gt;false&lt;/activityparties&gt;&lt;/associatedentity&gt;&lt;connection&gt;true&lt;/connection&gt;&lt;auditenabled&gt;false&lt;/auditenabled&gt;&lt;docmgmtenabled&gt;false&lt;/docmgmtenabled&gt;&lt;businessprocessenabled&gt;false&lt;/businessprocessenabled&gt;&lt;collaboration&gt;false&lt;/collaboration&gt;&lt;autoroutetoownerqueue&gt;false&lt;/autoroutetoownerqueue&gt;&lt;visibleinmobile&gt;false&lt;/visibleinmobile&gt;&lt;visibleinmobileclient&gt;false&lt;/visibleinmobileclient&gt;&lt;readonlyinmobileclient&gt;false&lt;/readonlyinmobileclient&gt;&lt;readingpaneenabled&gt;true&lt;/readingpaneenabled&gt;&lt;attribute&gt;&lt;displayname&gt;Name&lt;/displayname&gt;&lt;schemaname&gt;name&lt;/schemaname&gt;&lt;reqlevel&gt;Required&lt;/reqlevel&gt;&lt;description&gt;The name of the custom entity.&lt;/description&gt;&lt;type&gt;&lt;name&gt;nvarchar&lt;/name&gt;&lt;format&gt;text&lt;/format&gt;&lt;length&gt;100&lt;/length&gt;&lt;/type&gt;&lt;/attribute&gt;&lt;isquickcreateenabled&gt;false&lt;/isquickcreateenabled&gt;&lt;/entity&gt;";
			dataXml = HttpUtility.HtmlDecode(dataXml);
			string name = Utils.GetRandomString(5, 10);
			string description = Utils.GetRandomString(100, 120);

			dataXml = dataXml.Replace("<singularname>", "<singularname>" + name);
			dataXml = dataXml.Replace("<pluralname>", "<pluralname>" + name);
			dataXml = dataXml.Replace("<schemaname>", "<schemaname>" + name);
			dataXml = dataXml.Replace("<description>", "<description>" + description);

			XmlDocument data = new XmlDocument();
			data.LoadXml(dataXml);
			return (data);
		}

		public static XmlNode GeneratePublishXml(Guid entityId)
		{
			string dataXml = "<data><publish><entities><entity>" + entityId.ToString("B") + "</entity></entities></publish></data>";

			XmlDocument data = new XmlDocument();
			data.LoadXml(dataXml);
			return (data);
		}

		public static XmlNode GenerateAttributeXml(Guid entityId)
		{
			// use a validating reader to read the grid xml fragment and pull in the namespace
			NameTable nt = new NameTable();
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(nt);
			nsmgr.AddNamespace(String.Empty, ConfigSettings.Default.WebServiceNS);

			XmlParserContext context = new XmlParserContext(null, nsmgr, null, XmlSpace.None);
			string name = Utils.GetRandomString(5, 7);

			string dataXml = "<attribute><entityid>" + entityId.ToString("B") + "</entityid><attributeid></attributeid><displayname>" + name + "</displayname><schemaname>" + name + "</schemaname><reqlevel>None</reqlevel><imemode>auto</imemode><description>test cust atttribute</description><type><name>nvarchar</name><format>text</format><length>100</length></type></attribute>";

			XmlTextReader reader = new XmlTextReader(dataXml,
					XmlNodeType.Element, context);

			XmlDocument data = new XmlDocument();
			data.Load(reader);
			return (data);
		}
	}

	class BandWidthUtilities
	{
		public static bool StopCapture(string sCommandName, string sParams)
		{
			//e.g. sCommandName = "Ping"; sParams = "-n 1  1.1.1.1";
			if (StartProgram(sCommandName, sParams, null, true) >= 0)
				return true;
			else
				return false;
		}

		public static void StopProgram(int pid)
		{
			Process process = Process.GetProcessById(pid);
			process.Kill();
		}

		public static int StartProgram(string exe, string sArgs, string path, bool waitForExit)
		{
			try
			{
				Process MyProcess = new Process();
				MyProcess.StartInfo.CreateNoWindow = true;
				MyProcess.StartInfo.UseShellExecute = false;
				MyProcess.StartInfo.FileName = exe;
				if (path != string.Empty)
					MyProcess.StartInfo.WorkingDirectory = path;

				if (sArgs.Trim().ToLower() != "null")
					MyProcess.StartInfo.Arguments = sArgs;

				if (MyProcess.Start() == true)
				{
					if (waitForExit)
					{
						MyProcess.WaitForExit();
						return 0;
					}
					return MyProcess.Id;
				}
			}
			catch (Exception e)
			{
				//write to error log
				WriteErrorLog("failed in StartProgram, exception: " + e.ToString());

			}
			return -1;
		}

		public static bool RunNetMonExpert(string CapFileFullName)
		{
			bool status = true;
			int pid = 0;
			string Exe = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Microsoft\VRTA\VRTA.EXE";
			string ProgArgs = null;

			try
			{
				ProgArgs = "\"" + CapFileFullName + "\"";
				if ((pid = (StartProgram(Exe, ProgArgs, string.Empty, false))) > 0)
				{
					Thread.Sleep(2000);
					StopProgram(pid);
				}
				else
					WriteErrorLog("Run VRTA failed! " + CapFileFullName);
			}
			catch (Exception e)
			{
				status = false;
				WriteErrorLog(e.ToString());
			}
			return status;
		}

		public static void ParseRTAFile(string fileName, string title)
		{
			string dir = Path.GetDirectoryName(fileName);

			if (dir == "")
				dir = ".";

			Console.WriteLine("Dir:" + dir);

			string fName = dir + "\\" + Path.GetFileNameWithoutExtension(fileName) + ".html";
			StreamWriter htmlwriter = new StreamWriter(fName, false);

			htmlwriter.WriteLine("<html><head><title>" + title + "</title></head><body>");
			htmlwriter.WriteLine("<p>&nbsp;</p><p align=\"center\"><b><font size=\"6\">" + title + "</font></b></p>");
			htmlwriter.WriteLine("<p>&nbsp;<b><font size=\"3\"><a href=\"" + fileName + "\">Open Netcom capture File</a></font></b></p>");
			htmlwriter.WriteLine("<p>&nbsp;<b><font size=\"3\"><a href=\"" + Path.GetFileNameWithoutExtension(fileName) + "_rta.txt\">Open Capture file as text</a></font></b></p>");
			htmlwriter.WriteLine("<table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse\" bordercolor=\"#111111\" width=\"100%\">");
			htmlwriter.WriteLine("<tr>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Request URI</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Status Code</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Content Type</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Total Bytes</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Upstream Bytes</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Content Length</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Number of Roundtrips </b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Relative Time</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Time to 1st Byte</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Kbs Down</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Duration</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Finish Status</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>HTTP Method</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Expire Date</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>Referrer Request</b></td>");
			htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>URI Args</b></td>");
			htmlwriter.WriteLine("</tr>");

			StreamReader fileReader = new StreamReader(dir + "\\" + Path.GetFileNameWithoutExtension(fileName) + "_rta.txt");

			try
			{
				string line1 = fileReader.ReadLine();
				int Rts = 0;
				int numRequests = 0;
				string[] strs1 = null;
				string[] strs2 = null;
				string[] nodes = line1.Split(new char[] { '\t' });
				line1 = fileReader.ReadLine();
				string line2 = fileReader.ReadLine();
				strs1 = line1.Split(new char[] { '\t' });

				//lets make sure we are starting from the right frame
				while (line1 != null)
				{
					strs1 = line1.Split(new char[] { '\t' });
					if (line2 != null)
						strs2 = line2.Split(new char[] { '\t' });
					if (strs1[3].IndexOf("Stop Capture") >= 0)
					{
						line1 = line2;
						line2 = fileReader.ReadLine();
						continue;
					}
					else
					{
						if (strs1[0].IndexOf("TOTALS") >= 0)
						{
							htmlwriter.WriteLine("<tr>");
							htmlwriter.WriteLine("<td width=\"25%\"><b> TOTALS: Number of Requests:" + numRequests + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + strs1[4] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + strs1[5] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + strs1[6] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + strs1[7] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + strs1[8] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + Rts + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + strs1[1] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + strs1[12] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + strs1[13] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\"><b>" + strs1[10] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\"><b>" + strs1[16] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\"><b>" + strs1[17] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\"><b>" + strs1[20] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\"><b>" + strs1[18] + "</b></td>");
							htmlwriter.WriteLine("<td width=\"25%\"><b>" + strs1[25] + "</b></td>");
							htmlwriter.WriteLine("</tr>");
							line1 = line2;
							line2 = fileReader.ReadLine();
						}
						else
						{
							htmlwriter.WriteLine("<tr>");
							htmlwriter.WriteLine("<td width=\"25%\"> " + strs1[3] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[4] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[5] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[6] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[7] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[8] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[15] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[1] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[12] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[13] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\" align=\"center\">" + strs1[10] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\">" + strs1[16] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\">" + strs1[17] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\">" + strs1[20] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\">" + strs1[18] + "</td>");
							htmlwriter.WriteLine("<td width=\"25%\">" + strs1[25] + "</td>");
							htmlwriter.WriteLine("</tr>");
							numRequests++;
							Rts = Rts + Convert.ToInt32(strs1[15]);
							line1 = line2;
							line2 = fileReader.ReadLine();
						}
					}
				}
			}
			catch (Exception e)
			{
				Console.WriteLine("Exception:" + e.ToString());
			}
			finally
			{
				htmlwriter.WriteLine("</table</body></html>");
				htmlwriter.Close();
				fileReader.Close();
			}
		}

		public static void WriteErrorLog(string LogString)
		{
			try
			{
				string ErrLogName = "error.log";
				StreamWriter sw = new StreamWriter(ErrLogName, true);
				sw.WriteLine(DateTime.Now.ToString() + " - " + LogString);
				sw.Close();
			}
			catch (Exception e)
			{
				Console.WriteLine(e.ToString());
			}
		}
	}

	public class ME_EntityHelper
	{
		public string logicalName = null;
		public int otc = -1;
		public Dictionary<string, Guid> views = new Dictionary<string, Guid>();
		public Guid defaultViewId;
	}

	public class MobileExpressHelper
	{
		private static MobileExpressHelper m_instance = null;
		private SqlConnection m_CRMSQLCon = null;
		private Dictionary<string, ME_EntityHelper> m_me_EntityHelpers;
		private const string infoQueryText =
			@"select e.LogicalName, e.ObjectTypeCode, sq.Name, sq.SavedQueryId, sq.IsDefault
				from savedquery sq join metadataschema.entity e on sq.ReturnedTypeCode = e.ObjectTypeCode
				where
					sq.querytype = 0
					and e.LogicalName in (";

		private const string entityQueryText =
			@"select e.EntityId, e.ObjectTypeCode
				from metadataschema.entity e
				where e.ObjectTypeCode = {0};";

		public static MobileExpressHelper Instance
		{
			get
			{
				return m_instance;
			}
		}

		public ME_EntityHelper GetRandomHomepageEntity()
		{
			int idx = r.Next(m_me_EntityHelpers.Values.Count);
			int i = 0;
			foreach (ME_EntityHelper meeh in m_me_EntityHelpers.Values)
			{
				if (i == idx)
				{
					return (meeh);
				}
				i++;
			}
			return null;
		}

		public ME_EntityHelper GetHomepageEntity(string logicalName)
		{
			if (m_me_EntityHelpers.ContainsKey(logicalName.ToLowerInvariant()))
			{
				return m_me_EntityHelpers[logicalName.ToLowerInvariant()];
			}
			return null;
		}

		private MobileExpressHelper()
		{
			Init();
		}

		public string GetEntityId(string logicalName, CRMEntity entity)
		{
			string id = string.Empty;
			switch (logicalName.ToLowerInvariant())
			{
				case "account":
					id = entity[EntityIDNames.Account];
					break;
				case "contact":
					id = entity[EntityIDNames.Contact];
					break;
				case "lead":
					id = entity[EntityIDNames.Lead];
					break;
				case "opportunity":
					id = entity[EntityIDNames.Opportunities];
					break;
				case "task":
					id = entity[EntityIDNames.Task];
					break;
			}

			return id;
		}

		public string GetProperEntityName(string logicalName)
		{
			string id = string.Empty;
			switch (logicalName.ToLowerInvariant())
			{
				case "account":
					id = EntityNames.Accounts;
					break;
				case "contact":
					id = EntityNames.Contacts;
					break;
				case "lead":
					id = EntityNames.Leads;
					break;
				case "opportunity":
					id = EntityNames.Opportunities;
					break;
				case "task":
					id = EntityNames.Tasks;
					break;
			}

			return id;
		}

		private void Init()
		{
			using (m_CRMSQLCon = new SqlConnection(ConfigSettings.Default.m_MulServers[0].SQLCNN))
			{
				m_CRMSQLCon.Open();
				SqlCommand infoQuery = new SqlCommand();
				infoQuery.Connection = m_CRMSQLCon;
				infoQuery.CommandText = GetInfoQuery();
				infoQuery.CommandType = System.Data.CommandType.Text;
				using (SqlDataReader sdr = infoQuery.ExecuteReader())
				{
					m_me_EntityHelpers = new Dictionary<string, ME_EntityHelper>();

					while (sdr.Read())
					{
						ME_EntityHelper me_eh;

						if (m_me_EntityHelpers.ContainsKey(sdr["LogicalName"].ToString()))
						{
							me_eh = m_me_EntityHelpers[sdr["LogicalName"].ToString()];
						}
						else
						{
							me_eh = new ME_EntityHelper();
							me_eh.logicalName = sdr["LogicalName"].ToString();
							me_eh.otc = (int)sdr["ObjectTypeCode"];
							m_me_EntityHelpers.Add(me_eh.logicalName, me_eh);
						}

						// don't add the default view to the views dictionary;
						// doing so can lead to picking it when nav'ing to a non-default
						// view, which has the origViewSel and viewSel as the same view;
						// this throws an exception at the server
						if ((Boolean)sdr["IsDefault"] == true)
						{
							me_eh.defaultViewId = new Guid(sdr["SavedQueryId"].ToString());
						}
						else
						{
							if (me_eh.views.ContainsKey(sdr["Name"].ToString()) == false)
							{
								me_eh.views.Add(sdr["Name"].ToString(), new Guid(sdr["SavedQueryId"].ToString()));
							}
						}
					}
				}
			}
		}

		private string GetInfoQuery()
		{
			StringBuilder sb = new StringBuilder(infoQueryText);
			for (int i = 0; i < validHomepageEntities.Length; i++)
			{
				sb.Append('\'');
				sb.Append(validHomepageEntities[i]);
				sb.Append('\'');
				if (i != (validHomepageEntities.Length - 1))
				{
					sb.Append(',');
				}
			}
			sb.Append(')');
			return (sb.ToString());
		}

		private static string[] validHomepageEntities = 
			{
				"account",
				"case",
				"contact",
				"lead",
				"opportunity",
				"task"
			};

		// use the default seed for repeatability
		private static Random r = new Random();
	}

	public class InlineEditHelper
	{
		private string m_commandXml;
		private CRMEntity m_user;
		private WRPCInfo rpcInfo;
		private WebTestRequestHeader headerItem;
		WebTestRequest wtr;

		public InlineEditHelper(string commandXml, CRMEntity user)
		{
			m_commandXml = commandXml;
			m_user = user;
		}

		public WebTestRequest getInlineEditWTR(string referer, int commandCode = 1)
		{
			InlineEditWebService.InlineEditWebService inlineeditws = new InlineEditWebService.InlineEditWebService();
			wtr = null;
			try
			{
#if (CRM2015SP1)
				inlineeditws.Execute(commandCode, m_commandXml, true);
#else
				inlineeditws.Execute(commandCode, m_commandXml);
#endif
			}
			catch (crmException x)
			{
				wtr = (CrmRequest)x.wtr;
				wtr.Url = Utils.ReplaceServerName(wtr.Url, m_user);
				rpcInfo = Utils.GenerateWRPCToken();
				headerItem = new WebTestRequestHeader();
				headerItem.Name = "crmwrpctokentimestamp";
				headerItem.Value = rpcInfo.timeStamp.ToString();
				wtr.Headers.Add(headerItem);
				headerItem = new WebTestRequestHeader();
				headerItem.Name = "crmwrpctoken";
				headerItem.Value = rpcInfo.token;
				wtr.Headers.Add(headerItem);
				headerItem = new WebTestRequestHeader();
				headerItem.Name = "referer";
				headerItem.Value = referer;
				wtr.Headers.Add(headerItem);
				wtr.Method = "Post";
			}
			return wtr;
		}


	}

	/// <summary>
	/// Helper class for ServerSideSync feature macro test cases.
	/// </summary>
	public static class ServerSideSyncHelper
	{
		public static Guid GetValidUserOrQueueId(bool isUser, bool isActive, string orgName)
		{
			//Read only SQL call without any explicit lock.
			//First try with cached SQLConnection.
			string commandString = @"
										Select top 1 *
										from CRMMailbox
										where IsUser = @isUser and
										IsActive = @isActive and
										OrgName = @orgName
										order by NEWID();
									";

			try
			{
				using (SqlConnection connection = new SqlConnection(GetConnectionString()))
				{
					connection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, connection))
					{
						SqlParameterCollection parameters = (SqlParameterCollection)sqlCommand.Parameters;
						parameters.AddWithValue("@isUser", isUser);
						parameters.AddWithValue("@isActive", isActive);
						parameters.AddWithValue("@orgName", orgName);
						SqlDataReader dataReader = sqlCommand.ExecuteReader();
						dataReader.Read();

						return (Guid)dataReader["UserId"];
					}
				}
			}
			catch (Exception)
			{
				//ToDo: Log Exception.

				//Waiting for 5 seconds.
				System.Threading.Thread.CurrentThread.Join(5 * 1000);

				using (SqlConnection connection = new SqlConnection(GetConnectionString()))
				{
					connection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, connection))
					{
						SqlParameterCollection parameters = (SqlParameterCollection)sqlCommand.Parameters;
						parameters.AddWithValue("@isUser", isUser);
						parameters.AddWithValue("@isActive", isActive);
						parameters.AddWithValue("@orgName", orgName);
						SqlDataReader dataReader = sqlCommand.ExecuteReader();
						dataReader.Read();
						return (Guid)dataReader["UserId"];
					}
				}
			}
		}

		public static Guid GetValidContact(string orgName)
		{
			//Read only SQL call without any explicit lock.
			//First try with cached SQLConnection.
			string commandString = @"
										Select top 1 *
										from CRMContact
										where OrgName = @orgName
										order by NEWID();
									";

			try
			{
				using (SqlConnection connection = new SqlConnection(GetConnectionString()))
				{
					connection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, connection))
					{
						SqlParameterCollection parameters = (SqlParameterCollection)sqlCommand.Parameters;
						parameters.AddWithValue("@orgName", orgName);
						SqlDataReader dataReader = sqlCommand.ExecuteReader();
						dataReader.Read();
						return (Guid)dataReader["Id"];
					}
				}
			}
			catch (Exception)
			{
				//ToDo: Log Exception.

				//Waiting for 5 seconds.
				System.Threading.Thread.CurrentThread.Join(5 * 1000);

				using (SqlConnection connection = new SqlConnection(GetConnectionString()))
				{
					connection.Open();
					using (SqlCommand sqlCommand = new SqlCommand(commandString, connection))
					{
						SqlParameterCollection parameters = (SqlParameterCollection)sqlCommand.Parameters;
						parameters.AddWithValue("@orgName", orgName);
						SqlDataReader dataReader = sqlCommand.ExecuteReader();
						dataReader.Read();
						return (Guid)dataReader["Id"];
					}
				}
			}
		}

		public static List<Guid> GetValidContacts(string orgName, int count)
		{
			//Read only SQL call without any explicit lock.
			//First try with cached SQLConnection.
			string commandString = @"
										Select top (@count) *
										from CRMContact
										where OrgName = @orgName
										order by NEWID();
									";
			using (SqlConnection connection = new SqlConnection(GetConnectionString()))
			{
				connection.Open();
				using (SqlCommand sqlCommand = new SqlCommand(commandString, connection))
				{
					SqlParameterCollection parameters = (SqlParameterCollection)sqlCommand.Parameters;
					parameters.AddWithValue("@orgName", orgName);
					parameters.AddWithValue("@count", count);
					SqlDataReader dataReader = sqlCommand.ExecuteReader();
					List<Guid> ids = new List<Guid>();
					while (dataReader.Read())
					{
						ids.Add((Guid)dataReader["Id"]);
					}
					return ids;
				}
			}
		}

		/// <summary>
		/// Get the connection string otherwise thorws informative exception.
		/// </summary>
		/// <param></param>
		private static string GetConnectionString()
		{
			return ConfigSettings.Default.EMSQLCNN;
		}
	}

}