﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;


namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// test LoseOpportunityRequest
	/// 1. create a dummy opportunity
	/// 2. close the opportunity created
	/// </summary>
	[TestClass]
	public class LoseOpportunityRequestUnitTest : UnitTestBase
	{
		private CRMEntity m_opportunity, m_account, m_pricelevel;

		#region Lose opportunity request
		/// <summary>
		/// Test losing opportunity request
		/// </summary>
		[TestMethod()]
		public void UnitTest__LoseOpportunityReqeust()
		{
			m_opportunity = RetrieveTestEntity(m_user, EntityNames.Opportunities);
			m_account = RetrieveTestEntity(m_user, EntityNames.Accounts);
			m_pricelevel = RetrieveTestEntity(m_user, EntityNames.PriceLevels);
			//create a dummy opportunity
			Guid opportunityId = Guid.Empty;
			Entity opportunity = new Entity("opportunity");
			opportunity.Attributes.Add("customerid", new EntityReference(EntityNames.Accounts.ToLower(), new Guid(m_account["accountId"])));
			opportunity.Attributes.Add("pricelevelid", new EntityReference(EntityNames.PriceLevels.ToLower(), new Guid(m_pricelevel["pricelevelId"])));
			opportunity.Attributes.Add("discountpercentage", 0.50m);
			opportunity.Attributes.Add("name", Utils.GetRandomString(5, 10));
			opportunityId = Proxy.Create(opportunity);
			//close the opportunity just created
			LoseOpportunityRequest req = new LoseOpportunityRequest();
			Entity opportunityClose = new Entity("opportunityclose");
			opportunityClose.Attributes.Add("opportunityid", new EntityReference("opportunity", opportunityId));
			//opportunityClose.Attributes.Add("ownerid", new EntityReference("systemuser", new Guid(m_user["systemuserid"])));
			opportunityClose.Attributes.Add("subject", "Lost the Opportunity!");
			req.OpportunityClose = opportunityClose;
			OptionSetValue o = new OptionSetValue();
			o.Value = 4;
			req.Status = o;

			TestContext.BeginTimer("LoseOpportunityRequest Unit Test");
			try
			{
				LoseOpportunityResponse resp = (LoseOpportunityResponse)Proxy.Execute(req);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("LoseOpportunityRequest Unit Test");
		}
		#endregion
	}
}
