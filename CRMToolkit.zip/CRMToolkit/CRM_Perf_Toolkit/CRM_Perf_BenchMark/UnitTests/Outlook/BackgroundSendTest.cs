﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Extensibility;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Types;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Test class for sending background emails in CRM client
	/// </summary>
	[TestClass]
	public sealed class BackgroundSendTest : OutlookTestBaseClass
	{
		#region Individual Test Cases

		[TestMethod]
		public void BackgroundSendEmailRichClient()
		{
			BackgroundSendEmailRequest request = new BackgroundSendEmailRequest();
			request.Query = CreateBackgroundSendQuery();
			BackgroundSendEmailResponse response = (BackgroundSendEmailResponse)this.serviceCreator.OrganizationService.Execute(request);

			// process emails and set their status as 'sent'
			if (response != null && response.EntityCollection != null)
			{
				for (int i = 0; i < response.EntityCollection.Entities.Count; i++)
				{
					Entity item = response.EntityCollection.Entities[i];
					if (response.HasAttachments != null && response.HasAttachments[i])
					{
						ProcessAttachments(item);
					}

					// set state to 'completed' and status to 3 - 'sent'
					SetState(EntityName.email.ToString(), item.Id, (int)EmailState.Completed, 3);
				}
			}
		}

		#endregion

		#region Private Methods

		private QueryExpression CreateBackgroundSendQuery()
		{
			QueryExpression query = new QueryExpression(EntityName.email.ToString());
			query.ColumnSet = new ColumnSet(true);
			query.PageInfo.Count = 10;
			query.PageInfo.PageNumber = 1;

			// sender of the email should be the current user
			LinkEntity link = new LinkEntity(query.EntityName, EntityName.activityparty.ToString(), "activityid", "activityid", JoinOperator.Inner);
			link.LinkCriteria.Conditions.Add(new ConditionExpression("participationtypemask", ConditionOperator.Equal, 1));
			link.LinkCriteria.Conditions.Add(new ConditionExpression("partyid", ConditionOperator.Equal, new object[] { this.UserId }));
			query.LinkEntities.Add(link);
			LinkEntity link2 = new LinkEntity(query.EntityName, EntityName.activitypointer.ToString(), "activityid", "activityid", JoinOperator.Inner);
			link2.LinkCriteria.Conditions.Add(new ConditionExpression("ownerid", ConditionOperator.Equal, new object[] { this.UserId }));
			query.LinkEntities.Add(link2);
			return query;
		}

		private void ProcessAttachments(Entity item)
		{
			QueryExpression query = new QueryExpression(EntityName.activitymimeattachment.ToString());
			query.ColumnSet = new ColumnSet(true);
			query.Criteria.Conditions.Add(new ConditionExpression("activityid", ConditionOperator.Equal, ((Guid)item["activityid"])));
			this.serviceCreator.OrganizationService.RetrieveMultiple(query);
		}

		private void SetState(string entityName, Guid entityId, int stateCode, int statusCode)
		{
			SetStateRequest request = new SetStateRequest();
			request.EntityMoniker = new EntityReference(entityName, entityId);
			request.State = new OptionSetValue(stateCode);
			request.Status = new OptionSetValue(statusCode);
			this.serviceCreator.OrganizationService.Execute(request);
		}

		#endregion
	}
}
