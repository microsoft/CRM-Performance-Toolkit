﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.WebTesting;
using CRM_Perf_BenchMark.Espresso;

namespace CRM_Perf_BenchMark
{
	public abstract class me_CreateEntity : EspressoPageTestBase
	{
		private ME_EntityHelper _entityHelper;
		private CrmRequest _createEntity;
		private readonly string logicalName;

		public me_CreateEntity(string entityName)
			: base()
		{
			this.logicalName = entityName.ToLowerInvariant();
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction(EspressoTransactionNames.HomePage);
			var homepage = new _m_default_aspx(user);
			yield return (homepage);
			this.EndTransaction(EspressoTransactionNames.HomePage);

			this._entityHelper = MobileExpressHelper.Instance.GetHomepageEntity(logicalName);

			this.BeginTransaction(EspressoTransactionNames.EntityGrid);
			var entityHome = new _m_eh_aspx(user) { etn = this._entityHelper.logicalName };
			entityHome.Headers.Add(new WebTestRequestHeader("referer", homepage.lastResponse.ResponseUri.ToString()));
			yield return (entityHome);
			this.EndTransaction(EspressoTransactionNames.EntityGrid);

			this.BeginTransaction(string.Format(EspressoTransactionNames.EntityCreatePage, this.logicalName));
			var forms = new _m_forms_page_aspx(user) { Etc = this._entityHelper.otc };
			forms.Headers.Add(new WebTestRequestHeader("referer", entityHome.lastResponse.ResponseUri.ToString()));
			yield return forms;
			this.EndTransaction(string.Format(EspressoTransactionNames.EntityCreatePage, this.logicalName));


			this.BeginTransaction(string.Format(EspressoTransactionNames.EntitySubmit, this.logicalName));
			InlineEditHelper inlineEdit = new InlineEditHelper(GetCommandXml(), user);
			this._createEntity = inlineEdit.getInlineEditWTR(forms.lastResponse.ResponseUri.ToString(), 2) as CrmRequest;
			this._createEntity.ValidateResponse += this.NewEntity_ValidateResponse;
			yield return this._createEntity;
			this.EndTransaction(string.Format(EspressoTransactionNames.EntitySubmit, this.logicalName));
		}

		public void NewEntity_ValidateResponse(object sender, EventArgs e)
		{
			this._createEntity.ValidateResponse -= this.NewEntity_ValidateResponse;
		}

		public virtual string GetCommandXml()
		{
			return string.Empty;
		}
	}
}
