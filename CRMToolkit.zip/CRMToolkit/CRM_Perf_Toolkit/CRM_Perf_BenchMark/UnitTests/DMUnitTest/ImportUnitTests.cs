using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;
using System.Web.Services.Protocols;
using System.Xml;
using Microsoft.Win32;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.Crm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages.Internal;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using System.ServiceModel;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;



namespace CRM_Perf_BenchMark.DMUnitTest
{
	[TestClass]
	public class ImportUnitTests : UnitTestBase
	{
		private static string resultDir =  string.Format(@"{0}\PerfResult", Environment.SystemDirectory.Split(new char[] { '\\' }, 2)[0]);

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		[ClassInitialize()]
		public static void ClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
			}
			EntityManager.Instance.IsPerUserPerRun = true;
		}


		#endregion

		#region Individual Test Cases

		[TestMethod()]
		public void DMUnitTest_Import_ImportExportMap()
		{
			ImportExportMaps();
		}

		[TestMethod()]
		public void DMUnitTest_Import_ImportLeads_2K()
		{
			ImportLeads(2000);
		}


		#endregion

		#region Private Methodes

		private string LoadMap(string mapXml)
		{
			var reader = Utils.GetXmlReaderForXmlFile(mapXml);
			XmlDocument doc = new XmlDocument();
			doc.Load(reader);
			XmlNode mapNode = doc.SelectSingleNode("/Map");
			mapNode.Attributes["Name"].Value += DateTime.UtcNow.Ticks;

			return doc.InnerXml;
		}

		private Guid ImportLeads(int noOfRows)
		{
			string timestamp = System.DateTime.Now.Ticks.ToString();
			string CSVFile = resultDir + @"\PerfLead_" + timestamp + ".csv";
			string SummaryFile = resultDir + @"\Perf_Import_" + noOfRows.ToString() + "Leads_Summary_" + timestamp + ".log";
			//write logic to create the csv file
			StreamWriter sw = new StreamWriter(CSVFile, false);
			string row = "Topic,Annual Revenue,Business Phone,City,Company Name,Country/Region,Description,E-mail,Est. Close Date,Est. Value,Fax,First Name,Home Phone,Industry,Job Title,Last Name,Lead Source,Middle Name,Mobile Phone,No. of Employees,Other Phone,Pager,Preferred Method of Contact,Priority,Rating,Salutation,Send Marketing Materials,Do not allow E-mails,SIC Code,Web Site";
			sw.WriteLine(row);
			string clocktick = DateTime.Now.Millisecond.ToString();
			string today = DateTime.Today.ToString();
			for (int i = 1; i <= noOfRows; i++)
			{   //logic to create distinct rows
				row = "Topic" + clocktick + i.ToString() + ",545454544,11111111,Hyderabad,Microsoft,India,Have a nice day!!!,a@a.com," + today + ",23424,44444444,Firstname" + clocktick + i.ToString() + ",22222222,Accounting,Test Manager,Lastname " + clocktick + i.ToString() + ",Advertisement,Middlename " + clocktick + i.ToString() + ",33333333,87878,77777777,99999999,E-mail,Normal,Hot,Sir,1,0,321,www.microsoft.com";
				sw.WriteLine(row);
			}
			sw.Flush();
			sw.Close();

			string configDirKeyPath = "SOFTWARE\\Wow6432Node\\Microsoft\\MSCRMToolkit";
			string configDir = null;

			if (Registry.LocalMachine.OpenSubKey(configDirKeyPath) != null)
			{
				RegistryKey regKey = Registry.LocalMachine.OpenSubKey(configDirKeyPath);
				configDir = (string)regKey.GetValue("CRM_Perf_Toolkit_ConfigDir", Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles");
			}
			else
			{
				//setting the default directory of configsettings.xml
				configDir = Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles";
			}

			string importMapInnerXml = LoadMap(configDir + "\\lead.xml");
			return ImportEntityForGivenMapXMLAndCSVFIle(importMapInnerXml, new string[] { "lead" }, new string[] { CSVFile }, SummaryFile, noOfRows, 0);
		}

		private void ImportContactsForUpdate(int noOfRows)
		{
			
			Guid[] contactIds = new Guid[noOfRows + 1];

			Entity c = new Entity("contact");
			c["firstname"] = "InitialFirstName";
			c["lastname"] = "InitialLastName";

			for (int i = 1; i <= noOfRows; i++)
			{
				c.Id = contactIds[i] = Guid.NewGuid();
				Proxy.Create(c);
			}

			string timestamp = System.DateTime.Now.Ticks.ToString();
			string CSVFile = resultDir + @"\PerfContact_" + timestamp + ".csv";
			string SummaryFile = resultDir + @"\Perf_Import_" + noOfRows.ToString() + "Contacts_Update_Summary_" + timestamp + ".log";
			//write logic to create the csv file
			StreamWriter sw = new StreamWriter(CSVFile, false);
			string row = "Contact,Business Phone,Anniversary,Annual Income,Assistant,Assistant Phone,Birthday,Childrens Names,Credit Hold,Department,Description,E-mail,Employee,Fax,Gender,Government,Has Children,Home Phone,Job Title,Last Name,Manager,Manager Phone,Marital Status,Middle Name,First Name,Mobile Phone,Nickname,No. of Children,Pager,Payment Terms,Preferred Day,Role,Salutation,Suffix,Web Site";
			sw.WriteLine(row);
			string clocktick = DateTime.Now.Millisecond.ToString();
			string today = DateTime.Today.ToString();
			for (int i = 1; i <= noOfRows; i++)
			{   //logic to create distinct rows
				row = contactIds[i] + ",11111111," + today + ",234324,Mary,55555555," + today + ",Childrens Names,0,Finance,Have a nice day!!!,a@a.com,24245,44444444,Female,USA,1,22222222,Development Lead,Lastname" + clocktick + i.ToString() + ",David,66666666,Married,Middlename" + clocktick + i.ToString() + ",FinalFirstname" + clocktick + i.ToString() + ",33333333,Julia,4,77777777,Net 30,Monday,Employee,Mrs.,Supremo,www.microsoft.com";
				sw.WriteLine(row);
			}
			sw.Flush();
			sw.Close();

			string configDirKeyPath = "SOFTWARE\\Wow6432Node\\Microsoft\\MSCRMToolkit";
			string configDir = null;

			if (Registry.LocalMachine.OpenSubKey(configDirKeyPath) != null)
			{
				RegistryKey regKey = Registry.LocalMachine.OpenSubKey(configDirKeyPath);
				configDir = (string)regKey.GetValue("CRM_Perf_Toolkit_ConfigDir", Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles");
			}
			else
			{
				//setting the default directory of configsettings.xml
				configDir = Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles";
			}

			string importMapInnerXml = LoadMap(configDir + "\\contact.xml");

			ImportEntityForGivenMapXMLAndCSVFIle(importMapInnerXml, new string[] { "contact" }, new string[] { CSVFile }, true, SummaryFile, noOfRows, 0); ;
		}

		private void ImportExportMaps()
		{
			// Import a map
			string configDirKeyPath = "SOFTWARE\\Wow6432Node\\Microsoft\\MSCRMToolkit";
			string configDir = null;

			if (Registry.LocalMachine.OpenSubKey(configDirKeyPath) != null)
			{
				RegistryKey regKey = Registry.LocalMachine.OpenSubKey(configDirKeyPath);
				configDir = (string)regKey.GetValue("CRM_Perf_Toolkit_ConfigDir", Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles");
			}
			else
			{
				//setting the default directory of configsettings.xml
				configDir = Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles";
			}

			ImportMappingsImportMapRequest importRequest = new ImportMappingsImportMapRequest();
			ImportMappingsImportMapResponse importResponse = new ImportMappingsImportMapResponse();
			importRequest.MappingsXml = LoadMap(configDir + "\\SFMap.xml");
			importRequest.ReplaceIds = true;

			DateTime before = DateTime.Now;
			try
			{
				TestContext.BeginTimer("Import Map");
				importResponse = (ImportMappingsImportMapResponse)Proxy.Execute(importRequest);
				TestContext.EndTimer("Import Map");
			}
			catch (FaultException<IOrganizationService> e)
			{
				System.Diagnostics.Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine("Import Mapping Failed:" + e.ToString());
				throw e;
			}
			DateTime after = DateTime.Now;

			double importMapTime = ((TimeSpan)(after - before)).TotalMilliseconds;

			// Export a map

			ExportMappingsImportMapRequest exportRequest = new ExportMappingsImportMapRequest();
			ExportMappingsImportMapResponse exportResponse = new ExportMappingsImportMapResponse();
			exportRequest.ImportMapId = importResponse.ImportMapId;
			exportRequest.Parameters["ExportIds"] = false;
			before = DateTime.UtcNow;
			try
			{
				TestContext.BeginTimer("Export Map");
				exportResponse = (ExportMappingsImportMapResponse)Proxy.Execute(exportRequest);
				TestContext.EndTimer("Export Map");
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine("Export Mapping Failed:" + e.ToString());
				throw e;
			}
			after = DateTime.UtcNow;

			double exportMapTime = ((TimeSpan)(after - before)).TotalMilliseconds;

			string summaryFile = resultDir + @"\MapImportExport_" + DateTime.Now.Ticks.ToString() + ".log";

			StreamWriter logWriter = new StreamWriter(summaryFile);
			lock (logWriter)
			{
				logWriter.WriteLine("Logging test reult for Map Import/Export ...");
				logWriter.WriteLine("--------------------------------------");
				logWriter.WriteLine("Map Import took {0} milisecond", importMapTime);
				logWriter.WriteLine("Map Export took {0} milisecond", exportMapTime);
				logWriter.Flush();
				logWriter.Close();
			}
		}

		private Guid ImportEntityForGivenMapXMLAndCSVFIle(string importMapInnerXml, string[] entitynames, string[] CSVFiles, string SummaryFile, int expectedSuccessCount, int expectedFailureCount)
		{
			return ImportEntityForGivenMapXMLAndCSVFIle(importMapInnerXml, entitynames, CSVFiles, false, SummaryFile, expectedSuccessCount, expectedFailureCount);
		}

		private Guid ImportEntityForGivenMapXMLAndCSVFIle(string importMapInnerXml, string[] entitynames, string[] CSVFiles, bool isUpdate, string SummaryFile, int expectedSuccessCount, int expectedFailureCount)
		{
			Guid importMapId = CreateImportMapforGivenXML(importMapInnerXml, true);
			if (isUpdate)
				return PerfTestImportUsingFileMapAndCSV(entitynames, CSVFiles, importMapId, true, SummaryFile, expectedSuccessCount, expectedFailureCount);
			else
				return PerfTestImportUsingFileMapAndCSV(entitynames, CSVFiles, importMapId, false, SummaryFile, expectedSuccessCount, expectedFailureCount);
		}

		private Guid PerfTestImportUsingFileMapAndCSV(string[] entityNames, string[] fileNames, Guid importMapId, string SummaryFile, int expectedSuccessCount, int expectedFailureCount)
		{
			return PerfTestImportUsingFileMapAndCSV(entityNames, fileNames, importMapId, false, SummaryFile, expectedSuccessCount, expectedFailureCount);
		}

		private Guid PerfTestImportUsingFileMapAndCSV(string[] entityNames, string[] fileNames, Guid importMapId, bool isUpdate, string SummaryFile, int expectedSuccessCount, int expectedFailureCount)
		{
			DateTime start = DateTime.UtcNow;

			// Create import and import files
			Entity perfImport = new Entity("import");
			StringBuilder name = new StringBuilder();
			foreach (string entityName in entityNames)
				name.Append(entityName);
			perfImport["name"] = "import" + name.ToString() + DateTime.Now.Ticks.ToString();
			perfImport["isimport"] = true;
			if (isUpdate)
				perfImport["modecode"] = new OptionSetValue(1); // Picklist(ImportModeCode.Update);
			else
				perfImport["modecode"] = new OptionSetValue(0); // Picklist(ImportModeCode.Create);
			Guid importId = Proxy.Create(perfImport);

			Guid[] importFileIds = new Guid[fileNames.Length];
			for (int i = 0; i < fileNames.Length; i++)
			{
				Entity importFile = new Entity("importfile");
				importFile["content"] = ReadCSV(fileNames[i]);

				importFile["fielddelimitercode"] = new OptionSetValue(2);
				importFile["datadelimitercode"] = new OptionSetValue(2);  //Picklist(ImportDataDelimiter.Null);
				importFile["isfirstrowheader"] = true;

				importFile["importid"] = new EntityReference("import", importId);
				importFile["sourceentityname"] = entityNames[i];
				importFile["targetentityname"] = entityNames[i];

				importFile["importmapid"] = new EntityReference("importmap", importMapId);
				importFile["enableduplicatedetection"] = false;

				importFileIds[i] = Proxy.Create(importFile);
			}

			// Parse the files
			ParseImportRequest parseRequest = new ParseImportRequest();
			parseRequest.ImportId = importId;
			ParseImportResponse parseResponse;
			try
			{

				parseResponse = (ParseImportResponse)Proxy.Execute(parseRequest);
			}
			catch (Exception e)
			{
				throw e;
			}

			// Transform parse data
			TransformImportRequest tarnsformRequest = new TransformImportRequest();
			tarnsformRequest.ImportId = importId;
			TransformImportResponse transformResponse;
			try
			{

				transformResponse = (TransformImportResponse)Proxy.Execute(tarnsformRequest);
			}
			catch (Exception e)
			{
				throw e;
			}

			// Import transformed data
			ImportRecordsImportRequest importRequest = new ImportRecordsImportRequest();
			importRequest.ImportId = importId;
			ImportRecordsImportResponse importResponse;
			try
			{
				importResponse = (ImportRecordsImportResponse)Proxy.Execute(importRequest);
			}
			catch (Exception e)
			{
				throw e;
			}

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Import/Migrate ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Import Id for this test is " + importId.ToString());
				logWriter.WriteLine("Test started at " + start);
				logWriter.Flush();
				logWriter.Close();
			}

			return importId;
		}

		private Guid CreateImportMapforGivenXML(String mappingsXml, bool replaceIds)
		{
			ImportMappingsImportMapRequest request = new ImportMappingsImportMapRequest();
			request.MappingsXml = mappingsXml;
			request.ReplaceIds = replaceIds;
			ImportMappingsImportMapResponse response = new ImportMappingsImportMapResponse();
			try
			{
				response = (ImportMappingsImportMapResponse)Proxy.Execute(request);
				System.Diagnostics.Trace.WriteLine("Pass");
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine("Import Mapping Failed:" + e.ToString());
				throw e;
			}
			return response.ImportMapId;
		}

		private string ReadCSV(string filePath)
		{

			StringBuilder data = new StringBuilder();
			StreamReader reader = new StreamReader(filePath);
			string value = reader.ReadLine();
			while (value != null)
			{
				data.AppendLine(value);

				value = reader.ReadLine();
			}

			return data.ToString();

		}

		#endregion
	}
}