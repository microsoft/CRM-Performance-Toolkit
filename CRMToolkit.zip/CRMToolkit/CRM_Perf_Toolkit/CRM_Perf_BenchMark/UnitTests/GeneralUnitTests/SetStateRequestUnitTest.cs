﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// test SetStateRequest
	/// 1. create an appointment first
	/// 2. set the state of appointment to close
	/// 3. delete the appointment just created
	/// </summary>
	[TestClass]
	public class SetStateRequestUnitTest : UnitTestBase
	{
		#region Set state request
		/// <summary>
		/// Set state request
		/// </summary>
		[TestMethod]
		public void UnitTest__SetStateRequest()
		{
			//create an appointment
			Entity appointment = new Entity("appointment");
			appointment["subject"] = "Sample CWR test appointment";
			appointment["scheduledstart"] = DateTime.Now.AddDays(1);
			appointment["scheduledend"] = DateTime.Now.AddDays(3);
			Guid appointmentId = Proxy.Create(appointment);

			//set the state of the appointment
			SetStateRequest req = new SetStateRequest();
			req.EntityMoniker = new EntityReference("appointment", appointmentId);
			//set the state to 
			req.State = new OptionSetValue(1);
			req.Status = new OptionSetValue(3);

			//execute the request
			DateTime start = DateTime.UtcNow;
			DateTime end;
			TestContext.BeginTimer("SetState Request Unit Test");
			try
			{
				Proxy.Execute(req);
				TestContext.EndTimer("SetState Request Unit Test");
				end = DateTime.UtcNow;
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			finally
			{
				//clean up after test; delete the appointment just created
				if (appointmentId != null)
				{
					Proxy.Delete(appointment.LogicalName, appointmentId);
				}
			}

		}
		#endregion
	}
}
