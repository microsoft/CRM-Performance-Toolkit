﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Services.Protocols;

namespace CRM_Perf_BenchMark
{
	abstract class AppWebServiceBase
	{
		protected CRMEntity User { get; set; }

		public AppWebServiceBase(CRMEntity user)
		{
			this.User = user;
		}

	}
}
