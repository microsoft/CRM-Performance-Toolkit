﻿using System.Collections.Generic;
using CRM_Perf_BenchMark.Espresso;
using CRM_Perf_Benchmark;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace CRM_Perf_Benchmark
{
	public class WebService_GetDefaultCommandBarDefinitions : EspressoWebServiceTestBase
	{
		public WebService_GetDefaultCommandBarDefinitions()
			: base()
		{
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction(EspressoTransactionNames.WebService_GetDefaultCommandBarDefinitions);
			yield return base.Execute(() => new MobileExpressWebService().GetDefaultCommandBarDefinitions());
			this.EndTransaction(EspressoTransactionNames.WebService_GetDefaultCommandBarDefinitions);
		}

		protected override void ResponseValidator(object sender, ValidationEventArgs e)
		{
			// HTTP Status code is checked by default validator, no need for any more validation in this call.
		}
	}
}
