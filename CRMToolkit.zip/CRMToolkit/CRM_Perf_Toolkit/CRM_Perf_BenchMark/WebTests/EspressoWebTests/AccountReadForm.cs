﻿namespace CRM_Perf_BenchMark
{
	public class me_AccountReadForm : me_ReadForm
	{
		public me_AccountReadForm()
			: base(EntityNames.Accounts)
		{

		}
	}
}
