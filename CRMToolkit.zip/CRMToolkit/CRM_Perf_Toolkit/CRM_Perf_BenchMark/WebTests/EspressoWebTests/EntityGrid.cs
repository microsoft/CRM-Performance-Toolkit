﻿namespace CRM_Perf_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using Espresso;

	/// <summary>
	/// 1. Go to sitemap
	/// 2. Go to random grid
	/// 3. Do search on random grid
	/// </summary>

	public class me_Entitypage : EspressoPageTestBase
	{
		public me_Entitypage()
			: base()
		{
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction(EspressoTransactionNames.HomePage);
			_m_default_aspx hp = new _m_default_aspx(user);
			yield return (hp);
			this.EndTransaction(EspressoTransactionNames.HomePage);

			this.BeginTransaction(EspressoTransactionNames.EntityGrid);
			string referer = hp.lastResponse.ResponseUri.ToString();
			WebTestRequestHeader header = new WebTestRequestHeader();
			header.Name = "referer";
			header.Value = referer;
			_m_eh_aspx eh = new _m_eh_aspx(user);
			eh.Headers.Add(header);
			ME_EntityHelper meeh = MobileExpressHelper.Instance.GetRandomHomepageEntity();
			eh.etn = meeh.logicalName;
			yield return (eh);
			this.EndTransaction(EspressoTransactionNames.EntityGrid);
		}
	}
}
