﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit Testcases for creating, updating, retrieving and deleting Contact entity
	/// </summary>
	[TestClass]
	public class RetrieveMultipleContactUnitTest : UnitTestBase
	{
		#region Retreive multiple contact
		/// <summary>
		/// Retrieve multiple contacts
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_Contact()
		{
			CRMEntity m_contact = RetrieveTestEntity(m_user, EntityNames.Contacts);
			Entity contact = new Entity("contact");
			QueryExpression query = new QueryExpression("contact");
			query.ColumnSet.AddColumn("contactid");
			query.ColumnSet.AddColumn("fullname");
			query.Criteria.AddCondition("lastname", ConditionOperator.GreaterThan, m_contact["lastname"]);
			EntityCollection results;

			TestContext.BeginTimer("Contact RetrieveMultiple UnitTest");
			try
			{
				results = Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Contact RetrieveMultiple UnitTest");
		}
		#endregion
	}
}
