﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Collections;
using System.Diagnostics;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using CommonTypes;

namespace CRM_Perf_BenchMark
{
	public partial class EntityManager
	{

		private static void ReadReports(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, "EntityManagerOwningUser", EntityIDNames.Report, "FileName", "ReportTypeCode", "ReportNameOnSRS" };
			string Table = EntityNames.Reports;

			Trace.WriteLine("Read " + ReadSpecialEntityFromTable(serverData, Table, Fields, null, null, orgId) + " Reports");
		}

		private static void ReadOutlookUsers(Guid orgId)
		{
			string roles = @"select distinct role as role from systemuser";
			ArrayList rolesList = new ArrayList();
			SqlCommand cmd = new SqlCommand(roles, m_EMSQLCon);
			SqlDataReader reader = null;
			try
			{
				reader = cmd.ExecuteReader();

				while (reader.Read())
				{
					if (reader[0] != DBNull.Value)
					{
						rolesList.Add((string)reader[0]);
					}
				}
				reader.Close();
			}
			catch (SqlException e)
			{
				Debug.WriteLine(e.ToString());
			}
			finally
			{
				cmd.Dispose();
			}

			foreach (string role in rolesList)
			{
				int numOutlookUsers = 0;
				string userCount = @"select count(*) from systemuser where systemuser.role =  @role";
				SqlCommand cmd2 = new SqlCommand(userCount, m_EMSQLCon);
				cmd2.Parameters.AddWithValue("role", role);

				try
				{
					SqlDataReader reader2 = cmd2.ExecuteReader();
					int outlookUserPercentage = ConfigSettings.Default.OutlookUserPercentage;
					while (reader2.Read())
					{
						int numUsers = (int)reader2[0];
						numOutlookUsers = (int)(Math.Ceiling(Convert.ToDouble(numUsers * outlookUserPercentage / 100)));
					}
					reader2.Close();
				}
				catch (SqlException e)
				{
					Trace.WriteLine(e.ToString());
				}
				finally
				{
					cmd2.Dispose();
				}

				string setOutlookUsers = String.Format(@"update systemuser set outlookuser = '1' where systemuserid in (select top {0} systemuserid from systemuser where role = @role)", numOutlookUsers.ToString());
				SqlCommand cmd3 = new SqlCommand(setOutlookUsers, m_EMSQLCon);
				cmd3.Parameters.AddWithValue("role", role);

				try
				{
					cmd3.ExecuteNonQuery();
				}
				catch (SqlException e)
				{
					Trace.WriteLine(e.ToString());
				}
				finally
				{
					cmd3.Dispose();
				}
			}
		}


		private static void ReadSystemUserRoles()
		{
			QueryExpression query;
			EntityCollection results = null;

			try
			{
				Entity role = new Entity();
				role.LogicalName = "role";

				Entity systemUserRoles = new Entity();
				systemUserRoles.LogicalName = "systemuserroles";

				Entity systemUser = new Entity();
				systemUser.LogicalName = "systemuser";

				query = new QueryExpression();
				query.EntityName = systemUserRoles.LogicalName;

				query.LinkEntities.Add(new LinkEntity(systemUserRoles.LogicalName, role.LogicalName, "roleid", "roleid", JoinOperator.Inner));
				query.LinkEntities[0].Columns.AddColumns("name");
				query.LinkEntities[0].EntityAlias = "Role";

				query.LinkEntities.Add(new LinkEntity(systemUserRoles.LogicalName, systemUser.LogicalName, "systemuserid", "systemuserid", JoinOperator.Inner));
				query.LinkEntities[1].Columns.AddColumns("domainname");
				query.LinkEntities[1].EntityAlias = "SystemUser";

				bool getmorerows = true;
				query.PageInfo.Count = 5000;
				query.PageInfo.PageNumber = 1;

				while (getmorerows)
				{
					results = adminUserProxy.RetrieveMultiple(query);
					query.PageInfo.PageNumber++;
					query.PageInfo.PagingCookie = results.PagingCookie;
					getmorerows = results.MoreRecords;

					for (int k = 0; k < results.Entities.Count; k++)
					{
						Entity en = results[k];
						if (en.Attributes.Contains("Role.name") && en.Attributes.Contains("SystemUser.domainname"))
						{
							string updateCmd = @"update systemuser set Role = @role where domainname = @domainname";
							using (SqlCommand EMDcmd = new SqlCommand(updateCmd, m_EMSQLCon))
							{
								EMDcmd.Parameters.AddWithValue("role", ((AliasedValue)en.Attributes["Role.name"]).Value);
								EMDcmd.Parameters.AddWithValue("domainname", ((AliasedValue) en.Attributes["SystemUser.domainname"]).Value);
								EMDcmd.ExecuteNonQuery();
							}
						}
					}
				}
			}
			catch (System.Exception e)
			{
				Trace.WriteLine("Exception:\n" + e.ToString());
				throw;
			}
		}

		//Read User's RO setting 
		private static void ReadUserSettings()
		{
			try
			{
				EntityCollection results = null;

				bool getmorerows = true;
				QueryExpression query = new QueryExpression("usersettings");
				query.PageInfo.Count = 5000;
				query.PageInfo.PageNumber = 1;
				query.ColumnSet.AllColumns = true;

				while (getmorerows)
				{
					results = adminUserProxy.RetrieveMultiple(query);
					query.PageInfo.PageNumber++;
					query.PageInfo.PagingCookie = results.PagingCookie;
					getmorerows = results.MoreRecords;

					for (int k = 0; k < results.Entities.Count; k++)
					{
						Entity en = results[k];
						if (en.Attributes.Contains("systemuserid") && en.Attributes.Contains("entityformmode"))
						{
							string updateCmd = @"update systemuser set entityformmode = @entityformmode where SystemUserId = @systemUserId";
							using (SqlCommand EMDcmd = new SqlCommand(updateCmd, m_EMSQLCon))
							{
								EMDcmd.Parameters.AddWithValue("entityformmode", ((OptionSetValue) en.Attributes["entityformmode"]).Value.ToString());
								EMDcmd.Parameters.AddWithValue("systemUserId", en.Attributes["systemuserid"].ToString());

								EMDcmd.ExecuteNonQuery();
							}
						}
					}
				}
			}
			catch (System.Exception e)
			{
				Trace.WriteLine("Exception:\n" + e.ToString());
				throw;
			}
		}

		private static void ReadCompetitors(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, "EntityManagerOwningUser", EntityIDNames.Competitor, "Name" };
			string Table = EntityNames.Competitor;

			Trace.WriteLine("Read " + ReadSpecialEntityFromTable(serverData, Table, Fields, null, null, orgId) + " Competitors");
		}

		private static uint ReadSpecialEntityFromTable(MultipleServersData serverData, string EntityName, string[] Props, FilterExpression Where, string strORDERBY, Guid orgId)
		{
			return ReadEntityFromTable(serverData, EntityName, Props, Where, strORDERBY, null, orgId, "", EntityType.Special);
		}

		private static void ReadTransactionCurrencies(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, "EntityManagerOwningUser", EntityIDNames.TransactionCurrency, "CurrencyName", "CurrencySymbol", "ISOCurrencyCode" };
			string Table = EntityNames.TransactionCurrency;

			Trace.WriteLine("Read " + ReadSpecialEntityFromTable(serverData, Table, Fields, null, null, orgId) + " Currencies");
		}

		private static void ReadPrivileges(MultipleServersData serverData, Guid orgId)
		{
			string[] Fields = { EntityIDNames.Organization, "PrivilegeID", EntityIDNames.Privilege };
			string Table = EntityNames.Privileges;

			Trace.WriteLine("Read " + ReadSpecialEntityFromTable(serverData, Table, Fields, null, null, orgId) + " Privileges");
		}

		private static void ReadExchangeSyncSettings(Guid orgId, SqlConnection emSqlConn)
		{
			QueryExpression query;
			EntityCollection results = null;

			try
			{
				Entity mailbox = new Entity();
				mailbox.LogicalName = "mailbox";

				Entity EmailServerProfile = new Entity();
				EmailServerProfile.LogicalName = "emailserverprofile";

				query = new QueryExpression();
				query.EntityName = mailbox.LogicalName;
				query.ColumnSet.AddColumns("emailaddress", "regardingobjecttypecode", "mailboxid", "actdeliverymethod", "enabledforact", "ownerid");
				query.LinkEntities.Add(new LinkEntity(mailbox.LogicalName, EmailServerProfile.LogicalName, "emailserverprofile", "emailserverprofileid", JoinOperator.Inner));
				query.LinkEntities[0].Columns.AddColumns("outgoingserverlocation");
				query.LinkEntities[0].Columns.AddColumns("useautodiscover");
				query.LinkEntities[0].EntityAlias = "EmailServerProfile";

				query.Criteria.AddCondition("emailaddress", ConditionOperator.NotNull);
				query.Criteria.AddCondition("regardingobjecttypecode", ConditionOperator.Equal, 8);
				bool getmorerows = true;
				query.PageInfo.Count = 5000;
				query.PageInfo.PageNumber = 1;
				bool isExchangeOrg = false;

				while (getmorerows)
				{
					results = adminUserProxy.RetrieveMultiple(query);
					query.PageInfo.PageNumber++;
					query.PageInfo.PagingCookie = results.PagingCookie;
					getmorerows = results.MoreRecords;

					for (int k = 0; k < results.Entities.Count; k++)
					{
						Entity en = results[k];
						using (SqlCommand emCmd = new SqlCommand())
						{
							emCmd.Connection = emSqlConn;
							int enabledForACT = ((bool)en.Attributes["enabledforact"]) ? 1 : 0;
							string internalEmailAddress = en.Attributes["emailaddress"].ToString();
							string ownerId = ((EntityReference)en.Attributes["ownerid"]).Id.ToString();

							if (((OptionSetValue)en.Attributes["actdeliverymethod"]).Value.ToString().Equals("1")) // if it's a user mailbox, update its owner's EnableForACT and InternalEmailAddress in EMDB.SystemUser table
							{
								isExchangeOrg = true;

								using (SqlCommand emCmd2 = new SqlCommand())
								{
									emCmd2.Connection = emSqlConn;
									string update = @"UPDATE SystemUser SET EnabledForACT=@enableForACT, InternalEmailAddress=@internalEmailAddress, ExchangePassword=@exchangePassword WHERE SystemUserId=@systemUserId and OrganizationId=@organizationId";
									emCmd2.CommandText = update;
									emCmd2.Parameters.AddWithValue("enableForACT", enabledForACT);
									emCmd2.Parameters.AddWithValue("internalEmailAddress", internalEmailAddress);
									emCmd2.Parameters.AddWithValue("exchangePassword", ConfigSettings.Default.ExchangePassword);
									emCmd2.Parameters.AddWithValue("systemUserId", ownerId);
									emCmd2.Parameters.AddWithValue("organizationId", orgId.ToString());

									try
									{
										if (1 != emCmd2.ExecuteNonQuery())
										{
											Trace.Write("Didn't effect 1 row");
										}
									}
									catch (Exception er)
									{
										Trace.WriteLine("Exception:\n" + er.ToString());
									}
								}
							}

							string insert = String.Format(
							"INSERT INTO ExchangeSyncSettings (MailboxId,OrganizationId,SystemUserId,OutgoingServerLocation,UseAutoDiscover,EnabledForACT) VALUES ('{0}','{1}','{2}','{3}',{4},{5})"
							, en.Attributes["mailboxid"]
							, orgId.ToString()
							, ownerId
							, en.Attributes.Contains("EmailServerProfile.outgoingserverlocation") ? ((AliasedValue)en.Attributes["EmailServerProfile.outgoingserverlocation"]).Value : DBNull.Value
							, ((bool)((AliasedValue)en.Attributes["EmailServerProfile.useautodiscover"]).Value) ? 1 : 0
							, enabledForACT);

							emCmd.CommandText = insert;
							try
							{
								if (1 != emCmd.ExecuteNonQuery())
								{
									Trace.Write("Didn't effect 1 row");
								}
							}
							catch (Exception er)
							{
								Trace.WriteLine("Exception:\n" + er.ToString());
							}
						}
					}
				}

				if (isExchangeOrg)
				{
					using (SqlCommand emCmd3 = new SqlCommand())
					{
						emCmd3.Connection = emSqlConn;
						string update = "UPDATE Organization SET ExchangeMode = 1 WHERE OrganizationId= @orgId";
						emCmd3.CommandText = update;
						emCmd3.Parameters.AddWithValue("orgId", orgId.ToString());
						try
						{
							if (1 != emCmd3.ExecuteNonQuery())
							{
								Trace.Write("Didn't effect 1 row");
							}
						}
						catch (Exception er)
						{
							Trace.WriteLine("Exception:\n" + er.ToString());
						}
					}
				}
			}
			catch (System.Exception e)
			{
				Trace.WriteLine("Exception:\n" + e.ToString());
				throw;
			}
		}


		private static void ReadExchangeData(Guid orgId, SqlConnection emSqlConn)
		{
			string select = "Select SystemUserId,UserPassword,InternalEmailAddress From SystemUser WHERE EnabledForACT=1";

			using (SqlCommand users = new SqlCommand(select, emSqlConn))
			{
				using (SqlDataReader reader = users.ExecuteReader())
				{
					while (reader.Read())
					{
						var userId = reader["SystemUserId"].ToString();
						Guid userGuid = Guid.Empty;
						Guid.TryParse(userId, out userGuid);
						if (userGuid == Guid.Empty)
						{
							Trace.WriteLine("Couldn't Parse User ID" + userId + "to Guid:\n");
							continue;
						}
						var emailAddress = reader["InternalEmailAddress"].ToString();
						var userPassword = reader["UserPassword"].ToString();
						if (String.IsNullOrWhiteSpace(emailAddress) || String.IsNullOrWhiteSpace(userPassword))
						{
							Trace.WriteLine(String.Format("User with Guid: {0} Doesn't have an Email Address or password configured", userGuid));
							continue;
						}

						var service = GetService(userGuid, emailAddress, userPassword);
						var entityManagerOwningUser = GetOwnerGuid(userGuid, orgId).ToString();
						ReadExchangeAppointments(userGuid, service, entityManagerOwningUser);
						ReadExchangeTasks(userGuid, service, entityManagerOwningUser);
						ReadExchangeContacts(userGuid, service, entityManagerOwningUser);
					}
				}

			}

		}

		private static void ReadExchangeAppointments(Guid userId, ExchangeService service, string entityManagerOwningUser)
		{
			int offset = 0;

			FindItemsResults<Item> appointements = null;
			using (SqlConnection con = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
			{
				con.Open();
				using (SqlCommand command = new SqlCommand())
				{
					command.Connection = con;
					do
					{
						ItemView view = new ItemView(100, offset);
						appointements = service.FindItems(WellKnownFolderName.Calendar, view);

						foreach (Appointment tas in appointements)
						{
							command.CommandText = String.Format("Insert into {0} (OwnerId,EntityManagerOwningUser,State,Subject,ExchangeId) Values (@OwnerId, @EntityManagerOwningUser, @State, @Subject, @ExchangeId", EntityNames.ExchangeAppointment);
							command.Parameters.AddWithValue("OwnerId", userId.ToString());
							command.Parameters.AddWithValue("EntityManagerOwningUser", entityManagerOwningUser);
							command.Parameters.AddWithValue("State", 0);
							command.Parameters.AddWithValue("Subject", tas.Subject);
							command.Parameters.AddWithValue("ExchangeId", tas.Id.UniqueId);
							try
							{
								command.ExecuteNonQuery();
							}
							catch
							{
								Trace.WriteLine("Failed to Add Exchange Appointment: " + tas.Id.UniqueId.ToString() + " To EMDB");
							}
						}
						offset += 100;
					} while (appointements != null && appointements.Items.Count == 100);
				}
			}
		}

		private static void ReadExchangeTasks(Guid userId, ExchangeService service, string entityManagerOwningUser)
		{
			int offset = 0;

			FindItemsResults<Item> tasks = null;
			using (SqlConnection con = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
			{
				con.Open();
				using (SqlCommand command = new SqlCommand())
				{
					command.Connection = con;
					do
					{
						ItemView view = new ItemView(100, offset);
						tasks = service.FindItems(WellKnownFolderName.Tasks, view);

						foreach (Task tas in tasks)
						{
							command.CommandText = String.Format("Insert into {0} (OwnerId,EntityManagerOwningUser,State,Subject,ExchangeId) Values ('{1}','{2}',{3},'{4}','{5}')", EntityNames.ExchangeTask, userId.ToString(), entityManagerOwningUser, 0, tas.Subject, tas.Id.UniqueId);
							try
							{
								command.ExecuteNonQuery();
							}
							catch
							{
								Trace.WriteLine("Failed to Add Exchange Task: " + tas.Id.UniqueId.ToString() + " To EMDB");
							}
						}
						offset += 100;
					} while (tasks != null && tasks.Items.Count == 100);
				}
			}
		}

		private static void ReadExchangeContacts(Guid userId, ExchangeService service, string entityManagerOwningUser)
		{
			int offset = 0;

			FindItemsResults<Item> contacts = null;
			using (SqlConnection con = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
			{
				con.Open();
				using (SqlCommand command = new SqlCommand())
				{
					command.Connection = con;
					do
					{
						ItemView view = new ItemView(100, offset);
						contacts = service.FindItems(WellKnownFolderName.Contacts, view);

						foreach (Contact tas in contacts)
						{
							command.CommandText = String.Format("Insert into {0} (OwnerId,EntityManagerOwningUser,State,LastName,ExchangeId) Values ('{1}','{2}',{3},'{4}','{5}')", EntityNames.ExchangeContact, userId.ToString(), entityManagerOwningUser, 0, tas.Surname, tas.Id.UniqueId);
							try
							{
								command.ExecuteNonQuery();
							}
							catch
							{
								Trace.WriteLine("Failed to Add Exchange Task: " + tas.Id.UniqueId.ToString() + " To EMDB");
							}
						}
						offset += 100;
					} while (contacts != null && contacts.Items.Count == 100);
				}
			}
		}
	}
}

