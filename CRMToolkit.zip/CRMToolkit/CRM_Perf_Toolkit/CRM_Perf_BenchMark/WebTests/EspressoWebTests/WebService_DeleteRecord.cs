﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM_Perf_BenchMark;
using CRM_Perf_BenchMark.Espresso;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace CRM_Perf_Benchmark
{
	public abstract class WebService_DeleteRecord : EspressoWebServiceTestBase
	{
		protected WebService_DeleteRecord(string entityName, int entityTypeCode)
			: base()
		{
			this._logicalName = entityName;
			this._entityTypeCode = entityTypeCode;
		}

		protected override void EspressoWebServiceTest_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			var accountER = new EntityRequest()
			{
				Type = _logicalName,
				ParentID = Guid.NewGuid(),
				ReturnAs = _logicalName,
				Props = new Hashtable
					{
						{GetDeletableAttributeName(), "deletable"}
					}
			};

			var entityRequest = new EntityRequest[] { accountER };

			System.Collections.Hashtable entities = WebTestBase_PreWebTest(sender, e, entityRequest, EntityNames.Accounts);
			if (entities != null)
			{
				this._entity = entities[_logicalName] as CRMEntity;
			}
		}

		protected override void EspressoWebServiceTest_PostWebTest(object sender, PostWebTestEventArgs e)
		{
			WebTestBase_PostWebTest(sender, e);
			EntityManager.Instance.DeleteEntity(this._entity);
			base.EspressoWebServiceTest_PostWebTest(sender, e);
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			string recordIdString = MobileExpressHelper.Instance.GetEntityId(this._logicalName, this._entity);
			Guid recordId = Guid.Parse(recordIdString);

			this.BeginTransaction(EspressoTransactionNames.HomePage);
			var homepage = new _m_default_aspx(user);
			yield return (homepage);
			this.EndTransaction(EspressoTransactionNames.HomePage);

			this._entityHelper = MobileExpressHelper.Instance.GetHomepageEntity(_logicalName);

			this.BeginTransaction(EspressoTransactionNames.EntityGrid);
			var entityHome = new _m_eh_aspx(user) { etn = this._entityHelper.logicalName };
			entityHome.Headers.Add(new WebTestRequestHeader("referer", homepage.lastResponse.ResponseUri.ToString()));
			yield return (entityHome);
			this.EndTransaction(EspressoTransactionNames.EntityGrid);

			this.BeginTransaction(string.Format(EspressoTransactionNames.EntityReadPage, this._logicalName));
			var readForm = new _m_ef_aspx(user)
			{
				Etn = this._entityHelper.logicalName,
				Id = recordId
			};
			readForm.Headers.Add(new WebTestRequestHeader("referer", entityHome.lastResponse.ResponseUri.ToString()));
			yield return readForm;
			this.EndTransaction(string.Format(EspressoTransactionNames.EntityReadPage, this._logicalName));

			this.BeginTransaction(string.Format(EspressoTransactionNames.WebService_DeleteRecord, this._logicalName));
			var wtr = base.Execute(() => new MobileExpressWebService().DeleteRecord(recordIdString, _entityTypeCode));
			yield return wtr;
			this.EndTransaction(string.Format(EspressoTransactionNames.WebService_DeleteRecord, this._logicalName));
		}

		protected override void ResponseValidator(object sender, ValidationEventArgs e)
		{
			// HTTP Status code is checked by default validator, no need for any more validation in this call.
		}

		private string GetDeletableAttributeName()
		{
			string attributeName = string.Empty;
			switch (_logicalName.ToLowerInvariant())
			{
				case "account":
					attributeName = "name";
					break;
				case "contact":
					attributeName = "lastname";
					break;
				case "lead":
					attributeName = "lastname";
					break;
				case "opportunity":
					attributeName = "name";
					break;
				case "task":
					attributeName = "subject";
					break;
			}

			return attributeName;
		}

		private CRMEntity _entity;
		private string _logicalName;
		private int _entityTypeCode;
		private ME_EntityHelper _entityHelper;
	}
}
