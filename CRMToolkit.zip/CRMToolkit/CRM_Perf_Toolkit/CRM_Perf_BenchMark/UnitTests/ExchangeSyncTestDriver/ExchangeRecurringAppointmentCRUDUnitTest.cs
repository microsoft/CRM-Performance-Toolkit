﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using System;
using System.Diagnostics;
using Entity = Microsoft.Xrm.Sdk.Entity;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting Appointment entity
	/// </summary>
	[TestClass]
	public class ExchangeRecurringAppointmentCRUDUnitTest : CreateBasicExchangeEntityBaseTest
	{
		/// <summary>
		/// Entity used to query EMDB for the entity data
		/// </summary>
		public override string EntityName
		{
			get { return EntityNames.ExchangeAppointment; }
		}

		protected override string DeleteIdentifier
		{
			get { return this.FilterAppendable + " exchange recurring del"; }
		}

		protected override string UpdateIdentifier
		{
			get { return this.FilterAppendable + " exchange recurring update"; }
		}



		/// <summary>
		/// Overide for to print the entity Data
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public override string PrintEntityData(Entity entity)
		{
			return String.Format("attributes are Appointment subject. Subject={0} ", entity["subject"].ToString());
		}

		public override void CreateEntity(string name)
		{
			string contactId;
			string timer = "Exchange Appointment Create Unit Test";
			Entity appointment = CreateRecurringAppointment(name);
			contactId = this.CreateEntityInExchange(appointment, timer);
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntityWithoutId(EntityNames.ExchangeAppointment, g,new string[] {"OwnerId", "ExchangeID", "EntityManagerOwningUser", "Subject"},new string[]{m_user["systemuserid"], contactId, g.ToString(),appointment.Attributes["subject"].ToString()});
		}

		/// <summary>
		/// Test creating an appointment
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create__ExchangeRecurringAppointment()
		{
			Init();
			this.CreateEntity(this.DeleteIdentifier);
		}

		/// <summary>
		/// test retrieving and updating a Appointment
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_ExchangeRecurringAppointment()
		{
			//find a Entity for update test
			string timerName = "Update Exchange Appointment";
			Init("subject", this.UpdateIdentifier,true);
			this.UpdateEntityInExchange(this.EntityName, m_contact, timerName, Utils.GetRandomString(5, 10) +  " " + this.UpdateIdentifier);
		}

		/// <summary>
		/// test deleting an Appointment
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_ExchangeRecurringAppointment()
		{
			//find a Entity for update test
			string timerName = "Update Exchange Appointment";
			if (!Init("subject", this.DeleteIdentifier,true))
			{
				this.DeleteEntityInExchange(this.EntityName, m_contact, timerName);
			}
			else
			{
				Trace.WriteLine(" Couldn't Find Exchange Recurring Appointment to Delete so Created one");
			}
		}


		private Entity CreateRecurringAppointment(string name)
		{
			Entity master = new Entity("recurringappointmentmaster");
			master["subject"] = Utils.GetRandomString(5, 10) + " " + name;
			master["location"] = "New Location";
			master["description"] = "New Description";
			// Only supporting weekly at the moment, 
			master["recurrencepatterntype"] = new OptionSetValue(1); // Picklist(RecurrencePatternType.Weekly);
			DateTime patternStart = DateTime.Now.AddDays(1.0);
			master["patternstartdate"] = patternStart;
			master["patternenddate"] = patternStart.AddHours(1.0);
			master["patternendtype"] = new OptionSetValue(3);
			master["statecode"] = new OptionSetValue(3);// RecurringAppointmentMasterStateInfo();
			master["statuscode"] = new OptionSetValue(-1);
			DateTime now = DateTime.Now.AddHours(1.0);
			master["scheduledstart"] = now;
			master["scheduledend"] = now.AddHours(1.0);
			master["owninguser"] = CreateEntityForSystemUser();

			return master;
		}
	}
}
