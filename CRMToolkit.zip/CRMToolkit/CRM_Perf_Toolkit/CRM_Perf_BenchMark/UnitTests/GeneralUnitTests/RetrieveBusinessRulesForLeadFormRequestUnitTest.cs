﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages.Internal;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class RetrieveBusinessRulesForLeadFormRequestUnitTest : UnitTestBase
	{

		[TestMethod]
		public void UnitTest__RetrieveBusinessRulesForLeadFormRequest()
		{
			//create RetrieveBusinessRulesForFormRequest Request 
			RetrieveBusinessRulesForFormRequest req = new RetrieveBusinessRulesForFormRequest();
			// Retrieve Rules for Lead Entity
			req.EntityTypeCode = 4;
			req.FormId = Guid.NewGuid();

			//execute the request
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("RetrieveBusinessRulesForFormRequest (Lead) Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveBusinessRulesForFormRequest (Lead) Unit Test");

		}


	}
}
