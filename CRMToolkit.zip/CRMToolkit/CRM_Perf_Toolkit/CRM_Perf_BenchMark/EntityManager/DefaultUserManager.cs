﻿using Microsoft.VisualStudio.TestTools.WebTesting;
using System.Net;

namespace CRM_Perf_BenchMark
{
	class DefaultUserManager : IUserManager
	{
		public string RefreshAuthToken(string userName, string password, string orgName, string orgBaseUrl)
		{
			return string.Empty;
		}

		public void RefreshAllAuthTokens(string userStart, string userCount, string userBase, string userDomain, string password, string orgName, string orgBaseUrl)
		{
		}

		public void SetAuthToken(WebTest webTest, string userName, string password, string orgName, string orgBaseUrl, string tokenExpirationTime, string token)
		{
			webTest.UserName = userName;
			webTest.Password = password;
		}

		public void SetAuthToken(HttpWebRequest webRequest, string userName, string password, string orgName, string orgBaseUrl, string tokenExpirationTime, string token)
		{
			webRequest.Credentials = new NetworkCredential(userName, password);
		}
	}
}
