﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Base Class for All CRM Entity Creation
	/// </summary>
	[TestClass]
	public abstract class CreateBasicEntityBaseTest
	{
		#region Protected and Private Members
		protected CRMEntity m_user, m_contact;
		protected string SummaryFile;
		protected IOrganizationService proxy;
		private TestContext m_testContext;
		private CRMEntity[] users;
		private readonly int PARTYCOUNT = 5;
		#endregion

		/// <summary>
		/// Abstract field used to Set the Entity Name
		/// </summary>
		public abstract string EntityName
		{
			get;
		}
		
		/// <summary>
		/// Gets the Cached List of Users from the EMDB
		/// </summary>
		protected CRMEntity[] Users
		{
			get
			{
				if (users == null)
				{
					EntityRequest userRequest = new EntityRequest();
					userRequest.Type = EntityNames.Users;
					userRequest.ParentID = new Guid(m_user[EntityIDNames.Organization]);
					userRequest.ReturnAs = EntityNames.Users;
					users = EntityManager.Instance.GetAllRecordsForEntity(userRequest, PARTYCOUNT);
				}
				return users;
			}
		}

		/// <summary>
		/// CTor for Base Class
		/// </summary>
		public CreateBasicEntityBaseTest()
		{
			string timestamp = System.DateTime.Now.Ticks.ToString();
			StringBuilder summaryFileSB = new StringBuilder();
			summaryFileSB.Append(CWR_Help.resultDir);
			summaryFileSB.Append(String.Format(@"\Perf_Contact_CRUD_Summary_",EntityName));
			summaryFileSB.Append(timestamp);
			summaryFileSB.Append(".log");
			SummaryFile = summaryFileSB.ToString();
		}

		/// <summary>
		/// Init method this should  retrieves data from EMDB
		/// </summary>
		/// <param name="help"></param>
		internal void Init(CWR_Help help)
		{   
			Hashtable Entities = help.getEntities();
			m_contact = (CRMEntity)Entities[EntityName];
			m_user = (CRMEntity)Entities[EntityNames.Users];
			proxy = help.getOrganizationServiceProxy();
		}

		/// <summary>
		/// Init method This should be called before testing
		/// </summary>
		/// <param name="props"></param>
		public void Init(System.Collections.Hashtable props)
		{
			CWR_Help help;
			if (props == null)
			{
				string[] contact_props = { EntityName };
				help = new CWR_Help(contact_props);
			}
			else
			{
				help = new CWR_Help(props);
			}
			Init(help);
		}

		/// <summary>
		/// initialization with sub-properties requirement
		/// for instance, require name contains keyword of 'deleteable'
		/// </summary>
		/// <param name="filterPropertyName"></param>
		/// <param name="filter"></param>
		public virtual void Init(string filterPropertyName = "lastname", string filter =null)
		{
			CWR_Help help;
			System.Collections.Hashtable props = new System.Collections.Hashtable();
			System.Collections.Hashtable sub_props = new System.Collections.Hashtable();
		  
			if (!string.IsNullOrEmpty(filter))
			{
				sub_props.Add(filterPropertyName, filter);
				props.Add(EntityName, sub_props);
				help = new CWR_Help(props);
			}
			else
			{
				string[] contact_props = { EntityName };
				help = new CWR_Help(contact_props);
			}
			Init(help);
		}

		/// <summary>
		/// VS Test Context
		/// </summary>
		public TestContext TestContext
		{
			get { return m_testContext; }
			set { m_testContext = value; }
		}

		/// <summary>
		/// Creates the Entity in CRM 
		/// </summary>
		/// <param name="entity">entity to Create</param>
		/// <param name="timerName">Timer Name</param>
		/// <returns></returns>
		public Guid CreateEntityInCRM(Entity entity, string timerName)
		{
			Guid returnGuid = Guid.Empty;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer(timerName);
					try
			{
				returnGuid = proxy.Create(entity);
			}
				catch (FaultException fe)
				{
					Trace.WriteLine(fe.Message);
					Trace.WriteLine(fe.StackTrace);
					throw;
				}
				catch (SoapException se)
				{
					Trace.WriteLine(se.Detail);
					Trace.WriteLine(se.StackTrace);
					throw;
				}
				TestContext.EndTimer(timerName);
				DateTime end = DateTime.UtcNow;
				TimeSpan duration = (end - start);

				lock (typeof(StreamWriter))
				{
					StreamWriter logWriter = new StreamWriter(SummaryFile);
					logWriter.WriteLine("Logging test result for Creating " + this.EntityName + " test ...");
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine(this.EntityName + " id created in this test is " + returnGuid.ToString());
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine(this.PrintEntityData(entity));
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine("Test started at " + start);
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
					logWriter.WriteLine("-----------------------------------------");
					logWriter.Flush();
					logWriter.Close();
				}
				return returnGuid;
		}

		/// <summary>
		/// Updates the Entity In CRM
		/// </summary>
		/// <param name="entity"></param>
		/// <param name="timerName"></param>
		public void UpdateEntityInCRM(Entity entity, string timerName)
		{
			//update the Phone Call
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer(timerName);
			try
			{
				proxy.Update(entity);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer(timerName);
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Updating " + this.EntityName + " test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the " + this.EntityName + " retrieved in this test is " + entity.Id.ToString());
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine(this.PrintEntityData(entity));
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}            
		}

		/// <summary>
		/// Deletes the Entity In CRM
		/// </summary>
		/// <param name="lookupId"></param>
		/// <param name="entity"></param>
		/// <param name="timerName"></param>
		public void DeleteEntityInCRM(string lookupId,Entity entity, string timerName)
		{
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer(timerName);
			try
			{
				proxy.Delete(entity.LogicalName, new Guid(m_contact[lookupId]));
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer(timerName);
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Deleting contact test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the contact deleted in this test is " + m_contact["contactId"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
			//delete the contact from EMDB
			EntityManager.Instance.DeleteEntity(m_contact);
		}

		/// <summary>
		/// Abstract String that has to be overwriten with the Entity Data that should be printed when a test finishes
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public abstract string PrintEntityData(Entity entity);

		/// <summary>
		/// Creates an EntityList with the current User only
		/// </summary>
		/// <returns></returns>
		internal Entity[] CreateEntityForSystemUser()
		{
			Entity organizer = new Entity("activityparty");
			organizer["partyid"] = new EntityReference("systemuser", new Guid(m_user["systemuserid"]));
			return new Entity[] {organizer};
		}

		/// <summary>
		/// Creates an Entity List with a list of CRM Users
		/// </summary>
		/// <returns></returns>
		protected Entity[] CreateListOfUsers()
		{
			//Get Min size or the two
			int actualPartyCount = Math.Min(PARTYCOUNT, this.Users.Length);
			Entity[] entityArray = new Entity[actualPartyCount];
			
			for (int i = 0; i < actualPartyCount; i++)
			{
				Entity party = new Entity("activityparty");
				party["partyid"] = new EntityReference("systemuser", new Guid(users[i]["systemuserid"]));
				entityArray[i] = party;
			}
			return entityArray;
		}
	}
}
