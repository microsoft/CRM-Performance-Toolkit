namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;

	/// <summary>
	/// All Tests are written from a warm perspective(meaning that each page has been visited recently so that it is not an initial (cold) load)
	/// 1. Start at Marketing homepage
	/// 2. Select Marketing Lists
	/// 3. Click On New List
	/// 4. Enter Data and Click �Save�
	/// 5. Click Add Icon on Members
	/// 6. Select �Use Lookup to add members�
	/// 7. Open Campaign HomePage
	/// 8. Click on New Campaign
	/// 9. Input information and Click �Save�
	/// 10. Click + button of "Marketing List�
	/// 11. Add Marketing List created earlier
	/// 12. Click on + button on top �Campaign Activities� subgrid
	/// 13. Select Channel as �Fax�
	/// 14. Fill data and click �Save�
	/// 15. Click on �Distribute Campaign Activity�
	/// 16. Fill data and click "Distribute"
	/// 17. Refresh Campaign Activity Grid till it changes to complete
	/// 18. Click on Action and Select "Delete Campaign"
	/// </summary>


	public class DeleteCampaignDistributed : WebTestBase
	{

		#region Class constructor
		/// <summary>
		/// Default class constructor
		/// </summary>
		public DeleteCampaignDistributed()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(DeleteCampaignDistributed_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(WebTestBase_PostWebTest);
		}
		#endregion

		#region Pre WebTest
		/// <summary>
		/// Pre WebTest
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void DeleteCampaignDistributed_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			//get test user
			WebTestBase_PreWebTest(sender, e);
			//get test entities owned by the test user
			currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
			GetSecondUser(new Guid(user["organizationid"]));
			listMarketingListView = GridXmlHelper.MarketingListGridForEntityView(-1, listMarketingListViewId, null);
			account = RetrieveTestEntity(user, EntityNames.Accounts);
		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction("CreateNewLists");

			this.BeginTransaction(string.Format("{0}HomePageNavigation", entityName));
			CrmRequest homePage = HomePageNavigation(entityName, siteMapPath);
			yield return homePage;
			this.EndTransaction(string.Format("{0}HomePageNavigation", entityName));

			string referer = homePage.lastResponse.ResponseUri.ToString();

			this.BeginTransaction(string.Format("Create{0}", entityName));
			main_aspx mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[entityName],
				extraqs = "etc=" + WebTestHelp.EntityEtc[entityName],
				pagetype = "entityrecord",
				pagemode = "iframe",

			};
			yield return mainPage;

			//create new entity
			referer = mainPage.lastResponse.ResponseUri.ToString();

			InlineEditHelper inlineEdit = new InlineEditHelper(commandXml, user);
			CrmRequest createEntity = inlineEdit.getInlineEditWTR(referer, 1) as CrmRequest;
			createEntity.ValidateResponse += this.NewEntity_ValidateResponse;
			yield return createEntity;

			foreach (string gridXml in gridXmls)
			{
				yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(gridXml), referer);
			}

			Ribbon.RibbonWebService ribbon = new Ribbon.RibbonWebService();
			CrmRequest wtr = null;
			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(WebTestHelp.RefreshGridXmls[EntityViewNames.MyActiveMarketingList]), referer);

			yield return (wtr);

			this.EndTransaction(string.Format("Create{0}", entityName));

			this.EndTransaction("CreateNewLists");

			this.BeginTransaction("AddMembersToList");

			MA_lists_ListQualificationDlg_dlg_manage_members_aspx listQualifications = new MA_lists_ListQualificationDlg_dlg_manage_members_aspx(user);
			yield return (listQualifications);

			MarketingAutomation.MarketingAutomationWebService mws = new MarketingAutomation.MarketingAutomationWebService();
			try
			{
				mws.RetrieveList(new Guid(newEntityId), new string[] { " " });
			}
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}

			_controls_lookup_lookupinfo_aspx lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo.objecttypes = "1";
			lookupInfo.browse = 0;
			lookupInfo.LookupStyle = "multi";
			yield return (lookupInfo);

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(processListMemeberGridXml(WebTestHelp.RefreshGridXmls[EntityViewNames.AccountListMembers])), referer);

			_grid_cmds_dlg_addtolist_aspx addlist = new _grid_cmds_dlg_addtolist_aspx(user);
			addlist.itemObjectId = new Guid(newEntityId);
			addlist.iObjType = 1;
			addlist.iTotal = 1;
			addlist.autoTrigger = 1;

			yield return addlist;

			_grid_cmds_dlg_addtolist_aspx addtoList = new _grid_cmds_dlg_addtolist_aspx(user);
			addtoList.iId = new Guid(account[EntityIDNames.Account]);
			addtoList.iObjType = 1;
			addtoList.iTotal = 1;
			addtoList.itemObjectId = new Guid(newEntityId);
			yield return addtoList;

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(processListMemeberGridXml(WebTestHelp.RefreshGridXmls[EntityViewNames.AccountListMembers])), referer);

			this.EndTransaction("AddMembersToList");

			this.BeginTransaction("CreateCampaign");

			this.BeginTransaction(string.Format("{0}HomepageNavigation", EntityNames.Campaigns));
			yield return HomePageNavigation(EntityNames.Campaigns, siteMapPath);
			this.EndTransaction(string.Format("{0}HomepageNavigation", EntityNames.Campaigns));

			mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[EntityNames.Campaigns],
				extraqs = "etc=" + WebTestHelp.EntityEtc[EntityNames.Campaigns],
				pagetype = "entityrecord",
				pagemode = "iframe",

			};
			yield return mainPage;

			referer = mainPage.lastResponse.ResponseUri.ToString();

			inlineEdit = new InlineEditHelper(campaigncommandXml, user);
			createEntity = inlineEdit.getInlineEditWTR(referer, 1) as CrmRequest;
			createEntity.ValidateResponse += this.NewCampaignEntity_ValidateResponse;
			yield return createEntity;

			ribbon = new Ribbon.RibbonWebService();
			try { ribbon.ReloadCommandBar(EntityNames.Campaigns.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtr);

			foreach (string gridXml in campaigngridXmls)
			{
				yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(gridXml), referer);
			}

			this.EndTransaction("CreateCampaign");

			//open an entity
			this.BeginTransaction(string.Format("Open{0}", EntityNames.Campaigns));
			CrmRequest openEntity = OpenEntity(EntityNames.Campaigns, WebTestHelp.EntityEtc[EntityNames.Campaigns], WebTestHelp.EntityEtc[EntityNames.Campaigns], new Guid(campaignentityId));
			yield return openEntity;
			this.EndTransaction(string.Format("Open{0}", EntityNames.Campaigns));

			this.BeginTransaction("AddListToCampaign");

			userdefined_areas_aspx udap = new userdefined_areas_aspx(user);
			udap.oId = new Guid(campaignentityId);
			udap.oType = 4400;
			udap.security = 852023;
			udap.tabSet = "areaTargetLists";
			udap.pagemode = "iframe";

			lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo.Class = "";
			lookupInfo.objecttypes = "4300";
			lookupInfo.browse = 0;
			lookupInfo.LookupStyle = "multi";
			yield return (lookupInfo);

			ActivitiesWebService.ActivitiesWebService actws = new ActivitiesWebService.ActivitiesWebService();
			wtr = null;
			try { actws.GetQueryListForLookup("4300", 0); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtr);

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignMarketingLists]), referer);

			_grid_cmds_dlg_listcaassociation_aspx lassoc = new _grid_cmds_dlg_listcaassociation_aspx(user);
			lassoc.iObjType = 4300;
			yield return (lassoc);

			AssociateRecords.AssociateRecords ar = new AssociateRecords.AssociateRecords();
			WebTestRequest wtrRefresh = null;
			try { ar.Associate(4300, 4400, new Guid(newEntityId), new Guid(campaignentityId), "targetListsaddtoCA", "campaignlist_association"); }
			catch (crmException x)
			{
				wtrRefresh = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtrRefresh);

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignMarketingLists]), referer);

			this.EndTransaction("AddListToCampaign");

			this.BeginTransaction("CreateCampaignActivity");

			mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[EntityNames.CampaignActivities],
				extraqs = string.Format("?_CreateFromId=%7b{0}%7d&_CreateFromType={1}&etc={2}", newEntityId, WebTestHelp.EntityEtc[entityName].ToString(), WebTestHelp.EntityEtc[EntityNames.CampaignActivities].ToString()),
				pagetype = "entityrecord",
			};
			yield return mainPage;

			string modifiedQueryXml = null;
			if (queryXml.Contains("SYSTEM_USERID"))
			{
				modifiedQueryXml = queryXml.Replace("SYSTEM_USERID", user[EntityIDNames.User]);
			}
			yield return RetrieveMultiple(modifiedQueryXml);

			this.BeginTransaction(string.Format("CreateAssosiatedEntity{0}", EntityNames.CampaignActivities));
			InlineEditHelper inlineEditHelper = new InlineEditHelper(AssosiatedEntityCommandXml, user);
			CrmRequest createAssosiateEntity = inlineEditHelper.getInlineEditWTR(referer, 1) as CrmRequest;
			createAssosiateEntity.ValidateResponse += this.NewCampaignActivityEntity_ValidateResponse;
			yield return createAssosiateEntity;
			this.EndTransaction(string.Format("CreateAssosiatedEntity{0}", EntityNames.CampaignActivities));

			try { ribbon.ReloadCommandBar(EntityNames.Campaigns.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtr);

			this.EndTransaction("CreateCampaignActivity");

			this.BeginTransaction("PropogateCampaignActivity");

			MarketingAutomation.MarketingAutomationWebService maws = new MarketingAutomation.MarketingAutomationWebService();
			try { maws.GetTargetListAssociated(new Guid(campaignentityId)); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtr);

			_grid_cmds_dlg_listfax_aspx listFax = new _grid_cmds_dlg_listfax_aspx(user);
			listFax.iObjType = 4402;
			listFax.iTotal = 1;
			listFax.sIds = new Guid(campaignActivityentityId).ToString("B");
			yield return (listFax);

			referer = listFax.lastResponse.ResponseUri.AbsoluteUri;

			MA_CampaignActivity_Dialogs_confirm_propagation_aspx propConfirm = new MA_CampaignActivity_Dialogs_confirm_propagation_aspx(user);
			propConfirm.EntityTypeCode = 4204;
			yield return (propConfirm);

			listFax = new _grid_cmds_dlg_listfax_aspx(user);
			listFax.iObjType = 4402;
			listFax.iTotal = 1;
			listFax.iIndex = 0;
			listFax.SendEmail = false;
			listFax.ownerType = 8;
			listFax.OwnerOption = 3;
			listFax.iId = new Guid(campaignActivityentityId);

			StringHttpBody httpBody = new StringHttpBody();
			string faxXml = "<fax><directioncode>1</directioncode><subject>" + Utils.GetRandomString(10, 15) + "</subject><description>" + Utils.GetRandomString(100, 120) + "</description><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode></fax>";
			httpBody.BodyString = faxXml;
			httpBody.ContentType = "text/xml";
			listFax.Body = httpBody;

			rpcInfo = Utils.GenerateWRPCToken();

			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCTokenTimeStamp";
			headerItem.Value = rpcInfo.timeStamp.ToString();
			listFax.Headers.Add(headerItem);
			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCToken";
			headerItem.Value = rpcInfo.token;
			listFax.Headers.Add(headerItem);
			listFax.Method = "Post";
			yield return (listFax);

			this.EndTransaction("PropogateCampaignActivity");

			this.BeginTransaction("DeleteCampaign");

			_grid_cmds_dlg_delete_aspx delCamp = new _grid_cmds_dlg_delete_aspx(user);
			delCamp.iObjType = 4400;
			delCamp.iTotal = 1;
			delCamp.sIds = campaignentityId;
			yield return (delCamp);

			delCamp = new _grid_cmds_dlg_delete_aspx(user);
			delCamp.iObjType = 4400;
			delCamp.iTotal = 1;
			delCamp.iIndex = 0;
			delCamp.sSubTypes = null;
			delCamp.iId = campaignentityId;

			httpBody = new StringHttpBody();
			httpBody.BodyString = "<node />";
			httpBody.ContentType = "text/xml";
			delCamp.Body = httpBody;

			rpcInfo = Utils.GenerateWRPCToken();

			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCTokenTimeStamp";
			headerItem.Value = rpcInfo.timeStamp.ToString();
			delCamp.Headers.Add(headerItem);
			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCToken";
			headerItem.Value = rpcInfo.token;
			delCamp.Headers.Add(headerItem);
			delCamp.Method = "Post";
			yield return (delCamp);

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(WebTestHelp.RefreshGridXmls[EntityViewNames.MyCampaigns]), referer);

			this.EndTransaction("DeleteCampaign");
		}

		#endregion

		protected override string entityName
		{
			get
			{
				return EntityNames.Lists;
			}
		}
		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.MarketingSiteMapPath[EntityNames.Lists];
			}
		}

		//command xml needed for entity creation operation
		protected string commandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, entityName.ToLower(), "6e77626b-e693-44f0-a1c7-359b1a7a9a4c");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateListXml(new Guid(user["systemuserid"]), 8, currency);
				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}

		protected string AssosiatedEntityCommandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, EntityNames.CampaignActivities.ToLower(), "30b5a041-afe1-4ced-91c5-86c7554df10c");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				if (newEntityId != null)
				{
					string dataXml = EntityXmlHelper.GetCreateCampaignActivityXml(new Guid(user[EntityIDNames.User]), 8, new Guid(campaignentityId), 4400, 5);
					//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
					dataXml = dataXml.Replace("<", "&#60;");
					dataXml = dataXml.Replace(">", "&#62;");
					dataXml = dataXml.Replace("</", "&#60;&#47;");
					dataXml = dataXml.Replace("=", "&#61;");
					dataXml = dataXml.Replace("\"", "&#34;");
					sb.Append(dataXml);
					sb.Append(commandXml_post);


				}
				return sb.ToString(); ;
			}
		}

		protected string campaigncommandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, EntityNames.Campaigns.ToLower(), formId);
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateCampaignXml(new Guid(user[EntityIDNames.User]), 8);
				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}
		protected string formId
		{
			get
			{
				return "6356ff2a-bbbe-49fb-9da2-160b08865688";
			}
		}

		protected string[] gridXmls
		{
			get
			{
				return new string[5]
				{
					processListMemeberGridXml(WebTestHelp.RefreshGridXmls[EntityViewNames.LeadListMembers]),
					WebTestHelp.RefreshGridXmls[EntityViewNames.ListCampaigns],
					WebTestHelp.RefreshGridXmls[EntityViewNames.MyQuickCampaigns],
					processListMemeberGridXml(WebTestHelp.RefreshGridXmls[EntityViewNames.AccountListMembers]),
					processListMemeberGridXml(WebTestHelp.RefreshGridXmls[EntityViewNames.ContactListMembers]),
				};

			}
		}

		private string processListMemeberGridXml(string xmlfile)
		{
			string marker = "oId&gt;&amp;#123;";
			int startIndex = xmlfile.IndexOf(marker);
			startIndex += marker.Length;
			xmlfile = xmlfile.Remove(startIndex, 36);
			xmlfile = xmlfile.Insert(startIndex, newEntityId);
			return xmlfile;
		}


		protected string[] campaigngridXmls
		{
			get
			{
				return new string[4]
				{
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignActivities],
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignLeads],
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignResponses] ,
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignMarketingLists]
				};

			}
		}
		protected string queryXml
		{
			get
			{
				return WebTestHelp.QueryXmls["SystemUserQuery"];
			}
		}


		#region Validate Repsonse
		/// <summary>
		/// Validate response
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">ValidationEvent</param>
		private void NewEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			newEntityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				newEntityId = new Guid(newEntityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}

		private void NewCampaignEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			campaignentityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				campaignentityId = new Guid(campaignentityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}

		private void NewCampaignActivityEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			campaignActivityentityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				campaignActivityentityId = new Guid(campaignActivityentityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}
		#endregion
		private CRMEntity currency, account;
		protected string newEntityId, campaignentityId, campaignActivityentityId;
		protected readonly string newIdMarker = "\"Id\":\"{";
		private static string listMarketingListViewId = "F500D0FA-A21E-47FB-B0C6-7BE373175895";
		private string listMarketingListView;
	}
}