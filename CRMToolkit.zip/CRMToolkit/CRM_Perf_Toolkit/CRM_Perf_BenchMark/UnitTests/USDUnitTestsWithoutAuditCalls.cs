﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using System.Reflection;
using System.Data.SqlClient;
using System.Data;

namespace CRM_Perf_BenchMark.UnitTests
{

	[TestClass]
	public class USDUnitTestsWithoutAuditCalls : UnitTestBase
	{
		private string uii_hostedapplicationid_AgentScripting;
		private string uii_hostedapplicationid_NotesManager;
		private string uii_hostedapplicationid_CustomPanel;
		private string uii_hostedapplicationid_Dashboard;
		private string uii_hostedapplicationid_Contact;
		private string uii_hostedapplicationid_Notes;
		private string uii_hostedapplicationid_Incident;
		private string uii_hostedapplicationid_Bing;
		private string uii_hostedapplicationid_Email;
		private string uii_hostedapplicationid_Search;
		private Guid phonecallId;
		private CRMEntity m_contact;
		private CRMEntity m_incidents;

		[TestInitialize]
		public void testInitialize()
		{

			phonecallId = Guid.Empty;
			m_contact = RetrieveTestEntity(m_user, EntityNames.Contacts);
			m_incidents = RetrieveTestEntity(m_user, EntityNames.Incidents);

			Hashtable table = GetUiiHostedApplicationId("Agent Scripting");
			CRMEntity table1 = (CRMEntity)table["UII_hostedapplicationid"];
			uii_hostedapplicationid_AgentScripting = table1["uii_hostedapplicationid"].ToString();

			Hashtable table2 = GetUiiHostedApplicationId("NotesManager");
			CRMEntity table3 = (CRMEntity)table2["UII_hostedapplicationid"];
			uii_hostedapplicationid_NotesManager = table3["uii_hostedapplicationid"].ToString();

			Hashtable table4 = GetUiiHostedApplicationId("Custom Panel");
			CRMEntity table5 = (CRMEntity)table4["UII_hostedapplicationid"];
			uii_hostedapplicationid_CustomPanel = table5["uii_hostedapplicationid"].ToString();

			Hashtable table6 = GetUiiHostedApplicationId("Dashboard");
			CRMEntity table7 = (CRMEntity)table6["UII_hostedapplicationid"];
			uii_hostedapplicationid_Dashboard = table7["uii_hostedapplicationid"].ToString();

			Hashtable table8 = GetUiiHostedApplicationId("Contact");
			CRMEntity table9 = (CRMEntity)table8["UII_hostedapplicationid"];
			uii_hostedapplicationid_Contact = table9["uii_hostedapplicationid"].ToString();

			Hashtable table10 = GetUiiHostedApplicationId("Notes");
			CRMEntity table11 = (CRMEntity)table10["UII_hostedapplicationid"];
			uii_hostedapplicationid_Notes = table11["uii_hostedapplicationid"].ToString();

			Hashtable table18 = GetUiiHostedApplicationId("Incident");
			CRMEntity table19 = (CRMEntity)table18["UII_hostedapplicationid"];
			uii_hostedapplicationid_Incident = table19["uii_hostedapplicationid"].ToString();

			Hashtable table12 = GetUiiHostedApplicationId("Bing");
			CRMEntity table13 = (CRMEntity)table12["UII_hostedapplicationid"];
			uii_hostedapplicationid_Bing = table13["uii_hostedapplicationid"].ToString();

			Hashtable table14 = GetUiiHostedApplicationId("Email");
			CRMEntity table15 = (CRMEntity)table14["UII_hostedapplicationid"];
			uii_hostedapplicationid_Email = table15["uii_hostedapplicationid"].ToString();

			Hashtable table16 = GetUiiHostedApplicationId("Search");
			CRMEntity table17 = (CRMEntity)table16["UII_hostedapplicationid"];
			uii_hostedapplicationid_Search = table17["uii_hostedapplicationid"].ToString();
		}



		[TestMethod()]
		public void UnitTest__ActivityCreationAndSolutionSearch_WithoutAuditCalls()
		{
			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("RetrieveMultipleRequest1");
			string query1 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest1");

			TestContext.BeginTimer("RetrieveMultipleRequest2");
			string query2 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest2");

			TestContext.BeginTimer("RetrieveAllEntitiesRequest");
			organizationRequests.RetrieveAllEntitiesRequestRequest(Proxy);
			TestContext.EndTimer("RetrieveAllEntitiesRequest");
			//Check 

			TestContext.BeginTimer("RetrieveMultipleRequest3");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest3");

			TestContext.BeginTimer("InstantiateTemplateRequest1");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest1");

			TestContext.BeginTimer("RetrieveMultipleRequest4");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest4");

			TestContext.BeginTimer("InstantiateTemplateRequest2");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest2");

			//CloseCall step
			TestContext.BeginTimer("CloseCallStep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			TestContext.EndTimer("CloseCallStep");

			TestContext.BeginTimer("RetrieveEntityRequest");
			organizationRequests.RetrieveEntityRequest(Proxy);
			TestContext.EndTimer("RetrieveEntityRequest");
		}

		[TestMethod()]
		public void UnitTest__CaseCreationAndSolutionSearch_WithoutAuditCalls()
		{

			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("RetrieveMultipleRequest1");
			string query1 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest1");

			TestContext.BeginTimer("RetrieveMultipleRequest2");
			string query2 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			string query3 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query3, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest2");

			int resolved = Convert.ToInt32(m_incidents["statecode"]);

			TestContext.BeginTimer("UpdateIncidentRequest");
			if (resolved != 1)
			{
				organizationRequests.UpdateIncident(m_incidents, Proxy);
			}
			TestContext.EndTimer("UpdateIncidentRequest");

			TestContext.BeginTimer("RetrieveMultipleRequest3");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest3");

			TestContext.BeginTimer("InstantiateTemplateRequest1");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest1");

			TestContext.BeginTimer("RetrieveMultipleRequest4");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest4");

			TestContext.BeginTimer("InstantiateTemplateRequest2");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest2");

			//ResolveCaseStep

			TestContext.BeginTimer("UpdateIncidentRequest2");
			if (resolved != 1)
			{
				organizationRequests.UpdateIncidentForResolution(m_incidents, Proxy);
			}
			TestContext.EndTimer("UpdateIncidentRequest2");

			TestContext.BeginTimer("ResolveCaseStep");
			if (resolved != 1)
			{
				organizationRequests.CloseIncident(m_incidents, Proxy);
			}
			TestContext.EndTimer("ResolveCaseStep");
			string query4 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query4, Proxy);


			//CloseCall step
			TestContext.BeginTimer("CloseCallStep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			TestContext.EndTimer("CloseCallStep");
		}

		[TestMethod()]
		public void UnitTest__NewCustomerRecord_WithoutAuditCalls()
		{

			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("MultipleRequest1");
			string query1 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("MultipleRequest1");

			TestContext.BeginTimer("RetriveMultiple1");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetriveMultiple1");

			TestContext.BeginTimer("InstantiateTemplateRequest1");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest1");

			TestContext.BeginTimer("RetriveMultiple2");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetriveMultiple2");

			TestContext.BeginTimer("InstantiateTemplateRequest2");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest2");

			//Close Call Step
			TestContext.BeginTimer("ClosecallStep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			TestContext.EndTimer("ClosecallStep");

			TestContext.BeginTimer("MultipleRequest2");
			string query2 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("MultipleRequest2");
		}

		[TestMethod()]
		public void UnitTest__CustomerPhoneNumebrNotPresent_WithoutAuditCalls()
		{

			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("MultipleRequest1");
			string query1 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("MultipleRequest1");

			TestContext.BeginTimer("MultipleRequest2");
			string query2 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("MultipleRequest2");

			TestContext.BeginTimer("RetriveAllEntitiesRequest1");
			organizationRequests.RetrieveAllEntitiesRequestRequest(Proxy);
			TestContext.EndTimer("RetriveAllEntitiesRequest1");

			TestContext.BeginTimer("RetriveMultiple1");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetriveMultiple1");

			TestContext.BeginTimer("InstantiateTemplateRequest1");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest1");

			TestContext.BeginTimer("RetriveMultiple2");
			organizationRequests.RetrieveMultiple(Proxy);
			TestContext.EndTimer("RetriveMultiple2");

			TestContext.BeginTimer("InstantiateTemplateRequest2");
			organizationRequests.InstantiateTemplateRequest(new Guid("a1740b9c-9073-e311-87f2-00155dd8d60b"), new Guid(m_user["systemuserid"]), "systemuser", Proxy);
			TestContext.EndTimer("InstantiateTemplateRequest2");

			//Close Call Step
			TestContext.BeginTimer("Closecallstep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			TestContext.EndTimer("Closecallstep");

			TestContext.BeginTimer("MultipleRequest3");
			string query3 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query3, Proxy);
			TestContext.EndTimer("MultipleRequest3");
		}

		[TestMethod()]
		public void UnitTest__CaseCreationAndAssignment_WithoutAuditCalls()
		{

			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("MultipleRequest1");
			string query1 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("MultipleRequest1");

			TestContext.BeginTimer("MultipleRequest2");
			string query2 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("MultipleRequest2");

			TestContext.BeginTimer("MultipleRequest3");
			string query3 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query3, Proxy);
			TestContext.EndTimer("MultipleRequest3");

			TestContext.BeginTimer("MultipleRequest4");
			string query4 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query4, Proxy);
			TestContext.EndTimer("MultipleRequest4");
		}

		[TestMethod()]
		public void UnitTest__ActivityUpdateOnly_WithoutAuditCalls()
		{
			OrionUnitTests.USDOrganizationRequests organizationRequests = new OrionUnitTests.USDOrganizationRequests();

			TestContext.BeginTimer("RetrieveMultipleRequest1");
			string query1 = "<fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"contact\"><attribute name=\"fullname\" /><attribute name=\"telephone1\" /><attribute name=\"contactid\" /><attribute name=\"emailaddress1\" /><attribute name=\"address1_postalcode\" /><attribute name=\"address1_stateorprovince\" /><attribute name=\"address1_city\" /><attribute name=\"address1_composite\" /><attribute name=\"msdyusd_facebook\" /><attribute name=\"msdyusd_twitter\" /><order attribute=\"fullname\" descending=\"false\" /><filter type=\"and\"><condition attribute=\"contactid\" operator=\"eq\" uitype=\"contact\" value=\"{A2766B8E-0213-E411-81CF-00155DED1914}\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query1, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest1");

			//Close call
			TestContext.BeginTimer("CloseCallStep");
			organizationRequests.CreateAndSetStateOfPhoneCallActivity(m_user, phonecallId, m_contact["ContactId"], "Call with" + m_contact["LastName"], m_user["systemuserid"], m_contact["ContactId"], Utils.GetRandomString(5, 30), Proxy);
			TestContext.EndTimer("CloseCallStep");

			TestContext.BeginTimer("RetrieveMultipleRequest2");
			string query2 = "<fetch distinct=\"false\" mapping=\"logical\"><entity name=\"incident\"><attribute name=\"actualserviceunits\" /><attribute name=\"billedserviceunits\" /><attribute name=\"customersatisfactioncode\" /><filter type=\"and\"><condition attribute=\"statecode\" operator=\"eq\" value=\"1\" /><condition attribute=\"modifiedby\" operator=\"eq-userid\" /></filter></entity></fetch>";
			organizationRequests.RetrieveMultipleRequest(query2, Proxy);
			TestContext.EndTimer("RetrieveMultipleRequest2");
		}

		private Hashtable GetUiiHostedApplicationId(string uii_name)
		{

			CRMEntity FoundEntity = null;
			Hashtable RetEntities = new Hashtable();

			SqlConnection SqlCon = new SqlConnection(ConfigSettings.Default.EMSQLCNN);

			try
			{
				SqlCon.Open();
				//Build the SQL for the current request
				SqlTransaction tran = SqlCon.BeginTransaction(System.Data.IsolationLevel.Serializable);

				SqlCommand cmd = new SqlCommand();
				cmd.Transaction = tran;
				cmd.Connection = SqlCon;
				cmd.CommandText = ("SELECT top 1 UII_hostedapplicationid  FROM UII_hostedapplication where UII_Name = @UII_name");
				cmd.Parameters.AddWithValue("UII_name", uii_name);
				SqlDataReader reader = cmd.ExecuteReader();

				DataTable table = new DataTable();
				table.Load(reader);
				int numberOfRows = table.Rows.Count;

				if (numberOfRows <= 0)
				{
					throw new EntityNotFoundException("No rows found");
				}

				cmd.Parameters.Clear();
				tran.Dispose();
				reader.Close();
				cmd.Connection.Dispose();
				FoundEntity = new CRMEntity(table, 0, "UII_hostedapplicationid");
				RetEntities.Add("UII_hostedapplicationid", FoundEntity);
			}
			finally
			{
				SqlCon.Close();
			}
			return RetEntities;
		}
	}
}