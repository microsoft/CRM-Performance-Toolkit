#!/usr/bin/perl

use strict;
use warnings;
use File::Copy;

my $find1 = "Global";
my $find2 = "{6BD71CCC-5CCB-4F64-AB14-6B86ECE1F1A2}.Release|x86.ActiveCfg = Release|Any CPU";
my $find2_regex = "\\\{6BD71CCC-5CCB-4F64-AB14-6B86ECE1F1A2\\\}\\\.Release\\\|x86\\\.ActiveCfg = Release\\\|Any CPU";

my $replacement1 = "Project(\"{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}\") = \"CRMOnline\", \"CRMOnline\\CRMOnline.csproj\", \"{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}\" \nEndProject \n$find1";
my $replacement2 = "$find2 \n 		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2013SP1|Any CPU.ActiveCfg = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2013SP1|Any CPU.Build.0 = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2013SP1|Mixed Platforms.ActiveCfg = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2013SP1|Mixed Platforms.Build.0 = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2013SP1|x86.ActiveCfg = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015|Any CPU.ActiveCfg = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015|Any CPU.Build.0 = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015|Mixed Platforms.ActiveCfg = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015|Mixed Platforms.Build.0 = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015|x86.ActiveCfg = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015SP1|Any CPU.ActiveCfg = Release|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015SP1|Any CPU.Build.0 = Release|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015SP1|Mixed Platforms.ActiveCfg = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015SP1|Mixed Platforms.Build.0 = Debug|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.CRM2015SP1|x86.ActiveCfg = Release|Any CPU
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Debug|Any CPU.ActiveCfg = Debug|Any CPU 
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Debug|Any CPU.Build.0 = Debug|Any CPU 
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Debug|Mixed Platforms.ActiveCfg = Debug|Any CPU 
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Debug|Mixed Platforms.Build.0 = Debug|Any CPU 
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Debug|x86.ActiveCfg = Debug|Any CPU 
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Release|Any CPU.ActiveCfg = Release|Any CPU 
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Release|Any CPU.Build.0 = Release|Any CPU 
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Release|Mixed Platforms.ActiveCfg = Release|Any CPU 
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Release|Mixed Platforms.Build.0 = Release|Any CPU 
		{D3F42650-ED49-4EB8-9ADF-F57363E8F57B}.Release|x86.ActiveCfg = Release|Any CPU ";

my $internalSlnFile = $ARGV[1];
open FILE, "$ARGV[0]" or die $!;

if (! -e "temp.sln") {
	open FILE1, ">temp.sln" or die $!;
	while (<FILE>) {
	   s/^$find1$/$replacement1/g; 
	   s/$find2_regex/$replacement2/g;
	   print FILE1 "$_";
	}
	
	unlink "$internalSlnFile" if -e "$internalSlnFile";
	close FILE;
	close FILE1;
	move("temp.sln", "$internalSlnFile");
}
