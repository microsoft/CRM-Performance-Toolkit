﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	//test RetrieveAttributeRequest
	[TestClass]
	public class RetrieveAttributeRequestUnitTest : UnitTestBase
	{
		#region Retrieve attribute request
		/// <summary>
		/// Test retrieving attribute request
		/// </summary>
		[TestMethod]
		public void UnitTest__RetrieveAttributeRequest()
		{
			//create RetrieveAttributeRequest
			Microsoft.Xrm.Sdk.Messages.RetrieveAttributeRequest req = new Microsoft.Xrm.Sdk.Messages.RetrieveAttributeRequest();
			req.EntityLogicalName = EntityNames.Accounts.ToLower();
			req.LogicalName = "address1_city";
			req.RetrieveAsIfPublished = true;
			//execute the request
			TestContext.BeginTimer("RetrieveAttributeRequest Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveAttributeRequest Unit Test");
		}
		#endregion
	}
}
