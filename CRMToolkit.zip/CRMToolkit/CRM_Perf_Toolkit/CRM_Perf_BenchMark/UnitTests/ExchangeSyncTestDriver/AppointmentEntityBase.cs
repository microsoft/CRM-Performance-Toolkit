﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using System.Collections;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Base Class for Creating updating and Deleting CRM Appointments
	/// </summary>    
	public abstract class AppointmentEntityBase: CreateBasicEntityBaseTest
	{
		public abstract int InstanceTypeCode
		{
			get;
		}

		/// <summary>
		/// Builds a Basic Appointment Entity
		/// </summary>
		/// <returns></returns>
		public Entity BuildBasicEntity(string subjectAppendValue)
		{
			Entity appointment = new Entity(EntityName.ToLower());
			appointment["subject"] = Utils.GetRandomString(5, 10) + subjectAppendValue;
			appointment["location"] = Utils.GetRandomString(50, 100);
			//Todo don't like using date time now 
			DateTime now = DateTime.Now;
			appointment["scheduledstart"] = now;
			int increment = Utils.GetRandomInt(1, 5);
			appointment["scheduledend"] = now.AddHours(increment);
			appointment["scheduleddurationminutes"] = increment * 60;
			appointment["isalldayevent"] = false;
			appointment["owninguser"] = CreateEntityForSystemUser();
			return appointment;
		}
		
		/// <summary>
		/// Creates the Properties for Getting entity from EMDB
		/// </summary>
		/// <param name="subjectName"></param>
		/// <returns></returns>
		protected Hashtable CreateProperties(string subjectName)
		{
			System.Collections.Hashtable props = new System.Collections.Hashtable();
			System.Collections.Hashtable sub_props = new System.Collections.Hashtable();

			sub_props.Add("subject", subjectName);            
			sub_props.Add("InstanceTypeCode", InstanceTypeCode);
			props.Add(EntityName, sub_props);
			return props;
		}

	}
}
