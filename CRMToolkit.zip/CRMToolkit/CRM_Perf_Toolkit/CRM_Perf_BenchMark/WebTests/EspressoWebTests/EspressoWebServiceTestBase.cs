﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM_Perf_BenchMark;
using Microsoft.VisualStudio.TestTools.WebTesting;
using MobileExpressWebServiceBase = MobileExpressWebService.MobileExpressWebService;
using System.Web.Script.Serialization;

namespace CRM_Perf_Benchmark
{
	public class MobileExpressWebService : MobileExpressWebServiceBase
	{
		public string AddAttachment(string parentEntityId, int parentEntityOtc, string fileName, string base64EncodedContents, string mimeType)
		{
			var palDataFileDictionary = new Dictionary<string, object>
				{
					{"FileName",fileName},
					{"IsDocument",true},
					{"FileContents",base64EncodedContents},
					{"MimeType",mimeType}
				};

			var commandDictionary = new Dictionary<string, object>();
			commandDictionary[Action] = "AddAttachment";
			commandDictionary[ClientVersion] = "1.0";
			commandDictionary[IsNew] = true;
			commandDictionary[ObjectId] = "";
			commandDictionary[ObjectTypeCode] = 5; //Annotation otc
			commandDictionary[ParentId] = parentEntityId;
			commandDictionary[ParentType] = parentEntityOtc;
			commandDictionary[PalDataFile] = palDataFileDictionary;

			var commandJson = new JavaScriptSerializer().Serialize(commandDictionary);
			return this.Execute(commandJson);
		}

		public string MarkActivityAsComplete(string recordId, int recordOtc)
		{
			var commandDictionary = new Dictionary<string, object>();
			commandDictionary[Action] = "MarkAsComplete";
			commandDictionary[ClientVersion] = "1.0";
			commandDictionary[IsNew] = false;
			commandDictionary[ObjectId] = recordId;
			commandDictionary[ObjectTypeCode] = recordOtc;
			var commandJson = new JavaScriptSerializer().Serialize(commandDictionary);
			return this.Execute(commandJson);
		}

		public string DeleteRecord(string recordId, int recordOtc)
		{
			var commandDictionary = new Dictionary<string, object>();
			commandDictionary[Action] = "Delete";
			commandDictionary[ClientVersion] = "1.0";
			commandDictionary[IsNew] = false;
			commandDictionary[ObjectId] = recordId;
			commandDictionary[ObjectTypeCode] = recordOtc;
			var commandJson = new JavaScriptSerializer().Serialize(commandDictionary);
			return this.Execute(commandJson);
		}

		public string SaveNote(string noteSubject, string noteText, string parentId, string parentType, string noteId)
		{
			bool isNew = String.IsNullOrEmpty(noteId);
			var commandDictionary = new Dictionary<string, object>();
			commandDictionary[Action] = "SaveNote";
			commandDictionary[ClientVersion] = "1.0";
			commandDictionary[IsNew] = isNew;
			commandDictionary[ObjectId] = isNew ? "" : noteId;
			commandDictionary[ObjectTypeCode] = 5;
			commandDictionary[Subject] = noteSubject;
			commandDictionary[NoteText] = noteText;
			commandDictionary[ParentId] = parentId;
			commandDictionary[ParentType] = parentType;

			var commandJson = new JavaScriptSerializer().Serialize(commandDictionary);
			return this.Execute(commandJson);
		}

		public string GetRelatedEntities(int objectTypeCode)
		{
			var commandDictionary = new Dictionary<string, object>();
			commandDictionary[Action] = "GETRELATEDENTITIES";
			commandDictionary[ClientVersion] = "1.0";
			commandDictionary[ObjectTypeCode] = objectTypeCode;

			var commandJson = new JavaScriptSerializer().Serialize(commandDictionary);
			return this.Execute(commandJson);
		}

		public string GetRelatedEntityRecords(int objectTypeCode, string objectId, string relationshipId)
		{
			var commandDictionary = new Dictionary<string, object>();
			commandDictionary[Action] = "GETRELATEDENTITYRECORDS";
			commandDictionary[ClientVersion] = "1.0";
			commandDictionary[ObjectId] = objectId;
			commandDictionary[ObjectTypeCode] = objectTypeCode;
			commandDictionary[RelationshipId] = relationshipId;

			var commandJson = new JavaScriptSerializer().Serialize(commandDictionary);
			return this.Execute(commandJson);
		}

		public string GetDefaultCommandBarDefinitions()
		{
			var commandDictionary = new Dictionary<string, object>();
			commandDictionary[Action] = "GETDEFAULTCOMMANDBARDEFINITIONS";
			commandDictionary[ClientVersion] = "1.0";

			var commandJson = new JavaScriptSerializer().Serialize(commandDictionary);
			return this.Execute(commandJson);
		}

		public string GetCommandBarDefinition(int objectTypeCode, string objectId, string relationshipId, bool isNew, string pageContext)
		{
			var commandDictionary = new Dictionary<string, object>();
			commandDictionary[Action] = "GETCOMMANDBARDEFINITION";
			commandDictionary[ClientVersion] = "1.0";
			commandDictionary[ObjectTypeCode] = objectTypeCode;
			commandDictionary[PageContext] = pageContext;
			commandDictionary[ObjectId] = objectId;
			commandDictionary[IsNew] = isNew;
			commandDictionary[RelationshipId] = relationshipId;

			var commandJson = new JavaScriptSerializer().Serialize(commandDictionary);
			return this.Execute(commandJson);
		}

		private const string Action = "Action";
		private const string ClientVersion = "ClientVersion";
		private const string IsNew = "IsNew";
		private const string ObjectId = "ObjectId";
		private const string ObjectTypeCode = "ObjectTypeCode";

		private const string Subject = "Subject";
		private const string NoteText = "NoteText";
		private const string ParentId = "ParentId";
		private const string ParentType = "ParentType";
		private const string PalDataFile = "PalDataFile";

		private const string PageContext = "PageContext";
		private const string RelationshipId = "RelationshipId";
		private const string RelationshipRoleOrdinal = "RelationshipRoleOrdinal";
		private const string PagingCookie = "PagingCookie";
		private const string PageNumber = "PageNumber";
		private const string PreviousPage = "PreviousPage";
		private const string NextPage = "NextPage";
		private const string TabId = "TabId";
	}

	public abstract class EspressoWebServiceTestBase : WebTestBase
	{
		protected EspressoWebServiceTestBase()
			: base()
		{
			PreWebTest += (sender, e) =>
			{
				e.WebTest.Context["IsMobilePhoneUser"] = 1;
				EspressoWebServiceTest_PreWebTest(sender, e);
			};

			PostWebTest += (sender, e) =>
			{
				e.WebTest.Context["IsMobilePhoneUser"] = 1;
				EspressoWebServiceTest_PostWebTest(sender, e);
			};
		}

		protected virtual void EspressoWebServiceTest_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			WebTestBase_PreWebTest(sender, e);
		}

		protected virtual void EspressoWebServiceTest_PostWebTest(object sender, PostWebTestEventArgs e)
		{
			this.WebTestBase_PostWebTest(sender, e);
		}

		protected MobileExpressWebService MobileExpressWebService
		{
			get { return new MobileExpressWebService(); }
		}

		protected override string entityName
		{
			get
			{
				return "";
			}
		}

		protected override string siteMapPath
		{
			get
			{
				return "";
			}
		}

		protected WebTestRequest Execute(Action callback)
		{
			CrmRequest wtr = null;
			try
			{
				callback();
			}
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
				wtr.ValidateResponse += ResponseValidator;
			}

			return wtr;
		}

		protected abstract void ResponseValidator(object sender, ValidationEventArgs e);
	}
}
