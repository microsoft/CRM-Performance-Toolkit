﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Collections;
using System.Xml.Linq;
using System.IO;

namespace CRM_Perf_BenchMark
{
	public static class ExchangeSyncLoadMapper
	{
		public const string Identifier = "ExchangeSync";


		#region Private Methods

		private static string CreateAppendable(ExchangeEntityLoadProfile profile)
		{
			if (ExchangeSyncLoadProfile.Instance.Enabled)
			{
				if (profile.ExchangeCreatesInRun < profile.TotalExchangeCreatesInRun)
				{
					long localCreated = Interlocked.Increment(ref profile.CreatesInRun);
					if (Interlocked.Read(ref profile.ExchangeCreatesInRun) <
					    profile.TotalCreatesInRun%profile.TotalExchangeCreatesInRun || localCreated%profile.CreateComparand == 0)
					{
						Interlocked.Increment(ref profile.ExchangeCreatesInRun);
						return Identifier;
					}
					return "";
				}
				Interlocked.Increment(ref profile.CreatesInRun);
			}
			return "";
		}

		private static Hashtable UpdateFilter(ExchangeEntityLoadProfile profile, string entityRow, string entityName)
		{
			if (ExchangeSyncLoadProfile.Instance.Enabled)
			{
				if (profile.ExchangeUpdatesInRun < profile.TotalExchangeUpdatesInRun)
				{
					long localAptUpdated = Interlocked.Increment(ref profile.UpdatesInRun);
					if (profile.ExchangeUpdatesInRun < profile.TotalUpdatesInRun%profile.TotalExchangeUpdatesInRun ||
					    profile.TotalExchangeUpdatesInRun%profile.UpdateComparand == 0)
					{
						Interlocked.Increment(ref profile.ExchangeUpdatesInRun);
						System.Collections.Hashtable props = new System.Collections.Hashtable();
						System.Collections.Hashtable sub_props = new System.Collections.Hashtable();
						sub_props.Add(entityRow, Identifier);
						props.Add(entityName.ToLower(), sub_props);
						return sub_props;
					}
					return null;
				}
				Interlocked.Increment(ref profile.UpdatesInRun);
			}
			return null;
		}

		#endregion

		#region Create Requests

		public static string CreateAppointmentAppendable()
		{
			return CreateAppendable(ExchangeSyncLoadProfile.Instance.Appointments);
		}

		public static string CreateContactAppendable()
		{
			return CreateAppendable(ExchangeSyncLoadProfile.Instance.Contacts);
		}

		public static string CreateTaskAppendable()
		{
			return CreateAppendable(ExchangeSyncLoadProfile.Instance.Tasks);
		}

		public static string CreateLetterAppendable()
		{
			return CreateAppendable(ExchangeSyncLoadProfile.Instance.Letters);
		}

		public static string CreatePhoneCallAppendable()
		{
			return CreateAppendable(ExchangeSyncLoadProfile.Instance.PhoneCalls);
		}

		public static string CreateRecurringAppointmentAppendable()
		{
			return CreateAppendable(ExchangeSyncLoadProfile.Instance.RecurringAppointments);
		}

		#endregion

		#region Update Requests

		public static Hashtable UpdateAppointmentFilter()
		{
			return UpdateFilter(ExchangeSyncLoadProfile.Instance.Appointments, "Subject", EntityNames.Appointments);
		}

		public static Hashtable UpdateContactFilter()
		{
			return UpdateFilter(ExchangeSyncLoadProfile.Instance.Contacts, "LastName", EntityNames.Contacts);
		}

		public static Hashtable UpdateTaskFilter()
		{
			return UpdateFilter(ExchangeSyncLoadProfile.Instance.Tasks, "Subject", EntityNames.Tasks);
		}

		public static Hashtable UpdateLetterFilter()
		{
			return UpdateFilter(ExchangeSyncLoadProfile.Instance.Letters, "Subject", EntityNames.Letters);
		}

		public static Hashtable UpdatePhoneCallFilter()
		{
			return UpdateFilter(ExchangeSyncLoadProfile.Instance.PhoneCalls, "Subject", EntityNames.Phonecalls);
		}

		public static Hashtable UpdateRecurringAppointmentFilter()
		{
			return UpdateFilter(ExchangeSyncLoadProfile.Instance.RecurringAppointments, "Subject",
			                    EntityNames.RecurringAppointments);
		}

		#endregion

	}


	public class ExchangeSyncLoadProfile
	{

		private ExchangeSyncLoadProfile()
		{
		}

		private static ExchangeSyncLoadProfile m_instance;
		private static object lockRef = new object();

		public static ExchangeSyncLoadProfile Instance
		{
			get
			{
				if (m_instance == null)
				{
					lock (lockRef)
					{
						if (m_instance == null)
						{
							Init();
						}
					}
				}
				return m_instance;
			}
		}

		private static void Init()
		{
			m_instance = new ExchangeSyncLoadProfile();
			XDocument doc =
				XDocument.Load(Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles\\ExchangeSyncLoad.xml");
			XElement root = doc.Root;
			XElement config = root.Element("Configuration");

			if (config != null)
			{
				m_instance.Enabled = (config.Element("Enabled") == null) ? false : bool.Parse(config.Element("Enabled").Value);
				m_instance.Identifier = (config.Element("Identifier") == null) ? "" : config.Element("Identifier").Value;
				m_instance.Duration = (config.Element("Duration") == null) ? 0 : Int32.Parse(config.Element("Duration").Value);
			}

			XElement elem = root.Element("Entities");
			m_instance.Appointments = m_instance.ReadElements(EntityNames.Appointments, elem);
			m_instance.Contacts = m_instance.ReadElements(EntityNames.Contacts, elem);
			m_instance.Tasks = m_instance.ReadElements(EntityNames.Tasks, elem);
			m_instance.Letters = m_instance.ReadElements(EntityNames.Letters, elem);
			m_instance.PhoneCalls = m_instance.ReadElements(EntityNames.Phonecalls, elem);
			m_instance.RecurringAppointments = m_instance.ReadElements(EntityNames.RecurringAppointments, elem);
			m_instance.ServiceAppointments = m_instance.ReadElements(EntityNames.ServiceAppointments, elem);
		}

		internal ExchangeEntityLoadProfile ReadElements(string entityName, XElement doc)
		{
			var element = from s in doc.Elements("Entity")
			              where s.Attribute("Name").Value == entityName
			              select new ExchangeEntityLoadProfile
				              {
								  TotalCreatesInRun = Int32.Parse(s.Element("TotalCreatesPerHour").Value) * Duration,
								  TotalExchangeCreatesInRun = Int32.Parse(s.Element("TotalExchangeCreatesPerHour").Value) * Duration,
								  TotalUpdatesInRun = Int32.Parse(s.Element("TotalUpdatesPerHour").Value) * Duration,
								  TotalExchangeUpdatesInRun = Int32.Parse(s.Element("TotalExchangeUpdatesPerHour").Value) * Duration
				              };
			return element.Single<ExchangeEntityLoadProfile>();
		}

		public bool Enabled { get; private set; }

		public string Identifier { get; private set; }

		public int Duration { get; private set; }

		public ExchangeEntityLoadProfile Appointments { get; private set; }

		public ExchangeEntityLoadProfile RecurringAppointments { get; set; }

		public ExchangeEntityLoadProfile Tasks { get; set; }

		public ExchangeEntityLoadProfile Contacts { get; set; }

		public ExchangeEntityLoadProfile ServiceAppointments { get; set; }

		public ExchangeEntityLoadProfile PhoneCalls { get; set; }

		public ExchangeEntityLoadProfile Letters { get; set; }
	}

	public class ExchangeEntityLoadProfile
	{
		public ExchangeEntityLoadProfile()
		{
			CreatesInRun = 0;
			ExchangeCreatesInRun = 0;
			UpdatesInRun = 0;
			ExchangeUpdatesInRun = 0;
		}

		public int TotalCreatesInRun { get; set; }

		public int TotalExchangeCreatesInRun { get; set; }

		public int TotalUpdatesInRun { get; set; }

		public int CreatesInRun;
		public long ExchangeCreatesInRun;
		public int UpdatesInRun;
		public long ExchangeUpdatesInRun;

		public int TotalExchangeUpdatesInRun { get; set; }

		public int CreateComparand
		{
			get
			{
				if (createComparand == Int32.MinValue)
				{
					if (TotalExchangeCreatesInRun > TotalCreatesInRun)
					{
						throw new Exception("We Can't Create more Entities to Sync than are configured to Run");
					}
					else
					{
						createComparand = TotalCreatesInRun/TotalExchangeCreatesInRun;
					}
				}
				return createComparand;
			}
		}

		private int createComparand = Int32.MinValue;


		public int UpdateComparand
		{
			get
			{
				if (updateComparand == Int32.MinValue)
				{
					if (TotalExchangeUpdatesInRun > TotalUpdatesInRun)
					{
						throw new Exception("We Can't Update more Entities to Sync than are configured to Run");
					}
					else
					{
						updateComparand = TotalUpdatesInRun/TotalExchangeUpdatesInRun;
					}
				}
				return updateComparand;
			}
		}

		private int updateComparand = Int32.MinValue;
	}
}
