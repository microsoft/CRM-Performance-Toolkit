﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using System.Collections;
using System.Diagnostics;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class ServiceAppointmentCRUDUnitTest : AppointmentEntityBase
	{

		public override int InstanceTypeCode
		{
			get
			{
				return 1;
			}
		}

		public override string EntityName
		{
			get
			{
				return EntityNames.ServiceAppointments;
			}
		}

		public override string PrintEntityData(Entity entity)
		{
			return String.Format("{0} subject={1}", EntityName, entity["subject"].ToString());
		}

		public override void CreateEntity(string name)
		{
			string timer = "Appointment Create Unit Test";
			Entity appointment = BuildBasicEntity(name);
			appointment["serviceid"] = this.GetAvailableService();
			appointment["resources"] = this.CreateEntityForSystemUser();
			Guid phoneId = CreateEntityInCRM(appointment, timer);
			//add the phonecall to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(this.EntityName, g,new string[] {"OwnerId", "ActivityId", "EntityManagerOwningUser", "Subject"},new string[]{m_user["systemuserid"], phoneId.ToString(), g.ToString(),appointment["subject"].ToString()});
		}

		[TestMethod]
		public void UnitTest__CreateServiceAppointment()
		{
			Init();
			CreateEntity(this.DeleteIdentifier);			
		}

		[TestMethod]
		public void UnitTest__UpdateServiceAppointment()
		{
			Entity phonecall = new Entity(EntityName.ToLower());

			//find a CRM Entity for update test
			Init("subject", this.UpdateIdentifier);
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "location", "subject", "serviceid" });
			//get the Phone Call in CRM
			phonecall = proxy.Retrieve(phonecall.LogicalName, new Guid(m_contact["activityid"]), attributes);
			//update contact address city value
			phonecall["location"] = Utils.GetRandomString(50, 100);
			this.UpdateEntityInCRM(phonecall, "Contact Update Unit Test");

		}

		[TestMethod]
		public void UnitTest__DeleteServiceAppointment()
		{
			Entity phonecall = new Entity(EntityName.ToLower());
			//find a CRM Entity for update test
			if (!Init("subject", this.DeleteIdentifier))
			{
				DeleteEntityInCRM("activityid", phonecall, " Delete Phone Call Entity");
			}
			else
			{
				Trace.TraceWarning("Couldn't Find a Service Appointment To Delete so Creating One");
			}
		}

		protected EntityReference GetAvailableService()
		{
			EntityRequest userRequest = new EntityRequest();
			userRequest.Type = EntityNames.Service;
			userRequest.ParentID = new Guid(m_user[EntityIDNames.Organization]);
			userRequest.ReturnAs = EntityNames.Service;
			CRMEntity[] entity = EntityManager.Instance.GetAllRecordsForEntity(userRequest, 1);
			if (entity == null || entity.Length < 1)
			{
				throw new EntityNotFoundException("Can't find a service that is available");
			}

			//Entity[] entities = new Entity[entity.Length];
			//for(int i=0; i< entity.Length; i++)
			//         {
			EntityReference ent = new EntityReference("service", new Guid(entity[0]["ServiceId"]));
			// ent.Id = ;
			//ent["partyid"] = new EntityReference("service", new Guid(entity[i]["ServiceId"]));

			//  entities[i] = ent;
			// }
			//return entities;
			return ent;
		}
	}
}
	

