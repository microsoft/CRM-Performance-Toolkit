﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting opportunity entity
	/// </summary>
	[TestClass]
	public class OpportunityCRUDUnitTest : UnitTestBase
	{
		#region Create an opportunity
		/// <summary>
		/// Test creating an opportunity
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_Opportunity()
		{
			//create an opportunity
			CRMEntity m_account = RetrieveTestEntity(m_user, EntityNames.Accounts);
			CRMEntity m_pricelevel = RetrieveTestEntity(new Guid(m_user[EntityIDNames.Organization]), EntityNames.PriceLevels);
			Entity opportunity = new Entity("opportunity");
			Guid opportunityId = Guid.Empty;
			opportunity.Attributes.Add("customerid", new EntityReference(EntityNames.Accounts.ToLower(), new Guid(m_account["accountId"])));
			opportunity.Attributes.Add("pricelevelid", new EntityReference(EntityNames.PriceLevels.ToLower(), new Guid(m_pricelevel["pricelevelId"])));
			opportunity.Attributes.Add("discountpercentage", 0.50m);
			opportunity.Attributes.Add("name", Utils.GetRandomString(5, 10));

			TestContext.BeginTimer("Opportunity Create Unit Test");
			try
			{
				opportunityId = Proxy.Create(opportunity);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Opportunity Create Unit Test");
			
			//add the opportunity to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Opportunities, g, new string[] { "OwnerId",  "OpportunityID", "EntityManagerOwningUser" }, new string[] { m_user["systemuserid"], opportunityId.ToString(), g.ToString() });
		}
		#endregion

		#region Retrieve an opportunity
		/// <summary>
		/// Test retrieving an opportunity
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_Opportunity()
		{
			CRMEntity m_opportunity = RetrieveTestEntity(m_user, EntityNames.Opportunities);
			Entity opportunity = new Entity("opportunity");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "name", "estimatedvalue" });
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Opportunity Retrieve Unit Test");
			try
			{
				opportunity = Proxy.Retrieve(opportunity.LogicalName, new Guid(m_opportunity["opportunityId"]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Opportunity Retrieve Unit Test");
		}
		#endregion

		#region Update an opportunity
		//test retrieving and updating an opportunity
		[TestMethod()]
		public void UnitTest__Update_Opportunity()
		{
			Entity opportunity = new Entity("opportunity");
			//find a CRM Entity for update test
			CRMEntity m_opportunity = RetrieveTestEntity(m_user, EntityNames.Opportunities, new Hashtable() { { "name", "connection" } });
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "name", "discountpercentage" });
			//get the opportunity in CRM
			opportunity = Proxy.Retrieve(opportunity.LogicalName, new Guid(m_opportunity["opportunityid"]), attributes);
			//update opportunity address city value
			opportunity["discountpercentage"] = 0.20m;
			//update the opportunity
			TestContext.BeginTimer("Opportunity Update Unit Test");
			try
			{
				Proxy.Update(opportunity);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Opportunity Update Unit Test");
		}
		#endregion

		#region Delete an opportunity
		/// <summary>
		/// Test deleting an opportunity
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_Opportunity()
		{
			CRMEntity m_opportunity = RetrieveTestEntity(m_user, EntityNames.Opportunities, new Hashtable() { { "name", "deletable" } });
			TestContext.BeginTimer("Opportunity Delete Unit Test");
			try
			{
				Proxy.Delete("opportunity", new Guid(m_opportunity["opportunityId"]));

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Opportunity Delete Unit Test");
			//delete the opportunity from EMDB
			EntityManager.Instance.DeleteEntity(m_opportunity);
		}
		#endregion

		#region Retrieve multiple opportunities
		/// <summary>
		/// Test retrieving multiple opportunity records
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_opportunity()
		{
			Entity opportunity = new Entity("opportunity");
			var queryExpression = new QueryExpression()
			{
				Distinct = false,
				EntityName = opportunity.LogicalName,
				ColumnSet = new ColumnSet("name", "description", "estimatedvalue", "estimatedclosedate"),

				Criteria =
				{
					Filters = 
						{
							new FilterExpression
							{
								FilterOperator = LogicalOperator.Or,
								Conditions = 
								{
									new ConditionExpression("estimatedvalue", ConditionOperator.GreaterEqual, "1000"),
									new ConditionExpression("estimatedclosedate", ConditionOperator.NextMonth)
									
								   
								},
							},

							new FilterExpression
							{
								FilterOperator = LogicalOperator.And,
								Conditions =
								{
									new ConditionExpression("actualvalue_base", ConditionOperator.GreaterThan, "100"),
									new ConditionExpression("totalamount", ConditionOperator.LessThan, "1000000")
								}
							}
							
						   
						}
				}
			};


			EntityCollection results;
			TestContext.BeginTimer("Opportunity RetrieveMultiple Unit Test");
			try
			{
				results = Proxy.RetrieveMultiple(queryExpression);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Opportunity RetrieveMultiple Unit Test");
		}
		#endregion
	}
}
