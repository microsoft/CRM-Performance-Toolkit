﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.Crm.Application.Platform;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using CRM_Perf_BenchMark.Utilities;
using Entity = Microsoft.Xrm.Sdk.Entity;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting Appointment entity
	/// </summary>
	[TestClass]
	public class ExchangeRecurringAppointmentCRUDUnitTest : CreateBasicExchangeEntityBaseTest
	{
		/// <summary>
		/// Entity used to query EMDB for the entity data
		/// </summary>
		public override string EntityName
		{
			get { return EntityNames.ExchangeAppointment; }
		}



		/// <summary>
		/// Overide for to print the entity Data
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public override string PrintEntityData(Entity entity)
		{
			return String.Format("attributes are Appointment subject. Subject={0} ", entity["subject"].ToString());
		}

		/// <summary>
		/// Test creating an appointment
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create__ExchangeRecurringAppointment()
		{
			Init();
			string contactId;
			string timer = "Exchange Appointment Create Unit Test";
			Entity appointment = CreateRecurringAppointment();
			contactId = this.CreateEntityInExchange(appointment, timer);
			Guid g = EntityManager.Instance.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.ExchangeAppointment, g, new string[] { "OwnerId", "ExchangeID", "EntityManagerOwningUser" , "Subject" }, new string[] { m_user["systemuserid"], contactId, g.ToString(), appointment.Attributes["subject"].ToString() });
		}

		/// <summary>
		/// test retrieving and updating a Appointment
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_ExchangeRecurringAppointment()
		{
			//find a Entity for update test
			string timerName = "Update Exchange Appointment";
			Init("subject", "exchange recurring update");
			this.UpdateEntityInExchange(this.EntityName, m_contact, timerName, Utils.GetRandomString(5, 10) + " exchange reccuring update");
		}

		/// <summary>
		/// test deleting an Appointment
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_ExchangeRecurringAppointment()
		{
			//find a Entity for update test
			string timerName = "Update Exchange Appointment";
			Init("subject", "exchange recurring del");
			this.DeleteEntityInExchange(this.EntityName, m_contact, timerName);
			EntityManager.Instance.DeleteEntity(m_contact);
		}


		private Entity CreateRecurringAppointment()
		{
			Entity master = new Entity("recurringappointmentmaster");
			master["subject"] = Utils.GetRandomString(5, 10) + " exchange recurring update";
			master["location"] = "New Location";
			master["description"] = "New Description";
			// Only supporting weekly at the moment, 
			master["recurrencepatterntype"] = new OptionSetValue(1); // Picklist(RecurrencePatternType.Weekly);
			DateTime patternStart = DateTime.Now.AddDays(1.0);
			master["patternstartdate"] = patternStart;
			master["patternenddate"] = patternStart.AddHours(1.0);
			master["patternendtype"] = new OptionSetValue(3);
			master["statecode"] = new OptionSetValue(3);// RecurringAppointmentMasterStateInfo();
			master["statuscode"] = new OptionSetValue(-1);
			DateTime now = DateTime.Now.AddHours(1.0);
			master["scheduledstart"] = now;
			master["scheduledend"] = now.AddHours(1.0);
			master["owninguser"] = CreateEntityForSystemUser();

			return master;
		}
	}
}
