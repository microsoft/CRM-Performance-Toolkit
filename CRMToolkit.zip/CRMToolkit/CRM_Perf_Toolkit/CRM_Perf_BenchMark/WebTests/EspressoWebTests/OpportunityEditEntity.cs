﻿using System;
using System.Web;

namespace CRM_Perf_BenchMark
{
	public class me_OpportunityEditEntity : me_EditEntity
	{
		private const string CommandXmlTemplate =
			@"<Input>
				<id>{0}</id>
				<name>opportunity</name>
				<formId>fc278fff-83b8-41e0-b9e3-b63e8f8e2337</formId>
				<dataxml>
					<opportunity>
						<description>{1}</description>
					</opportunity>
				</dataxml>
				<associations/>
			</Input>";

		public me_OpportunityEditEntity()
			: base(EntityNames.Opportunities)
		{
		}

		public override string GetCommandXml(Guid editEntity)
		{
			var data = string.Format(CommandXmlTemplate, editEntity.ToString("B"), Utils.GetRandomString(5, 10));
			data = HttpUtility.HtmlEncode(data);
			return data;
		}
	}
}
