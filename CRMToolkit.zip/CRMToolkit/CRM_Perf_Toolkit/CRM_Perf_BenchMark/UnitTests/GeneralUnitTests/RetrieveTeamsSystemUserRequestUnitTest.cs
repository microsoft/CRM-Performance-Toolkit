﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{

	[TestClass]
	public class RetrieveTeamsSystemUserRequestUnitTest : UnitTestBase
	{
		private CRMEntity m_account;

		#region Retrieve team system users
		/// <summary>
		/// Test retrieving team system users
		/// </summary>
		[TestMethod]
		public void UnitTest__RetrieveTeamsSystemUserRequest()
		{
			m_account = RetrieveTestEntity(m_user, EntityNames.Accounts);
			//create RetrieveTeamsSystemUserRequest
			RetrieveTeamsSystemUserRequest req = new RetrieveTeamsSystemUserRequest();
			req.EntityId = new Guid(m_account["accountid"]);
			Microsoft.Xrm.Sdk.Query.ColumnSet cs = new Microsoft.Xrm.Sdk.Query.ColumnSet(true);
			req.ColumnSet = cs;

			//execute the request
			TestContext.BeginTimer("RetrieveTeamsSystemUserRequest Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveTeamsSystemUserRequest Unit Test");
		}
		#endregion
	}
}
