﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting task entity
	/// </summary>
	[TestClass]
	public class TaskCRUDUnitTest
	{
		CRMEntity m_user, m_task;
		string SummaryFile;
		IOrganizationService Proxy;
		private TestContext m_testContext;

		//test creating/retrieving/updating/deleting an task
		public TaskCRUDUnitTest()
		{
			string timestamp = System.DateTime.Now.Ticks.ToString();
			StringBuilder summaryFileSB = new StringBuilder();
			summaryFileSB.Append(CWR_Help.resultDir);
			summaryFileSB.Append(@"\Perf_Task_CRUD_Summary_");
			summaryFileSB.Append(timestamp);
			summaryFileSB.Append(".log");
			SummaryFile = summaryFileSB.ToString();

		}

		public TestContext TestContext
		{
			get { return m_testContext; }
			set { m_testContext = value; }
		}

		//initialization with sub-properties requirement
		//for instance, require name contains keyword of 'deletable'
		public void init(string filter)
		{
			System.Collections.Hashtable props = new System.Collections.Hashtable();
			System.Collections.Hashtable sub_props = new System.Collections.Hashtable();
			CWR_Help help = null;
			if (!string.IsNullOrEmpty(filter))
			{
				sub_props.Add("lastname", filter);
				props.Add(EntityNames.Tasks, sub_props);
				help = new CWR_Help(props);
			}
			else
			{
				string[] task_props = { EntityNames.Tasks };
				help = new CWR_Help(task_props);
			}

			Hashtable Entities = help.getEntities();
			m_task = (CRMEntity)Entities[EntityNames.Tasks];
			m_user = (CRMEntity)Entities[EntityNames.Users];
			Proxy = help.getOrganizationServiceProxy();

		}

		//default initialization which with no sub-properties requirement 
		public void init()
		{
			string temp = string.Empty;
			init(temp);
		}
		/// <summary>
		/// Test creating an task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_Task()
		{
			init();
			//create an task
			Guid taskId = Guid.Empty;
			Entity task = new Entity("task");
			task["subject"] = Utils.GetRandomString(5, 20);

			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Task Create Unit Test");
			try
			{
				taskId = Proxy.Create(task);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task Create Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Creating task test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("task id created in this test is " + taskId.ToString());
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
			//add the task to EMDB
			Guid g = EntityManager.Instance.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Tasks, g, new string[] { "OwnerId", "ActivityID", "EntityManagerOwningUser", "Subject" }, new string[] { m_user["systemuserid"], taskId.ToString(), g.ToString(), task.Attributes["subject"].ToString() });
		}

		[TestMethod()]
		public void UnitTest__Retrieve_Task()
		{
			init();
			Entity task = new Entity("task");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "activityid", "subject" });
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Task Retrieve Unit Test");
			try
			{
				task = Proxy.Retrieve(task.LogicalName, new Guid(m_task["activityid"]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task Retrieve Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Retrieving task test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the task retrieved in this test is " + m_task["taskId"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Retrieved attributes are task activity Id and subject. " + "activityid=" + task["activityid"] + " subject=" + task["subject"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		//test retrieving and updating an task
		[TestMethod()]
		public void UnitTest__Update_Task()
		{
			Entity task = new Entity("task");
			//find a CRM Entity for update test
			init();
			//create a dummy task for update
			task["subject"] = Utils.GetRandomString(5, 20);
			Guid taskId = Proxy.Create(task);

			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "subject"});
			//get the task in CRM
			task = Proxy.Retrieve(task.LogicalName, taskId, attributes);
			//update task subject value
			task["subject"] = Utils.GetRandomString(10, 20);
			//update the task
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Task Update Unit Test");
			try
			{
				Proxy.Update(task);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task Update Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Updating task test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the task retrieved in this test is " + m_task["taskId"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Updated attribute is task's subject" + " subject=" + task["subject"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}

		}

		//test deleting an task
		[TestMethod()]
		public void UnitTest__Delete_Task()
		{
			init();
			//create a dummy task for deletion
			Entity task = new Entity("task");
			task["subject"] = Utils.GetRandomString(5, 20);
			Guid taskId = Proxy.Create(task);

			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Task Delete Unit Test");
			try
			{
				Proxy.Delete("task", taskId);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task Delete Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Deleting task test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the task deleted in this test is " + taskId);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
			//delete the task from EMDB
			//EntityManager.Instance.DeleteEntity(m_task);

		}


		[TestMethod()]
		//retrieve multiple task records
		public void UnitTest__RetrieveMultiple_task()
		{
			init();
			Entity task = new Entity("task");
			var queryExpression = new QueryExpression()
			{
				Distinct = false,
				EntityName = task.LogicalName,
				ColumnSet = new ColumnSet("activityid"),

				Criteria =
				{
					Filters = 
						{
							new FilterExpression
							{
								FilterOperator = LogicalOperator.And,
								Conditions = 
								{
									new ConditionExpression("new_attribute4", ConditionOperator.GreaterEqual, "90000"),
									new ConditionExpression("new_attribute5", ConditionOperator.LessThan, "80000"),
								},
							}

						   
						}
				}
			};


			EntityCollection results;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Task RetrieveMultiple Unit Test");
			try
			{
				results = Proxy.RetrieveMultiple(queryExpression);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task RetrieveMultiple Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for retrieving multiple task test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The total number of results retunred is " + results.Entities.Count);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}

		}



	}
}
