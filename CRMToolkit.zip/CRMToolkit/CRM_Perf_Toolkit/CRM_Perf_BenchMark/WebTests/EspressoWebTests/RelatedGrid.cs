﻿namespace CRM_Perf_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using Espresso;

	/// <summary>
	/// 1. Go to sitemap
	/// 2. Go to random grid
	/// 3. Go to random entity
	/// 4. Go to related entity
	/// </summary>

	public class me_RelatedGrid : EspressoPageTestBase
	{
		public me_RelatedGrid()
			: base()
		{
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			ME_EntityHelper meeh = MobileExpressHelper.Instance.GetRandomHomepageEntity();
			CRMEntity entity = RetrieveTestEntity(user, MobileExpressHelper.Instance.GetProperEntityName(meeh.logicalName));

			this.BeginTransaction(EspressoTransactionNames.HomePage);
			_m_default_aspx hp = new _m_default_aspx(user);
			yield return (hp);
			this.EndTransaction(EspressoTransactionNames.HomePage);

			this.BeginTransaction(EspressoTransactionNames.EntityGrid);
			string referer = hp.lastResponse.ResponseUri.ToString();
			WebTestRequestHeader header = new WebTestRequestHeader();
			header.Name = "referer";
			header.Value = referer;
			_m_eh_aspx eh = new _m_eh_aspx(user);
			eh.Headers.Add(header);
			eh.etn = meeh.logicalName;
			yield return (eh);
			this.EndTransaction(EspressoTransactionNames.EntityGrid);

			string recordIdString = MobileExpressHelper.Instance.GetEntityId(meeh.logicalName, entity);
			Guid recordId = Guid.Parse(recordIdString);

			this.BeginTransaction(String.Format(EspressoTransactionNames.EntityReadPage, meeh.logicalName));
			_m_ef_aspx forms = new _m_ef_aspx(user)
			{
				Etn = meeh.logicalName,
				Id = recordId
			};
			forms.Headers.Add(new WebTestRequestHeader("referer", eh.lastResponse.ResponseUri.ToString()));
			yield return forms;
			this.EndTransaction(String.Format(EspressoTransactionNames.EntityReadPage, meeh.logicalName));

			this.BeginTransaction(EspressoTransactionNames.EntityRelatedGridPage);
			_m_re_aspx relatedForms = new _m_re_aspx(user)
			{
				Etn = meeh.logicalName,
				Id = recordId,
				Rid = GetRelatedEntityID(meeh.logicalName)
			};
			forms.Headers.Add(new WebTestRequestHeader("referer", eh.lastResponse.ResponseUri.ToString()));
			yield return forms;
			this.EndTransaction(EspressoTransactionNames.EntityRelatedGridPage);
		}

		private Guid GetRelatedEntityID(string etn)
		{
			switch (etn)
			{
				case "account":
					return new Guid("fc8caf7d-a1a7-49af-b85f-def77e65ade2");
				case "case":
					return new Guid("d22337e7-6aed-464b-ab82-a85129bde6b6");
				case "contact":
					return new Guid("1c0d43ae-5ca2-4213-afe8-ee0e074d1acd");
				case "opportunity":
					return new Guid("ce046ada-b0b5-4e0d-a4a0-9459c6dac714");
				case "lead":
					return new Guid("20f60cc9-abb8-4a81-a08e-f9d8895b8906");
				case "task":
					return new Guid("0d61f267-e60f-45f3-96c6-44d372382336");
				default:
					return Guid.Empty;
			}
		}

	}
}
