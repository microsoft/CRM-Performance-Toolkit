﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Xrm.Sdk;
using System.Globalization;
using System.Net;

namespace CRM_Perf_BenchMark.Utilities
{
	public sealed class ExchangeProvider
	{
		#region Constructor

		public ExchangeProvider(CRMEntity user)
			: this(user["internalemailaddress"], user["ExchangePassword"], Guid.Parse(user["SystemUserId"]))
		{ }

		public ExchangeProvider(string emailAddress, string password, Guid userId)
		{
			this.emailAddress = emailAddress;
			this.password = password;
			this.userId = userId;

			if (string.IsNullOrEmpty(this.emailAddress))
			{
				throw new InvalidOperationException("Cannot create Exchange provider, user has empty email address");
			}
			Console.WriteLine(String.Format("Exchange provider email address is set to {0}", this.emailAddress));

		}

		#endregion

		#region Private members

		public readonly ExtendedPropertyDefinition CRMLINKSTATE = new ExtendedPropertyDefinition(DefaultExtendedPropertySet.PublicStrings, "crmLinkState", MapiPropertyType.Double);
		public readonly ExtendedPropertyDefinition CRMID = new ExtendedPropertyDefinition(DefaultExtendedPropertySet.PublicStrings, "crmid", MapiPropertyType.String);

		private ExchangeService _service;
		private string emailAddress;
		private string password;
		private Guid userId;


		#endregion

		#region Public Methods and Properties

		/// <summary>
		/// Create Item
		/// </summary>
		/// <param name="entity">Entity</param>
		/// <returns>A Guid representing Entity Id</returns>
		public ItemId CreateItem(Entity entity)
		{
			ItemId itemId;
			switch (entity.LogicalName.ToLower())
			{
				case "contact":
					{
						itemId = SetItemProps(new Contact(this.Service), entity).Id;
						break;
					}
				case "task":
					{
						itemId = SetItemProps(new Task(this.Service), entity).Id;
						break;
					}
				case "appointment":
					{
						itemId = SetItemProps(new Appointment(this.Service), entity).Id;
						break;
					}
				case ("recurringappointmentmaster"):
					{
						itemId = SetItemProps(new Appointment(this.Service), entity).Id;
						break;
					}
				default:
					throw new SyncNotSupportedException("Exchange Sync is not Supported for Entity : " + entity.LogicalName);
			}

			Item item = Item.Bind(this.Service, itemId);
			item.SetExtendedProperty(CRMLINKSTATE, (double)LinkState.WillBeLinked);
			item.Update(ConflictResolutionMode.AlwaysOverwrite);

			PropertySet propertySet = new PropertySet(BasePropertySet.FirstClassProperties, CRMID);
			item = Item.Bind(this.Service, itemId, propertySet);
			return itemId;
		}

		/// <summary>
		/// Gets the Item Id
		/// </summary>
		/// <param name="entityLogicalName">EntityLogicalName</param>
		/// <param name="entityId">EntityId</param>
		/// <returns>A string representing EntityId</returns>
		public string GetItemId(string entityLogicalName, Guid entityId)
		{
			Item item = FindItem(entityLogicalName, entityId);
			return item.Id.ToString();
		}

		/// <summary>
		/// Update Item
		/// </summary>
		/// <param name="entityLogicalName">EntityLogicalName</param>
		/// <param name="entityId">EntityId</param>
		/// <param name="updateEntity">Update Entity</param>
		public void UpdateItem(string entityLogicalName, string entityId, string updateValue)
		{
			Item item = Item.Bind(this.Service, entityId);

			string lowerCaseEntityName = entityLogicalName.ToLower();
			if (lowerCaseEntityName.Contains("contact"))
			{
				Contact con = item as Contact;
				con.Subject = updateValue;
				con.Update(ConflictResolutionMode.AlwaysOverwrite);
			}
			else if (lowerCaseEntityName.Contains("task"))
			{
				Task t = item as Task;
				t.Subject = updateValue;
				t.Update(ConflictResolutionMode.AlwaysOverwrite);
			}
			else if (lowerCaseEntityName.Contains("appointment"))
			{
				Appointment app = item as Appointment;
				app.Subject = updateValue;
				app.Update(ConflictResolutionMode.AlwaysOverwrite);
			}
		}

		/// <summary>
		/// Delete Item
		/// </summary>
		/// <param name="entityLogicalName">EntityLogicalName</param>
		/// <param name="entityId">Entity Id</param>
		public void DeleteItem(string id)
		{
			ItemId itemId = new ItemId(id);
			Item item = Item.Bind(this.Service, itemId);
			item.Delete(DeleteMode.MoveToDeletedItems);
		}

		/// <summary>
		/// Finds Exchange Item
		/// </summary>
		/// <param name="entityLogicalName">EntityLogicalName</param>
		/// <param name="entityId">Entity Id</param>
		/// <returns>An Exchange Item that represents the Synced Item, throws ItemNotFoundException Otherwise</returns>
		public Item FindItem(string entityLogicalName, Guid entityId)
		{
			WellKnownFolderName parentFolderName;
			switch (entityLogicalName)
			{
				case "contact":
					parentFolderName = WellKnownFolderName.Contacts;
					break;

				default:
					throw new SyncNotSupportedException("Exchange Sync is not Supported for Entity : " + entityLogicalName);

			}

			ExtendedPropertyDefinition extendedPropertyDefinition = CRMID;
			SearchFilter filter = new SearchFilter.ContainsSubstring(extendedPropertyDefinition, entityId.ToString());
			ItemView view = new ItemView(1);
			view.PropertySet = new PropertySet(BasePropertySet.FirstClassProperties, extendedPropertyDefinition);
			FindItemsResults<Item> findResults = this.Service.FindItems(parentFolderName, filter, view);

			if (findResults.TotalCount == 0)
			{
				throw new ItemNotFoundException("Could not find Exchange Item with crmId : " + entityId);
			}
			else if (findResults.TotalCount > 1)
			{
				string ids = string.Empty;
				foreach (Item result in findResults)
				{
					ids += string.Format(CultureInfo.CurrentCulture, "{0}; ", result.Id);
				}

				//Should this write to console or is there a logger?
				Console.WriteLine(String.Format("Multiple items found for crmId {0}: {1}", entityId, ids));
			}

			return findResults.Single();
		}

		/// <summary>
		/// Builds a Crm Entity from Item
		/// </summary>
		/// <param name="entityLogicalName">EntityLogicalName</param>
		/// <param name="entityId">EntityId</param>
		/// <returns>Entity representation of Item</returns>
		public Entity BuildCrmEntityFromItem(string entityLogicalName, Guid entityId)
		{
			Item item = FindItem(entityLogicalName, entityId);
			return BuildCrmEntityFromItem(entityLogicalName, item.Id.ToString());
		}

		/// <summary>
		/// Builds a Crm Entity from Item
		/// </summary>
		/// <param name="entityLogicalName">EntityLogicalName</param>
		/// <param name="entityId">EntityId</param>
		/// <returns>Entity representation of Item</returns>
		public Entity BuildCrmEntityFromItem(string entityLogicalName, string itemId)
		{
			Item item = Item.Bind(this.Service, itemId);
			Entity entity;
			switch (entityLogicalName)
			{
				case "contact":
					Contact exchangeContact = (Contact)item;
					entity = new Entity("contact");
					entity["lastname"] = exchangeContact.Surname;
					entity["middlename"] = exchangeContact.MiddleName;
					entity["firstname"] = exchangeContact.GivenName;
					break;

				default:
					throw new SyncNotSupportedException("Exchange Sync is not Supported for Entity : " + entityLogicalName);
			}

			return entity;

		}


		/// <summary>
		/// Does Item Exist
		/// </summary>
		/// <param name="itemId">ItemId</param>
		/// <returns>Returns a Boolean representing if Item Exists or not</returns>
		public bool ItemExists(string itemId)
		{
			Item item = Item.Bind(this.Service, itemId);
			return (item != null);
		}

		/// <summary>
		/// Does Item Exist with CrmId
		/// </summary>
		/// <param name="entityLogicalName">EntityLogicalName</param>
		/// <param name="entityId">EntityId</param>
		/// <returns>Returns a Boolean representing if Item was found with Guid</returns>
		public bool ItemExists(string entityLogicalName, Guid entityId)
		{
			try
			{
				FindItem(entityLogicalName, entityId);
				return true;
			}
			catch (ItemNotFoundException)
			{
				return false;
			}
		}

		/// <summary>
		/// Get Item LinkState
		/// </summary>
		/// <param name="itemId">ItemId</param>
		/// <returns>A enum representing Crm LinkState</returns>
		public LinkState GetLinkState(string itemId)
		{
			LinkState linkState;
			PropertySet propertySet = new PropertySet(BasePropertySet.FirstClassProperties, CRMLINKSTATE);
			Item item = Item.Bind(this.Service, itemId, propertySet);
			if (item.ExtendedProperties.Count == 1)
			{
				string propertyValue = (string)item.ExtendedProperties[0].Value;
				if (!Enum.TryParse(propertyValue, out linkState))
				{
					string message = string.Format(CultureInfo.InvariantCulture, "Unknown LinkState: {0} Set on Item with Item Id : ", propertyValue, item.Id.ToString());
					throw new ItemPropertyNotSetException(message);
				}
			}
			else
			{
				linkState = LinkState.DoesNotExist;
			}

			return linkState;
		}


		/// <summary>
		/// Sets Item LinkState
		/// </summary>
		/// <param name="entityLogicalName">EntityLogicalName</param>
		/// <param name="entityId">EntityId</param>
		/// <returns>A enum representing Crm LinkState</returns>
		public void SetLinkState(string itemId, LinkState linkState)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Gets the CrmId published on Item after Sync
		/// </summary>
		/// <param name="itemId">ItemID</param>
		/// <returns>A Guid representing the crmId of Tracked Item</returns>
		public Guid GetCrmIdFromItem(string itemId)
		{
			throw new NotImplementedException();
		}

		public ExchangeService Service
		{
			get
			{
				if (_service == null)
				{
					_service = GetService();
				}
				return _service;
			}
		}

		#endregion

		#region Private Helper Functions


		private ExchangeService GetService()
		{
			return EntityManager.GetService(userId, emailAddress, password);
		}

		private Item SetItemProps(Item item, Entity entity)
		{
			switch (entity.LogicalName.ToLower())
			{
				case "contact":
					{
						Contact exchangeContact = (Contact)item;

						exchangeContact.GivenName = entity.Attributes["firstname"].ToString();
						exchangeContact.Surname = entity.Attributes["lastname"].ToString();
						exchangeContact.FileAs = entity.Attributes["lastname"].ToString();
						if (exchangeContact.Id == null)
						{
							exchangeContact.Save();
						}
						else
						{
							exchangeContact.Update(ConflictResolutionMode.AlwaysOverwrite);
						}
						return exchangeContact;
					}
				case "task":
					{

						Task exchangeTask = (Task)item;
						exchangeTask.Subject = entity.Attributes["subject"].ToString();
						if (exchangeTask.Id == null)
						{
							exchangeTask.Save();
						}
						else
						{
							exchangeTask.Update(ConflictResolutionMode.AlwaysOverwrite);
						}
						return exchangeTask;
					}
				case "appointment":
					{
						Appointment exchangeAppointment = CreateExchangeAppointment(item, entity);
						exchangeAppointment.Subject = entity.Attributes["subject"].ToString();
						if (entity.Attributes.ContainsKey("description"))
						{
							exchangeAppointment.Body = entity.Attributes["description"].ToString();
						}
						exchangeAppointment.Start = DateTime.Parse(entity.Attributes["scheduledstart"].ToString());
						exchangeAppointment.End = DateTime.Parse(entity.Attributes["scheduledend"].ToString());
						if (exchangeAppointment.Id == null)
						{
							exchangeAppointment.Save(SendInvitationsMode.SendToNone);
						}
						else
						{
							exchangeAppointment.Update(ConflictResolutionMode.AlwaysOverwrite, SendInvitationsOrCancellationsMode.SendToNone);
						}
						return exchangeAppointment;

					}
				case "recurringappointmentmaster":
					{
						Appointment exchangeAppointment = CreateExchangeAppointment(item, entity);
						exchangeAppointment.Subject = entity.Attributes["subject"].ToString();
						if (entity.Attributes.ContainsKey("description"))
						{
							exchangeAppointment.Body = entity.Attributes["description"].ToString();
						}
						exchangeAppointment.Start = DateTime.Parse(entity.Attributes["scheduledstart"].ToString());
						exchangeAppointment.End = DateTime.Parse(entity.Attributes["scheduledend"].ToString());

						DayOfTheWeek[] days = new DayOfTheWeek[] { DayOfTheWeek.Tuesday };
						exchangeAppointment.Recurrence = new Recurrence.DailyPattern(exchangeAppointment.Start, 1);
						exchangeAppointment.Recurrence.StartDate = exchangeAppointment.Start.Date;
						exchangeAppointment.Recurrence.NumberOfOccurrences = 10;

						if (exchangeAppointment.Id == null)
						{
							exchangeAppointment.Save(SendInvitationsMode.SendToNone);
						}
						else
						{
							exchangeAppointment.Update(ConflictResolutionMode.AlwaysOverwrite, SendInvitationsOrCancellationsMode.SendToNone);
						}
						return exchangeAppointment;

					}
				default:
					throw new SyncNotSupportedException("Exchange Sync is not Supported for Entity : " + entity.LogicalName);
			}
		}

		#endregion


		private Appointment CreateExchangeAppointment(Item item, Entity entity)
		{
			Appointment exchangeAppointment = (Appointment)item;
			exchangeAppointment.Subject = entity.Attributes["subject"].ToString();
			if (entity.Attributes.ContainsKey("description"))
			{
				exchangeAppointment.Body = entity.Attributes["description"].ToString();
			}
			exchangeAppointment.Location = entity.Attributes["location"].ToString();
			exchangeAppointment.Start = DateTime.Parse(entity.Attributes["scheduledstart"].ToString());
			exchangeAppointment.End = DateTime.Parse(entity.Attributes["scheduledend"].ToString());
			return exchangeAppointment;
		}

		static bool RedirectionUrlValidationCallback(String redirectionUrl)
		{
			// Perform validation.
			// Validation is developer dependent to ensure a safe redirect.
			return true;
		}
	}


	/// <summary>
	/// An enum representing Crm LinkState
	/// </summary>
	public enum LinkState
	{
		NotLinked = 0,
		WillBeLinked = 1,
		IsLinked = 2,
		WillBeUnlinked = 3,
		WillBeUnlinkedAndDeleted = 4,
		DoesNotExist = 5,
	}
}
