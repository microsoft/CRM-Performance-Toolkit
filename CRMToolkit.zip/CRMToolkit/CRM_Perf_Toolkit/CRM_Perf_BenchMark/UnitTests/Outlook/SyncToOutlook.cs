using System;
using System.IO;
using System.Net;
using Microsoft.Win32;
using System.Web.Services;
using System.Reflection;
using System.Xml;
using System.Xml.XPath;
using System.Web.Services.Protocols;

using System.Runtime.InteropServices;
using System.Globalization;
using System.Security.Principal;
using Microsoft.Crm;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages.Internal;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Summary description for SyncToOutlook
	/// </summary>
	[TestClass]
	public class SyncToOutlook : OutlookTestBaseClass
	{
		XmlDocument resultsDoc = null;
		MySyncDataRecorder sdr = null;

		// Account fields
		const string c_wzAccountColumnSetInsert = "<columnset><column>accountid</column>SampleBulkDeleteUnitTests<column>name</column>SampleBulkDeleteUnitTests<column>telephone1</column>SampleBulkDeleteUnitTests<column>telephone2</column>SampleBulkDeleteUnitTests<column>fax</column>SampleBulkDeleteUnitTests<column>emailaddress1</column>SampleBulkDeleteUnitTests<column>donotemail</column>SampleBulkDeleteUnitTests<column>donotfax</column>SampleBulkDeleteUnitTests<column>donotphone</column>SampleBulkDeleteUnitTests<column>donotpostalmail</column>SampleBulkDeleteUnitTests<column>address1_line1</column>SampleBulkDeleteUnitTests<column>address1_line2</column>SampleBulkDeleteUnitTests<column>address1_line3</column>SampleBulkDeleteUnitTests<column>address1_city</column>SampleBulkDeleteUnitTests<column>address1_stateorprovince</column>SampleBulkDeleteUnitTests<column>address1_postalcode</column>SampleBulkDeleteUnitTests<column>address1_country</column>SampleBulkDeleteUnitTests<column>modifiedon</column>SampleBulkDeleteUnitTests</columnset>";

		const string c_wzAccountColumnSetDelete = "<columnset><column>accountid</column></columnset>";

		// Contact fields
		const string c_wzContactColumnSetInsert = "<columnset>SampleBulkDeleteUnitTests<column>contactid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>parentcustomerid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>address1_city</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>address1_country</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>address1_line1</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>address1_line2</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>address1_line3</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>address1_postalcode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>address1_postofficebox</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>address1_stateorprovince</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>anniversary</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>assistantname</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>assistantphone</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>birthdate</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>childrensnames</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>department</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>description</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>emailaddress1</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>emailaddress2</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>emailaddress3</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>fax</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>firstname</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>ftpsiteurl</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>governmentid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>jobtitle</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>lastname</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>managername</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>middlename</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>mobilephone</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>nickname</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>ownerid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>pager</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>salutation</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>spousesname</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>statuscode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>suffix</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>telephone1</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>telephone2</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>telephone3</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>websiteurl</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>yomifirstname</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>yomilastname</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>yomimiddlename</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests</columnset>";
		const string c_wzContactColumnSetDelete = "<columnset><column>contactid</column></columnset>";

		// Recurring Appointment fields
		const string c_wzRecurringeApptColumnSetInsert = "<columnset>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>activityid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>location</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>patternstartdate</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>regardingobjectid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>ruleid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>recurrencepatterntype</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>ownerid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>prioritycode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>subject</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>patternenddate</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>starttime</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>endtime</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>statuscode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>description</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>isalldayevent</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>outlookownerapptid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>globalobjectid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>requiredattendees</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>optionalattendees</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>organizer</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests</columnset>";
		const string c_wzRecurringApptColumnSetDelete = "<columnset><column>activityid</column></columnset>";

		// Appointment fields
		const string c_wzApptColumnSetInsert = "<columnset>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>activityid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>location</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>scheduledstart</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>regardingobjectid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>ownerid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>prioritycode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>subject</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>scheduledend</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>statuscode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>description</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>isalldayevent</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>outlookownerapptid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>globalobjectid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>requiredattendees</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>optionalattendees</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>organizer</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests</columnset>";
		const string c_wzApptColumnSetDelete = "<columnset><column>activityid</column></columnset>";

		// Service Appointment fields
		const string c_wzServiceApptColumnSetInsert = "<columnset>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>activityid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>location</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>scheduledstart</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>regardingobjectid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>ownerid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>prioritycode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>subject</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>scheduledend</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>statuscode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>description</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>isalldayevent</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>serviceid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>resources</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>customers</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests</columnset>";
		const string c_wzServiceApptColumnSetDelete = "<columnset><column>activityid</column></columnset>";

		// Task fields
		const string c_wzTaskColumnSetInsert = "<columnset>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>activityid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>description</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>ownerid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>regardingobjectid</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>scheduleddurationminutes</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>scheduledend</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>scheduledstart</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>prioritycode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>statecode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>statuscode</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>subject</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests<column>percentcomplete</column>SampleBulkDeleteUnitTestsSampleBulkDeleteUnitTests</columnset>";
		const string c_wzTaskColumnSetDelete = "<columnset><column>activityid</column></columnset>";

		int DELETED_ITEMS_BATCH_SIZE = 100;
		int INSERTED_ITEMS_BATCH_SIZE = 100;	// TODO:  DISCOVER OPTIMUM VALUES FOR THESE

		static string c_wzTagIdAccount = "accountid";
		static string c_wzTagIdContact = "contactid";
		static string c_wzTagIdActivity = "activityid";

		static string c_wzPlatformNameContact = "Contact";
		static string c_wzPlatformNameTask = "Task";
		static string c_wzPlatformNameAppt = "Appointment";
		static string c_wzPlatformNameServiceAppt = "ServiceAppointment";

		// NOTE:  THE ORDER OF THIS ARRAY MUST MATCH THE ORDER OF THE ENTITY_NAMES ENUM!
		static string[] s_EntityNamesForSync = {
									c_wzPlatformNameContact,
									c_wzPlatformNameTask,
									c_wzPlatformNameAppt,
									c_wzPlatformNameServiceAppt};
		private String clientId = null;
		private String subscriptionId = null;


		private RegistryKey regKey = null;
		string outDir = string.Empty;

		private RegistryKey RegKey
		{
			get
			{
				if (this.regKey == null)
				{
					this.regKey = Registry.CurrentUser.OpenSubKey(m_clientKeyPath, true);
					if (this.regKey == null)
					{
						throw new Exception("Client registry subkey not found in the registry");
					}
				}
				return this.regKey;
			}
		}

		private String SubscriptionId
		{
			get
			{
				if (this.subscriptionId == null)
				{
					subscriptionId = (String)RegKey.GetValue("OutlookSyncSubscriptionId");
				}
				return this.subscriptionId;
			}
			set
			{
				subscriptionId = value;
				RegKey.SetValue("OutlookSyncSubscriptionId", subscriptionId);
			}
		}

		private String ClientId
		{
			get
			{
				if (this.clientId == null)
				{
					clientId = (String)RegKey.GetValue("OutlookSyncClientId");
				}
				return this.clientId;
			}
			set
			{
				clientId = value;
				RegKey.SetValue("OutlookSyncClientId", clientId);
			}
		}

		#region Additional test attributes

		[ClassInitialize()]
		public static void MyClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(string.Format(@"{0}outlooksyncdata\SyncToOutlook", Path.GetPathRoot(Environment.CurrentDirectory))))
			{
				Directory.CreateDirectory(string.Format(@"{0}outlooksyncdata\SyncToOutlook", Path.GetPathRoot(Environment.CurrentDirectory)));
			}
			EntityManager.Instance.IsPerUserPerRun = true;
		}

		#endregion

		#region test init
		/// <summary>
		/// Initialize() is called once during test execution before
		/// test methods in this test class are executed.
		/// </summary>
		[TestInitialize()]
		public override void Initialize()
		{
			System.Diagnostics.Trace.WriteLine("init" + DateTime.Now.ToString());
			base.Initialize();

			try
			{
				//we are going to see here if registry exists, if it does not then we are going to create the registry
				CreateRegistryForUser(m_nc);

				sdr = new MySyncDataRecorder();
				// create transfer data provider
				resultsDoc = new XmlDocument();
				resultsDoc.AppendChild(resultsDoc.CreateElement("run_results"));
			}
			catch (Exception ex)
			{
				base.Cleanup();
				throw ex;
			}
		}
		#endregion 

		#region test cleanup
		/// <summary>
		/// Cleanup() is called once during test execution after
		/// test methods in this class have executed unless the
		/// corresponding Initialize() call threw an exception.
		/// </summary>
		[TestCleanup()]
		public override void Cleanup()
		{
			if (m_user == null)
				return;
			System.Diagnostics.Trace.WriteLine("SyncToOutlook:cleanup" + DateTime.Now.ToString());

			base.Cleanup();

			try
			{
				XmlDocument docNode = resultsDoc.DocumentElement.OwnerDocument;
				XmlElement el;
				el = sdr.SerializeToXML(resultsDoc.DocumentElement.OwnerDocument);
				resultsDoc.DocumentElement.AppendChild(el);


				string fileName = string.Format("{0}_SyncToOutlook_{1}.xml", m_userName, DateTime.Now.ToString());
				fileName = fileName.Replace(" ", "_");
				fileName = fileName.Replace("/", "_");
				fileName = fileName.Replace(":", "_");
				System.Diagnostics.Trace.WriteLine(fileName);

				resultsDoc.Save(string.Format("{0}\\SyncToOutlook\\{1}", ConfigSettings.Default.OutlookSyncDir, fileName));
			}
			catch { }
		}
		#endregion

		#region Individual Test Cases

		/// <summary>
		/// Test method for Outlook client sync. SDK calls:
		/// IsPrimaryClientSubscriptionClients, 
		/// GetOutlookSyncDataSubscriptionClients, 
		/// PrepareOutlookSyncSubscriptionClients, 
		/// PostOutlookSyncSubscriptionClients
		/// </summary>
		[TestMethod]
		public void SyncToOutlookTM()
		{
			if (m_user == null)
				return;

			try
			{
				DateTime dtStart = DateTime.Now;
				DateTime dtFinish = DateTime.Now;

				if (SubscriptionId == null)
				{
					dtStart = DateTime.Now;
					CreateOnlineSubscription();
					dtFinish = DateTime.Now;

					if (sdr != null)
					{
						sdr.CreateSubscription = dtFinish - dtStart;
					}
				}

				// Client always checks if it's primary before sync
				IsPrimaryOnlineClient(ClientId);

				// Step2 : PrepareSync
				dtStart = DateTime.Now;
				String syncInfo = PrepareOnlineSync();
				dtFinish = DateTime.Now;
				if (sdr != null)
				{
					sdr.PrepareSync = dtFinish - dtStart;
					sdr.SyncInfo = syncInfo;
				}

				// Step2 : GetData
				System.Diagnostics.Trace.WriteLine(syncInfo);

				XmlDocument doc = CreateXmlDocument(syncInfo);
				XPathNavigator nav = doc.CreateNavigator();
				XPathNodeIterator iterator = nav.Select("/result/entity");

				SyncInfo[] syncData = new SyncInfo[iterator.Count];

				int total = 0;
				dtStart = DateTime.Now;
				int numEntities = GetData(iterator, ref syncData, ref total);
				dtFinish = DateTime.Now;

				if (total == 0)
					return;

				for (int j = 0; j < numEntities; j++)
				{
					switch (syncData[j].entityName.ToLower())
					{
						case "account":
							SyncItemByType(syncData[j], SubscriptionId, c_wzTagIdAccount, c_wzAccountColumnSetInsert, c_wzAccountColumnSetDelete, "SyncToOutlook:SyncItemByTypeForAccount");
							break;

						case "contact":
							SyncItemByType(syncData[j], SubscriptionId, c_wzTagIdContact, c_wzContactColumnSetInsert, c_wzContactColumnSetDelete, "SyncToOutlook:SyncItemByTypeForContact");
							break;

						case "task":
							SyncItemByType(syncData[j], SubscriptionId, c_wzTagIdActivity, c_wzTaskColumnSetInsert, c_wzTaskColumnSetDelete, "SyncToOutlook:SyncItemByTypeForTask");
							break;

						case "recurringappointmentmaster":
							SyncItemByType(syncData[j], SubscriptionId, c_wzTagIdActivity, c_wzRecurringeApptColumnSetInsert, c_wzRecurringApptColumnSetDelete, "SyncToOutlook:SyncItemByTypeForRecurringAppt");
							break;

						case "appointment":
							SyncItemByType(syncData[j], SubscriptionId, c_wzTagIdActivity, c_wzApptColumnSetInsert, c_wzApptColumnSetDelete, "SyncToOutlook:SyncItemByTypeForAppt");
							break;

						case "serviceappointment":
							SyncItemByType(syncData[j], SubscriptionId, c_wzTagIdActivity, c_wzServiceApptColumnSetInsert, c_wzServiceApptColumnSetDelete, "SyncToOutlook:SyncItemByTypeForServiceAppt");
							break;

						default:
							break;
					}
				}

				ReportOnlineSubscriptionSyncInfo();

				dtFinish = DateTime.Now;
				if (sdr != null)
					sdr.MoveData = dtFinish - dtStart;

				System.Diagnostics.Trace.WriteLine(string.Format("User: {0} SyncEnd: {1}", m_userName, DateTime.Now.ToString()));
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
		}

		#endregion

		#region Private Methods
		/// <summary>
		/// Report statistics after outlook sync and go offline sync.
		/// Calls CreateSubscriptionSyncInfo SDK method
		/// </summary>
		private void ReportOnlineSubscriptionSyncInfo()
		{
			if (string.IsNullOrEmpty(SubscriptionId))
			{
				CreateOnlineSubscription();
			}

			// report statistics to server: this information does not need to be accurate
			Entity syncInfo = new Entity("subscriptionsyncinfo");
			syncInfo["subscriptionid"] = new EntityReference("subscription", new Guid(subscriptionId));
			syncInfo["datasize"] = Utils.GetRandomInt(1, 10);
			syncInfo["deleteobjectcount"] = Utils.GetRandomInt(1, 10);
			syncInfo["insertobjectcount"] = Utils.GetRandomInt(1, 10);
			syncInfo["syncresult"] = true;
			syncInfo["clientversion"] = "5.0.9688.583";

			CreateSubscriptionSyncInfoRequest request = new CreateSubscriptionSyncInfoRequest();
			request.Target = syncInfo;
			TestContext.BeginTimer("SyncToOutlook:CreateSubscriptionSyncInfo");
			this.serviceCreator.OrganizationService.Execute(request);
			TestContext.EndTimer("SyncToOutlook:CreateSubscriptionSyncInfo");
		}

		private XmlDocument CreateXmlDocument(string xml)
		{
			XmlTextReader reader = new XmlTextReader(new StringReader(xml));

			reader.DtdProcessing = DtdProcessing.Prohibit;
			reader.WhitespaceHandling = WhitespaceHandling.Significant;

			XmlDocument xmlDoc = new XmlDocument();

			// Set XmlResolver to null to prevent usage of the default XmlResolver.
			xmlDoc.XmlResolver = null;

			xmlDoc.Load(reader);
			reader.Close();

			return xmlDoc;
		}

		private int ConvertAttributeToInt(XmlAttribute attribute)
		{
			if (attribute == null)
				return 0;

			try
			{
				int count = Int32.Parse(attribute.Value);
				return count;
			}
			catch
			{
				throw new CrmArgumentException("Cannot convert attribute to integer.", attribute.Value);
			}
		}

		private void CreateOnlineSubscription()
		{
			IOrganizationService orgService = serviceCreator.OrganizationService;
			string clientId = String.Empty;
			try
			{
				Entity subscrClient = new Entity("subscriptionclients");
				subscrClient["machinename"] = Environment.UserDomainName + "\\" + Environment.MachineName;

				CreateOutlookSubscriptionSubscriptionClientsRequest request = new CreateOutlookSubscriptionSubscriptionClientsRequest();
				request.Target = subscrClient;

				CreateOutlookSubscriptionSubscriptionClientsResponse response = (CreateOutlookSubscriptionSubscriptionClientsResponse)orgService.Execute(request);

				// Actually it's a clientId
				Guid clientIdGuid = response.id;

				clientId = clientIdGuid.ToString("B").ToUpper();

				// Retrieve subscription id
				RetrieveClientSubscriptionSubscriptionClientsRequest reqRetrieve = new RetrieveClientSubscriptionSubscriptionClientsRequest();
				reqRetrieve.ClientId = clientIdGuid;
				ColumnSet columnSet = new ColumnSet();
				columnSet.Columns.Add("subscriptionid");
				reqRetrieve.ColumnSet = columnSet;
				TestContext.BeginTimer("SyncToOutlook:CreateSubscription");
				RetrieveClientSubscriptionSubscriptionClientsResponse respRetrieve = (RetrieveClientSubscriptionSubscriptionClientsResponse)orgService.Execute(reqRetrieve);
				TestContext.EndTimer("SyncToOutlook:CreateSubscription");
				Guid subscriptionId = ((Guid)respRetrieve.Entity["subscriptionid"]);

				ClientId = clientId;

				SubscriptionId = subscriptionId.ToString("B").ToUpper();

				Console.WriteLine(string.Format("User: {0} {1} {2}", m_userName, subscriptionId.ToString(), DateTime.Now.ToString()));

				if (IsPrimaryOnlineClient(clientId) == false)
				{
					Console.WriteLine(string.Format("User: {0} Setting this primary client {1}", m_userName, DateTime.Now.ToString()));
					SetPrimaryOnlineClient(clientId);
				}
			}
			catch (SoapException e)
			{
				throw e;
			}
		}
		/// <summary>
		/// Returns the value returned from the IsPrimaryOnlineClient API
		/// on the SyncService.
		/// </summary>
		/// <param name="clientId"></param>
		/// <returns></returns>
		private bool IsPrimaryOnlineClient(String clientId)
		{
			IOrganizationService orgService = serviceCreator.OrganizationService;
			IsPrimaryClientSubscriptionClientsRequest request = new IsPrimaryClientSubscriptionClientsRequest();
			request.ClientId = new Guid(clientId);
			IsPrimaryClientSubscriptionClientsResponse response;
			try
			{
				response = (IsPrimaryClientSubscriptionClientsResponse)orgService.Execute(request);
			}
			catch (Exception e)
			{
				throw e;
			}
			return response.isPrimaryClient;
		}

		/// <summary>
		/// Invokes the SetPrimaryClient API on the SyncService.
		/// </summary>
		/// <param name="clientId"></param>
		private void SetPrimaryOnlineClient(String clientId)
		{
			IOrganizationService orgService = serviceCreator.OrganizationService;
			SetPrimaryClientSubscriptionClientsRequest request = new SetPrimaryClientSubscriptionClientsRequest();
			request.ClientId = new Guid(clientId);
			try
			{

				orgService.Execute(request);
			}
			catch (Exception e)
			{
				throw e;
			}
		}

		/// <summary>
		/// Invokes Prepare Outlook Sync on the sync service.
		/// </summary>
		/// <param name="clientId"></param>
		/// <returns></returns>
		private String PrepareOnlineSync()
		{
			IOrganizationService orgService = serviceCreator.OrganizationService;
			PrepareOutlookSyncSubscriptionClientsRequest request = new PrepareOutlookSyncSubscriptionClientsRequest();
			request.ClientId = new Guid(ClientId);
			PrepareOutlookSyncSubscriptionClientsResponse response;
			try
			{
				TestContext.BeginTimer("SyncToOutlook:DoPrepareSync");
				response = (PrepareOutlookSyncSubscriptionClientsResponse)orgService.Execute(request);
				TestContext.EndTimer("SyncToOutlook:DoPrepareSync");
			}
			catch (Exception e)
			{
				throw e;
			}
			return response.SyncInfoXml;
		}

		/// <summary>
		/// Invokes the PostOutlookSync on the SyncService.
		/// </summary>
		/// <param name="clientId"></param>
		/// <param name="entityName"></param>
		/// <param name="syncAction"></param>
		/// <param name="batchSize"></param>
		private void PostOnlineSync(String clientId, String entityName, SyncAction syncAction, int batchSize, string transactionName)
		{
			IOrganizationService orgService = serviceCreator.OrganizationService;
			PostOutlookSyncSubscriptionClientsRequest request = new PostOutlookSyncSubscriptionClientsRequest();
			request.ClientId = new Guid(clientId);
			request.BatchSize = batchSize;
			request.EntityName = entityName;
			request.SyncAction = syncAction;
			try
			{
				TestContext.BeginTimer(transactionName);
				orgService.Execute(request);
				TestContext.EndTimer(transactionName);
			}
			catch (Exception e)
			{
				throw e;
			}
		}

		private int GetData(XPathNodeIterator iterator, ref SyncInfo[] syncData, ref int total)
		{
			int insertCount = 0;
			int deleteCount = 0;

			int index = 0;

			TestContext.BeginTimer("SyncToOutlook:GetData");
			while (iterator.MoveNext())
			{
				XmlNode node = ((IHasXmlNode)iterator.Current).GetNode();
				XmlAttributeCollection xmlAttributes = node.Attributes;

				String entityName = xmlAttributes["name"].Value;

				deleteCount = ConvertAttributeToInt(xmlAttributes["delete_count"]);
				insertCount = ConvertAttributeToInt(xmlAttributes["insert_count"]);
				syncData[index] = new SyncInfo();
				syncData[index].entityName = entityName;
				syncData[index].deleteCount = deleteCount;
				syncData[index].insertCount = insertCount;

				System.Diagnostics.Trace.WriteLine("Entity:" + syncData[index].entityName);
				System.Diagnostics.Trace.WriteLine("deleteCount:" + syncData[index].deleteCount);
				System.Diagnostics.Trace.WriteLine("insertCount:" + syncData[index].insertCount);

				index++;
				total += insertCount + deleteCount;
			}
			TestContext.EndTimer("SyncToOutlook:GetData");
			return index;
		}

		/// <summary>
		/// Invokes the GetOutlookSyncData on the SyncService.
		/// </summary>
		/// <param name="clientId"></param>
		/// <param name="entityName"></param>
		/// <param name="syncAction"></param>
		/// <param name="batchSize"></param>
		/// <param name="columnSetXml"></param>
		/// <returns></returns>
		private String GetOnlineData(String clientId, String entityName, SyncAction syncAction, int batchSize, String columnSetXml)
		{
			IOrganizationService orgService = serviceCreator.OrganizationService;
			GetOutlookSyncDataSubscriptionClientsRequest request = new GetOutlookSyncDataSubscriptionClientsRequest();
			request.ClientId = new Guid(clientId);
			request.BatchSize = batchSize;
			request.ColumnSetXml = columnSetXml;
			request.EntityName = entityName;
			request.SyncAction = syncAction;
			GetOutlookSyncDataSubscriptionClientsResponse response;
			try
			{
				response = (GetOutlookSyncDataSubscriptionClientsResponse)orgService.Execute(request);
			}
			catch (Exception e)
			{
				throw e;
			}
			return response.SyncDataXml;
		}


		private void SyncItemByType(SyncInfo syncData, string id, string flag, string insertSet, string deleteSet, string transactionName)
		{
			int numberofItems = syncData.insertCount + syncData.deleteCount;

			System.Diagnostics.Trace.WriteLine(string.Format("User: {0} numberofItems: {1} {2}", m_userName, numberofItems, DateTime.Now.ToString()));
			if (numberofItems == 0)
				return;

			bool moreRecords = true;
			if (syncData.deleteCount > 0)
			{
				while (moreRecords)
				{
					string deletedItems = GetOnlineData(ClientId, syncData.entityName, SyncAction.Delete, DELETED_ITEMS_BATCH_SIZE, deleteSet);
					XmlDocument doc = CreateXmlDocument(deletedItems);
					XmlNodeList delNodeList = doc.FirstChild.ChildNodes;
					XmlNodeList delNodes = delNodeList[0].ChildNodes;

					if (delNodes.Count == 0)
					{
						moreRecords = false;
						continue;
					}

					for (int i = 0; i < delNodes.Count; i++)
					{
						XmlNode node = delNodes[i];

					}

					PostOnlineSync(ClientId, syncData.entityName, SyncAction.Delete, DELETED_ITEMS_BATCH_SIZE, transactionName);
				}
			}

			if (syncData.insertCount > 0)
			{
				moreRecords = true;
				while (moreRecords)
				{
					string insertedItems = GetOnlineData(ClientId, syncData.entityName, SyncAction.Insert, INSERTED_ITEMS_BATCH_SIZE, insertSet);
					XmlDocument doc = CreateXmlDocument(insertedItems);

					XmlNodeList BusinessEntities = doc.FirstChild.ChildNodes;
					XmlNodeList BusinessEntityList = BusinessEntities[0].ChildNodes;

					if (BusinessEntityList.Count == 0)
					{
						moreRecords = false;
						continue;
					}

					for (int i = 0; i < BusinessEntityList.Count; i++)
					{
						XmlNode node = BusinessEntityList[i];
					}
					PostOnlineSync(ClientId, syncData.entityName, SyncAction.Insert, INSERTED_ITEMS_BATCH_SIZE, transactionName);
				}
			}
		}

		private void CreateRegistryForUser(System.Net.NetworkCredential nc)
		{
			string userId = m_user["systemuserid"];
			string businessId = m_user["businessunitid"];

			RegistryKey userRegKey = Registry.CurrentUser.OpenSubKey(m_clientKeyPath, true);
			if (userRegKey == null)
				userRegKey = Registry.CurrentUser.CreateSubKey(m_clientKeyPath);

			//we need to create - BusinessId, UserId, ServerUrl
			userRegKey.SetValue("BusinessId", "{" + businessId + "}", RegistryValueKind.String);
			userRegKey.SetValue("UserId", "{" + userId + "}", RegistryValueKind.String);
			userRegKey.SetValue("ServerUrl", m_CrmServer + "/MSCRMServices", RegistryValueKind.String);
		}

		#endregion
	}

	public class SyncInfo
	{
		public int insertCount;
		public int deleteCount;
		public string entityName;
	}

	public class MySyncDataRecorder
	{
		public TimeSpan CreateSubscription;
		public TimeSpan PrepareSync;
		public TimeSpan GetSyncInfo;
		public String SyncInfo;
		public TimeSpan SchemaChanges;
		public TimeSpan MoveData;

		public XmlElement SerializeToXML(XmlDocument xmld)
		{
			XmlElement el;
			XmlAttribute att;
			el = xmld.CreateElement("Sync_Data");
			att = xmld.CreateAttribute("CreateSubscription");
			att.Value = CreateSubscription.ToString();
			el.Attributes.Append(att);
			att = xmld.CreateAttribute("PrepareSync");
			att.Value = PrepareSync.ToString();
			el.Attributes.Append(att);

			if (SyncInfo != null)
			{
				int count = ParseSyncInfo(SyncInfo);
				att = xmld.CreateAttribute("TotalEntity");
				att.Value = count.ToString();
				el.Attributes.Append(att);
				el.InnerXml = SyncInfo;
			}

			att = xmld.CreateAttribute("MoveData");
			att.Value = MoveData.ToString();
			el.Attributes.Append(att);

			return (el);
		}

		//this is to get total number of records
		public int ParseSyncInfo(string SyncInfo)
		{
			int count = 0;
			string nl = System.Environment.NewLine;
			string[] lines = SyncInfo.Split(new char[] { '/' });

			for (int i = 0; i < lines.Length - 1; i++)
			{
				//we need to get insert_count from each line
				string[] equals = lines[i].Split(new char[] { '=' });

				if (equals.Length == 3)
				{
					string countS = equals[2];
					countS = countS.Replace("\"", "");
					count = count + Convert.ToInt32(countS);
				}
				else
				{
					if (equals.Length > 3)
					{
						//we might have delete count too
						string countS = equals[2];
						countS = countS.Replace("\"", "");
						string[] insertCountS = countS.Split(new char[] { ' ' });
						countS = insertCountS[0];
						System.Diagnostics.Trace.WriteLine("countS:" + countS);
						count = count + Convert.ToInt32(countS);

						//insert count
						countS = equals[3];
						countS = countS.Replace("\"", "");
						count = count + Convert.ToInt32(countS);
					}
				}
			}
			return count;
		}
	}
}
