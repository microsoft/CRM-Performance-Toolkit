﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using CRM_Perf_BenchMark.Utilities;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting Appointment entity
	/// </summary>
	[TestClass]
	public class ExchangeAppointmentCRUDUnitTest : CreateBasicExchangeEntityBaseTest
	{
		/// <summary>
		/// Entity used to query EMDB for the entity data
		/// </summary>
		public override string EntityName
		{
			get { return EntityNames.ExchangeAppointment; }
		}

		/// <summary>
		/// Overide for to print the entity Data
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public override string PrintEntityData(Entity entity)
		{
			return String.Format("attributes are Appointment subject. Subject={0} ", entity["subject"].ToString());
		}

		/// <summary>
		/// Test creating an appointment
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create__ExchangeAppointment()
		{
			Init();
			string contactId;
			string timer = "Exchange Appointment Create Unit Test";
			Entity appointment = CreateAppointment();
			contactId = this.CreateEntityInExchange(appointment, timer);
			Guid g = EntityManager.Instance.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.ExchangeAppointment, g, new string[] { "OwnerId", "ExchangeID", "EntityManagerOwningUser", "Subject" }, new string[] { m_user["systemuserid"], contactId, g.ToString(), appointment.Attributes["subject"].ToString() });
		}

		/// <summary>
		/// test retrieving and updating a Appointment
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_ExchangeAppointment()
		{
			//find a Entity for update test
			string timerName = "Update Exchange Appointment";
			Init("subject", "exchange update");
			this.UpdateEntityInExchange(this.EntityName, m_contact, timerName, Utils.GetRandomString(5, 10) + " exchange update");
		}

		/// <summary>
		/// test deleting an Appointment
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_ExchangeAppointment()
		{
			//find a Entity for update test
			string timerName = "Update Exchange Appointment";
			Init("subject", "exchange del");
			this.DeleteEntityInExchange(this.EntityName, m_contact, timerName);
			EntityManager.Instance.DeleteEntity(m_contact);
		}

		private Entity CreateAppointment()
		{
			Entity appointment = new Entity("appointment");
			appointment["subject"] = Utils.GetRandomString(5, 10) + " exchange del";
			appointment["location"] = Utils.GetRandomString(50, 100);
			//Todo don't like using date time now 
			DateTime now = DateTime.Now;
			appointment["scheduledstart"] = now;
			int increment = Utils.GetRandomInt(1, 5);
			appointment["scheduledend"] = now.AddHours(increment);
			appointment["scheduleddurationminutes"] = increment * 60;
			appointment["isalldayevent"] = false;            

			appointment["owninguser"] = CreateEntityForSystemUser();

			return appointment;
		}
	}
}
