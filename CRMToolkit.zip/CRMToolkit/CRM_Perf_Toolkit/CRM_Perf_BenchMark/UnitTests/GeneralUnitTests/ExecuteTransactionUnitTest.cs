﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services.Protocols;
using Microsoft.Crm.Sdk;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class ExecuteTransactionUnitTest : UnitTestBase
	{
		[TestInitialize]
		public override void Initialize()
		{
			//Rollup DB Populator generates the record in the custom entity tables which are mapped to "System Administrator" role. 
			//Hence setting the UserRole as "System Administrator" and user(DomainName) to "administrator".
			TestContext.Properties["UserRole"] = "System Administrator";
			TestContext.Properties["DomainName"] = "administrator";
			base.Initialize();

			// Loading the settings
			System.Net.ServicePointManager.DefaultConnectionLimit = 100;
			_maxNumberOfBatches = ExecuteTransactionConstants.TotalEntities / ExecuteTransactionConstants.BatchSize;
			_totalIterationsPerThread = _maxNumberOfBatches / ExecuteTransactionConstants.MaxThreads;
		}

		[TestMethod]
		public void ExecuteTransaction_Create_CustomAccounts()
		{
			List<ExecuteTransactionProxyRequestList> et_RequestLists = GetETProxyRequestLists(MessageName.Create);

			TestContext.BeginTimer("ExecuteTransaction_Create_CustomAccounts UnitTest");
			List<ExecuteTransactionProxyResponse> responses = ExecuteETProxyRequestLists(et_RequestLists);
			TestContext.EndTimer("ExecuteTransaction_Create_CustomAccounts UnitTest");

			Guid ownerId = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user[EntityIDNames.Organization]));

			foreach (ExecuteTransactionProxyResponse proxyResponse in responses)
			{
				if (proxyResponse.Exception != null)
				{
					HandleException(proxyResponse.Exception, "ExecuteTransaction_Create_CustomAccounts");
				}
				else
				{
					// If there are no exceptions, that means all the requests were successful
					for (int index = 0; index < proxyResponse.Request.Requests.Count; index++)
					{
						Guid customAccountId = (Guid)proxyResponse.Response.Responses[index]["id"];
						if (customAccountId != Guid.Empty)
						{
							Entity sourceCustomAccount = proxyResponse.Request.Requests[index]["Target"] as Entity;
							if (sourceCustomAccount != null)
							{
								String customAccountName = sourceCustomAccount[_primaryNameAttribute] as String;

								// Add the account to EMDB also
								EntityManager.Instance.AddEntity(EntityNames.New_CustomAccount, ownerId,
									new string[] { "ownerid", _primaryKeyAttribute, _primaryNameAttribute, "EntityManagerOwningUser" },
									new string[] { m_user[EntityIDNames.User], customAccountId.ToString(), customAccountName, ownerId.ToString() });
							}
						}
						else
						{
							Trace.WriteLine("ExecuteTransaction_Create_CustomAccounts : CreateRequest Failed");
						}
					}
				}
			}
		}

		[TestMethod]
		public void ExecuteTransaction_Retrieve_CustomAccounts()
		{
			List<ExecuteTransactionProxyRequestList> et_RequestLists = GetETProxyRequestLists(MessageName.Retrieve);

			TestContext.BeginTimer("ExecuteTransaction_Create_CustomAccounts UnitTest");
			List<ExecuteTransactionProxyResponse> responses = ExecuteETProxyRequestLists(et_RequestLists);
			TestContext.EndTimer("ExecuteTransaction_Create_CustomAccounts UnitTest");

			foreach (ExecuteTransactionProxyResponse proxyResponse in responses)
			{
				if (proxyResponse.Exception != null)
				{
					HandleException(proxyResponse.Exception, "ExecuteTransaction_Retrieve_CustomAccounts");
				}
			}
		}

		[TestMethod]
		public void ExecuteTransaction_Update_CustomAccounts()
		{
			List<ExecuteTransactionProxyRequestList> et_RequestLists = GetETProxyRequestLists(MessageName.Update);

			TestContext.BeginTimer("ExecuteTransaction_Update_CustomAccounts UnitTest");
			List<ExecuteTransactionProxyResponse> responses = ExecuteETProxyRequestLists(et_RequestLists);
			TestContext.EndTimer("ExecuteTransaction_Update_CustomAccounts UnitTest");

			foreach (ExecuteTransactionProxyResponse proxyResponse in responses)
			{
				if (proxyResponse.Exception != null)
				{
					HandleException(proxyResponse.Exception, "ExecuteTransaction_Update_CustomAccounts");
				}
			}
		}

		[TestMethod]
		public void ExecuteTransaction_Delete_CustomAccounts()
		{
			List<ExecuteTransactionProxyRequestList> et_RequestLists = GetETProxyRequestLists(MessageName.Delete);

			TestContext.BeginTimer("ExecuteTransaction_Create_CustomAccounts UnitTest");
			List<ExecuteTransactionProxyResponse> responses = ExecuteETProxyRequestLists(et_RequestLists);
			TestContext.EndTimer("ExecuteTransaction_Create_CustomAccounts UnitTest");

			foreach (ExecuteTransactionProxyResponse proxyResponse in responses)
			{
				if (proxyResponse.Exception != null)
				{
					HandleException(proxyResponse.Exception, "ExecuteTransaction_Delete_CustomAccounts");
				}
				else
				{
					// If there are no exceptions, that means all the requests were successful
					for (int index = 0; index < proxyResponse.Request.Requests.Count; index++)
					{
						EntityReference customAccountReference = proxyResponse.Request.Requests[index]["Target"] as EntityReference;
						if (null != customAccountReference)
						{
							Guid ownerId = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user[EntityIDNames.Organization]));

							// Removing the "deletable" string from primaryname
							CRMEntity entity = _customAccounts[customAccountReference.Id];
							entity[_primaryNameAttribute] = entity[_primaryNameAttribute].Split(new[] { EntityManager.IsDeletableFlag }, StringSplitOptions.RemoveEmptyEntries)[0];
							EntityManager.Instance.UpdateEntity(ref entity, EntityNames.New_CustomAccount, ownerId, new string[] { _primaryNameAttribute }, new string[] { entity[_primaryNameAttribute] }, _primaryKeyAttribute, entity[_primaryKeyAttribute]);

							// This will the entitystate to Deleted
							EntityManager.Instance.DeleteEntity(entity);
						}
					}
				}
			}
		}

		private List<ExecuteTransactionProxyRequestList> GetETProxyRequestLists(string requestName)
		{
			var et_proxyRequestLists = new List<ExecuteTransactionProxyRequestList>();
			for (int i = 0; i < _totalIterationsPerThread; i++)
			{
				ExecuteTransactionProxyRequestList proxyList = new ExecuteTransactionProxyRequestList();
				for (int y = 0; y < ExecuteTransactionConstants.MaxThreads; y++)
				{
					ExecuteTransactionRequest request = GetExecuteTransactionRequest(requestName, ExecuteTransactionConstants.BatchSize);

					ExecuteTransactionProxyRequest proxyRequest = new ExecuteTransactionProxyRequest { Proxy = Proxy, Request = request };
					proxyList.Add(proxyRequest);
				}
				et_proxyRequestLists.Add(proxyList);
			}
			return et_proxyRequestLists;
		}

		private ExecuteTransactionRequest GetExecuteTransactionRequest(string requestName, int batchSize)
		{
			ExecuteTransactionRequest request = new ExecuteTransactionRequest();
			request.Requests = new OrganizationRequestCollection();
			for (int i = 0; i < batchSize; i++)
			{
				request.Requests.Add(GetOrganizationRequest(requestName));
			}
			request.ReturnResponses = true;
			return request;
		}

		private OrganizationRequest GetOrganizationRequest(string requestName)
		{
			var request = new OrganizationRequest { RequestName = requestName };
			request.RequestId = Guid.NewGuid();

			Entity entity = new Entity(_entityLogicalName);

			switch (requestName)
			{
				case MessageName.Create:
					entity[_primaryNameAttribute] = Utils.GetRandomString(5, 30) + EntityManager.IsDeletableFlag + " object";
					request.Parameters["Target"] = entity;
					break;

				case MessageName.Retrieve:
					Guid id = GetRandomCustomAccountId();
					request.Parameters["Target"] = new EntityReference(_entityLogicalName, id);
					request.Parameters["ColumnSet"] = new ColumnSet(new String[] { _primaryNameAttribute, "ownerid" });
					break;

				case MessageName.Update:
					Guid id2 = GetRandomCustomAccountId();
					entity[_primaryNameAttribute] = Utils.GetRandomString(5, 30) + EntityManager.IsDeletableFlag + " object";
					entity.Id = id2;
					request.Parameters["Target"] = entity;
					break;

				case MessageName.Delete:
					Guid id3 = GetRandomCustomAccountId();
					request.Parameters["Target"] = new EntityReference(_entityLogicalName, id3);
					break;
			}
			return request;
		}

		private void LoadCustomAccounts()
		{
			EntityRequest entityRequest = new EntityRequest();
			entityRequest.Type = EntityNames.New_CustomAccount;
			entityRequest.ParentID = new Guid(m_user[EntityIDNames.User]);
			entityRequest.GrandParentID = new Guid(m_user[EntityIDNames.Organization]);
			entityRequest.ReturnAs = EntityNames.New_CustomAccount;

			Hashtable accountProps = new Hashtable();
			accountProps.Add(EntityManager.AppendFilter, GetFilterStringForCustomAccount());
			entityRequest.Props = accountProps;

			CRMEntity[] entities;
			try
			{
				// Loading new_customaccounts from EntityManager
				entities = EntityManager.Instance.GetAllRecordsForEntity(entityRequest, ExecuteTransactionConstants.TotalEntities);
				if (entities.Length < ExecuteTransactionConstants.TotalEntities)
				{
					throw new EntityNotFoundException("");
				}
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("ExecuteTransactionUnitTests__LoadCustomAccounts: Could not find any existing customaccounts, therefore creating some now");
				ExecuteTransaction_Create_CustomAccounts();
				entities = EntityManager.Instance.GetAllRecordsForEntity(entityRequest, ExecuteTransactionConstants.TotalEntities);
			}

			foreach (var entity in entities)
			{
				_customAccounts.Add(Guid.Parse(entity[_primaryKeyAttribute]), entity);
			}
			_remainingCustomAccountIds.Clear();
			_remainingCustomAccountIds.AddRange(_customAccounts.Keys);
		}

		private Guid GetRandomCustomAccountId()
		{
			if (_customAccounts.Count == 0)
			{
				LoadCustomAccounts();
			}

			Random random = new Random();
			Guid randomId = _remainingCustomAccountIds[random.Next(0, _remainingCustomAccountIds.Count - 1)];
			_remainingCustomAccountIds.Remove(randomId);
			return randomId;
		}

		private List<ExecuteTransactionProxyResponse> ExecuteETProxyRequestLists(List<ExecuteTransactionProxyRequestList> requestLists)
		{
			List<ExecuteTransactionProxyResponse> responses = new List<ExecuteTransactionProxyResponse>();
			foreach (var proxyRequestList in requestLists)
			{
				Parallel.ForEach(proxyRequestList, (request) =>
				{
					ExecuteTransactionProxyResponse executeTransactionResponse = new ExecuteTransactionProxyResponse();
					executeTransactionResponse.Request = request.Request;

					try
					{
						executeTransactionResponse.Response = request.Proxy.Execute(request.Request) as ExecuteTransactionResponse;
					}
					catch (Exception e)
					{
						executeTransactionResponse.Exception = e;
					}
					responses.Add(executeTransactionResponse);
				});
			}
			return responses;
		}

		private void HandleException(Exception exception, string prefixMessage)
		{
			var fe = exception as FaultException<OrganizationServiceFault>;
			if (fe != null)
			{
				ExecuteTransactionFault etFault = fe.Detail as ExecuteTransactionFault;
				if (etFault != null)
				{
					Trace.WriteLine(etFault.Message);
					Trace.WriteLine(prefixMessage + " : FaultedRequestIndex = " + etFault.FaultedRequestIndex);
				}
				Trace.WriteLine(fe.StackTrace);
			}
			SoapException se = exception as SoapException;
			if (se != null)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
			}
		}

		private string GetFilterStringForCustomAccount()
		{
			return string.Format("{0} like '%{1}%' AND {2} = {3}", 
							_primaryNameAttribute,
							EntityManager.IsDeletableFlag,
							EntityManager.EntityManagerStateCode, 
							(int)EntityStates.Free);
		}

		#region Private Fields
		private int _maxNumberOfBatches;
		private int _totalIterationsPerThread;

		private Dictionary<Guid, CRMEntity> _customAccounts = new Dictionary<Guid, CRMEntity>();
		private List<Guid> _remainingCustomAccountIds = new List<Guid>();

		private string _entityLogicalName = EntityNames.New_CustomAccount;
		private string _primaryKeyAttribute = EntityIDNames.New_CustomAccount;
		private string _primaryNameAttribute = "new_name";
		#endregion
	}

	internal class ExecuteTransactionConstants
	{
		public const int BatchSize = 1000;
		public const int MaxThreads = 1;
		public const int TotalEntities = 1000;
	}

	internal sealed class MessageName
	{
		public const string Create = "Create";
		public const string Retrieve = "Retrieve";
		public const string Update = "Update";
		public const string Delete = "Delete";
	}

	internal sealed class ExecuteTransactionProxyRequestList : List<ExecuteTransactionProxyRequest>
	{
	}

	internal sealed class ExecuteTransactionProxyRequest
	{
		internal IOrganizationService Proxy { get; set; }
		internal ExecuteTransactionRequest Request { get; set; }
	}

	internal sealed class ExecuteTransactionProxyResponse
	{
		internal ExecuteTransactionRequest Request { get; set; }
		internal ExecuteTransactionResponse Response { get; set; }
		internal Exception Exception { get; set; }
	}
}
