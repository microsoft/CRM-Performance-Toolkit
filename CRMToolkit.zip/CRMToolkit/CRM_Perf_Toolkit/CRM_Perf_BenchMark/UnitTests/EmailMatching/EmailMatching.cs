using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml;
using System.Net;
using System.IO;
using System.Web.Services.Protocols;
using System;
//using Microsoft.Crm.Sdk.Proxy;

using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.EmailMatching
{
	/// <summary>
	/// Summary description for DMUnitTest1
	/// </summary>
	[TestClass]
	public class EmailMatchingUnitTests : UnitTestBase
	{
		private readonly int numOfRecipients = 3;
		private CRMEntity sender;
		private CRMEntity[] recipients;
		private EmailUnitTestHelp euth = new EmailUnitTestHelp();
		IOrganizationService proxy1, proxy2;
		#region Additional test attributes


		// Use TestInitialize to run code before running each test 
		[TestInitialize()]
		public void TestInitialize()
		{
			base.Initialize();
			System.Collections.ArrayList lockedUsers = new System.Collections.ArrayList();
			recipients = new CRMEntity[numOfRecipients];

			Guid orgId = EntityManager.Instance.GetRandomOrg();

			sender = m_user;
			lockedUsers.Add(sender);

			try
			{
				string userRole = string.Empty;
				if (TestContext.Properties["userRole"] != null)
				{
					userRole = "Customer Service Representative";
				}
				recipients = EntityManager.Instance.GetRandomUserRecipients(userRole, orgId);
			}
			catch (EntityNotFoundException nf)
			{
				//release all the locked users
				foreach (CRMEntity lockedUser in lockedUsers)
				{
					EntityManager.Instance.FreeUser(lockedUser);
				}
				throw nf;
			}
			proxy1 = EntityManager.Instance.GetTestUserProxy(sender);
			proxy2 = EntityManager.Instance.GetTestUserProxy(recipients[0]);
		}


		// Use TestCleanup to run code after each test has run
		[TestCleanup()]
		public void TestCleanup()
		{
			//release all the locked users
			EntityManager.Instance.FreeUser(sender);
			foreach (CRMEntity lockedUser in recipients)
			{
				if (null != lockedUser)
				{
					EntityManager.Instance.FreeUser(lockedUser);
				}
			}
		}

		#endregion

		#region Individual Test Cases

		[TestMethod()]
		public void OutgoingTest()
		{
			string subject = this.GenerateRandomText(5);
			string recipient5 = "random_2@external.address.com";

			DeliverPromoteEmailRequest deliverPromoteEmailRequest = euth.ComposePromoteEmailRequest(subject, new EntityCollection(), "activitymimeattachment", ConstructAddressList(recipients), ConstructAddressList(new CRMEntity[] { sender }), recipient5, String.Empty, Guid.NewGuid().ToString(), GenerateRandomText(1000), "high", DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Local), ConstructAddressList(new CRMEntity[] { sender }));
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("DeliverPromote");
			DeliverPromoteEmailResponse deliverPromoteEmailResponse = proxy1.Execute(deliverPromoteEmailRequest) as DeliverPromoteEmailResponse;
			TestContext.EndTimer("DeliverPromote");
			SendEmailRequest sendEmailRequest = new SendEmailRequest();
			sendEmailRequest.EmailId = deliverPromoteEmailResponse.EmailId;
			sendEmailRequest.IssueSend = false;
			sendEmailRequest.TrackingToken = String.Empty;
			TestContext.BeginTimer("SendEmail");
			SendEmailResponse sendEmailResponse = proxy1.Execute(sendEmailRequest) as SendEmailResponse;
			TestContext.EndTimer("SendEmail");
			DateTime end = DateTime.UtcNow;

			System.Diagnostics.Trace.WriteLine("OutgoingTest: DeliverPromote + SendEmail : " + TimeSpan.FromTicks(end.Ticks - start.Ticks).TotalMilliseconds.ToString() + " msec.");
		}

		[TestMethod()]
		public void IncomingSalesTest()
		{
			SetEmailFilteringMethod(recipients[0], 0, proxy2);

			string external = "recipient_1@external.domain.com";
			string subject = this.GenerateRandomText(5);

			DeliverPromoteEmailRequest deliverPromoteEmailRequest = euth.ComposePromoteEmailRequest(subject, new EntityCollection(), "activitymimeattachment", ConstructAddressList(recipients), ConstructAddressList(new CRMEntity[] { sender }), external, String.Empty, Guid.NewGuid().ToString(), GenerateRandomText(1000), "high", DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Local), ConstructAddressList(new CRMEntity[] { sender }));
			TestContext.BeginTimer("DeliverPromote");
			DeliverPromoteEmailResponse deliverPromoteEmailResponse = proxy1.Execute(deliverPromoteEmailRequest) as DeliverPromoteEmailResponse;
			TestContext.EndTimer("DeliverPromote");

			// Simulate email delivery 
			CheckIncomingEmailRequest checkIncomingEmailRequest = new CheckIncomingEmailRequest();
			checkIncomingEmailRequest.Subject = subject;
			checkIncomingEmailRequest.To = deliverPromoteEmailRequest.To;
			checkIncomingEmailRequest.From = deliverPromoteEmailRequest.From;
			checkIncomingEmailRequest.Cc = String.Empty;
			checkIncomingEmailRequest.Bcc = String.Empty;
			checkIncomingEmailRequest.MessageId = deliverPromoteEmailRequest.MessageId;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("CheckIncoming");
			CheckIncomingEmailResponse incomingResponse = proxy2.Execute(checkIncomingEmailRequest) as CheckIncomingEmailResponse;
			TestContext.EndTimer("CheckIncoming");
			DeliverIncomingEmailRequest deliverIncomingRequest = euth.ComposeIncomingEmailRequest(subject, deliverPromoteEmailRequest.Attachments, "activitymimeattachment", deliverPromoteEmailRequest.To, deliverPromoteEmailRequest.From, deliverPromoteEmailRequest.Cc, deliverPromoteEmailRequest.Bcc, deliverPromoteEmailRequest.MessageId, deliverPromoteEmailRequest.Body, "high", DateTime.Now, deliverPromoteEmailRequest.SubmittedBy);
			TestContext.BeginTimer("DeliverIncoming");
			DeliverIncomingEmailResponse deliverIncomingEmailResponse = proxy2.Execute(deliverIncomingRequest) as DeliverIncomingEmailResponse;
			TestContext.EndTimer("DeliverIncoming");
			DateTime end = DateTime.UtcNow;

			System.Diagnostics.Trace.WriteLine("IncomingSalesTest: CheckIncoming + DeliverIncoming : " + TimeSpan.FromTicks(end.Ticks - start.Ticks).TotalMilliseconds.ToString() + " msec.");
		}

		[TestMethod()]
		public void IncomingSupportTest()
		{
			SetEmailFilteringMethod(recipients[0], 1, proxy2);

			string external = "recipient_1@external.domain.com";
			string subject = this.GenerateRandomText(5);

			DeliverPromoteEmailRequest deliverPromoteEmailRequest = euth.ComposePromoteEmailRequest(subject, new EntityCollection(), "activitymimeattachment", ConstructAddressList(recipients), ConstructAddressList(new CRMEntity[] { sender }), external, String.Empty, Guid.NewGuid().ToString(), GenerateRandomText(1000), "high", DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Local), ConstructAddressList(new CRMEntity[] { sender }));
			TestContext.BeginTimer("DeliverPromote");
			DeliverPromoteEmailResponse deliverPromoteEmailResponse = proxy1.Execute(deliverPromoteEmailRequest) as DeliverPromoteEmailResponse;
			TestContext.EndTimer("DeliverPromote");

			// Simulate email delivery 
			CheckIncomingEmailRequest checkIncomingEmailRequest = new CheckIncomingEmailRequest();
			checkIncomingEmailRequest.Subject = subject;
			checkIncomingEmailRequest.To = deliverPromoteEmailRequest.To;
			checkIncomingEmailRequest.From = deliverPromoteEmailRequest.From;
			checkIncomingEmailRequest.Cc = String.Empty;
			checkIncomingEmailRequest.Bcc = String.Empty;
			checkIncomingEmailRequest.MessageId = deliverPromoteEmailRequest.MessageId;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("CheckIncoming");
			CheckIncomingEmailResponse incomingResponse = proxy2.Execute(checkIncomingEmailRequest) as CheckIncomingEmailResponse;
			TestContext.EndTimer("CheckIncoming");
			DeliverIncomingEmailRequest deliverIncomingRequest = euth.ComposeIncomingEmailRequest(subject, deliverPromoteEmailRequest.Attachments, "activitymimeattachment", deliverPromoteEmailRequest.To, deliverPromoteEmailRequest.From, deliverPromoteEmailRequest.Cc, deliverPromoteEmailRequest.Bcc, deliverPromoteEmailRequest.MessageId, deliverPromoteEmailRequest.Body, "high", DateTime.Now, deliverPromoteEmailRequest.SubmittedBy);
			TestContext.BeginTimer("DeliverIncoming");
			DeliverIncomingEmailResponse deliverIncomingEmailResponse = proxy2.Execute(deliverIncomingRequest) as DeliverIncomingEmailResponse;
			TestContext.EndTimer("DeliverIncoming");
			DateTime end = DateTime.UtcNow;

			System.Diagnostics.Trace.WriteLine("IncomingSupportTest: CheckIncoming + DeliverIncoming : " + TimeSpan.FromTicks(end.Ticks - start.Ticks).TotalMilliseconds.ToString() + " msec.");
		}

		#endregion

		#region Private Methods

		private string GenerateRandomText(int words)
		{
			StringBuilder subject = new StringBuilder();

			for (int i = 0; i < words; i++)
			{
				subject.Append(Guid.NewGuid().ToString());

				subject.Append(" ");
			}

			return subject.ToString();
		}

		private string ConstructAddressList(CRMEntity[] users)
		{
			StringBuilder address = new StringBuilder();

			for (int i = 0; i < users.Length; i++)
			{
				address.Append(users[i]["InternalEmailAddress"]);
				address.Append(";");
			}
			return address.ToString();
		}

		private void SetEmailFilteringMethod(CRMEntity user, int filterMethod, IOrganizationService Proxy)
		{
			Guid id = new Guid(user["systemuserid"]);

			Entity userSettings = new Entity("usersettings");
			userSettings["systemuserid"] = id;

			OptionSetValue picklist = new OptionSetValue(filterMethod);
			userSettings["IncomingEmailFilteringMethod"] = picklist;

			UpdateUserSettingsSystemUserRequest updateUserSettingsSystemUserRequest = new UpdateUserSettingsSystemUserRequest();
			updateUserSettingsSystemUserRequest.UserId = id;
			updateUserSettingsSystemUserRequest.Settings = userSettings;
			try
			{

				Proxy.Execute(updateUserSettingsSystemUserRequest);
			}
			catch (Exception e)
			{
				throw e;
			}
		}

		#endregion
	}
}
