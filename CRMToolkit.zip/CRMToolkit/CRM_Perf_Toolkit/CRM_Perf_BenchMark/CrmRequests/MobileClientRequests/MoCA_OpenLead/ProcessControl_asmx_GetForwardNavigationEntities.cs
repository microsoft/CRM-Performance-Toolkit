﻿namespace CRM_Perf_BenchMark.CrmRequests.MobileClientRequests.MoCA_OpenLead
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using CRM_Perf_BenchMark.CrmRequests.MobileClientRequests;

	public class ProcessControl_asmx_GetForwardNavigationEntities : MobileClientRequest
	{
		private const string url = "/AppWebServices/ProcessControl.asmx/GetForwardNavigationEntities";
		public ProcessControl_asmx_GetForwardNavigationEntities(CRMEntity user, CRMEntity lead)
			: base(url, user)
		{
			var jsonBodyWrapper = new JsonHttpBodyWrapper(
				new Dictionary<string, object>
				{
					{"currentEntityId", lead[EntityIDNames.Lead]},
					{"referencedEntityLogicalName","lead"},
					{"referencingEntityLogicalName","opportunity"},
					{"referencingEntityAttributeName","originatingleadid"},
				});

			this.Method = "POST";
			this.Body = jsonBodyWrapper.Body;
		}
	}
}
