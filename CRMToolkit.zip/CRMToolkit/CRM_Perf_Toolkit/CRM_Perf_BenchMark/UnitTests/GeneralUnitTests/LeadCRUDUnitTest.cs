﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting Lead entity
	/// </summary>
	[TestClass]
	public class LeadCRUDUnitTest : UnitTestBase
	{
		#region Create a lead
		/// <summary>
		/// Test creating an lead
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_Lead()
		{
			//create an lead
			Guid leadId = Guid.Empty;
			Entity lead = new Entity("lead");
			lead["firstname"] = Utils.GetRandomString(5, 10);
			lead["lastname"] = Utils.GetRandomString(5, 10);

			TestContext.BeginTimer("Lead Create Unit Test");
			try
			{
				leadId = Proxy.Create(lead);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Lead Create Unit Test");
			
			//add the lead to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Leads, g, new string[] { "OwnerId", "LeadID", "FirstName", "LastName", "EntityManagerOwningUser" }, new string[] { m_user["systemuserid"], leadId.ToString(), lead["firstname"].ToString(), lead["lastname"].ToString(), g.ToString() });
		}
		#endregion

		#region Retrieve a lead
		/// <summary>
		/// Test retrieving a lead
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_Lead()
		{
			CRMEntity m_lead = RetrieveTestEntity(m_user, EntityNames.Leads);
			Entity lead = new Entity("lead");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "lastname", "subject" });
			TestContext.BeginTimer("Lead Retrieve Unit Test");
			try
			{
				lead = Proxy.Retrieve(lead.LogicalName, new Guid(m_lead["leadId"]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Lead Retrieve Unit Test");
		}
		#endregion

		#region Update a lead
		/// <summary>
		///test retrieving and updating an lead
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_Lead()
		{
			Entity lead = new Entity("lead");
			//find a CRM Entity for update test
			CRMEntity m_lead = RetrieveTestEntity(m_user, EntityNames.Leads, new Hashtable() { { "LastName", "updatable" } });
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "firstname", "lastname" });
			//get the lead in CRM
			lead = Proxy.Retrieve(lead.LogicalName, new Guid(m_lead["leadId"]), attributes);
			//update lead address city value
			lead["subject"] = Utils.GetRandomString(10, 20);
			//update the lead
			TestContext.BeginTimer("Lead Update Unit Test");
			try
			{
				Proxy.Update(lead);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Lead Update Unit Test");
		}
		#endregion

		#region Delete a lead
		/// <summary>
		/// Test deleting an lead
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_Lead()
		{
			CRMEntity m_lead = RetrieveTestEntity(m_user, EntityNames.Leads, new Hashtable() { { "LastName", "deletable" } });
			TestContext.BeginTimer("Lead Delete Unit Test");
			try
			{
				Proxy.Delete("lead", new Guid(m_lead["leadId"]));

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Lead Delete Unit Test");
			//delete the lead from EMDB
			EntityManager.Instance.DeleteEntity(m_lead);
		}
		#endregion

		#region Retrieve multiple leads
		/// <summary>
		/// Test retrieving multiple lead records
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_lead()
		{
			Entity lead = new Entity("lead");
			var queryExpression = new QueryExpression()
			{
				Distinct = false,
				EntityName = lead.LogicalName,
				ColumnSet = new ColumnSet("subject", "createdon"),

				Criteria =
				{
					Filters = 
						{
							new FilterExpression
							{
								FilterOperator = LogicalOperator.Or,
								Conditions = 
								{
									new ConditionExpression("estimatedvalue", ConditionOperator.GreaterEqual, "1000"),
									new ConditionExpression("estimatedclosedate", ConditionOperator.NextMonth)
									
								   
								},
							},

							new FilterExpression
							{
								FilterOperator = LogicalOperator.And,
								Conditions =
								{
									new ConditionExpression("subject", ConditionOperator.NotNull),
									new ConditionExpression("revenue", ConditionOperator.GreaterThan, "1000000")
								}
							}
							
						   
						}
				}
			};

			EntityCollection results;
			TestContext.BeginTimer("Lead RetrieveMultiple Unit Test");
			try
			{
				results = Proxy.RetrieveMultiple(queryExpression);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Lead RetrieveMultiple Unit Test");

		}
		#endregion
	}
}
