﻿
namespace CRM_Perf_BenchMark.OrionWebTests.MobileClientTests
{
	using System;
	using System.Xml.XPath;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;
	using System.Collections;
	using System.Web;
	using CRM_Perf_BenchMark.CrmRequests;
	using System.Linq;
	using System.Xml.Linq;

	/// <summary>
	/// Account by owner chart
	/// Go to dashboard
	/// Click and hold on Account chart
	/// Click on select chart from command bar
	/// Click on Account by owner chart.
	/// </summary>
	public class MoCA_AccountByOwnerChart : MobileClientWebTestBase
	{
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction("MoCA_AccountByOwnerChart");
			var RetrieveEntitiesForAggregateRequest = new OrganizationServiceExecuteRequest(user, "\\CrmRequests\\MobileClientRequests\\MoCA_AccountByOwnerChart\\MoCA_AccountByOwnerChart_RetrieveEntitiesForAggregateQueryRequest");
			yield return this.PrepareRequest(RetrieveEntitiesForAggregateRequest);
			this.EndTransaction("MoCA_AccountByOwnerChart");
		}
	}
}
