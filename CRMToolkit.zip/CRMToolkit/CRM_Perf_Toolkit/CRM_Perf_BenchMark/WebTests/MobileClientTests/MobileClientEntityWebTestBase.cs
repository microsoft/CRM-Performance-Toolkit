﻿namespace CRM_Perf_BenchMark.OrionWebTests.MobileClientTests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Collections;
	
	public abstract class MobileClientEntityWebTestBase : MobileClientWebTestBase
	{
		public string EntityName;
		public int EntityEtc;
		public string EntityId;
		public string EntityIdName;
		public CRMEntity EntityRecord;
		public string SearchString;

		public MobileClientEntityWebTestBase(string entityName, string entityId)
		{
			this.EntityName = entityName;
			this.EntityId = entityId;
			this.EntityEtc = WebTestHelp.EntityEtc[this.EntityName];
			this.EntityIdName = EntityIDNames.GetByEntityName(this.EntityName);

			this.PreWebTest += new EventHandler<PreWebTestEventArgs>(MobileClientEntityWebTestBase_PreWebTest);
			this.PostWebTest += new EventHandler<PostWebTestEventArgs>(MobileClientEntityWebTestBase_PostWebTest);
		}

		public void MobileClientEntityWebTestBase_PreWebTest(object sender, PreWebTestEventArgs e)
		{
		}

		public void MobileClientEntityWebTestBase_PostWebTest(object sender, PostWebTestEventArgs e)
		{
		}

		public abstract string Operation { get; }

		public abstract IEnumerator<WebTestRequest> GetRequestEnumeratorInternal();

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			if (this.EntityId == null)
			{
				this.EntityRecord = RetrieveTestEntity(user, this.EntityName, null, true);
				this.EntityId = this.EntityRecord[EntityIDNames.GetByEntityName(this.EntityName)];
			}
			else
			{
				this.EntityRecord = RetrieveTestEntity(user, this.EntityName,
					new System.Collections.Hashtable() { { EntityIDNames.GetByEntityName(this.EntityName).ToLowerInvariant(), this.EntityId } });
			}

			if (this.ParentWebTest == null) // create transaction only if there is no parent web test
			{
				this.BeginTransaction("MoCA_" + this.Operation + this.EntityName);
			}

			// Search for the record
			if (!string.IsNullOrEmpty(this.SearchString))
			{
				var searchEntityRequests = this.SearchEntity(this.EntityName, this.SearchString);
				while (searchEntityRequests.MoveNext())
				{
					yield return searchEntityRequests.Current;
				}
			}

			var requests = this.GetRequestEnumeratorInternal();
			while (requests.MoveNext())
			{
				yield return requests.Current;
			}

			if (this.ParentWebTest == null)
			{
				this.EndTransaction("MoCA_" + this.Operation + this.EntityName);
			}

			EntityManager.Instance.FreeEntity(this.EntityRecord);
		}
	}
}
