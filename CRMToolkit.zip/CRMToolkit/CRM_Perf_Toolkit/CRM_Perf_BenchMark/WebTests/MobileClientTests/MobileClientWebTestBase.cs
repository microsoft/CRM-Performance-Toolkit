﻿namespace CRM_Perf_BenchMark
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using CRM_Perf_BenchMark.CrmRequests;
	using CRM_Perf_BenchMark.OrionWebTests.MobileClientTests;

	public abstract class MobileClientWebTestBase : WebTestBase
	{
		private const string ClientName = "MobileClientMacroTest";

		public MobileClientWebTestBase()
		{
			//this.AvailableUserWaitMaxTimeMilliseconds = 2 * 60 * 1000; // Wait up to 2 minutes for an available user

			PreWebTest += new EventHandler<PreWebTestEventArgs>((sender, e) => 
			{ 
				e.WebTest.Context["IsMoCAUser"] = 1;
				base.WebTestBase_PreWebTest(sender, e);
			});

			PostWebTest += new EventHandler<PostWebTestEventArgs>(base.WebTestBase_PostWebTest);
		}

		protected virtual void PrepareRequests(IEnumerable<WebTestRequest> requests)
		{
			foreach (var request in requests)
			{
				this.PrepareRequest(request);
			}
		}

		protected virtual WebTestRequest PrepareRequest(WebTestRequest request)
		{
			if (request != null)
			{
				request.Headers.Add("ClientAppName", ClientName);
				request.Cookies.Add(new Cookie("ReqClientId", ClientName));
			}

			return request;
		}

		protected WebTestRequest GetTransactedRequest(WebTestRequest request, string transactionName)
		{
			request.PreRequest += new EventHandler<PreRequestEventArgs>((sender, e) => { this.BeginTransaction(transactionName); });
			request.PostRequest += new EventHandler<PostRequestEventArgs>((sender, e) => { this.EndTransaction(transactionName); });

			return request;
		}

		protected override string entityName
		{
			get { throw new NotImplementedException(); }
		}

		protected override string siteMapPath
		{
			get { throw new NotImplementedException(); }
		}

		/// <summary>
		/// Open entity grid.
		/// MoCA version of HomePageNavigation.
		/// </summary>
		public IEnumerator<WebTestRequest> OpenEntityGrid(string entityName) 
		{
			string basePath = "\\CrmRequests\\MobileClientRequests\\MoCA_OpenEntityGrid\\";

			var requestMultiple = new OrganizationServiceExecuteRequest(user, basePath + "MoCA_OpenGrid" + entityName + "_RetrieveMultipleRequest");
			yield return requestMultiple;
		}

		// Search Entity
		public IEnumerator<WebTestRequest> SearchEntity(string entityName, string searchText) // equivalent of HomePageNavigation
		{
			string basePath = "\\CrmRequests\\MobileClientRequests\\MoCA_SearchEntity\\";

			var ExecuteQuickFindRequest = new OrganizationServiceExecuteRequest(user, basePath + "MoCA_SearchEntity_ExecuteQuickFindRequest", new Dictionary<string, string> 
			{
				{"ENTITY_NAME", entityName},
				{"SEARCH_TEXT", searchText},
			});
			
			yield return ExecuteQuickFindRequest;
		}

		public IEnumerator<WebTestRequest> OpenEntity(string entityName, string recordId = null)
		{
			MobileClientWebTestBase openEntityWebTest = null;
			switch (entityName)
			{
				case EntityNames.Accounts:
					openEntityWebTest = new MoCA_OpenAccount(recordId);
						break;
				case EntityNames.Opportunities:
						openEntityWebTest = new MoCA_OpenOpportunity(recordId);
						break;
				case EntityNames.Appointments:
						openEntityWebTest = new MoCA_OpenAppointment(recordId);
						break;
				case EntityNames.Phonecalls:
						openEntityWebTest = new MoCA_OpenPhoneCall(recordId);
						break;
				case EntityNames.Tasks:
						openEntityWebTest = new MoCA_OpenTask(recordId);
						break;
				case EntityNames.Emails:
						openEntityWebTest = new MoCA_OpenEmail(recordId);
						break;
				case EntityNames.Contacts:
						openEntityWebTest = new MoCA_OpenContact(recordId);
						break;
				case EntityNames.Leads:
						openEntityWebTest = new MoCA_OpenLead(recordId);
						break;
			}

			if (openEntityWebTest != null)
			{
				openEntityWebTest.ParentWebTest = this;
			}
			else
			{
				throw new Exception(string.Format("Open entity WebTest for \"{0}\" entity type is not defined.", entityName));
			}

			return openEntityWebTest.GetRequestEnumerator();
		}
	}
}
