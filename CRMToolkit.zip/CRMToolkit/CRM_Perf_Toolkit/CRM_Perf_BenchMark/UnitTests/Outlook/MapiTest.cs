﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Services.Protocols;
using System.Xml;
using Microsoft.Crm;
using Microsoft.Crm.Sdk;
using Microsoft.Crm.Outlook;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Mapi sync test class
	/// </summary>
	[TestClass]
	public class MapiSync : OutlookTestBaseClass
	{
		private XmlDocument resultsDoc = null;
		private MapiSyncDataRecorder sdr = null;
		private string outDir = string.Empty;

		#region Additional test attributes

		[ClassInitialize()]
		public static void MyClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"outlooksyncdata\MapiSync"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"outlooksyncdata\MapiSync");
			}
			EntityManager.Instance.IsPerUserPerRun = true;
		}

		#endregion

		#region Test init
		/// <summary>
		/// Initialize() is called once during test execution before
		/// test methods in this test class are executed.
		/// </summary>
		[TestInitialize()]
		public override void Initialize()
		{
			System.Diagnostics.Trace.WriteLine("init" + DateTime.Now.ToString());
			base.Initialize();
			try
			{
				sdr = new MapiSyncDataRecorder();
				// create transfer data provider
				resultsDoc = new XmlDocument();
				resultsDoc.AppendChild(resultsDoc.CreateElement("run_results"));
			}
			catch (Exception ex)
			{
				base.Cleanup();
				throw ex;
			}
		}
		#endregion

		#region Test cleanup
		/// <summary>
		/// Cleanup() is called once during test execution after
		/// test methods in this class have executed unless the
		/// corresponding Initialize() call threw an exception.
		/// </summary>
		[TestCleanup()]
		public override void Cleanup()
		{
			if (m_user == null)
				return;
			System.Diagnostics.Trace.WriteLine("MapiSync:cleanup" + DateTime.Now.ToString());

			base.Cleanup();

			try
			{
				XmlDocument docNode = resultsDoc.DocumentElement.OwnerDocument;
				XmlElement el;
				el = sdr.SerializeToXML(resultsDoc.DocumentElement.OwnerDocument);
				resultsDoc.DocumentElement.AppendChild(el);


				string fileName = string.Format("{0}_MapiSync_{1}.xml", m_userName, DateTime.Now.ToString());
				fileName = fileName.Replace(" ", "_");
				fileName = fileName.Replace("/", "_");
				fileName = fileName.Replace(":", "_");
				System.Diagnostics.Trace.WriteLine(fileName);

				resultsDoc.Save(string.Format("{0}\\MapiSync\\{1}", ConfigSettings.Default.OutlookSyncDir, fileName));
			}
			catch { }
		}
		#endregion

		#region Individual Test Cases

		[TestMethod]
		public void MapiSyncBackgroundInclude()
		{
			if (m_user == null)
			{
				return;
			}

			Guid id = new Guid(m_user["systemuserid"]);
			ICollection<TestDataCache> caches = UserStore.GetUserCaches(id);

			if (caches != null)
			{
				IOrganizationService orgService = serviceCreator.OrganizationService;
				foreach (TestDataCache cache in caches)
				{
					DateTime startTime = DateTime.Now;

					RetrieveMultipleRequest request = cache.FetchIncrementalInclusionData_GetRequest();
					TestContext.BeginTimer("MapiSync:MapiSyncBackgroundInclude");
					EntityCollection collection = ((RetrieveMultipleResponse)orgService.Execute(request)).EntityCollection;
					TestContext.EndTimer("MapiSync:MapiSyncBackgroundInclude");
					int includeItems = cache.FetchIncrementalInclusionData_Post(collection);
					DateTime stopTime = DateTime.Now;
					System.Diagnostics.Trace.WriteLine(
						string.Format("MapiSync:User:{0} Fetched {1} for background update of {2}", m_userName, includeItems, cache.CacheName));

					sdr.SyncInfo +=
					   string.Format(@"<BackgroundInclude entity=""{0}"" view=""{1}"" items=""{2}"" timespan=""{3}"" />",
					   cache.EntityType, cache.CacheName, includeItems, stopTime - startTime);
				}
			}
		}

		[TestMethod]
		public void MapiSyncBackgroundExclude()
		{
			if (m_user == null)
			{
				return;
			}

			Guid id = new Guid(m_user["systemuserid"]);
			ICollection<TestDataCache> caches = UserStore.GetUserCaches(id);

			if (caches != null)
			{
				IOrganizationService orgService = serviceCreator.OrganizationService;
				foreach (TestDataCache cache in caches)
				{
					DateTime startTime = DateTime.Now;

					int excludeItems = cache.FetchIncrementalExclusionData(orgService);

					DateTime stopTime = DateTime.Now;
					System.Diagnostics.Trace.WriteLine(
						string.Format("MapiSync:User:{0} Removed {1} for background update of {2}", m_userName, excludeItems, cache.CacheName));

					sdr.SyncInfo +=
						string.Format(@"<BackgroundExclude entity=""{0}"" view=""{1}"" items=""{2}"" timespan=""{3}"" />",
						cache.EntityType, cache.CacheName, excludeItems, stopTime - startTime);
				}
			}
		}

		[TestMethod]
		public void MapiSyncInitial()
		{
			if (m_user == null)
			{
				return;
			}

			try
			{
				IOrganizationService orgService = serviceCreator.OrganizationService;
				Guid id = new Guid(m_user["systemuserid"]);
				Tuple<string, string> mapiFolder = UserStore.GetNextMapiFolderToPin(id);

				if (mapiFolder != null)
				{
					string entityType = mapiFolder.Item1;
					string viewName = mapiFolder.Item2;

					Dictionary<string, Collection<Entity>> queries = QueriesRetriever.GetSavedQueriesFromEntityType(new string[] { entityType }, orgService);
					Entity query = queries[entityType].First(q => (string)q["name"] == viewName);
					string fetchXml = query["fetchxml"] as string;

					DateTime startTime = DateTime.Now;

					string entityId = entityType + "id";
					TestDataCache cache = new TestDataCache(fetchXml, entityType, entityId, viewName);
					RetrieveMultipleRequest request = cache.FetchIncrementalInclusionData_GetRequest();
					TestContext.BeginTimer("MapiSync: InitialSync");
					EntityCollection collection = ((RetrieveMultipleResponse)orgService.Execute(request)).EntityCollection;
					TestContext.EndTimer("MapiSync: InitialSync");
					int initialItems = cache.FetchIncrementalInclusionData_Post(collection);
					DateTime stopTime = DateTime.Now;
					System.Diagnostics.Trace.WriteLine(
						string.Format("MapiSync:User:{0} Fetched {1} for initial update of {2}", m_userName, initialItems, query["name"]));

					sdr.SyncInfo +=
							string.Format(@"<InitialSync entity=""{0}"" view=""{1}"" items=""{2}"" timespan=""{3}"" />",
							cache.EntityType, cache.CacheName, initialItems, stopTime - startTime);

					UserStore.AddCache(id, mapiFolder, cache);
				}
				else
				{
					System.Diagnostics.Trace.WriteLine("User:" + m_userName + " no more views to pin");
				}

				System.Diagnostics.Trace.WriteLine("User:" + m_userName + " SyncEnd:" + DateTime.Now.ToString());
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine("MapiSync:User:" + m_userName + " Begin Got SOAP exception");
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine("MapiSync:User:" + m_userName + " End Got SOAP exception");
				throw e;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine("MapiSync:User:" + m_userName + " Begin Got exception");
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine("MapiSync:User:" + m_userName + " End Got exception");
				throw e;
			}
		}

		/// <summary>
		/// Initialize ABP, Todo, Reminder Mapi sync - run once per user on initialization
		/// </summary>
		/// can we divide this into 3 unit tests? 
		[TestMethod]
		public void InitializeABPToDoReminders()
		{
			RetrieveMultipleRequest request = null;
			EntityCollection collection = new EntityCollection();

			if (m_user == null)
			{
				return;
			}

			try
			{
				IOrganizationService orgService = serviceCreator.OrganizationService;
				Guid id = new Guid(m_user["systemuserid"]);

				// add abp folders
				RetrieveMultipleRequest abRequest = new RetrieveMultipleRequest();
				QueryExpression abQuery = new QueryExpression("userquery");
				abQuery.ColumnSet.AllColumns = true;
				abQuery.Criteria.Conditions.Add(new ConditionExpression("querytype", ConditionOperator.Equal, SavedQueryQueryType.AddressBookFilters));
				abRequest.Query = abQuery;
				RetrieveMultipleResponse retrieveResponse = (RetrieveMultipleResponse)orgService.Execute(abRequest);
				foreach (Entity query in retrieveResponse.EntityCollection.Entities)
				{
					string fetchXml = query["fetchxml"] as string;
					if (string.IsNullOrWhiteSpace(fetchXml))
					{
						continue;
					}

					string entityType = (string)query["returnedtypecode"];
					string entityTypeId = entityType + "id";
					string viewName = (string)query["name"];

					DateTime startTime = DateTime.Now;

					TestDataCache cache = new TestDataCache(fetchXml, entityType, entityTypeId, viewName);

					request = cache.FetchIncrementalInclusionData_GetRequest();
					TestContext.BeginTimer("MapiSync:InstantiateABPTodoReminders:InitialItems");
					collection = ((RetrieveMultipleResponse)orgService.Execute(request)).EntityCollection;
					TestContext.EndTimer("MapiSync:InstantiateABPTodoReminders:InitialItems");
					int initialItems = cache.FetchIncrementalInclusionData_Post(collection);

					DateTime stopTime = DateTime.Now;
					System.Diagnostics.Trace.WriteLine(
						string.Format("MapiSync:User:{0} Fetched {1} for initial update of {2}", m_userName, initialItems, query["name"]));

					sdr.SyncInfo +=
							string.Format(@"<InitialSync entity=""{0}"" view=""{1}"" items=""{2}"" timespan=""{3}"" />",
							cache.EntityType, cache.CacheName, initialItems, stopTime - startTime);
					UserStore.AddCache(id, Tuple.Create(entityType, viewName), cache);
				}

				// add todo
				System.Diagnostics.Trace.WriteLine("User:" + m_userName + " Adding todo cache:" + DateTime.Now.ToString());
				var ownerTodo = new ConditionExpression("ownerid", ConditionOperator.EqualUserId);
				var flag = new ConditionExpression("flagstatus", ConditionOperator.Equal, "2");
				var todoFilter = new FilterExpression(LogicalOperator.And);
				todoFilter.AddCondition(ownerTodo);
				todoFilter.AddCondition(flag);

				QueryExpression todoQuery = new QueryExpression("userentityinstancedata");
				todoQuery.ColumnSet.AllColumns = true;
				todoQuery.Criteria.AddFilter(todoFilter);
				QueryExpressionToFetchXmlRequest req = new QueryExpressionToFetchXmlRequest();
				req.Query = todoQuery;
				var response = (QueryExpressionToFetchXmlResponse)orgService.Execute(req);
				string todoFetchXml = response.FetchXml;
				TestDataCache todoCache = new TestDataCache(todoFetchXml, "userentityinstancedata", "objectid", "Todo");
				request = todoCache.FetchIncrementalInclusionData_GetRequest();
				TestContext.BeginTimer("MapiSync:InstantiateABPTodoReminders:InitialTodoItems");
				collection = ((RetrieveMultipleResponse)orgService.Execute(request)).EntityCollection;
				TestContext.EndTimer("MapiSync:InstantiateABPTodoReminders:InitialTodoItems");
				int initialTodoItems = todoCache.FetchIncrementalInclusionData_Post(collection);


				UserStore.AddCache(id, Tuple.Create("userentityinstancedata", "Todo"), todoCache);

				// add reminder
				System.Diagnostics.Trace.WriteLine("User:" + m_userName + " Adding reminder cache:" + DateTime.Now.ToString());
				var ownerReminder = new ConditionExpression("ownerid", ConditionOperator.EqualUserId);
				var setReminder = new ConditionExpression("reminderset", ConditionOperator.Equal, "true");
				var reminderFilter = new FilterExpression(LogicalOperator.And);
				reminderFilter.AddCondition(ownerReminder);
				reminderFilter.AddCondition(setReminder);

				QueryExpression reminderQuery = new QueryExpression("userentityinstancedata");
				reminderQuery.ColumnSet.AllColumns = true;
				reminderQuery.Criteria.AddFilter(reminderFilter);

				QueryExpressionToFetchXmlRequest reqReminder = new QueryExpressionToFetchXmlRequest();
				reqReminder.Query = reminderQuery;
				var responseReminder = (QueryExpressionToFetchXmlResponse)orgService.Execute(reqReminder);
				string reminderFetchXml = responseReminder.FetchXml;
				TestDataCache reminderCache = new TestDataCache(reminderFetchXml, "userentityinstancedata", "objectid", "Reminder");
				request = reminderCache.FetchIncrementalInclusionData_GetRequest();
				TestContext.BeginTimer("MapiSync:InstantiateABPTodoReminders:InitialReminderItems");
				collection = ((RetrieveMultipleResponse)orgService.Execute(request)).EntityCollection;
				TestContext.EndTimer("MapiSync:InstantiateABPTodoReminders:InitialReminderItems");
				int initialReminderItems = reminderCache.FetchIncrementalInclusionData_Post(collection);

				UserStore.AddCache(id, Tuple.Create("userentityinstancedata", "Reminder"), reminderCache);

				System.Diagnostics.Trace.WriteLine("User:" + m_userName + " SyncEnd:" + DateTime.Now.ToString());
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine("MapiSync:User:" + m_userName + " Begin Got SOAP exception");
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine("MapiSync:User:" + m_userName + " End Got SOAP exception");
				throw e;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine("MapiSync:User:" + m_userName + " Begin Got exception");
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine("MapiSync:User:" + m_userName + " End Got exception");
				throw e;
			}
		}

		/// <summary>
		/// Fetching query de
		/// </summary>
		[TestMethod]
		public void FetchXmlQueryTest()
		{
			// get and cache a collection of available queries using queries retriever
			string[] entities = new[] { "account", "contact", "lead", "queue", "systemuser" };
			Dictionary<string, Collection<Entity>> queriesByType = QueriesRetriever.GetSavedQueriesFromEntityType(entities, serviceCreator.OrganizationService);

			// pick one of the fetch xmls
			List<Entity> queries = queriesByType.SelectMany(items => items.Value).ToList();
			Entity query = queries[Utils.GetRandomInt(0, queries.Count)];

			if (query != null && query.Contains("fetchxml"))
			{
				// make a FetchXmlToQueryExpressionRequest to retrieve a view
				string fetchXml = query["fetchxml"] as string;
				QueryExpression queryExpression = BuildQueryFromXml(fetchXml, serviceCreator.OrganizationService);
				this.serviceCreator.OrganizationService.RetrieveMultiple(queryExpression);
			}
		}

		#endregion

		#region Private Methods

		protected QueryExpression BuildQueryFromXml(string fetchXml, IOrganizationService context)
		{
			FetchXmlToQueryExpressionRequest fetchToQueryReq = new FetchXmlToQueryExpressionRequest();
			fetchToQueryReq.FetchXml = fetchXml;
			FetchXmlToQueryExpressionResponse fetchToQueryResp = (FetchXmlToQueryExpressionResponse)context.Execute(fetchToQueryReq);

			return fetchToQueryResp.Query;
		}

		private XmlDocument CreateXmlDocument(string xml)
		{
			XmlTextReader reader = new XmlTextReader(new StringReader(xml));

			reader.DtdProcessing = DtdProcessing.Prohibit;
			reader.WhitespaceHandling = WhitespaceHandling.Significant;

			XmlDocument xmlDoc = new XmlDocument();

			// Set XmlResolver to null to prevent usage of the default XmlResolver.
			xmlDoc.XmlResolver = null;

			xmlDoc.Load(reader);
			reader.Close();

			return xmlDoc;
		}

		private int ConvertAttributeToInt(XmlAttribute attribute)
		{
			if (attribute == null)
				return 0;

			try
			{
				int count = Int32.Parse(attribute.Value);
				return count;
			}
			catch
			{
				throw new CrmArgumentException("Cannot convert attribute to integer.", attribute.Value);
			}
		}

		#endregion
	}

	public class MapiSyncDataRecorder
	{
		private TimeSpan CreateSubscription;
		private TimeSpan PrepareSync;
		public String SyncInfo;
		private TimeSpan MoveData;

		public XmlElement SerializeToXML(XmlDocument xmld)
		{
			XmlElement el;
			XmlAttribute att;
			el = xmld.CreateElement("Sync_Data");
			att = xmld.CreateAttribute("CreateSubscription");
			att.Value = CreateSubscription.ToString();
			el.Attributes.Append(att);
			att = xmld.CreateAttribute("PrepareSync");
			att.Value = PrepareSync.ToString();
			el.Attributes.Append(att);

			if (SyncInfo != null)
			{
				att = xmld.CreateAttribute("TotalEntity");
				att.Value = "0".ToString();
				el.Attributes.Append(att);
				el.InnerXml = SyncInfo;
			}

			att = xmld.CreateAttribute("MoveData");
			att.Value = MoveData.ToString();
			el.Attributes.Append(att);

			return (el);
		}
	}
}

