﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Summary description for LetterCRUD
	/// </summary>
	[TestClass]
	public class LetterCRUD : CreateBasicEntityBaseTest
	{
		public override string EntityName
		{
			get
			{
				return EntityNames.Letters;
			}
		}


		public override string PrintEntityData(Entity entity)
		{
			return String.Format("{0} subject={1}", EntityName, entity["subject"].ToString());

		}


		[TestMethod]
		public void UnitTest__CreateLetter()
		{
			string timer = "Letter Create Unit Test";
			Init();
			Entity letter = new Entity("letter");
			letter["subject"] = Utils.GetRandomString(5, 10) + "deleteable";
			letter["description"] = Utils.GetRandomString(50, 100);
			letter["actualdurationminutes"] = 30;
			letter["actualstart"] = DateTime.Now;

			Entity organizer = new Entity("activityparty");
			organizer["partyid"] = new EntityReference("systemuser", new Guid(m_user["systemuserid"]));
			//phonecall["organizer"] = new Entity[] { organizer };
			letter["from"] = new Entity[] { organizer };
			letter["owninguser"] = new Entity[] { organizer };
			Guid letterId = CreateEntityInCRM(letter, timer);
			

			//add the phonecall to EMDB
			Guid g = EntityManager.Instance.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(this.EntityName, g, new string[] { "OwnerId", "ActivityId", "EntityManagerOwningUser", "Subject" }, new string[] { m_user["systemuserid"], letterId.ToString(), g.ToString(), letter["subject"].ToString() });
		}

		[TestMethod]
		public void UnitTest__UpdateLetter()
		{
			Entity letter = new Entity("letter");
			//find a CRM Entity for update test
			Init("subject", "updatable");

			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "subject", "description", "subject" });
			//get the Phone Call in CRM
			letter = proxy.Retrieve(letter.LogicalName, new Guid(m_contact["ActivityId"]), attributes);
			//update contact address city value
			letter["description"] = Utils.GetRandomString(50, 100);
			this.UpdateEntityInCRM(letter, "Letter Update Unit Test");

		}

		[TestMethod]
		public void UnitTest__DeleteLetter()
		{
			Entity phonecall = new Entity("letter");
			//find a CRM Entity for update test
			Init("subject", "deleteable");
			DeleteEntityInCRM("activityid", phonecall, " Delete Letter Entity");
			EntityManager.Instance.DeleteEntity(m_contact);
		}
	}
}
