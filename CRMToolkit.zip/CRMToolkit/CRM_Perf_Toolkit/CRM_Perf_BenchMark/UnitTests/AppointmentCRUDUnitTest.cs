﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using System.Collections;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class AppointmentCRUDUnitTest : AppointmentEntityBase
	{

		public override int InstanceTypeCode
		{
			get 
			{
				return 0;
			}
		}
		
		public override string EntityName
		{
			get
			{
				return EntityNames.Appointments;
			}
		}


		public override string PrintEntityData(Entity entity)
		{
			return String.Format("{0} subject={1}", EntityName, entity["subject"].ToString());

		}

		public AppointmentCRUDUnitTest():base()
		{}


		[TestMethod]
		public void UnitTest__CreateAppointment()
		{
			string timer = "Appointment Create Unit Test";
			Init();
			Entity appointment = BuildBasicEntity();
			appointment["organizer"] = CreateEntityForSystemUser();
			// This caused sync to stop working before needs verifying if it can be added back.
			//appointment["requiredattendees"] = CreateListOfUsers();

			Guid phoneId = CreateEntityInCRM(appointment, timer);
			//add the Appointment to EMDB
			Guid g = EntityManager.Instance.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(this.EntityName, g, new string[] { "OwnerId", "ActivityId", "EntityManagerOwningUser", "Subject", "InstanceTypeCode" }, new string[] { m_user["systemuserid"], phoneId.ToString(), g.ToString(), appointment["subject"].ToString(),"0"});
		}

		[TestMethod]
		public void UnitTest__UpdateAppointment()
		{
			Entity appointment = new Entity("appointment");

			//find a CRM Entity for update test
			Init(CreateProperties("updatable"));
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "subject", "description", "subject" });
			//get the Appointment in CRM
			appointment = proxy.Retrieve(appointment.LogicalName, new Guid(m_contact["ActivityId"]), attributes);
			//Update the subject
			appointment["subject"] = Utils.GetRandomString(50, 100);
			this.UpdateEntityInCRM(appointment, "Contact Update Unit Test");

		}

		[TestMethod]
		public void UnitTest__DeleteAppointment()
		{
			Entity appointment = new Entity("appointment");
			//find a CRM Entity for update test
			Init(CreateProperties("deleteable"));
			DeleteEntityInCRM("activityid", appointment, " Delete Phone Call Entity");
			// Delete the Entity from the EMDB
			EntityManager.Instance.DeleteEntity(m_contact);
		}

	}
}
