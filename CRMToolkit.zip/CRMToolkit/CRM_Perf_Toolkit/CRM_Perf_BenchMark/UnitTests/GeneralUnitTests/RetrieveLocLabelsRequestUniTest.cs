﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{

	//test RetrieveLocLablesRequest
	[TestClass]
	public class RetrieveLocLabelsRequestUniTest : UnitTestBase
	{
		#region Retrieve loc label
		//RetrieveLocLabelsRequest only supports a limited set of entities 
		//To test RetrieveLocLabelsRequest, we need to create a entity supported by RetrieveLocLabelsRequest first
		//in this unit test, we choose TimezoneDefinition.userInterfaceName to test RetrieveLocLabelsRequest
		[TestMethod]
		public void UnitTest__RetrieveLocLabelsRequest()
		{
			//query and retrieve a timezonedefinition entity from CRM DB first
			Entity timezonedefinition = new Entity("timezonedefinition");
			
			QueryExpression query = new QueryExpression("timezonedefinition");
			query.ColumnSet.AddColumn("timezonedefinitionid");
			query.ColumnSet.AddColumn("userinterfacename");
			query.Criteria.AddCondition("userinterfacename", ConditionOperator.NotNull);

			EntityCollection results;
			results = Proxy.RetrieveMultiple(query);
			Entity res = results.Entities[0];

			//create RetrieveLocLabelsRequest
			RetrieveLocLabelsRequest req = new RetrieveLocLabelsRequest();
			req.EntityMoniker = new EntityReference("timezonedefinition", res.Id);
			req.AttributeName = "standardname";
			req.IncludeUnpublished = false;

			//execute the request
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("RetrieveLocLabelsRequest Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveLocLabelsRequest Unit Test");
		}
		#endregion
	}
}
