﻿using System;
using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.WebTesting;
using CRM_Perf_BenchMark.Espresso;

namespace CRM_Perf_BenchMark
{
	public abstract class me_EditEntity : EspressoPageTestBase
	{
		private ME_EntityHelper _entityHelper;
		private CrmRequest _createEntity;
		private readonly string _logicalName;

		public me_EditEntity(string logicalName)
		{
			this._logicalName = logicalName;
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction(EspressoTransactionNames.HomePage);
			var homepage = new _m_default_aspx(user);
			yield return (homepage);
			this.EndTransaction(EspressoTransactionNames.HomePage);

			this._entityHelper = MobileExpressHelper.Instance.GetHomepageEntity(_logicalName.ToLowerInvariant());

			CRMEntity entity = RetrieveTestEntity(user, this._logicalName);

			this.BeginTransaction(EspressoTransactionNames.EntityGrid);
			var entityHome = new _m_eh_aspx(user) { etn = this._entityHelper.logicalName };
			entityHome.Headers.Add(new WebTestRequestHeader("referer", homepage.lastResponse.ResponseUri.ToString()));
			yield return (entityHome);
			this.EndTransaction(EspressoTransactionNames.EntityGrid);

			string recordIdString = MobileExpressHelper.Instance.GetEntityId(this._logicalName, entity);
			Guid recordId = Guid.Parse(recordIdString);

			this.BeginTransaction(string.Format(EspressoTransactionNames.EntityReadPage, this._logicalName));
			var readForm = new _m_ef_aspx(user)
			{
				Etn = this._entityHelper.logicalName,
				Id = recordId
			};
			readForm.Headers.Add(new WebTestRequestHeader("referer", entityHome.lastResponse.ResponseUri.ToString()));
			yield return readForm;
			this.EndTransaction(string.Format(EspressoTransactionNames.EntityReadPage, this._logicalName));

			this.BeginTransaction(string.Format(EspressoTransactionNames.EntityEditPage, this._logicalName));

			var editForm = new _m_forms_page_aspx(user)
			{
				Etc = this._entityHelper.otc,
				Id = recordId
			};
			editForm.Headers.Add(new WebTestRequestHeader("referer", readForm.lastResponse.ResponseUri.ToString()));
			yield return editForm;
			this.EndTransaction(string.Format(EspressoTransactionNames.EntityEditPage, this._logicalName));

			this.BeginTransaction(string.Format(EspressoTransactionNames.EntitySubmit, this._logicalName));
			InlineEditHelper inlineEdit = new InlineEditHelper(GetCommandXml(recordId), user);
			this._createEntity = inlineEdit.getInlineEditWTR(editForm.lastResponse.ResponseUri.ToString(), 2) as CrmRequest;
			this._createEntity.ValidateResponse += this.NewEntity_ValidateResponse;
			yield return this._createEntity;
			this.EndTransaction(string.Format(EspressoTransactionNames.EntitySubmit, this._logicalName));
		}

		public void NewEntity_ValidateResponse(object sender, EventArgs e)
		{
			this._createEntity.ValidateResponse -= this.NewEntity_ValidateResponse;
		}

		public virtual string GetCommandXml(Guid editEntity)
		{
			return string.Empty;
		}
	}
}
