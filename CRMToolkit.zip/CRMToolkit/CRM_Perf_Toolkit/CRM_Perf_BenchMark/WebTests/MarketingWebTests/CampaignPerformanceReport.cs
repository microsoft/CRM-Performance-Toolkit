namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;

	/// <summary>
	/// All Tests are written from a warm perspective(meaning that each page has been visited recently so that it is not an initial (cold) load)
	/// 1. Start workplace report Homepage
	/// 2. Open Account Overview report
	/// 3. Click 'Run report'
	/// </summary>

	public class CampaignPerformanceReport : ViewReportTemplate
	{
		#region Class constructor
		/// <summary>
		/// Default class constructor
		/// </summary>
		public CampaignPerformanceReport()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(CampaignPerformanceReport_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(WebTestBase_PostWebTest);
		}
		#endregion

		#region Pre WebTest
		/// <summary>
		/// Pre WebTest
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">PreWebTestEvent</param>
		public void CampaignPerformanceReport_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			WebTestBase_PreWebTest(sender, e);
		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
		   return base.GetRequestEnumerator();
		}
		#endregion

		protected override string entityName
		{
			get
			{
				return EntityNames.Reports;
			}
		}

		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.WorkplaceSiteMapPath[EntityNames.Reports];
			}
		}

		protected override string viewName
		{
			get 
			{ 
				return EntityNames.Campaigns.ToLower(); 
			}
		}

		protected override string filter
		{
			get
			{
				return @"<ReportFilter><ReportEntity paramname=""CRM_FilteredCampaign"" displayname=""Campaigns""><fetch version=""1.0"" output-format=""xml-platform"" mapping=""logical"" distinct=""false""><entity name=""campaign""><all-attributes/></entity></fetch></ReportEntity></ReportFilter>";
			}
		}

		protected override string filterText
		{
			get 
			{
				return "";
			}
		}

		//Campaign Performance report entity from EMDB
		protected override CRMEntity report
		{
			get 
			{
				return RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.Reports, new System.Collections.Hashtable() { { "filename", "Campaign Performance.rdl" } }); 
			}
		}
	}
}