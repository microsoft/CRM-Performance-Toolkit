//-------------------------------------------------------------------------------
// <copyright file="SocialActivityToLeadUnitTest.cs" company="Microsoft">
//		Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//-------------------------------------------------------------------------------

namespace CRM_Perf_BenchMark.SocialActivity
{
	using Microsoft.Crm.Sdk.Messages;
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using Microsoft.Xrm.Sdk;
	using System;

	/// <summary>
	/// Unit Test to check SocialActivity to Lead Flow
	/// </summary>
	[TestClass]
	public class SocialActivityToLeadUnitTests : UnitTestBase
	{
		//WorkFlow Id for creating Social Activity to Lead which is imported through solution
		private Guid workFlowId = new Guid("9ae7ddcf-45bc-4be2-aa51-9180d2f588a7");

		#region Additional test attributes

		// Use TestInitialize to run code before running each test 
		[TestInitialize()]
		public void TestInitialize()
		{
			base.Initialize();
		}
		#endregion

		#region Individual Test Cases

		/// <summary>
		/// Test Case for Social Activity to Lead
		/// </summary>
		[TestMethod()]
		public void SocialActivityToLeadTest()
		{
			String socialActivityName = "socialactivity";
			Entity socialActivity = new Entity(socialActivityName);
			socialActivity.Attributes["subject"] = "Social To Lead " + Utils.GetRandomString(5, 10);

			string socialHandle = "social handle" + Utils.GetRandomString(5, 10);
			string profileName = "profile name" + Utils.GetRandomString(5, 10);
			string profileLink = "profile link" + Utils.GetRandomString(5, 10);
			socialActivity.Attributes["socialadditionalparams"] = "{'targetEntityName':'incident', 'socialHandle':'" + socialHandle + "', 'profileName':'" + profileName + "', 'profilelink':'" + profileLink + "','community':'1', 'influencescore':'1.2', queueId:'" + null + "'}";
			Guid socialActivityId = Proxy.Create(socialActivity);

			//Executing WorkFlow to Create Lead
			ExecuteWorkflowRequest request = new ExecuteWorkflowRequest()
			{
				WorkflowId = workFlowId
			};
			request.EntityId = socialActivityId;
			Proxy.Execute(request);
		}

		#endregion

	}
}
