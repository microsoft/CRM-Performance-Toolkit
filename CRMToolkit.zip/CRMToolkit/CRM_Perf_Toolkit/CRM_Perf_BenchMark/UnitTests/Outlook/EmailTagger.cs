using System;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Security.Permissions;
using System.Diagnostics;
using System.Collections.Generic;
using Microsoft.Win32;
using System.Xml;
using System.Web.Services.Protocols;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.WebTesting;
using Microsoft.Crm.Application.Outlook.OfflineSync;
//using OfflineSyncTestDriver;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using System.Text;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Summary description for EmailTaggerUT
	/// </summary>
	[TestClass]
	public class EmailTaggerUT : OutlookTestBaseClass
	{
		private PerfSync sync = null;
		private XmlDocument resultsDoc = null;
		private SyncDataRecorder sdr = null;

		private string thresholdDate = @"1971-01-01T00:00:00";
		private int initialTagDelay = 5;

		public EmailTaggerUT()
		{
			System.Diagnostics.Trace.WriteLine(string.Format("EmailTaggerUT:Ctor {0}", DateTime.Now.ToString()));
		}

		#region Additional test attributes

		[ClassInitialize()]
		public static void MyClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"outlooksyncdata\EmailTagger"))
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"outlooksyncdata\EmailTagger");
		}

		#endregion

		#region test init
		/// <summary>
		/// Initialize() is called once during test execution before
		/// test methods in this test class are executed.
		/// </summary>
		[TestInitialize()]
		public override void Initialize()
		{
			isOutlookUser = true;
			System.Diagnostics.Trace.WriteLine("EmailTaggerUT:Init " + DateTime.Now.ToString());
			base.Initialize();
			System.Diagnostics.Trace.WriteLine("EmailTaggerUT:User " + m_userName + " " + DateTime.Now.ToString());

			try
			{
				Guid OrganizationId = new Guid(m_user["organizationid"]);

				//MSCRMClient just needs one entry RCOffline == 0
				RegistryKey clientRegKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\MSCRMClient", true);
				if (clientRegKey == null)
				{
					clientRegKey = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\MSCRMClient");
					clientRegKey.SetValue("RCOffline", 0, RegistryValueKind.DWord);
					clientRegKey.SetValue("WebAppUrl", m_CrmServer, RegistryValueKind.String);
				}

				PT_ClientOrgInfo myPTClientOrgInfo = new PT_ClientOrgInfo(m_clientKeyPath);

				sdr = new SyncDataRecorder();
				sync = new PerfSync(sdr);
				sync.ClientKeyPath = m_clientKeyPath;
				sync.ServiceCreator = serviceCreator;
				sync.MachineName = m_userName;
				sync.UserName = m_userName;
				sync.UserDomain = m_domain;
				sync.NetworkCredential = m_nc;
				sync.OrganizationId = OrganizationId;

				resultsDoc = new XmlDocument();
				resultsDoc.AppendChild(resultsDoc.CreateElement("run_result"));
			}

			catch (System.Web.Services.Protocols.SoapException ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("User {0} Soap Exception Detail: {1}", m_userName, ex.Detail.InnerXml));
				base.Cleanup();
				throw ex;
			}
			catch (Exception ex)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("User {0} :Exception Message: {1}", m_userName, ex.Message));
				base.Cleanup();
				throw ex;
			}

		}
		#endregion

		#region test cleanup
		/// <summary>
		/// Cleanup() is called once during test execution after
		/// test methods in this class have executed unless the
		/// corresponding Initialize() call threw an exception.
		/// </summary>
		[TestCleanup()]
		public override void Cleanup()
		{
			//we need a valid user to run
			if (m_user == null)
				return;
			System.Diagnostics.Trace.WriteLine("EmailTaggerUT:Cleanup " + DateTime.Now.ToString());

			base.Cleanup();

			XmlDocument docNode = resultsDoc.DocumentElement.OwnerDocument;
			XmlElement el;

			try
			{
				el = sdr.SerializeToXML(resultsDoc.DocumentElement.OwnerDocument);
				resultsDoc.DocumentElement.AppendChild(el);

				string fileName = string.Format("{0}_EmailTagger_{1}.xml", m_userName, DateTime.Now.ToString());
				fileName = fileName.Replace(" ", "_");
				fileName = fileName.Replace("/", "_");
				fileName = fileName.Replace(":", "_");
				System.Diagnostics.Trace.WriteLine(fileName);
				resultsDoc.Save(string.Format("{0}\\EmailTagger\\{1}", ConfigSettings.Default.OutlookSyncDir, fileName));
			}
			catch
			{
			}

			sync = null;
			sdr = null;
			resultsDoc = null;
		}
		#endregion

		#region Individual Test Cases

		[TestMethod]
		public void InitialTagTM()
		{
			try
			{
				DateTime newDate = DateTime.Now.ToUniversalTime();
				FetchEmails(thresholdDate);
				thresholdDate = newDate.ToString("yyyy-MM-ddTHH:mm:ss");
				initialTagDelay = 0;
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("EmailTaggerUT:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine(string.Format("EmailTaggerUT:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("EmailTaggerUT:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine(string.Format("EmailTaggerUT:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
		}

		[TestMethod]
		public void RecurringTagTM()
		{
			// Letting initial tag to finish
			if (initialTagDelay > 0)
			{
				initialTagDelay--;
				return;
			}
			try
			{
				TestContext.BeginTimer("EmailTaggerUT:RecurringTagTM");
				DateTime newDate = DateTime.Now.ToUniversalTime();
				FetchEmails(thresholdDate);
				thresholdDate = newDate.ToString("yyyy-MM-ddTHH:mm:ss");
				TestContext.EndTimer("EmailTaggerUT:RecurringTagTM");
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("EmailTaggerUT:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine(string.Format("EmailTaggerUT:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("EmailTaggerUT:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine(string.Format("EmailTaggerUT:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
		}

		#endregion

		#region Private Methods

		private void FetchEmails(string thresholdDate)
		{
			// Define the fetch attributes.
			// The number of records per page to retrieve.
			int fetchCount = 50;
			// Initialize the page number.
			int pageNumber = 1;
			// The current paging cookie. For retrieving the first page, 
			// pagingCookie should be null.
			string pagingCookie = null;

			// Create the FetchXml string used for tagging
			StringBuilder sb = new StringBuilder();
			sb.Append(@"<fetch version='1.0' mapping='logical' distinct='true' output-format='xml-platform'>");
			sb.Append(@"<entity name='email'> <attribute name='modifiedon' /><attribute name='messageid'/><attribute name='activityid'/><attribute name='regardingobjectid'/>");
			sb.Append(@"<attribute name='from'/><attribute name='to'/><attribute name='cc'/>");
			sb.Append(@"<link-entity name='activityparty' to='activityid' from='activityid'>");
			sb.AppendFormat(@"<filter type='and'><condition attribute='partyid' operator='eq' value='{0}'/>", m_user["systemuserid"]);
			sb.Append(@"</filter></link-entity>");
			sb.Append(@"<filter type='and'>");
			sb.AppendFormat(@"<condition attribute='modifiedon' operator='on-or-after' value='{0}'/>", thresholdDate);
			sb.Append(@"<condition attribute='messageid' operator='not-null'/>");
			sb.Append(@"</filter><order attribute='messageid' descending='false'/></entity></fetch>");
			string fetchXml = sb.ToString();
			IOrganizationService service = serviceCreator.OrganizationService;
			while (true)
			{

				// Build fetchXml string with the placeholders.
				string fetchXmlToExecute = CreateXml(fetchXml, pagingCookie, pageNumber, fetchCount);

				// Excute the fetch query and get the xml result.
				ExecuteFetchRequest fetchReq = new ExecuteFetchRequest()
				{
					FetchXml = fetchXmlToExecute
				};

				TestContext.BeginTimer("EmailTaggerUT:InitialTagTM");
				ExecuteFetchResponse fetchResponse = (ExecuteFetchResponse)service.Execute(fetchReq);
				TestContext.EndTimer("EmailTaggerUT:InitialTagTM");

				string fetchResult = fetchResponse.FetchXmlResult;

				// Load the fetch result into XMLDocument to parse its cotents.
				XmlDocument doc = new XmlDocument();
				doc.LoadXml(fetchResult);

				// The morerecords attribute will return 1 if there are more records.
				string moreRecords = ExtractAttribute(doc, "morerecords");

				// The paging-cookie attribute holds the paging cookie to pass in the next query.
				pagingCookie = ExtractAttribute(doc, "paging-cookie");

				// Check for morerecords, if it returns 1.
				if (moreRecords != null && moreRecords == "1")
				{
					// Increment the page number to retrieve the next page.
					pageNumber++;
				}
				else
				{
					// If no more records in the result nodes, exit the loop.
					break;
				}
			}
		}

		private string ExtractAttribute(XmlDocument doc, string name)
		{
			XmlAttributeCollection attrs = doc.DocumentElement.Attributes;
			XmlAttribute attr = (XmlAttribute)attrs.GetNamedItem(name);
			if (null == attr)
			{
				return null;
			}
			return attr.Value;
		}

		private string CreateXml(string xml, string cookie, int page, int count)
		{
			StringReader stringReader = new StringReader(xml);
			XmlTextReader reader = new XmlTextReader(stringReader);

			// Load document
			XmlDocument doc = new XmlDocument();
			doc.Load(reader);

			return CreateXml(doc, cookie, page, count);
		}

		private string CreateXml(XmlDocument doc, string cookie, int page, int count)
		{
			XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

			if (cookie != null)
			{
				XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
				pagingAttr.Value = cookie;
				attrs.Append(pagingAttr);
			}

			XmlAttribute pageAttr = doc.CreateAttribute("page");
			pageAttr.Value = System.Convert.ToString(page);
			attrs.Append(pageAttr);

			XmlAttribute countAttr = doc.CreateAttribute("count");
			countAttr.Value = System.Convert.ToString(count);
			attrs.Append(countAttr);

			StringBuilder sb = new StringBuilder(1024);
			StringWriter stringWriter = new StringWriter(sb);

			XmlTextWriter writer = new XmlTextWriter(stringWriter);
			doc.WriteTo(writer);
			writer.Close();

			return sb.ToString();
		}

		#endregion
	}
}
