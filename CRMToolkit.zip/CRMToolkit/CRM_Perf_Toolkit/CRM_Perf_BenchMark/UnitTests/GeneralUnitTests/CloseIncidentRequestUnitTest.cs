﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// unit test for closing incident request
	/// 1 create an incident first
	/// 2 close the incident created in step 1
	/// 3 update the statecode of the incident accordingly
	/// </summary>
	[TestClass]
	public class CloseIncidentRequestUnitTest : UnitTestBase
	{
		private CRMEntity m_incident;

		#region Close incicdent request
		[TestMethod()]
		public void UnitTest__CloseIncidentRequest()
		{
			m_incident = RetrieveTestEntity(m_user, EntityNames.Incidents);
			CloseIncidentRequest closeIncidentRequest = new CloseIncidentRequest();

		   // Create the incident's resolution.
			Entity incidentResolution = new Entity("incidentresolution");
			incidentResolution.Attributes.Add("subject", "Resolved Sample CWR Incident");
			incidentResolution.Attributes.Add("incidentid", new EntityReference("incident", new Guid(m_incident["incidentid"])));
			try
			{
				Proxy.Create(incidentResolution);
			}
			catch (FaultException<IOrganizationService> fe)
			{
				Trace.WriteLine(fe.Detail);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			
			closeIncidentRequest.IncidentResolution = incidentResolution;
			
			//set the incident's status to problem solved
			OptionSetValue status = new OptionSetValue();
			status.Value = 5;
			closeIncidentRequest.Status = status;
			closeIncidentRequest.RequestName = "CloseIncident";
			
			//execute the associate request
			TestContext.BeginTimer("Close Incident Request Unit Test");
			try
			{
				Proxy.Execute(closeIncidentRequest);
			}
			catch (FaultException<IOrganizationService> fe)
			{
				Trace.WriteLine(fe.Detail);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Close Incident Request Unit Test");
			
			//update the status code in EMDB accordingly
			string[] prop = {"statecode"};
			string[] propvalue = {"1"};
			EntityManager.Instance.UpdateEntity(ref m_incident, "incident", new Guid(m_incident["EntityManagerOwningUser"]), prop, propvalue, "incidentid", m_incident["incidentid"].ToString());

		}
		#endregion

	}


}
