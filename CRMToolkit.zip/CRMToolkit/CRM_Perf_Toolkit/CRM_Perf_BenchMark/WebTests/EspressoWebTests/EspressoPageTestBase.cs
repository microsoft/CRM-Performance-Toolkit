﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace CRM_Perf_BenchMark
{
	public abstract class EspressoPageTestBase : WebTestBase
	{
		protected EspressoPageTestBase()
			: base()
		{
			PreWebTest += (sender, e) =>
			{
				e.WebTest.Context["IsMobilePhoneUser"] = 1;
				EspressoPageTest_PreWebTest(sender, e);
			};

			PostWebTest += (sender, e) =>
			{
				e.WebTest.Context["IsMobilePhoneUser"] = 1;
				EspressoPageTest_PostWebTest(sender, e);
			};
		}

		protected virtual void EspressoPageTest_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			WebTestBase_PreWebTest(sender, e);
		}

		protected virtual void EspressoPageTest_PostWebTest(object sender, PostWebTestEventArgs e)
		{
			WebTestBase_PostWebTest(sender, e);
		}

		protected override string entityName
		{
			get
			{
				return "";
			}
		}

		protected override string siteMapPath
		{
			get
			{
				return "";
			}
		}
	}
}
