﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.ServiceModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// This test case will pick up any random rollup field ("new_actualrevenue", "new_estimatedrevenue", "new_opportunitycount") from Account entity
	/// and calculates a value of retrieved rollup field.
	/// </summary>
	[TestClass]
	public class RollupFieldCalculateNowUnitTest : UnitTestBase
	{
		#region Rollup field CalculateNow

		const string HIERARCHICAL_ATTRIBUTE = "new_hierarchynodelevel";
		private const string CustomEntityName = "account";
		private const string Id = "AccountId";
		Dictionary<int, Hierarchy> dictionary = new Dictionary<int, Hierarchy>();
		private String[] listRollupAttributes;
		private Random randomObject = new Random();

		#region Initialize
		[TestInitialize]
		public override void Initialize()
		{
			//Rollup DB Populator generates the record in the custom entity tables which are mapped to "System Administrator" role. 
			//Hence setting the UserRole as "System Administrator" and user(DomainName) to "administrator".
			TestContext.Properties["UserRole"] = "System Administrator";
			TestContext.Properties["DomainName"] = "administrator";			
			base.Initialize();
			InitializeHierarchyNodes();
			//List of OOB Rollup fields for Account entity
			listRollupAttributes = new[] { "openrevenue", "opendeals", "openappointments" };
		}

		#endregion

		/// <summary>
		/// Test Rollup field CalculateNow
		/// </summary>
		[TestMethod()]
		public void UnitTest__RollupFieldCalculateNow()
		{
			Entity customeEntity = new Entity(CustomEntityName);
			//Retrieve entity Id from EMDB
			Guid entityId = RetrieveTestEntityForRollupCalculateNow();
			//Retrieve Rollup field name
			string attributeName = RetrieveRollupFieldName();

			OrganizationRequest request = new OrganizationRequest();
			request.RequestName = "CalculateRollupField";
			request.Parameters.Add("FieldName", attributeName);
			request.Parameters.Add("Target", new EntityReference(customeEntity.LogicalName, entityId));

			TestContext.BeginTimer("RollupFieldCalculateNowUnitTest");
			try
			{
				OrganizationResponse response = Proxy.Execute(request);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RollupFieldCalculateNowUnitTest");
		}

		#endregion

		#region Helper Methods

		/// <summary>
		/// Retrieves a entity Id 
		/// </summary>
		/// <returns></returns>
		private Guid RetrieveTestEntityForRollupCalculateNow()
		{
			int treeId = GetRandomTreeId();
			Hierarchy tree = dictionary[treeId];
			return GetCustomEntity(tree.Root);
		}

		/// <summary>
		/// Retrieved Rollup field name
		/// </summary>
		/// <returns></returns>
		private string RetrieveRollupFieldName()
		{
			int random = randomObject.Next(0, 2);
			return listRollupAttributes[random];
		}

		#region helper methods

		private Guid GetCustomEntity(string nodeId)
		{
			Guid entityId = GetTestEntity(CustomEntityName, nodeId);
			return entityId;
		}

		private void InitializeHierarchyNodes()
		{
			//Initialize hierarchy nodes
			for (int id = 1; id <= 15; id++)
			{
				Hierarchy node = new Hierarchy();
				node.Root = string.Format("HIERARCHY{0} - LEVEL{1}", id, randomObject.Next(1, 7));
				node.Subtree = string.Format("HIERARCHY{0} - LEVEL{1}", id, randomObject.Next(1, 7));
				node.Leaf = string.Format("HIERARCHY{0} - LEVEL{1}", id, randomObject.Next(1, 7));
				dictionary.Add(id, node);
			}
		}

		private int GetRandomTreeId()
		{
			return randomObject.Next(1, 15);
		}

		private class Hierarchy
		{
			public string Root { get; set; }
			public string Subtree { get; set; }
			public string Leaf { get; set; }
		}

		#endregion


		#endregion

		private Guid GetTestEntity(string entityName, string nodeId)
		{			
			using (SqlConnection sqlConnection = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
			{
				sqlConnection.Open();

				//Build the SQL for the current request
				SqlCommand cmd = new SqlCommand();
				cmd.Connection = sqlConnection;				
				cmd.CommandText = string.Concat("SELECT top 1 * FROM ", entityName, " WHERE State=0 AND ", HIERARCHICAL_ATTRIBUTE, "='", nodeId, "'" );

				SqlDataReader reader = cmd.ExecuteReader();
				DataTable table = new DataTable();
				table.Load(reader);

				if (table.Rows.Count <= 0)
				{
					throw new EntityNotFoundException("No rows found for entity: " + cmd.CommandText, entityName);
				}
				else
				{
					return new Guid(table.Rows[0][Id].ToString());
				}
			}
		}
	}

	[TestClass]
	public class RollupFieldCalculateNowCustomAccountUnitTest : UnitTestBase
	{
		#region Rollup field CalculateNow

		private string _entityLogicalName = "new_customaccount";
		//private string _primaryNameAttribute = "new_name";
		private string _primaryKeyAttribute = "new_customaccountid";
		//private string _parentingAttribute = "new_parentid";

		private String[] listRollupAttributes;
		private Random randomObject = new Random();

		[TestInitialize]
		public override void Initialize()
		{
			//Rollup DB Populator generates the record in the custom entity tables which are mapped to "System Administrator" role. 
			//Hence setting the UserRole as "System Administrator" and user(DomainName) to "administrator".
			TestContext.Properties["UserRole"] = "System Administrator";
			TestContext.Properties["DomainName"] = "administrator";			
			base.Initialize();
			listRollupAttributes = new[] { "new_actualrevenue", "new_estimatedrevenue", "new_opportunitycount" };
		}

		/// <summary>
		/// Test Rollup field CalculateNow
		/// </summary>
		[TestMethod()]
		public void UnitTest__RollupFieldCustomAccountCalculateNow()
		{
			Entity customaccount = new Entity(_entityLogicalName);
			string primaryNameAttribute = "new_name";

			System.Collections.Hashtable filter = new System.Collections.Hashtable()
				{
					{ primaryNameAttribute, "customaccountName"}
				};
			//Retrieve entity Id from EMDB
			CRMEntity m_customaccount = null;
			try
			{
				m_customaccount = RetrieveTestEntity(m_user, EntityNames.New_CustomAccount, filter);
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__RollupFieldCustomAccountCalculateNow: Could not find any customaccount to hit calculatenow on. exiting.");
			}

			if (m_customaccount == null) return;

			customaccount.Id = new Guid(m_customaccount[_primaryKeyAttribute]);

			//Retrieve Rollup field name
			string attributeName = RetrieveRollupFieldName();

			OrganizationRequest request = new OrganizationRequest();
			request.RequestName = "CalculateRollupField";
			request.Parameters.Add("FieldName", attributeName);
			request.Parameters.Add("Target", customaccount.ToEntityReference());

			TestContext.BeginTimer("RollupFieldCustomAccountCalculateNowUnitTest");
			try
			{
				OrganizationResponse response = Proxy.Execute(request);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RollupFieldCustomAccountCalculateNowUnitTest");
		}

		#endregion

		/// <summary>
		/// Retrieved Rollup field name
		/// </summary>
		/// <returns></returns>
		private string RetrieveRollupFieldName()
		{
			int random = randomObject.Next(0, 2);
			return listRollupAttributes[random];
		}
	}
}