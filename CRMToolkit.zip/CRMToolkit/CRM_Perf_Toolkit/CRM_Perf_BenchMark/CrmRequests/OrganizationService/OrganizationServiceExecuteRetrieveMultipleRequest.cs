﻿namespace CRM_Perf_BenchMark.CrmRequests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	
	class OrganizationServiceExecuteRetrieveMultipleRequest : OrganizationServiceExecuteRequest
	{
		public OrganizationServiceExecuteRetrieveMultipleRequest(CRMEntity user, string keyValuePairsTemplateName, Dictionary<string, string> templateParameters = null)
			: base(user, "\\CrmRequests\\OrganizationService\\RequestTemplates\\Execute_RetrieveMultiple", templateParameters)
		{
			this.TemplateParameters.Add( "KEY_VALUE_PAIRS", String.Format("###{0}###", keyValuePairsTemplateName));

			this.RefreshBody();
		}
	}
}
